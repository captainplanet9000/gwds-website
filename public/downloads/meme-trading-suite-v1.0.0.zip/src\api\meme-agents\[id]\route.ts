export const dynamic = 'force-dynamic';
import { NextRequest, NextResponse } from 'next/server';
import * as db from '@/lib/meme-agents-db';

export async function GET(request: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  try {
    const { id } = await params;
    const agent = db.getAgent(id);
    if (!agent) return NextResponse.json({ error: 'Not found' }, { status: 404 });
    const positions = db.getAgentPositions(id);
    const trades = db.getAgentTrades(id, 20);
    const thoughts = db.getAgentThoughts(id, 30);
    const config = db.getAgentConfig(id);
    return NextResponse.json({ agent, positions, trades, thoughts, config });
  } catch (e: any) {
    return NextResponse.json({ error: e.message }, { status: 500 });
  }
}

export async function PUT(request: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  try {
    const { id } = await params;
    const body = await request.json();
    const agent = db.updateAgent(id, body);
    if (!agent) return NextResponse.json({ error: 'Not found' }, { status: 404 });
    return NextResponse.json({ agent });
  } catch (e: any) {
    return NextResponse.json({ error: e.message }, { status: 500 });
  }
}

export async function PATCH(request: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  try {
    const { id } = await params;
    const body = await request.json();
    // Handle execution_mode specifically
    if (body.execution_mode) {
      const { setExecutionMode } = await import('@/lib/meme-agents-db');
      setExecutionMode(id, body.execution_mode);
    }
    // Reset circuit breaker when reactivating an agent
    if (body.status === 'active') {
      const { resetCircuitBreaker } = await import('@/lib/meme-agent-engine');
      resetCircuitBreaker(id);
    }
    const agent = db.updateAgent(id, body);
    if (!agent) return NextResponse.json({ error: 'Not found' }, { status: 404 });
    return NextResponse.json({ agent });
  } catch (e: any) {
    return NextResponse.json({ error: e.message }, { status: 500 });
  }
}

export async function DELETE(request: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  try {
    const { id } = await params;
    db.deleteAgent(id);
    return NextResponse.json({ success: true });
  } catch (e: any) {
    return NextResponse.json({ error: e.message }, { status: 500 });
  }
}
