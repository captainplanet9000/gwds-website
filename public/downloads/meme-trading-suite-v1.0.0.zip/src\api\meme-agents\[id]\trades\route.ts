export const dynamic = 'force-dynamic';
import { NextRequest, NextResponse } from 'next/server';
import * as db from '@/lib/meme-agents-db';

export async function GET(request: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  try {
    const { id } = await params;
    const url = new URL(request.url);
    const limit = parseInt(url.searchParams.get('limit') || '50');
    const trades = db.getAgentTrades(id, limit);
    return NextResponse.json({ trades });
  } catch (e: any) {
    return NextResponse.json({ error: e.message }, { status: 500 });
  }
}
