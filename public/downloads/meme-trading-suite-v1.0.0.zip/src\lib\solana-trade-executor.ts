// Solana Trade Executor — Real Jupiter swap execution
import { Connection, Keypair, VersionedTransaction, LAMPORTS_PER_SOL } from '@solana/web3.js';
import { getConnection, keypairFromEncrypted, getBalance } from './solana-wallet-manager';

export const SOL_MINT = 'So11111111111111111111111111111111111111112';
const JUPITER_QUOTE = 'https://public.jupiterapi.com/quote';
const JUPITER_SWAP = 'https://public.jupiterapi.com/swap';
const JUPITER_PRICE = 'https://api.jup.ag/price/v2';

const MAX_RETRIES = 3;
const CONFIRM_TIMEOUT_MS = 60000;

export interface SwapResult {
  success: boolean;
  txHash?: string;
  inputAmount?: number;
  outputAmount?: number;
  error?: string;
}

export interface JupiterQuote {
  inputMint: string;
  inAmount: string;
  outputMint: string;
  outAmount: string;
  otherAmountThreshold: string;
  swapMode: string;
  slippageBps: number;
  routePlan: any[];
  [key: string]: any;
}

export async function getQuote(
  inputMint: string,
  outputMint: string,
  amountLamports: number,
  slippageBps: number = 100
): Promise<JupiterQuote> {
  const params = new URLSearchParams({
    inputMint,
    outputMint,
    amount: String(amountLamports),
    slippageBps: String(slippageBps),
  });

  const res = await fetch(`${JUPITER_QUOTE}?${params}`);
  if (!res.ok) {
    const text = await res.text();
    throw new Error(`Jupiter quote failed (${res.status}): ${text}`);
  }
  return res.json();
}

export async function executeSwap(
  encryptedKey: string,
  quote: JupiterQuote,
  priorityFee?: number
): Promise<SwapResult> {
  const conn = getConnection();
  const keypair = keypairFromEncrypted(encryptedKey);

  // Check balance
  const balance = await conn.getBalance(keypair.publicKey);
  if (quote.inputMint === SOL_MINT) {
    const needed = parseInt(quote.inAmount) + (priorityFee || 5000);
    if (balance < needed) {
      return { success: false, error: `Insufficient SOL: have ${balance / LAMPORTS_PER_SOL}, need ${needed / LAMPORTS_PER_SOL}` };
    }
  }

  let lastError = '';
  for (let attempt = 1; attempt <= MAX_RETRIES; attempt++) {
    try {
      // Get swap transaction
      const swapBody: any = {
        quoteResponse: quote,
        userPublicKey: keypair.publicKey.toBase58(),
        wrapAndUnwrapSol: true,
        dynamicComputeUnitLimit: true,
      };
      if (priorityFee) {
        swapBody.prioritizationFeeLamports = priorityFee;
      }

      const swapRes = await fetch(JUPITER_SWAP, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(swapBody),
      });

      if (!swapRes.ok) {
        const text = await swapRes.text();
        throw new Error(`Jupiter swap API failed (${swapRes.status}): ${text}`);
      }

      const { swapTransaction } = await swapRes.json();
      if (!swapTransaction) throw new Error('No swap transaction returned');

      // Deserialize and sign
      const txBuf = Buffer.from(swapTransaction, 'base64');
      const tx = VersionedTransaction.deserialize(txBuf);

      // Simulate first
      const simResult = await conn.simulateTransaction(tx, { sigVerify: false });
      if (simResult.value.err) {
        throw new Error(`Simulation failed: ${JSON.stringify(simResult.value.err)}`);
      }

      // Sign
      tx.sign([keypair]);

      // Send
      const rawTx = tx.serialize();
      const txHash = await conn.sendRawTransaction(rawTx, {
        skipPreflight: true,
        maxRetries: 2,
      });

      // Confirm with timeout
      const startTime = Date.now();
      let confirmed = false;
      while (Date.now() - startTime < CONFIRM_TIMEOUT_MS) {
        const status = await conn.getSignatureStatus(txHash);
        if (status.value?.confirmationStatus === 'confirmed' || status.value?.confirmationStatus === 'finalized') {
          if (!status.value.err) {
            confirmed = true;
            break;
          } else {
            throw new Error(`Transaction failed on-chain: ${JSON.stringify(status.value.err)}`);
          }
        }
        await sleep(2000);
      }

      if (!confirmed) {
        // Check one more time
        const finalStatus = await conn.getSignatureStatus(txHash);
        if (finalStatus.value?.confirmationStatus && !finalStatus.value.err) {
          confirmed = true;
        }
      }

      if (confirmed) {
        return {
          success: true,
          txHash,
          inputAmount: parseInt(quote.inAmount),
          outputAmount: parseInt(quote.outAmount),
        };
      } else {
        throw new Error('Transaction confirmation timeout');
      }
    } catch (err: any) {
      lastError = err.message;
      console.error(`[trade-executor] Attempt ${attempt}/${MAX_RETRIES} failed: ${err.message}`);
      if (attempt < MAX_RETRIES) {
        await sleep(1000 * attempt); // Backoff
      }
    }
  }

  return { success: false, error: `Failed after ${MAX_RETRIES} attempts: ${lastError}` };
}

export async function buyToken(
  encryptedKey: string,
  tokenMint: string,
  solAmount: number,
  slippageBps: number = 100,
  priorityFee?: number
): Promise<SwapResult> {
  try {
    const lamports = Math.round(solAmount * LAMPORTS_PER_SOL);
    const quote = await getQuote(SOL_MINT, tokenMint, lamports, slippageBps);
    return await executeSwap(encryptedKey, quote, priorityFee);
  } catch (err: any) {
    return { success: false, error: `buyToken failed: ${err.message}` };
  }
}

export async function sellToken(
  encryptedKey: string,
  tokenMint: string,
  tokenAmount: number,
  slippageBps: number = 150,
  priorityFee?: number
): Promise<SwapResult> {
  try {
    // tokenAmount should be in raw (smallest unit) — caller must handle decimals
    const quote = await getQuote(tokenMint, SOL_MINT, Math.round(tokenAmount), slippageBps);
    return await executeSwap(encryptedKey, quote, priorityFee);
  } catch (err: any) {
    return { success: false, error: `sellToken failed: ${err.message}` };
  }
}

export async function getTokenPrice(tokenMint: string): Promise<number | null> {
  try {
    const res = await fetch(`${JUPITER_PRICE}?ids=${tokenMint}`);
    if (!res.ok) return null;
    const data = await res.json();
    return data.data?.[tokenMint]?.price ?? null;
  } catch {
    return null;
  }
}

function sleep(ms: number): Promise<void> {
  return new Promise(resolve => setTimeout(resolve, ms));
}
