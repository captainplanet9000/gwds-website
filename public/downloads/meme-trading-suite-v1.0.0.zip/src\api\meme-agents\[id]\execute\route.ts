import { NextResponse } from 'next/server';
import { getAgent, getAgentWallet, createTrade as dbCreateTrade, getAgentPositions, updatePosition, createPosition } from '@/lib/meme-agents-db';
import { buyToken, sellToken, getTokenPrice } from '@/lib/solana-trade-executor';
import { getBalance } from '@/lib/solana-wallet-manager';
import { sendNotification, NotificationChannel } from '@/lib/notifications';

const MAX_POSITION_SOL = 50; // Hard cap per trade

// POST — execute a real swap
export async function POST(req: Request, { params }: { params: { id: string } }) {
  try {
    const body = await req.json();
    const { tokenMint, side, amount, slippageBps } = body;

    if (!tokenMint || !side || !amount) {
      return NextResponse.json({ error: 'tokenMint, side, amount required' }, { status: 400 });
    }
    if (!['buy', 'sell'].includes(side)) {
      return NextResponse.json({ error: 'side must be "buy" or "sell"' }, { status: 400 });
    }

    const agent = getAgent(params.id);
    if (!agent) return NextResponse.json({ error: 'Agent not found' }, { status: 404 });

    const wallet = getAgentWallet(params.id);
    if (!wallet) return NextResponse.json({ error: 'No wallet assigned' }, { status: 404 });
    if (wallet.executionMode !== 'live') {
      return NextResponse.json({ error: 'Agent not in live mode' }, { status: 400 });
    }

    // Safety: position size limit
    if (side === 'buy' && amount > MAX_POSITION_SOL) {
      return NextResponse.json({ error: `Amount exceeds max position size of ${MAX_POSITION_SOL} SOL` }, { status: 400 });
    }

    // Check balance
    const balance = await getBalance(wallet.publicKey);
    if (side === 'buy' && balance < amount + 0.01) {
      return NextResponse.json({ error: `Insufficient balance: ${balance.toFixed(4)} SOL` }, { status: 400 });
    }

    // Execute
    let result;
    if (side === 'buy') {
      result = await buyToken(wallet.encryptedKey, tokenMint, amount, slippageBps || 100);
    } else {
      result = await sellToken(wallet.encryptedKey, tokenMint, amount, slippageBps || 150);
    }

    // Record trade in DB — try Jupiter price, fallback to DexScreener
    let price = await getTokenPrice(tokenMint);
    let tokenSymbol = tokenMint.slice(0, 6);
    let tokenName = '';
    // Try to get symbol from existing position first
    try {
      const existingPos = getAgentPositions(params.id).find(p => p.token_address === tokenMint);
      if (existingPos) { tokenSymbol = existingPos.symbol || tokenSymbol; tokenName = existingPos.name || ''; }
    } catch {}
    if (!price) {
      try {
        const dexRes = await fetch(`https://api.dexscreener.com/latest/dex/tokens/${tokenMint}`);
        if (dexRes.ok) {
          const dexData = await dexRes.json();
          const pair = dexData.pairs?.[0];
          if (pair) {
            price = parseFloat(pair.priceUsd || '0') || null;
            tokenSymbol = pair.baseToken?.symbol || tokenSymbol;
            tokenName = pair.baseToken?.name || '';
          }
        }
      } catch {}
    }
    // Estimate price from SOL amount if all else fails
    if (!price && result.outputAmount && result.outputAmount > 0) {
      try {
        const solRes = await fetch('https://api.jup.ag/price/v2?ids=So11111111111111111111111111111111111111112');
        const solData = await solRes.json();
        const solPrice = solData.data?.['So11111111111111111111111111111111111111112']?.price;
        if (solPrice) {
          price = (amount * parseFloat(solPrice)) / result.outputAmount;
        }
      } catch {}
    }
    try {
      dbCreateTrade({
        agent_id: params.id,
        token_address: tokenMint,
        chain_id: 'solana',
        symbol: tokenSymbol,
        name: tokenName,
        side,
        amount_usd: amount * (price || 0),
        price: price || 0,
        quantity: result.outputAmount || 0,
        pnl: 0,
        pnl_pct: 0,
        entry_reason: `Manual ${side} via API`,
        exit_reason: '',
        security_score: '',
        tx_hash: result.txHash || '',
      });
    } catch {}

    // Update or create position
    if (result.success) {
      try {
        const positions = getAgentPositions(params.id);
        const existing = positions.find(p => p.token_address === tokenMint);
        const newQty = result.outputAmount || 0;
        const newAmountUsd = amount * (price || 0);

        if (side === 'buy') {
          if (existing) {
            // Average up: weighted average entry price
            const oldTotal = existing.quantity * existing.entry_price;
            const newTotal = newQty * (price || 0);
            const combinedQty = existing.quantity + newQty;
            const avgPrice = combinedQty > 0 ? (oldTotal + newTotal) / combinedQty : existing.entry_price;
            updatePosition(existing.id, {
              quantity: combinedQty,
              entry_price: avgPrice,
              amount_usd: (existing.amount_usd || 0) + newAmountUsd,
              current_price: price || existing.current_price,
            });
          } else {
            createPosition({
              agent_id: params.id,
              token_address: tokenMint,
              chain_id: 'solana',
              symbol: tokenSymbol,
              name: tokenName,
              entry_price: price || 0,
              current_price: price || 0,
              quantity: newQty,
              amount_usd: newAmountUsd,
              unrealized_pnl: 0,
              unrealized_pnl_pct: 0,
              stop_loss: null,
              take_profit: null,
            });
          }
        } else if (side === 'sell' && existing) {
          const remainingQty = existing.quantity - newQty;
          if (remainingQty <= 0) {
            // Position fully closed — remove it
            const { deletePosition } = await import('@/lib/meme-agents-db');
            deletePosition(existing.id);
          } else {
            updatePosition(existing.id, {
              quantity: remainingQty,
              amount_usd: (existing.amount_usd || 0) - newAmountUsd,
              current_price: price || existing.current_price,
            });
          }
        }
      } catch (posErr: any) {
        console.error('Position update failed:', posErr.message);
      }
    }

    // Send notification
    const displaySymbol = tokenSymbol || tokenMint.slice(0, 6);
    const displayAmount = side === 'buy' ? `${amount} SOL` : `${amount.toLocaleString()} ${displaySymbol}`;
    if (result.success) {
      sendNotification({ title: `🟢 MANUAL ${side.toUpperCase()}: ${displaySymbol}`, message: `Agent ${agent.name} — manual ${side} ${displaySymbol} — ${displayAmount} — tx: ${result.txHash?.slice(0,8)}...`, type: 'trade', channels: [NotificationChannel.LOG, NotificationChannel.TELEGRAM_PREP] });
    } else {
      sendNotification({ title: `❌ MANUAL ${side.toUpperCase()} FAILED: ${displaySymbol}`, message: `Agent ${agent.name} — manual ${side} ${displaySymbol} failed: ${result.error}`, type: 'alert', channels: [NotificationChannel.LOG, NotificationChannel.TELEGRAM_PREP] });
    }

    // Never expose keys
    return NextResponse.json({
      success: result.success,
      txHash: result.txHash,
      inputAmount: result.inputAmount,
      outputAmount: result.outputAmount,
      error: result.error,
      solscanUrl: result.txHash ? `https://solscan.io/tx/${result.txHash}` : undefined,
    });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}
