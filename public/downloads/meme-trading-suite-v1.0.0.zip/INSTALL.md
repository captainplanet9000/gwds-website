# Meme Trading Suite — Installation Guide

## Step 1: Prerequisites

Make sure you have:
- [ ] AI Trading Dashboard v9.0+ running locally or on Vercel
- [ ] Supabase project with service role key
- [ ] Solana RPC endpoint (Helius recommended — free tier works)
- [ ] A funded Solana wallet for trade execution
- [ ] Node.js 18+ and npm

## Step 2: Install npm Dependencies

From your dashboard root:

```bash
npm install @solana/web3.js @solana/spl-token bs58
```

## Step 3: Copy Plugin Files

### On macOS/Linux:
```bash
# From your dashboard root, with the plugin extracted nearby:
cp -r meme-trading-suite/src/pages/meme-coins/ src/app/dashboard/meme-coins/
cp -r meme-trading-suite/src/api/meme-agents/ src/app/api/meme-agents/
cp -r meme-trading-suite/src/api/dexscreener/ src/app/api/dexscreener/
cp meme-trading-suite/src/lib/meme-*.ts src/lib/
cp meme-trading-suite/src/lib/solana-*.ts src/lib/
cp -r meme-trading-suite/src/lib/services/ src/lib/services/
```

### On Windows (PowerShell):
```powershell
Copy-Item -Recurse meme-trading-suite\src\pages\meme-coins\ src\app\dashboard\meme-coins\
Copy-Item -Recurse meme-trading-suite\src\api\meme-agents\ src\app\api\meme-agents\
Copy-Item -Recurse meme-trading-suite\src\api\dexscreener\ src\app\api\dexscreener\
Copy-Item meme-trading-suite\src\lib\meme-*.ts src\lib\
Copy-Item meme-trading-suite\src\lib\solana-*.ts src\lib\
Copy-Item -Recurse meme-trading-suite\src\lib\services\ src\lib\services\
```

## Step 4: Environment Variables

Add these to your `.env.local` file:

```env
# === REQUIRED ===

# Supabase
SUPABASE_URL=https://your-project.supabase.co
SUPABASE_SERVICE_ROLE_KEY=eyJhbGci...your-service-role-key
NEXT_PUBLIC_SUPABASE_URL=https://your-project.supabase.co
NEXT_PUBLIC_SUPABASE_ANON_KEY=eyJhbGci...your-anon-key

# Solana
SOLANA_RPC_URL=https://mainnet.helius-rpc.com/?api-key=YOUR_HELIUS_KEY
SOLANA_PRIVATE_KEY=your-base58-encoded-private-key

# Encryption (generate with: openssl rand -hex 32)
ENCRYPTION_KEY=your-64-character-hex-string

# === OPTIONAL ===

# DexScreener (higher rate limits)
DEXSCREENER_API_KEY=your-key

# Helius (enhanced Solana RPC)
HELIUS_API_KEY=your-key
```

## Step 5: Create Supabase Tables

Run this SQL in your Supabase SQL Editor:

```sql
-- Meme Agents
CREATE TABLE IF NOT EXISTS meme_agents (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL,
  strategy TEXT NOT NULL DEFAULT 'momentum',
  status TEXT NOT NULL DEFAULT 'idle',
  config JSONB DEFAULT '{}',
  wallet_address TEXT,
  balance NUMERIC DEFAULT 0,
  total_pnl NUMERIC DEFAULT 0,
  total_trades INTEGER DEFAULT 0,
  win_rate NUMERIC DEFAULT 0,
  last_cycle_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Meme Agent Trades
CREATE TABLE IF NOT EXISTS meme_agent_trades (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  agent_id UUID REFERENCES meme_agents(id) ON DELETE CASCADE,
  token_address TEXT NOT NULL,
  token_symbol TEXT,
  token_name TEXT,
  side TEXT NOT NULL, -- 'buy' or 'sell'
  amount NUMERIC NOT NULL,
  price NUMERIC NOT NULL,
  value_usd NUMERIC,
  tx_hash TEXT,
  status TEXT DEFAULT 'pending',
  pnl NUMERIC,
  pnl_percent NUMERIC,
  signal_score NUMERIC,
  strategy TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Meme Agent Thoughts
CREATE TABLE IF NOT EXISTS meme_agent_thoughts (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  agent_id UUID REFERENCES meme_agents(id) ON DELETE CASCADE,
  thought TEXT NOT NULL,
  type TEXT DEFAULT 'analysis', -- 'analysis', 'decision', 'error', 'info'
  metadata JSONB DEFAULT '{}',
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Meme Agent Positions
CREATE TABLE IF NOT EXISTS meme_agent_positions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  agent_id UUID REFERENCES meme_agents(id) ON DELETE CASCADE,
  token_address TEXT NOT NULL,
  token_symbol TEXT,
  token_name TEXT,
  amount NUMERIC NOT NULL,
  entry_price NUMERIC NOT NULL,
  current_price NUMERIC,
  unrealized_pnl NUMERIC,
  unrealized_pnl_percent NUMERIC,
  status TEXT DEFAULT 'open',
  opened_at TIMESTAMPTZ DEFAULT NOW(),
  closed_at TIMESTAMPTZ
);

-- Meme Watchlist
CREATE TABLE IF NOT EXISTS meme_watchlist (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  token_address TEXT NOT NULL UNIQUE,
  token_symbol TEXT,
  token_name TEXT,
  chain TEXT DEFAULT 'solana',
  added_price NUMERIC,
  alert_above NUMERIC,
  alert_below NUMERIC,
  notes TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Meme Alerts
CREATE TABLE IF NOT EXISTS meme_alerts (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  token_address TEXT NOT NULL,
  token_symbol TEXT,
  alert_type TEXT NOT NULL, -- 'price_above', 'price_below', 'volume_spike', 'market_cap'
  threshold NUMERIC NOT NULL,
  triggered BOOLEAN DEFAULT FALSE,
  triggered_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Meme Wallets (encrypted)
CREATE TABLE IF NOT EXISTS meme_wallets (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL,
  address TEXT NOT NULL,
  encrypted_key TEXT, -- AES-256 encrypted private key
  balance_sol NUMERIC DEFAULT 0,
  balance_usd NUMERIC DEFAULT 0,
  is_primary BOOLEAN DEFAULT FALSE,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Smart Money Wallets
CREATE TABLE IF NOT EXISTS smart_money_wallets (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  address TEXT NOT NULL UNIQUE,
  label TEXT,
  tags TEXT[] DEFAULT '{}',
  total_pnl NUMERIC DEFAULT 0,
  win_rate NUMERIC DEFAULT 0,
  tracked_since TIMESTAMPTZ DEFAULT NOW(),
  last_activity TIMESTAMPTZ,
  notes TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Indexes
CREATE INDEX IF NOT EXISTS idx_meme_trades_agent ON meme_agent_trades(agent_id);
CREATE INDEX IF NOT EXISTS idx_meme_trades_token ON meme_agent_trades(token_address);
CREATE INDEX IF NOT EXISTS idx_meme_thoughts_agent ON meme_agent_thoughts(agent_id);
CREATE INDEX IF NOT EXISTS idx_meme_positions_agent ON meme_agent_positions(agent_id);
CREATE INDEX IF NOT EXISTS idx_meme_positions_status ON meme_agent_positions(status);
CREATE INDEX IF NOT EXISTS idx_smart_money_address ON smart_money_wallets(address);
```

## Step 6: Add Navigation Link

In your dashboard's sidebar/navigation component, add:

```tsx
{
  name: "Meme Coins",
  href: "/dashboard/meme-coins",
  icon: "🚀"  // or use a Lucide icon like Rocket
}
```

## Step 7: Restart and Verify

```bash
npm run dev
```

Visit `http://localhost:YOUR_PORT/dashboard/meme-coins`

You should see the 9-tab interface. The Scanner tab will immediately start pulling data from DexScreener.

## Troubleshooting

**"Module not found" errors:**
- Make sure `@solana/web3.js`, `@solana/spl-token`, and `bs58` are installed
- Check that all lib files are in `src/lib/` (not nested in a subdirectory)

**Scanner shows no data:**
- DexScreener's public API has rate limits. If you hit them, add a `DEXSCREENER_API_KEY`

**Wallet errors:**
- Generate an `ENCRYPTION_KEY`: `openssl rand -hex 32`
- Make sure `SOLANA_PRIVATE_KEY` is base58-encoded (not hex or array)

**Agent won't execute trades:**
- Check that `SOLANA_RPC_URL` points to mainnet (not devnet)
- Ensure the wallet has SOL for gas fees
- Check the agent's thought log for error details
