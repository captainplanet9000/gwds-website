export const dynamic = 'force-dynamic';
import { NextRequest, NextResponse } from 'next/server';
import * as db from '@/lib/meme-agents-db';

export async function GET(request: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  try {
    const { id } = await params;
    const positions = db.getAgentPositions(id);
    return NextResponse.json({ positions });
  } catch (e: any) {
    return NextResponse.json({ error: e.message }, { status: 500 });
  }
}

// PATCH: update position (e.g. toggle hold_mode)
export async function PATCH(request: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  try {
    const body = await request.json();
    const { positionId, hold_mode, quantity, amount_usd, current_price, unrealized_pnl, unrealized_pnl_pct } = body;
    if (!positionId) return NextResponse.json({ error: 'positionId required' }, { status: 400 });
    
    const updates: any = {};
    if (hold_mode !== undefined) updates.hold_mode = hold_mode ? 1 : 0;
    if (quantity !== undefined) updates.quantity = quantity;
    if (amount_usd !== undefined) updates.amount_usd = amount_usd;
    if (current_price !== undefined) updates.current_price = current_price;
    if (unrealized_pnl !== undefined) updates.unrealized_pnl = unrealized_pnl;
    if (unrealized_pnl_pct !== undefined) updates.unrealized_pnl_pct = unrealized_pnl_pct;
    
    db.updatePosition(positionId, updates);
    return NextResponse.json({ ok: true, positionId, updated: Object.keys(updates) });
  } catch (e: any) {
    return NextResponse.json({ error: e.message }, { status: 500 });
  }
}

// DELETE: remove a position by id
export async function DELETE(request: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  try {
    const body = await request.json();
    const { positionId } = body;
    if (!positionId) return NextResponse.json({ error: 'positionId required' }, { status: 400 });
    db.deletePosition(positionId);
    return NextResponse.json({ ok: true, deleted: positionId });
  } catch (e: any) {
    return NextResponse.json({ error: e.message }, { status: 500 });
  }
}
