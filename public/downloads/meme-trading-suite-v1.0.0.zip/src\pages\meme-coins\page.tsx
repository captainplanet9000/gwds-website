'use client'

import React, { useState, useEffect, useCallback, useMemo, useRef } from 'react'
import { s, colors, pctColor, AGENT_STATUS_COLORS, AGENT_STRATEGIES, getAgentStrategyInfo } from '@/lib/meme-coins-styles'

// ── Types ──────────────────────────────────────────────────────────────────
interface TokenPair {
  chainId: string
  pairAddress: string
  baseToken: { address: string; name: string; symbol: string }
  quoteToken: { address: string; name: string; symbol: string }
  priceUsd: string
  priceNative: string
  txns: { h24: { buys: number; sells: number }; h1: { buys: number; sells: number }; m5?: { buys: number; sells: number } }
  volume: { h24: number; h6: number; h1: number; m5: number }
  priceChange: { m5: number; h1: number; h6: number; h24: number }
  liquidity: { usd: number }
  fdv: number
  marketCap: number
  pairCreatedAt: number
  boostAmount?: number
  boostIcon?: string
  info?: { imageUrl?: string; websites?: { label: string; url: string }[]; socials?: { type: string; url: string }[] }
  url?: string
}

interface WatchlistItem {
  chainId: string; tokenAddress: string; name: string; symbol: string
  notes: string; allocatedAmount: number; entryPrice: number; addedAt: string
}

interface TradeRecord {
  id: string; tokenAddress: string; chainId: string; symbol: string
  side: string; amount: number; price: number; txHash: string; timestamp: string
}

interface Settings {
  maxPerToken: number; totalBudget: number; chains: string[]
  scanInterval: number; minLiquidity: number; minVolume: number; maxAgeDays: number
}

interface PriceAlert {
  id: string; tokenAddress: string; chainId: string; symbol: string
  targetPrice: number; direction: 'above' | 'below'; active: boolean
  createdAt: string; triggeredAt?: string
}

interface SmartMoneyWallet {
  address: string; label: string; pnl: number; winRate: number
  totalTrades: number; lastActive: string; recentTokens: string[]
}

interface MemeAgent {
  id: string; name: string; strategy: string; status: string
  allocated_budget: number; current_balance: number; total_pnl: number
  total_trades: number; win_rate: number; risk_tolerance: string
  preferred_chains: string[]; execution_mode: 'live' | 'simulation'
  wallet_public_key?: string; openPositionCount?: number
  updated_at: string; created_at?: string
}

interface MemeAgentThought {
  id: string; agent_id: string; agent_name?: string; thought_type: string
  content: string; confidence?: number; created_at: string
}

interface MemeAgentTrade {
  id: string; agent_id: string; agent_name?: string; token_address: string
  token_symbol: string; side: string; amount: number; price: number
  pnl?: number; reason?: string; created_at: string
}

interface SecurityResult {
  tokenAddress: string; chainId: string
  goplus?: { isHoneypot: boolean; isOpenSource: boolean; buyTax: string; sellTax: string; holderCount: number; ownerPercent: string }
  rugcheck?: { score: number; risks: string[] }
  loading: boolean
}

// ── Helpers ────────────────────────────────────────────────────────────────
const fmt = (n: number, dec = 2) => n?.toLocaleString(undefined, { minimumFractionDigits: dec, maximumFractionDigits: dec }) ?? '0.00'
const fmtUSD = (n: number) => '$' + fmt(n)
const fmtCompact = (n: number) => {
  if (n >= 1e9) return '$' + (n / 1e9).toFixed(2) + 'B'
  if (n >= 1e6) return '$' + (n / 1e6).toFixed(2) + 'M'
  if (n >= 1e3) return '$' + (n / 1e3).toFixed(1) + 'K'
  return '$' + n.toFixed(2)
}
const fmtPrice = (p: string | number) => {
  const n = typeof p === 'string' ? parseFloat(p) : p
  if (n >= 1) return '$' + n.toFixed(2)
  if (n >= 0.01) return '$' + n.toFixed(4)
  if (n >= 0.0001) return '$' + n.toFixed(6)
  return '$' + n.toFixed(10)
}
const ageStr = (ts: number) => {
  if (!ts) return '—'
  const h = (Date.now() - ts) / 3600000
  if (h < 1) return Math.round(h * 60) + 'm'
  if (h < 24) return Math.round(h) + 'h'
  if (h < 720) return Math.round(h / 24) + 'd'
  return Math.round(h / 720) + 'mo'
}
const agentTimeAgo = (dateStr: string) => {
  if (!dateStr) return '—'
  const ms = Date.now() - new Date(dateStr).getTime()
  const sec = Math.floor(ms / 1000)
  if (sec < 60) return `${sec}s ago`
  const min = Math.floor(sec / 60)
  if (min < 60) return `${min}m ago`
  const hr = Math.floor(min / 60)
  if (hr < 24) return `${hr}h ago`
  const days = Math.floor(hr / 24)
  return `${days}d ago`
}
const copyToClipboard = (text: string) => { try { navigator.clipboard.writeText(text) } catch { } }

const CHAINS = ['All', 'solana', 'base', 'bsc', 'ethereum', 'arbitrum', 'polygon']
const CHAIN_LABELS: Record<string, string> = { solana: 'SOL', base: 'Base', bsc: 'BSC', ethereum: 'ETH', arbitrum: 'ARB', polygon: 'POLY' }
const TAB_NAMES = ['📡 Scanner', '🆕 New Pairs', '👀 Watchlist', '🔍 Search', '📊 Trades', '🔔 Alerts', '💰 Smart Money', '🤖 Agents', '⚙️ Settings']

const DEFAULT_SETTINGS: Settings = {
  maxPerToken: 50, totalBudget: 500, chains: ['solana', 'base', 'ethereum', 'bsc'],
  scanInterval: 30, minLiquidity: 10000, minVolume: 50000, maxAgeDays: 30
}

const THOUGHT_TYPE_ICONS: Record<string, string> = {
  analysis: '🔍', decision: '🧠', execution: '⚡', observation: '👁️', market_regime: '📊', trade_closed: '💰'
}

export default function MemeCoinsPage() {
  // ── Core State ─────────────────────────────────────────────────────────
  const [tab, setTab] = useState(0)
  const [tokens, setTokens] = useState<TokenPair[]>([])
  const [newPairs, setNewPairs] = useState<TokenPair[]>([])
  const [watchlist, setWatchlist] = useState<WatchlistItem[]>([])
  const [watchlistPrices, setWatchlistPrices] = useState<Map<string, TokenPair>>(new Map())
  const [trades, setTrades] = useState<TradeRecord[]>([])
  const [settings, setSettings] = useState<Settings>(DEFAULT_SETTINGS)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const [chainFilter, setChainFilter] = useState('All')
  const [sortCol, setSortCol] = useState('volume')
  const [sortDir, setSortDir] = useState<'asc' | 'desc'>('desc')
  const [expandedRow, setExpandedRow] = useState<string | null>(null)
  const [searchQuery, setSearchQuery] = useState('')
  const [searchResults, setSearchResults] = useState<TokenPair[]>([])
  const [searchLoading, setSearchLoading] = useState(false)
  const [countdown, setCountdown] = useState(30)
  const [addingToken, setAddingToken] = useState<string | null>(null)

  // ── Alerts State ───────────────────────────────────────────────────────
  const [alerts, setAlerts] = useState<PriceAlert[]>([])
  const [newAlertSymbol, setNewAlertSymbol] = useState('')
  const [newAlertAddress, setNewAlertAddress] = useState('')
  const [newAlertChain, setNewAlertChain] = useState('solana')
  const [newAlertPrice, setNewAlertPrice] = useState('')
  const [newAlertDirection, setNewAlertDirection] = useState<'above' | 'below'>('above')
  const [toastMessage, setToastMessage] = useState<{ text: string; type: 'success' | 'error' | 'info' } | null>(null)

  // ── Smart Money State ──────────────────────────────────────────────────
  const [smartMoneyWallets, setSmartMoneyWallets] = useState<SmartMoneyWallet[]>([])
  const [smartMoneyLoading, setSmartMoneyLoading] = useState(false)

  // ── New Pairs State ────────────────────────────────────────────────────
  const [newPairsLoading, setNewPairsLoading] = useState(false)

  // ── Security State ─────────────────────────────────────────────────────
  const [securityResults, setSecurityResults] = useState<Record<string, SecurityResult>>({})

  // ── Token Detail Modal ─────────────────────────────────────────────────
  const [tokenDetailPair, setTokenDetailPair] = useState<TokenPair | null>(null)
  const [showChart, setShowChart] = useState(false)

  // ── Agent State ────────────────────────────────────────────────────────
  const [memeAgents, setMemeAgents] = useState<MemeAgent[]>([])
  const [memeAgentsLoading, setMemeAgentsLoading] = useState(false)
  const [showCreateAgent, setShowCreateAgent] = useState(false)
  const [memeAgentCycleLoading, setMemeAgentCycleLoading] = useState<Record<string, boolean>>({})
  const [expandedAgentWallet, setExpandedAgentWallet] = useState<string | null>(null)
  const [showQR, setShowQR] = useState<Record<string, boolean>>({})
  const [agentWalletBalances, setAgentWalletBalances] = useState<Record<string, { sol: number; tokens: any[] }>>({})
  const [walletActionLoading, setWalletActionLoading] = useState<Record<string, boolean>>({})
  const [walletFundAmount, setWalletFundAmount] = useState('')
  const [walletWithdrawAddr, setWalletWithdrawAddr] = useState('')
  const [walletWithdrawAmount, setWalletWithdrawAmount] = useState('')
  const [solUsdPrice, setSolUsdPrice] = useState(0)
  const [schedulerStatus, setSchedulerStatus] = useState<any>(null)
  const [schedulerLoading, setSchedulerLoading] = useState(false)
  const [schedulerInterval, setSchedulerInterval] = useState(300000)
  const [monitorStatus, setMonitorStatus] = useState<any>(null)
  const [monitorLoading, setMonitorLoading] = useState(false)
  const [memeAgentThoughts, setMemeAgentThoughts] = useState<MemeAgentThought[]>([])
  const [memeAgentTrades, setMemeAgentTrades] = useState<MemeAgentTrade[]>([])
  const [agentDetailData, setAgentDetailData] = useState<any>(null)
  const [agentDetailLoading, setAgentDetailLoading] = useState(false)

  // ── Create Agent Form ──────────────────────────────────────────────────
  const [newAgentName, setNewAgentName] = useState('')
  const [newAgentStrategy, setNewAgentStrategy] = useState('safety_first')
  const [newAgentBudget, setNewAgentBudget] = useState('100')
  const [newAgentRisk, setNewAgentRisk] = useState('medium')
  const [newAgentChains, setNewAgentChains] = useState<string[]>(['solana'])
  const [newAgentMode, setNewAgentMode] = useState<'simulation' | 'live'>('simulation')
  const [createAgentLoading, setCreateAgentLoading] = useState(false)

  // ── Toast ──────────────────────────────────────────────────────────────
  const showToast = useCallback((text: string, type: 'success' | 'error' | 'info' = 'info') => {
    setToastMessage({ text, type })
    setTimeout(() => setToastMessage(null), 4000)
  }, [])

  // Load settings from localStorage
  useEffect(() => {
    try {
      const saved = localStorage.getItem('meme-settings')
      if (saved) setSettings(JSON.parse(saved))
      const savedAlerts = localStorage.getItem('meme-alerts')
      if (savedAlerts) setAlerts(JSON.parse(savedAlerts))
    } catch {}
  }, [])

  const saveSettings = (newS: Settings) => {
    setSettings(newS)
    localStorage.setItem('meme-settings', JSON.stringify(newS))
  }

  // ── Data Fetching ──────────────────────────────────────────────────────
  const fetchTrending = useCallback(async () => {
    try {
      setError(null)
      const r = await fetch('/api/dexscreener?action=trending')
      if (!r.ok) throw new Error('Failed to fetch trending')
      const d = await r.json()
      setTokens(d.pairs || d.tokens || [])
    } catch (e: any) {
      setError(e.message)
    } finally {
      setLoading(false)
      setCountdown(settings.scanInterval)
    }
  }, [settings.scanInterval])

  const fetchNewPairs = useCallback(async () => {
    setNewPairsLoading(true)
    try {
      const r = await fetch('/api/dexscreener/new-pairs')
      if (r.ok) { const d = await r.json(); setNewPairs(d.pairs || d.tokens || []) }
    } catch {} finally { setNewPairsLoading(false) }
  }, [])

  const fetchWatchlist = useCallback(async () => {
    try {
      const r = await fetch('/api/dexscreener/watchlist')
      if (r.ok) { const d = await r.json(); setWatchlist(d.watchlist || []) }
    } catch {}
  }, [])

  const fetchWatchlistPrices = useCallback(async () => {
    if (watchlist.length === 0) return
    const byChain: Record<string, string[]> = {}
    for (const w of watchlist) {
      if (!byChain[w.chainId]) byChain[w.chainId] = []
      byChain[w.chainId].push(w.tokenAddress)
    }
    const priceMap = new Map<string, TokenPair>()
    for (const [chain, addrs] of Object.entries(byChain)) {
      try {
        const r = await fetch(`/api/dexscreener?action=token&chain=${chain}&address=${addrs.join(',')}`)
        if (r.ok) {
          const d = await r.json()
          for (const p of (d.pairs || [])) {
            const key = p.baseToken?.address?.toLowerCase()
            if (key && (!priceMap.has(key) || (priceMap.get(key)!.volume?.h24 || 0) < (p.volume?.h24 || 0))) {
              priceMap.set(key, p)
            }
          }
        }
      } catch {}
    }
    setWatchlistPrices(priceMap)
  }, [watchlist])

  const fetchTrades = useCallback(async () => {
    try {
      const r = await fetch('/api/dexscreener/trades')
      if (r.ok) { const d = await r.json(); setTrades(d.trades || []) }
    } catch {}
  }, [])

  const fetchSmartMoney = useCallback(async () => {
    setSmartMoneyLoading(true)
    try {
      const r = await fetch('/api/dexscreener?action=smartmoney')
      if (r.ok) { const d = await r.json(); setSmartMoneyWallets(d.wallets || []) }
    } catch {} finally { setSmartMoneyLoading(false) }
  }, [])

  const fetchSecurityScan = useCallback(async (tokenAddress: string, chainId: string) => {
    const key = `${chainId}:${tokenAddress}`
    if (securityResults[key] && !securityResults[key].loading) return
    setSecurityResults(prev => ({ ...prev, [key]: { tokenAddress, chainId, loading: true } }))
    try {
      const r = await fetch(`/api/dexscreener?action=security&chain=${chainId}&address=${tokenAddress}`)
      if (r.ok) {
        const d = await r.json()
        setSecurityResults(prev => ({ ...prev, [key]: { tokenAddress, chainId, goplus: d.goplus, rugcheck: d.rugcheck, loading: false } }))
      } else {
        setSecurityResults(prev => ({ ...prev, [key]: { tokenAddress, chainId, loading: false } }))
      }
    } catch {
      setSecurityResults(prev => ({ ...prev, [key]: { tokenAddress, chainId, loading: false } }))
    }
  }, [securityResults])

  // ── Agent Fetching ─────────────────────────────────────────────────────
  const fetchMemeAgents = useCallback(async () => {
    setMemeAgentsLoading(true)
    try {
      const r = await fetch('/api/meme-agents')
      if (r.ok) { const d = await r.json(); setMemeAgents(d.agents || d || []) }
    } catch {} finally { setMemeAgentsLoading(false) }
  }, [])

  const fetchSchedulerStatus = useCallback(async () => {
    try {
      const r = await fetch('/api/meme-agents/scheduler')
      if (r.ok) { const d = await r.json(); setSchedulerStatus(d) }
    } catch {}
  }, [])

  const fetchMonitorStatus = useCallback(async () => {
    try {
      const r = await fetch('/api/meme-agents/monitor')
      if (r.ok) { const d = await r.json(); setMonitorStatus(d) }
    } catch {}
  }, [])

  const fetchAgentThoughts = useCallback(async () => {
    try {
      const allThoughts: any[] = []
      for (const agent of memeAgents) {
        try {
          const r = await fetch(`/api/meme-agents/${agent.id}/thoughts`)
          if (r.ok) { const d = await r.json(); allThoughts.push(...(d.thoughts || d || [])) }
        } catch {}
      }
      allThoughts.sort((a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime())
      setMemeAgentThoughts(allThoughts)
    } catch {}
  }, [memeAgents])

  const fetchAgentTrades = useCallback(async () => {
    try {
      const allTrades: any[] = []
      for (const agent of memeAgents) {
        try {
          const r = await fetch(`/api/meme-agents/${agent.id}/trades`)
          if (r.ok) { const d = await r.json(); allTrades.push(...(d.trades || d || [])) }
        } catch {}
      }
      allTrades.sort((a, b) => new Date(b.created_at || b.timestamp).getTime() - new Date(a.created_at || a.timestamp).getTime())
      setMemeAgentTrades(allTrades)
    } catch {}
  }, [memeAgents])

  const fetchSolPrice = useCallback(async () => {
    try {
      const r = await fetch('/api/dexscreener?action=token&chain=solana&address=So11111111111111111111111111111111111111112')
      if (r.ok) {
        const d = await r.json()
        const pair = (d.pairs || [])[0]
        if (pair) setSolUsdPrice(parseFloat(pair.priceUsd || '0'))
      }
    } catch {}
  }, [])

  const fetchAgentWalletBalance = useCallback(async (agentId: string) => {
    try {
      const r = await fetch(`/api/meme-agents/${agentId}/wallet`)
      if (r.ok) {
        const d = await r.json()
        setAgentWalletBalances(prev => ({ ...prev, [agentId]: { sol: d.solBalance || 0, tokens: d.tokens || [] } }))
      }
    } catch {}
  }, [])

  const fetchAgentDetail = useCallback(async (agentId: string) => {
    setAgentDetailLoading(true)
    try {
      const [agentR, thoughtsR, tradesR, positionsR, walletR] = await Promise.all([
        fetch(`/api/meme-agents/${agentId}`),
        fetch(`/api/meme-agents/${agentId}/thoughts`),
        fetch(`/api/meme-agents/${agentId}/trades`),
        fetch(`/api/meme-agents/${agentId}/positions`),
        fetch(`/api/meme-agents/${agentId}/wallet`),
      ])
      const agent = agentR.ok ? await agentR.json() : {}
      const thoughts = thoughtsR.ok ? await thoughtsR.json() : {}
      const trades = tradesR.ok ? await tradesR.json() : {}
      const positions = positionsR.ok ? await positionsR.json() : {}
      const wallet = walletR.ok ? await walletR.json() : {}
      setAgentDetailData({
        agent: agent.agent || agent,
        thoughts: thoughts.thoughts || thoughts || [],
        trades: trades.trades || trades || [],
        positions: positions.positions || positions || [],
        wallet,
      })
    } catch {} finally { setAgentDetailLoading(false) }
  }, [])

  // ── Agent Actions ──────────────────────────────────────────────────────
  const createAgent = async () => {
    setCreateAgentLoading(true)
    try {
      const r = await fetch('/api/meme-agents', {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          name: newAgentName, strategy: newAgentStrategy,
          allocated_budget: parseFloat(newAgentBudget) || 100,
          risk_tolerance: newAgentRisk, preferred_chains: newAgentChains,
          execution_mode: newAgentMode
        })
      })
      if (r.ok) {
        showToast('Agent created successfully', 'success')
        setShowCreateAgent(false)
        setNewAgentName(''); setNewAgentStrategy('safety_first'); setNewAgentBudget('100')
        setNewAgentRisk('medium'); setNewAgentChains(['solana']); setNewAgentMode('simulation')
        fetchMemeAgents()
      } else { showToast('Failed to create agent', 'error') }
    } catch { showToast('Error creating agent', 'error') }
    finally { setCreateAgentLoading(false) }
  }

  const deleteAgent = async (id: string) => {
    if (!confirm('Delete this agent? This cannot be undone.')) return
    try {
      const r = await fetch(`/api/meme-agents?id=${id}`, { method: 'DELETE' })
      if (r.ok) { showToast('Agent deleted', 'success'); fetchMemeAgents() }
      else showToast('Failed to delete agent', 'error')
    } catch { showToast('Error deleting agent', 'error') }
  }

  const runAgentCycle = async (agentId: string) => {
    setMemeAgentCycleLoading(prev => ({ ...prev, [agentId]: true }))
    try {
      const r = await fetch(`/api/meme-agents/${agentId}/cycle`, {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ agentId })
      })
      if (r.ok) { showToast('Agent cycle completed', 'success'); fetchMemeAgents(); fetchAgentThoughts(); fetchAgentTrades() }
      else showToast('Cycle failed', 'error')
    } catch { showToast('Cycle error', 'error') }
    finally { setMemeAgentCycleLoading(prev => ({ ...prev, [agentId]: false })) }
  }

  const toggleAgentStatus = async (agent: MemeAgent) => {
    const newStatus = agent.status === 'active' ? 'paused' : 'active'
    try {
      const r = await fetch('/api/meme-agents', {
        method: 'PATCH', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ id: agent.id, status: newStatus })
      })
      if (r.ok) fetchMemeAgents()
    } catch {}
  }

  const toggleExecutionMode = async (agent: MemeAgent) => {
    const newMode = agent.execution_mode === 'live' ? 'simulation' : 'live'
    if (newMode === 'live' && !confirm('Switch to LIVE mode? Real funds will be used!')) return
    try {
      const r = await fetch('/api/meme-agents', {
        method: 'PATCH', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ id: agent.id, execution_mode: newMode })
      })
      if (r.ok) { showToast(`Switched to ${newMode} mode`, newMode === 'live' ? 'error' : 'info'); fetchMemeAgents() }
    } catch {}
  }

  const generateAgentWallet = async (agentId: string) => {
    setWalletActionLoading(prev => ({ ...prev, [agentId + '_gen']: true }))
    try {
      const r = await fetch(`/api/meme-agents/${agentId}/wallet`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ action: 'generate' }) })
      if (r.ok) { showToast('Wallet generated!', 'success'); fetchMemeAgents(); fetchAgentWalletBalance(agentId) }
      else showToast('Failed to generate wallet', 'error')
    } catch { showToast('Error generating wallet', 'error') }
    finally { setWalletActionLoading(prev => ({ ...prev, [agentId + '_gen']: false })) }
  }

  const fundAgentWallet = async (agentId: string) => {
    const amount = parseFloat(walletFundAmount)
    if (!amount || amount <= 0) { showToast('Enter a valid amount', 'error'); return }
    setWalletActionLoading(prev => ({ ...prev, [agentId + '_fund']: true }))
    try {
      const r = await fetch(`/api/meme-agents/${agentId}/wallet`, {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'fund', amount })
      })
      if (r.ok) { showToast(`Funded ${amount} SOL`, 'success'); setWalletFundAmount(''); fetchAgentWalletBalance(agentId) }
      else showToast('Fund failed', 'error')
    } catch { showToast('Fund error', 'error') }
    finally { setWalletActionLoading(prev => ({ ...prev, [agentId + '_fund']: false })) }
  }

  const withdrawAgentWallet = async (agentId: string) => {
    const amount = parseFloat(walletWithdrawAmount)
    if (!amount || !walletWithdrawAddr) { showToast('Enter amount and address', 'error'); return }
    setWalletActionLoading(prev => ({ ...prev, [agentId + '_withdraw']: true }))
    try {
      const r = await fetch(`/api/meme-agents/${agentId}/wallet`, {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'withdraw', amount, to: walletWithdrawAddr })
      })
      if (r.ok) { showToast(`Withdrew ${amount} SOL`, 'success'); setWalletWithdrawAmount(''); setWalletWithdrawAddr(''); fetchAgentWalletBalance(agentId) }
      else showToast('Withdraw failed', 'error')
    } catch { showToast('Withdraw error', 'error') }
    finally { setWalletActionLoading(prev => ({ ...prev, [agentId + '_withdraw']: false })) }
  }

  const toggleScheduler = async (action: 'start' | 'stop') => {
    setSchedulerLoading(true)
    try {
      const r = await fetch('/api/meme-agents/scheduler', {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action, intervalMs: schedulerInterval })
      })
      if (r.ok) { showToast(`Scheduler ${action}ed`, 'success'); fetchSchedulerStatus() }
    } catch {} finally { setSchedulerLoading(false) }
  }

  const toggleMonitor = async (action: 'start' | 'stop') => {
    setMonitorLoading(true)
    try {
      const r = await fetch('/api/meme-agents/monitor', {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action, intervalMs: 30000 })
      })
      if (r.ok) { showToast(`Monitor ${action}ed`, 'success'); fetchMonitorStatus() }
    } catch {} finally { setMonitorLoading(false) }
  }

  const runAllAgentCycles = async () => {
    const activeAgents = memeAgents.filter(a => a.status === 'active')
    if (activeAgents.length === 0) { showToast('No active agents', 'error'); return }
    showToast(`Running cycles for ${activeAgents.length} agents...`, 'info')
    for (const agent of activeAgents) {
      await runAgentCycle(agent.id)
    }
    showToast('All cycles complete', 'success')
  }

  // ── Watchlist & Token Actions ──────────────────────────────────────────
  const addToWatchlist = async (pair: TokenPair) => {
    const addr = pair.baseToken.address
    setAddingToken(addr)
    try {
      const r = await fetch('/api/dexscreener/watchlist', {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          chainId: pair.chainId, tokenAddress: addr,
          name: pair.baseToken.name, symbol: pair.baseToken.symbol,
          entryPrice: parseFloat(pair.priceUsd || '0'), allocatedAmount: 0
        })
      })
      if (r.ok) { fetchWatchlist(); showToast(`Added ${pair.baseToken.symbol} to watchlist`, 'success') }
    } catch {}
    setAddingToken(null)
  }

  const removeFromWatchlist = async (addr: string) => {
    try {
      await fetch(`/api/dexscreener/watchlist?tokenAddress=${addr}`, { method: 'DELETE' })
      fetchWatchlist()
    } catch {}
  }

  const updateAllocation = async (addr: string, amount: number) => {
    try {
      await fetch('/api/dexscreener/watchlist', {
        method: 'PUT', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ tokenAddress: addr, allocatedAmount: amount })
      })
      fetchWatchlist()
    } catch {}
  }

  const doSearch = async () => {
    if (!searchQuery.trim()) return
    setSearchLoading(true)
    try {
      const r = await fetch(`/api/dexscreener?action=search&q=${encodeURIComponent(searchQuery)}`)
      if (r.ok) { const d = await r.json(); setSearchResults(d.pairs || []) }
    } catch {}
    setSearchLoading(false)
  }

  // ── Alerts ─────────────────────────────────────────────────────────────
  const addAlert = () => {
    if (!newAlertSymbol || !newAlertPrice) { showToast('Fill in symbol and price', 'error'); return }
    const alert: PriceAlert = {
      id: Date.now().toString(), tokenAddress: newAlertAddress, chainId: newAlertChain,
      symbol: newAlertSymbol, targetPrice: parseFloat(newAlertPrice), direction: newAlertDirection,
      active: true, createdAt: new Date().toISOString()
    }
    const updated = [...alerts, alert]
    setAlerts(updated)
    localStorage.setItem('meme-alerts', JSON.stringify(updated))
    setNewAlertSymbol(''); setNewAlertAddress(''); setNewAlertPrice('')
    showToast(`Alert set for ${alert.symbol}`, 'success')
  }

  const removeAlert = (id: string) => {
    const updated = alerts.filter(a => a.id !== id)
    setAlerts(updated)
    localStorage.setItem('meme-alerts', JSON.stringify(updated))
  }

  const toggleAlert = (id: string) => {
    const updated = alerts.map(a => a.id === id ? { ...a, active: !a.active } : a)
    setAlerts(updated)
    localStorage.setItem('meme-alerts', JSON.stringify(updated))
  }

  // ── Effects ────────────────────────────────────────────────────────────
  useEffect(() => { fetchTrending(); fetchWatchlist(); fetchTrades(); fetchSolPrice() }, [])
  useEffect(() => { fetchWatchlistPrices() }, [watchlist])

  useEffect(() => {
    const iv = setInterval(() => {
      setCountdown(c => {
        if (c <= 1) { fetchTrending(); return settings.scanInterval }
        return c - 1
      })
    }, 1000)
    return () => clearInterval(iv)
  }, [settings.scanInterval, fetchTrending])

  // Fetch agent data when Agents tab is active
  useEffect(() => {
    if (tab === 7) {
      fetchMemeAgents(); fetchSchedulerStatus(); fetchMonitorStatus()
      fetchAgentThoughts(); fetchAgentTrades()
    }
  }, [tab])

  // Poll wallet balances when agents tab is open
  useEffect(() => {
    if (tab !== 7) return
    const agentsWithWallets = memeAgents.filter(a => a.wallet_public_key)
    agentsWithWallets.forEach(a => fetchAgentWalletBalance(a.id))
    const iv = setInterval(() => {
      agentsWithWallets.forEach(a => fetchAgentWalletBalance(a.id))
    }, 30000)
    return () => clearInterval(iv)
  }, [tab, memeAgents])

  // Fetch new pairs when that tab opens
  useEffect(() => {
    if (tab === 1) fetchNewPairs()
  }, [tab])

  // Fetch smart money when that tab opens
  useEffect(() => {
    if (tab === 6) fetchSmartMoney()
  }, [tab])

  // Alert checking
  useEffect(() => {
    if (tokens.length === 0 || alerts.length === 0) return
    const activeAlerts = alerts.filter(a => a.active)
    for (const alert of activeAlerts) {
      const token = tokens.find(t => t.baseToken?.symbol?.toLowerCase() === alert.symbol.toLowerCase() || t.baseToken?.address?.toLowerCase() === alert.tokenAddress?.toLowerCase())
      if (!token) continue
      const price = parseFloat(token.priceUsd || '0')
      const triggered = alert.direction === 'above' ? price >= alert.targetPrice : price <= alert.targetPrice
      if (triggered) {
        showToast(`🔔 ${alert.symbol} is ${alert.direction} $${alert.targetPrice} (now ${fmtPrice(price)})`, 'info')
        const updated = alerts.map(a => a.id === alert.id ? { ...a, active: false, triggeredAt: new Date().toISOString() } : a)
        setAlerts(updated)
        localStorage.setItem('meme-alerts', JSON.stringify(updated))
      }
    }
  }, [tokens])

  // ── Computed ───────────────────────────────────────────────────────────
  const watchlistAddrs = useMemo(() => new Set(watchlist.map(w => w.tokenAddress.toLowerCase())), [watchlist])
  const totalAllocated = useMemo(() => watchlist.reduce((s, w) => s + (w.allocatedAmount || 0), 0), [watchlist])
  const available = settings.totalBudget - totalAllocated

  const bestPerformer = useMemo(() => {
    let best: TokenPair | null = null
    for (const t of tokens) {
      if (!best || (t.priceChange?.h24 || 0) > (best.priceChange?.h24 || 0)) best = t
    }
    return best
  }, [tokens])

  const tradeStats = useMemo(() => {
    let invested = 0, returned = 0
    for (const t of trades) {
      if (t.side === 'buy') invested += t.amount * t.price
      else returned += t.amount * t.price
    }
    return { invested, returned, pnl: returned - invested }
  }, [trades])

  const agentStats = useMemo(() => {
    const active = memeAgents.filter(a => a.status === 'active').length
    const totalPnl = memeAgents.reduce((s, a) => s + (a.total_pnl || 0), 0)
    const totalBudget = memeAgents.reduce((s, a) => s + (a.allocated_budget || 0), 0)
    const totalTrades = memeAgents.reduce((s, a) => s + (a.total_trades || 0), 0)
    return { active, total: memeAgents.length, totalPnl, totalBudget, totalTrades }
  }, [memeAgents])

  const filteredTokens = useMemo(() => {
    let list = chainFilter === 'All' ? tokens : tokens.filter(t => t.chainId === chainFilter)
    list = list.filter(t => {
      if ((t.liquidity?.usd || 0) < settings.minLiquidity) return false
      if ((t.volume?.h24 || 0) < settings.minVolume) return false
      if (settings.maxAgeDays > 0 && t.pairCreatedAt) {
        const ageDays = (Date.now() - t.pairCreatedAt) / 86400000
        if (ageDays > settings.maxAgeDays) return false
      }
      return true
    })
    const getSortVal = (t: TokenPair) => {
      switch (sortCol) {
        case 'name': return t.baseToken?.name?.toLowerCase() || ''
        case 'symbol': return t.baseToken?.symbol?.toLowerCase() || ''
        case 'chain': return t.chainId
        case 'price': return parseFloat(t.priceUsd || '0')
        case 'change': return t.priceChange?.h24 || 0
        case 'volume': return t.volume?.h24 || 0
        case 'liquidity': return t.liquidity?.usd || 0
        case 'mcap': return t.marketCap || 0
        case 'age': return t.pairCreatedAt || 0
        case 'txns': return (t.txns?.h24?.buys || 0) + (t.txns?.h24?.sells || 0)
        default: return t.volume?.h24 || 0
      }
    }
    return [...list].sort((a, b) => {
      const va = getSortVal(a), vb = getSortVal(b)
      const cmp = typeof va === 'string' ? va.localeCompare(vb as string) : (va as number) - (vb as number)
      return sortDir === 'desc' ? -cmp : cmp
    })
  }, [tokens, chainFilter, sortCol, sortDir, settings])

  const handleSort = (col: string) => {
    if (sortCol === col) setSortDir(d => d === 'desc' ? 'asc' : 'desc')
    else { setSortCol(col); setSortDir('desc') }
  }
  const sortArrow = (col: string) => sortCol === col ? (sortDir === 'desc' ? ' ▼' : ' ▲') : ''

  // ── Token Table (reused by Scanner, Search, New Pairs) ─────────────────
  const renderTokenTable = (list: TokenPair[], showAdd = true) => (
    <div style={{ overflowX: 'auto' }}>
      <table style={s.table}>
        <thead>
          <tr>
            <th style={s.th} onClick={() => handleSort('name')}>Token{sortArrow('name')}</th>
            <th style={s.th} onClick={() => handleSort('chain')}>Chain{sortArrow('chain')}</th>
            <th style={s.th} onClick={() => handleSort('price')}>Price{sortArrow('price')}</th>
            <th style={s.th} onClick={() => handleSort('change')}>24h %{sortArrow('change')}</th>
            <th style={s.th} onClick={() => handleSort('volume')}>Volume 24h{sortArrow('volume')}</th>
            <th style={s.th} onClick={() => handleSort('liquidity')}>Liquidity{sortArrow('liquidity')}</th>
            <th style={s.th} onClick={() => handleSort('mcap')}>MCap{sortArrow('mcap')}</th>
            <th style={s.th} onClick={() => handleSort('age')}>Age{sortArrow('age')}</th>
            <th style={s.th} onClick={() => handleSort('txns')}>Buys/Sells{sortArrow('txns')}</th>
            {showAdd && <th style={s.th}>Action</th>}
          </tr>
        </thead>
        <tbody>
          {list.map((t, i) => {
            const key = t.pairAddress || t.baseToken?.address || String(i)
            const change = t.priceChange?.h24 || 0
            const buys = t.txns?.h24?.buys || 0
            const sells = t.txns?.h24?.sells || 0
            const isExpanded = expandedRow === key
            const inWatchlist = watchlistAddrs.has(t.baseToken?.address?.toLowerCase())
            const secKey = `${t.chainId}:${t.baseToken?.address}`
            const sec = securityResults[secKey]
            return (
              <React.Fragment key={key}>
                <tr
                  style={{ background: i % 2 === 0 ? 'transparent' : 'color-mix(in srgb, var(--border) 20%, transparent)', cursor: 'pointer' }}
                  onClick={() => setExpandedRow(isExpanded ? null : key)}
                >
                  <td style={{ ...s.td, fontWeight: 600 }}>
                    <div style={{ display: 'flex', alignItems: 'center', gap: '6px' }}>
                      {t.info?.imageUrl && <img src={t.info.imageUrl} alt="" style={{ width: '20px', height: '20px', borderRadius: '50%' }} />}
                      <div>
                        <div>{t.baseToken?.symbol}</div>
                        <div style={{ fontSize: '11px', color: 'var(--muted-foreground)' }}>{t.baseToken?.name?.slice(0, 20)}</div>
                      </div>
                    </div>
                  </td>
                  <td style={s.td}><span style={s.chainBadge(t.chainId)}>{CHAIN_LABELS[t.chainId] || t.chainId}</span></td>
                  <td style={s.td}>{fmtPrice(t.priceUsd)}</td>
                  <td style={{ ...s.td, ...s.pnl(change) }}>{change >= 0 ? '+' : ''}{fmt(change)}%</td>
                  <td style={s.td}>{fmtCompact(t.volume?.h24 || 0)}</td>
                  <td style={s.td}>{fmtCompact(t.liquidity?.usd || 0)}</td>
                  <td style={s.td}>{t.marketCap ? fmtCompact(t.marketCap) : '—'}</td>
                  <td style={s.td}>{ageStr(t.pairCreatedAt)}</td>
                  <td style={s.td}>
                    <span style={{ color: 'var(--trading-profit)' }}>{buys}</span>
                    <span style={{ color: 'var(--muted-foreground)' }}>/</span>
                    <span style={{ color: 'var(--trading-loss)' }}>{sells}</span>
                  </td>
                  {showAdd && (
                    <td style={s.td} onClick={e => e.stopPropagation()}>
                      <div style={{ display: 'flex', gap: '4px', alignItems: 'center' }}>
                        {inWatchlist ? (
                          <span style={{ fontSize: '12px', color: 'var(--secondary)' }}>⭐ Watching</span>
                        ) : (
                          <button
                            onClick={() => addToWatchlist(t)}
                            disabled={addingToken === t.baseToken?.address}
                            style={{ ...s.btn('var(--primary)'), opacity: addingToken === t.baseToken?.address ? 0.5 : 1, padding: '4px 10px', fontSize: '12px' }}
                          >
                            {addingToken === t.baseToken?.address ? '...' : '+ Watch'}
                          </button>
                        )}
                        <button onClick={() => setTokenDetailPair(t)} style={{ ...s.btnSm('var(--border)', 'var(--muted-foreground)') }}>🔍</button>
                      </div>
                    </td>
                  )}
                </tr>
                {isExpanded && (
                  <tr>
                    <td colSpan={showAdd ? 10 : 9} style={{ padding: '12px', background: 'var(--card)', borderBottom: '1px solid var(--border)' }}>
                      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(180px, 1fr))', gap: '12px', fontSize: '13px' }}>
                        <div><span style={{ color: 'var(--muted-foreground)' }}>Pair: </span>{t.baseToken?.symbol}/{t.quoteToken?.symbol}</div>
                        <div><span style={{ color: 'var(--muted-foreground)' }}>Chain: </span>{t.chainId}</div>
                        <div><span style={{ color: 'var(--muted-foreground)' }}>5m: </span><span style={s.pnl(t.priceChange?.m5 || 0)}>{fmt(t.priceChange?.m5 || 0)}%</span></div>
                        <div><span style={{ color: 'var(--muted-foreground)' }}>1h: </span><span style={s.pnl(t.priceChange?.h1 || 0)}>{fmt(t.priceChange?.h1 || 0)}%</span></div>
                        <div><span style={{ color: 'var(--muted-foreground)' }}>6h: </span><span style={s.pnl(t.priceChange?.h6 || 0)}>{fmt(t.priceChange?.h6 || 0)}%</span></div>
                        <div><span style={{ color: 'var(--muted-foreground)' }}>Vol 1h: </span>{fmtCompact(t.volume?.h1 || 0)}</div>
                        <div><span style={{ color: 'var(--muted-foreground)' }}>Vol 5m: </span>{fmtCompact(t.volume?.m5 || 0)}</div>
                        <div><span style={{ color: 'var(--muted-foreground)' }}>FDV: </span>{t.fdv ? fmtCompact(t.fdv) : '—'}</div>
                        <div><span style={{ color: 'var(--muted-foreground)' }}>1h Txns: </span>
                          <span style={{ color: 'var(--trading-profit)' }}>{t.txns?.h1?.buys || 0}B</span> / <span style={{ color: 'var(--trading-loss)' }}>{t.txns?.h1?.sells || 0}S</span>
                        </div>
                        <div><span style={{ color: 'var(--muted-foreground)' }}>Address: </span>
                          <span style={{ fontSize: '11px', fontFamily: 'monospace', cursor: 'pointer' }} onClick={() => copyToClipboard(t.baseToken?.address)}>{t.baseToken?.address?.slice(0, 8)}...{t.baseToken?.address?.slice(-6)} 📋</span>
                        </div>
                        {t.boostAmount ? <div><span style={{ color: 'var(--muted-foreground)' }}>Boost: </span><span style={{ color: 'var(--accent)' }}>🔥 {t.boostAmount}</span></div> : null}
                      </div>
                      {/* Security scan */}
                      <div style={{ marginTop: '12px', display: 'flex', gap: '8px', alignItems: 'center', flexWrap: 'wrap' }}>
                        <button onClick={() => fetchSecurityScan(t.baseToken?.address, t.chainId)} style={s.btnSm('var(--border)', 'var(--muted-foreground)')}>
                          {sec?.loading ? '⏳ Scanning...' : '🛡️ Security Scan'}
                        </button>
                        <button onClick={() => setTokenDetailPair(t)} style={s.btnSm('var(--primary)')}>📊 Detail</button>
                        {t.url && <a href={t.url} target="_blank" rel="noopener noreferrer" style={{ ...s.btnSm('var(--border)', 'var(--secondary)'), textDecoration: 'none' }}>🔗 DexScreener</a>}
                        {sec && !sec.loading && (
                          <div style={{ display: 'flex', gap: '8px', flexWrap: 'wrap' }}>
                            {sec.goplus && (
                              <>
                                <span style={s.badge(sec.goplus.isHoneypot ? 'var(--trading-loss)' : 'var(--trading-profit)')}>
                                  {sec.goplus.isHoneypot ? '🍯 Honeypot' : '✅ Not Honeypot'}
                                </span>
                                <span style={s.badge(sec.goplus.isOpenSource ? 'var(--trading-profit)' : 'var(--accent)')}>
                                  {sec.goplus.isOpenSource ? '📖 Open Source' : '🔒 Closed Source'}
                                </span>
                                {parseFloat(sec.goplus.buyTax) > 5 && <span style={s.badge('var(--trading-loss)')}>Buy Tax: {sec.goplus.buyTax}%</span>}
                                {parseFloat(sec.goplus.sellTax) > 5 && <span style={s.badge('var(--trading-loss)')}>Sell Tax: {sec.goplus.sellTax}%</span>}
                              </>
                            )}
                            {sec.rugcheck && (
                              <span style={s.badge(sec.rugcheck.score >= 70 ? 'var(--trading-profit)' : sec.rugcheck.score >= 40 ? 'var(--accent)' : 'var(--trading-loss)')}>
                                RugCheck: {sec.rugcheck.score}/100
                              </span>
                            )}
                          </div>
                        )}
                      </div>
                    </td>
                  </tr>
                )}
              </React.Fragment>
            )
          })}
        </tbody>
      </table>
    </div>
  )

  // ── Tab: Scanner ──────────────────────────────────────────────────────
  const renderScanner = () => (
    <div>
      <div style={{ display: 'flex', gap: '8px', marginBottom: '16px', flexWrap: 'wrap', alignItems: 'center' }}>
        <span style={{ fontSize: '13px', color: 'var(--muted-foreground)' }}>Chain:</span>
        {CHAINS.map(c => (
          <button key={c} onClick={() => setChainFilter(c)}
            style={{ ...s.btn(chainFilter === c ? 'var(--primary)' : 'var(--border)', chainFilter === c ? 'var(--foreground)' : 'var(--muted-foreground)'), padding: '4px 12px', fontSize: '12px' }}>
            {c === 'All' ? 'All' : CHAIN_LABELS[c] || c}
          </button>
        ))}
        <span style={{ marginLeft: 'auto', fontSize: '12px', color: 'var(--muted-foreground)' }}>
          <span style={s.dot(true)} /> Refresh in {countdown}s • {filteredTokens.length} tokens
        </span>
      </div>
      {loading ? (
        <div style={s.emptyState}><div style={{ fontSize: '48px', marginBottom: '12px' }}>🔄</div><div>Loading trending tokens...</div></div>
      ) : error ? (
        <div style={s.emptyState}><div style={{ fontSize: '48px', marginBottom: '12px' }}>⚠️</div><div style={{ color: 'var(--trading-loss)' }}>{error}</div>
          <button onClick={fetchTrending} style={{ ...s.btn('var(--primary)'), marginTop: '12px' }}>Retry</button></div>
      ) : filteredTokens.length === 0 ? (
        <div style={s.emptyState}><div style={{ fontSize: '48px', marginBottom: '12px' }}>📭</div><div>No tokens match filters</div></div>
      ) : renderTokenTable(filteredTokens)}
    </div>
  )

  // ── Tab: New Pairs ────────────────────────────────────────────────────
  const renderNewPairs = () => (
    <div>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '16px' }}>
        <div style={{ fontSize: '14px', color: 'var(--muted-foreground)' }}>Recently created trading pairs across all chains</div>
        <button onClick={fetchNewPairs} disabled={newPairsLoading} style={{ ...s.btn('var(--border)', 'var(--muted-foreground)'), opacity: newPairsLoading ? 0.5 : 1 }}>
          {newPairsLoading ? '⏳ Loading...' : '🔄 Refresh'}
        </button>
      </div>
      {newPairsLoading && newPairs.length === 0 ? (
        <div style={s.emptyState}><div style={{ fontSize: '48px', marginBottom: '12px' }}>🆕</div><div>Loading new pairs...</div></div>
      ) : newPairs.length === 0 ? (
        <div style={s.emptyState}><div style={{ fontSize: '48px', marginBottom: '12px' }}>🆕</div><div>No new pairs found</div></div>
      ) : renderTokenTable(newPairs)}
    </div>
  )

  // ── Tab: Watchlist ────────────────────────────────────────────────────
  const renderWatchlist = () => (
    <div>
      <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '16px', flexWrap: 'wrap', gap: '8px' }}>
        <div style={{ fontSize: '14px' }}>
          <span style={{ color: 'var(--muted-foreground)' }}>Allocated: </span><span style={{ color: 'var(--secondary)', fontWeight: 600 }}>{fmtUSD(totalAllocated)}</span>
          <span style={{ color: 'var(--muted-foreground)', marginLeft: '16px' }}>Available: </span><span style={{ color: available >= 0 ? 'var(--trading-profit)' : 'var(--trading-loss)', fontWeight: 600 }}>{fmtUSD(available)}</span>
        </div>
        <button onClick={fetchWatchlistPrices} style={{ ...s.btn('var(--border)', 'var(--muted-foreground)'), fontSize: '12px' }}>🔄 Refresh Prices</button>
      </div>
      {watchlist.length === 0 ? (
        <div style={s.emptyState}><div style={{ fontSize: '48px', marginBottom: '12px' }}>⭐</div><div>No tokens in watchlist. Add some from the Scanner or Search tabs!</div></div>
      ) : (
        <div style={{ overflowX: 'auto' }}>
          <table style={s.table}>
            <thead>
              <tr>
                <th style={s.th}>Token</th><th style={s.th}>Chain</th><th style={s.th}>Entry Price</th>
                <th style={s.th}>Current</th><th style={s.th}>P&L</th><th style={s.th}>24h %</th>
                <th style={s.th}>Volume</th><th style={s.th}>Allocation</th><th style={s.th}>Actions</th>
              </tr>
            </thead>
            <tbody>
              {watchlist.map((w, i) => {
                const pair = watchlistPrices.get(w.tokenAddress.toLowerCase())
                const currentPrice = pair ? parseFloat(pair.priceUsd || '0') : 0
                const pnlPct = w.entryPrice > 0 && currentPrice > 0 ? ((currentPrice - w.entryPrice) / w.entryPrice) * 100 : 0
                const pnlUsd = w.allocatedAmount > 0 ? w.allocatedAmount * (pnlPct / 100) : 0
                return (
                  <tr key={w.tokenAddress} style={{ background: i % 2 === 0 ? 'transparent' : 'color-mix(in srgb, var(--border) 20%, transparent)' }}>
                    <td style={{ ...s.td, fontWeight: 600 }}>{w.symbol}<div style={{ fontSize: '11px', color: 'var(--muted-foreground)' }}>{w.name?.slice(0, 20)}</div></td>
                    <td style={s.td}><span style={s.chainBadge(w.chainId)}>{CHAIN_LABELS[w.chainId] || w.chainId}</span></td>
                    <td style={s.td}>{w.entryPrice ? fmtPrice(w.entryPrice) : '—'}</td>
                    <td style={s.td}>{currentPrice ? fmtPrice(currentPrice) : '—'}</td>
                    <td style={{ ...s.td, ...s.pnl(pnlPct) }}>
                      {currentPrice ? <>{pnlPct >= 0 ? '+' : ''}{fmt(pnlPct)}%{w.allocatedAmount > 0 && <div style={{ fontSize: '11px' }}>{pnlUsd >= 0 ? '+' : ''}{fmtUSD(pnlUsd)}</div>}</> : '—'}
                    </td>
                    <td style={{ ...s.td, ...s.pnl(pair?.priceChange?.h24 || 0) }}>{pair ? `${fmt(pair.priceChange?.h24 || 0)}%` : '—'}</td>
                    <td style={s.td}>{pair ? fmtCompact(pair.volume?.h24 || 0) : '—'}</td>
                    <td style={s.td}>
                      <input
                        type="number" value={w.allocatedAmount || ''} placeholder="0"
                        style={{ ...s.input, width: '80px', fontSize: '12px', padding: '4px 8px' }}
                        onClick={e => e.stopPropagation()}
                        onChange={e => updateAllocation(w.tokenAddress, parseFloat(e.target.value) || 0)}
                      />
                    </td>
                    <td style={s.td}>
                      <div style={{ display: 'flex', gap: '4px' }}>
                        <button onClick={() => removeFromWatchlist(w.tokenAddress)} style={{ ...s.btnSm('var(--trading-loss)'), fontSize: '11px' }}>Remove</button>
                        {pair && <button onClick={() => setTokenDetailPair(pair)} style={s.btnSm('var(--border)', 'var(--muted-foreground)')}>🔍</button>}
                      </div>
                    </td>
                  </tr>
                )
              })}
            </tbody>
          </table>
        </div>
      )}
    </div>
  )

  // ── Tab: Search ───────────────────────────────────────────────────────
  const renderSearch = () => (
    <div>
      <div style={{ display: 'flex', gap: '8px', marginBottom: '16px' }}>
        <input
          value={searchQuery} onChange={e => setSearchQuery(e.target.value)}
          onKeyDown={e => e.key === 'Enter' && doSearch()}
          placeholder="Search tokens... (e.g. PEPE, DOGE, WIF)"
          style={{ ...s.input, maxWidth: '400px' }}
        />
        <button onClick={doSearch} disabled={searchLoading} style={{ ...s.btn('var(--primary)'), opacity: searchLoading ? 0.5 : 1 }}>
          {searchLoading ? 'Searching...' : '🔎 Search'}
        </button>
      </div>
      {searchResults.length === 0 ? (
        <div style={s.emptyState}><div style={{ fontSize: '48px', marginBottom: '12px' }}>🔎</div><div>Search for meme coins by name, symbol, or address</div></div>
      ) : (
        <>
          <div style={{ fontSize: '13px', color: 'var(--muted-foreground)', marginBottom: '8px' }}>{searchResults.length} results</div>
          {renderTokenTable(searchResults)}
        </>
      )}
    </div>
  )

  // ── Tab: Trade History ────────────────────────────────────────────────
  const renderTrades = () => (
    <div>
      <div style={{ ...s.cards, padding: 0, marginBottom: '16px' }}>
        {[
          { label: 'Total Invested', value: fmtUSD(tradeStats.invested), color: 'var(--foreground)' },
          { label: 'Total Returned', value: fmtUSD(tradeStats.returned), color: 'var(--foreground)' },
          { label: 'Net P&L', value: (tradeStats.pnl >= 0 ? '+' : '') + fmtUSD(tradeStats.pnl), color: tradeStats.pnl >= 0 ? 'var(--trading-profit)' : 'var(--trading-loss)' },
          { label: 'Total Trades', value: String(trades.length), color: 'var(--secondary)' },
        ].map(st => (
          <div key={st.label} style={s.card}>
            <div style={s.cardLabel}>{st.label}</div>
            <div style={{ ...s.cardValue, color: st.color }}>{st.value}</div>
          </div>
        ))}
      </div>
      {trades.length === 0 ? (
        <div style={s.emptyState}><div style={{ fontSize: '48px', marginBottom: '12px' }}>📊</div><div>No trades recorded yet</div></div>
      ) : (
        <div style={{ overflowX: 'auto' }}>
          <table style={{ ...s.table, minWidth: '700px' }}>
            <thead><tr>{['Time', 'Symbol', 'Chain', 'Side', 'Amount', 'Price', 'Total', 'Tx'].map(h => <th key={h} style={s.th}>{h}</th>)}</tr></thead>
            <tbody>
              {trades.slice().reverse().map((t, i) => (
                <tr key={t.id} style={{ background: i % 2 === 0 ? 'transparent' : 'color-mix(in srgb, var(--border) 20%, transparent)' }}>
                  <td style={{ ...s.td, fontSize: '12px', color: 'var(--muted-foreground)' }}>{new Date(t.timestamp).toLocaleString()}</td>
                  <td style={{ ...s.td, fontWeight: 600 }}>{t.symbol}</td>
                  <td style={s.td}><span style={s.chainBadge(t.chainId)}>{CHAIN_LABELS[t.chainId] || t.chainId || '—'}</span></td>
                  <td style={s.td}><span style={s.badge(t.side === 'buy' ? 'var(--trading-profit)' : 'var(--trading-loss)')}>{t.side.toUpperCase()}</span></td>
                  <td style={s.td}>{fmt(t.amount)}</td>
                  <td style={s.td}>{fmtPrice(t.price)}</td>
                  <td style={s.td}>{fmtUSD(t.amount * t.price)}</td>
                  <td style={{ ...s.td, fontSize: '11px', fontFamily: 'monospace' }}>{t.txHash ? t.txHash.slice(0, 8) + '...' : '—'}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  )

  // ── Tab: Alerts ───────────────────────────────────────────────────────
  const renderAlerts = () => (
    <div>
      <div style={{ ...s.card, marginBottom: '20px' }}>
        <div style={{ ...s.sectionTitle, marginBottom: '12px' }}>Create Price Alert</div>
        <div style={{ display: 'flex', gap: '8px', flexWrap: 'wrap', alignItems: 'flex-end' }}>
          <div style={s.formGroup}>
            <label style={s.label}>Symbol</label>
            <input value={newAlertSymbol} onChange={e => setNewAlertSymbol(e.target.value)} placeholder="PEPE" style={{ ...s.input, width: '120px' }} />
          </div>
          <div style={s.formGroup}>
            <label style={s.label}>Token Address (optional)</label>
            <input value={newAlertAddress} onChange={e => setNewAlertAddress(e.target.value)} placeholder="0x..." style={{ ...s.input, width: '200px' }} />
          </div>
          <div style={s.formGroup}>
            <label style={s.label}>Chain</label>
            <select value={newAlertChain} onChange={e => setNewAlertChain(e.target.value)} style={{ ...s.select, width: '120px' }}>
              {CHAINS.filter(c => c !== 'All').map(c => <option key={c} value={c}>{CHAIN_LABELS[c] || c}</option>)}
            </select>
          </div>
          <div style={s.formGroup}>
            <label style={s.label}>Direction</label>
            <select value={newAlertDirection} onChange={e => setNewAlertDirection(e.target.value as 'above' | 'below')} style={{ ...s.select, width: '100px' }}>
              <option value="above">Above ↑</option>
              <option value="below">Below ↓</option>
            </select>
          </div>
          <div style={s.formGroup}>
            <label style={s.label}>Target Price ($)</label>
            <input type="number" value={newAlertPrice} onChange={e => setNewAlertPrice(e.target.value)} placeholder="0.001" style={{ ...s.input, width: '140px' }} />
          </div>
          <button onClick={addAlert} style={s.btn('var(--primary)')}>🔔 Add Alert</button>
        </div>
      </div>
      {alerts.length === 0 ? (
        <div style={s.emptyState}><div style={{ fontSize: '48px', marginBottom: '12px' }}>🔔</div><div>No price alerts set. Create one above!</div></div>
      ) : (
        <div style={{ overflowX: 'auto' }}>
          <table style={{ ...s.table, minWidth: '600px' }}>
            <thead>
              <tr>
                <th style={s.th}>Symbol</th><th style={s.th}>Chain</th><th style={s.th}>Direction</th>
                <th style={s.th}>Target Price</th><th style={s.th}>Status</th><th style={s.th}>Created</th><th style={s.th}>Actions</th>
              </tr>
            </thead>
            <tbody>
              {alerts.map((a, i) => (
                <tr key={a.id} style={{ background: i % 2 === 0 ? 'transparent' : 'color-mix(in srgb, var(--border) 20%, transparent)' }}>
                  <td style={{ ...s.td, fontWeight: 600 }}>{a.symbol}</td>
                  <td style={s.td}><span style={s.chainBadge(a.chainId)}>{CHAIN_LABELS[a.chainId] || a.chainId}</span></td>
                  <td style={s.td}><span style={s.badge(a.direction === 'above' ? 'var(--trading-profit)' : 'var(--trading-loss)')}>{a.direction === 'above' ? '↑ Above' : '↓ Below'}</span></td>
                  <td style={s.td}>{fmtPrice(a.targetPrice)}</td>
                  <td style={s.td}>
                    {a.triggeredAt ? <span style={s.badge('var(--accent)')}>🔔 Triggered</span> : a.active ? <span style={s.badge('var(--trading-profit)')}>Active</span> : <span style={s.badge('var(--muted-foreground)')}>Paused</span>}
                  </td>
                  <td style={{ ...s.td, fontSize: '12px', color: 'var(--muted-foreground)' }}>{agentTimeAgo(a.createdAt)}</td>
                  <td style={s.td}>
                    <div style={{ display: 'flex', gap: '4px' }}>
                      <button onClick={() => toggleAlert(a.id)} style={s.btnSm(a.active ? 'var(--accent)' : 'var(--trading-profit)')}>{a.active ? 'Pause' : 'Enable'}</button>
                      <button onClick={() => removeAlert(a.id)} style={s.btnSm('var(--trading-loss)')}>Delete</button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  )

  // ── Tab: Smart Money ──────────────────────────────────────────────────
  const renderSmartMoney = () => (
    <div>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '16px' }}>
        <div style={{ fontSize: '14px', color: 'var(--muted-foreground)' }}>Track profitable wallets and their recent trades</div>
        <button onClick={fetchSmartMoney} disabled={smartMoneyLoading} style={{ ...s.btn('var(--border)', 'var(--muted-foreground)'), opacity: smartMoneyLoading ? 0.5 : 1 }}>
          {smartMoneyLoading ? '⏳ Loading...' : '🔄 Refresh'}
        </button>
      </div>
      {smartMoneyLoading && smartMoneyWallets.length === 0 ? (
        <div style={s.emptyState}><div style={{ fontSize: '48px', marginBottom: '12px' }}>💰</div><div>Loading smart money data...</div></div>
      ) : smartMoneyWallets.length === 0 ? (
        <div style={s.emptyState}>
          <div style={{ fontSize: '48px', marginBottom: '12px' }}>💰</div>
          <div>Smart money tracking is available when connected to on-chain analytics.</div>
          <div style={{ marginTop: '12px', fontSize: '13px', color: 'var(--muted-foreground)' }}>
            This feature monitors wallets with consistent profitable trading patterns and surfaces their recent token picks.
          </div>
        </div>
      ) : (
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(min(100%, 340px), 1fr))', gap: '12px' }}>
          {smartMoneyWallets.map(w => (
            <div key={w.address} style={s.card}>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '8px' }}>
                <div style={{ fontWeight: 600, fontSize: '14px' }}>{w.label || 'Unknown'}</div>
                <span style={s.badge(w.pnl >= 0 ? 'var(--trading-profit)' : 'var(--trading-loss)')}>{w.pnl >= 0 ? '+' : ''}{fmt(w.pnl)}%</span>
              </div>
              <div style={{ fontSize: '11px', fontFamily: 'monospace', color: 'var(--muted-foreground)', marginBottom: '8px', cursor: 'pointer' }} onClick={() => copyToClipboard(w.address)}>
                {w.address.slice(0, 8)}...{w.address.slice(-6)} 📋
              </div>
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '4px', fontSize: '12px', marginBottom: '8px' }}>
                <div><span style={{ color: 'var(--muted-foreground)' }}>Win Rate:</span> <span style={{ color: 'var(--trading-profit)' }}>{fmt(w.winRate)}%</span></div>
                <div><span style={{ color: 'var(--muted-foreground)' }}>Trades:</span> {w.totalTrades}</div>
                <div><span style={{ color: 'var(--muted-foreground)' }}>Last Active:</span> {agentTimeAgo(w.lastActive)}</div>
              </div>
              {w.recentTokens && w.recentTokens.length > 0 && (
                <div style={{ marginTop: '4px' }}>
                  <span style={{ fontSize: '11px', color: 'var(--muted-foreground)' }}>Recent: </span>
                  {w.recentTokens.slice(0, 5).map(t => <span key={t} style={{ ...s.badge('var(--primary)'), marginRight: '4px' }}>{t}</span>)}
                </div>
              )}
            </div>
          ))}
        </div>
      )}
    </div>
  )

  // ── Tab: Agents ───────────────────────────────────────────────────────
  const renderAgents = () => {
    return (
      <div>
        {/* Top Controls */}
        <div style={{ ...s.card, marginBottom: '16px', display: 'flex', gap: '12px', flexWrap: 'wrap', alignItems: 'center' }}>
          {/* Scheduler */}
          <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
            <span style={{ fontSize: '13px', color: 'var(--muted-foreground)' }}>⏱️ Scheduler:</span>
            <span style={s.dot(schedulerStatus?.running)} />
            <span style={{ fontSize: '12px', color: schedulerStatus?.running ? 'var(--trading-profit)' : 'var(--muted-foreground)' }}>
              {schedulerStatus?.running ? 'Running' : 'Stopped'}
            </span>
            <select value={schedulerInterval} onChange={e => setSchedulerInterval(Number(e.target.value))} style={{ ...s.select, padding: '4px 8px', fontSize: '12px' }}>
              <option value={60000}>1 min</option>
              <option value={300000}>5 min</option>
              <option value={900000}>15 min</option>
              <option value={1800000}>30 min</option>
              <option value={3600000}>1 hour</option>
            </select>
            <button onClick={() => toggleScheduler(schedulerStatus?.running ? 'stop' : 'start')} disabled={schedulerLoading}
              style={{ ...s.btnSm(schedulerStatus?.running ? 'var(--trading-loss)' : 'var(--trading-profit)', '#000'), opacity: schedulerLoading ? 0.5 : 1 }}>
              {schedulerLoading ? '...' : schedulerStatus?.running ? '⏹ Stop' : '▶ Start'}
            </button>
          </div>
          {/* SL/TP Monitor */}
          <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
            <span style={{ fontSize: '13px', color: 'var(--muted-foreground)' }}>🎯 SL/TP:</span>
            <span style={s.dot(monitorStatus?.running)} />
            <span style={{ fontSize: '12px', color: monitorStatus?.running ? 'var(--trading-profit)' : 'var(--muted-foreground)' }}>
              {monitorStatus?.running ? 'Active' : 'Off'}
            </span>
            <button onClick={() => toggleMonitor(monitorStatus?.running ? 'stop' : 'start')} disabled={monitorLoading}
              style={{ ...s.btnSm(monitorStatus?.running ? 'var(--trading-loss)' : 'var(--trading-profit)', '#000'), opacity: monitorLoading ? 0.5 : 1 }}>
              {monitorLoading ? '...' : monitorStatus?.running ? '⏹ Stop' : '▶ Start'}
            </button>
          </div>
          {/* Actions */}
          <div style={{ marginLeft: 'auto', display: 'flex', gap: '8px' }}>
            <button onClick={runAllAgentCycles} style={s.btn('var(--secondary)')}>🔄 Run All Now</button>
            <button onClick={() => setShowCreateAgent(true)} style={s.btn('var(--primary)')}>+ Create Agent</button>
          </div>
        </div>

        {/* Stats Cards */}
        <div style={{ ...s.cards, padding: 0, marginBottom: '16px' }}>
          {[
            { label: 'Total Agents', value: String(agentStats.total), color: 'var(--foreground)' },
            { label: 'Active', value: String(agentStats.active), color: 'var(--trading-profit)' },
            { label: 'Total Budget', value: fmtUSD(agentStats.totalBudget), color: 'var(--secondary)' },
            { label: 'Combined P&L', value: (agentStats.totalPnl >= 0 ? '+' : '') + fmtUSD(agentStats.totalPnl), color: pctColor(agentStats.totalPnl) },
            { label: 'Total Trades', value: String(agentStats.totalTrades), color: 'var(--accent)' },
            { label: 'SOL Price', value: solUsdPrice > 0 ? fmtUSD(solUsdPrice) : '—', color: '#9945FF' },
          ].map(c => (
            <div key={c.label} style={s.card}>
              <div style={s.cardLabel}>{c.label}</div>
              <div style={{ ...s.cardValue, color: c.color }}>{c.value}</div>
            </div>
          ))}
        </div>

        {/* Agent Cards */}
        {memeAgentsLoading && memeAgents.length === 0 ? (
          <div style={s.emptyState}><div style={{ fontSize: '48px', marginBottom: '12px' }}>🤖</div><div>Loading agents...</div></div>
        ) : memeAgents.length === 0 ? (
          <div style={s.emptyState}>
            <div style={{ fontSize: '48px', marginBottom: '12px' }}>🤖</div>
            <div>No agents yet. Create one to get started!</div>
            <button onClick={() => setShowCreateAgent(true)} style={{ ...s.btn('var(--primary)'), marginTop: '12px' }}>+ Create Agent</button>
          </div>
        ) : (
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(min(100%, 380px), 1fr))', gap: '16px', marginBottom: '24px' }}>
            {memeAgents.map(agent => {
              const stratInfo = getAgentStrategyInfo(agent.strategy)
              const wb = agentWalletBalances[agent.id]
              const isExpanded = expandedAgentWallet === agent.id
              const solBal = wb?.sol || 0
              const tokens = wb?.tokens || []
              return (
                <div key={agent.id} style={{ ...s.card, border: `1px solid ${AGENT_STATUS_COLORS[agent.status] || 'var(--border)'}44` }}>
                  {/* Header */}
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '10px' }}>
                    <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                      <span style={{ fontSize: '20px' }}>{stratInfo.emoji}</span>
                      <div>
                        <div style={{ fontWeight: 700, fontSize: '15px' }}>{agent.name}</div>
                        <div style={{ fontSize: '11px', color: 'var(--muted-foreground)' }}>{agentTimeAgo(agent.updated_at)}</div>
                      </div>
                    </div>
                    <div style={{ display: 'flex', alignItems: 'center', gap: '6px' }}>
                      <span style={s.dot(agent.status === 'active')} />
                      <span style={{ fontSize: '12px', color: AGENT_STATUS_COLORS[agent.status] || 'var(--muted-foreground)', textTransform: 'capitalize' as const }}>{agent.status}</span>
                    </div>
                  </div>

                  {/* Strategy badge */}
                  <div style={{ marginBottom: '10px' }}>
                    <span style={{ ...s.badge(stratInfo.color), fontSize: '12px' }}>{stratInfo.emoji} {stratInfo.name}</span>
                  </div>

                  {/* Stats grid */}
                  <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '8px', marginBottom: '10px', fontSize: '13px' }}>
                    <div style={{ background: 'var(--background)', borderRadius: '8px', padding: '8px' }}>
                      <div style={{ fontSize: '11px', color: 'var(--muted-foreground)' }}>Budget</div>
                      <div style={{ fontWeight: 600 }}>{fmtUSD(agent.allocated_budget)}</div>
                    </div>
                    <div style={{ background: 'var(--background)', borderRadius: '8px', padding: '8px' }}>
                      <div style={{ fontSize: '11px', color: 'var(--muted-foreground)' }}>P&L</div>
                      <div style={{ fontWeight: 600, color: pctColor(agent.total_pnl) }}>{agent.total_pnl >= 0 ? '+' : ''}{fmtUSD(agent.total_pnl)}</div>
                    </div>
                    <div style={{ background: 'var(--background)', borderRadius: '8px', padding: '8px' }}>
                      <div style={{ fontSize: '11px', color: 'var(--muted-foreground)' }}>Win Rate</div>
                      <div style={{ fontWeight: 600, color: (agent.win_rate || 0) >= 50 ? 'var(--trading-profit)' : 'var(--trading-loss)' }}>{fmt(agent.win_rate || 0)}%</div>
                    </div>
                    <div style={{ background: 'var(--background)', borderRadius: '8px', padding: '8px' }}>
                      <div style={{ fontSize: '11px', color: 'var(--muted-foreground)' }}>Positions</div>
                      <div style={{ fontWeight: 600 }}>{agent.openPositionCount ?? 0} open / {agent.total_trades} total</div>
                    </div>
                  </div>

                  {/* Wallet bar */}
                  <div style={{ display: 'flex', alignItems: 'center', gap: '6px', marginBottom: '8px', flexWrap: 'wrap' }}>
                    <span style={{ fontSize: '12px', color: 'var(--muted-foreground)' }}>💳</span>
                    {agent.wallet_public_key ? (
                      <>
                        <span style={{ fontSize: '12px', color: '#9945FF', fontWeight: 600 }}>{solBal.toFixed(4)} SOL</span>
                        {solUsdPrice > 0 && <span style={{ fontSize: '11px', color: 'var(--muted-foreground)' }}>(${(solBal * solUsdPrice).toFixed(2)})</span>}
                      </>
                    ) : (
                      <span style={{ fontSize: '12px', color: 'var(--muted-foreground)' }}>No wallet</span>
                    )}
                    <div style={{ marginLeft: 'auto', display: 'flex', gap: '4px' }}>
                      {/* Execution mode toggle */}
                      <button onClick={() => toggleExecutionMode(agent)}
                        style={{ ...s.btnSm(agent.execution_mode === 'live' ? 'var(--trading-loss)44' : 'var(--trading-profit)44', agent.execution_mode === 'live' ? 'var(--trading-loss)' : 'var(--trading-profit)'), fontSize: '10px', fontWeight: 700 }}>
                        {agent.execution_mode === 'live' ? '🔴 LIVE' : '🟢 SIM'}
                      </button>
                      {agent.wallet_public_key && (
                        <>
                          <button onClick={() => fetchAgentWalletBalance(agent.id)} style={s.btnSm('var(--border)', 'var(--muted-foreground)')}>🔄</button>
                          <button onClick={() => setExpandedAgentWallet(isExpanded ? null : agent.id)} style={s.btnSm('var(--border)', 'var(--secondary)')}>
                            {isExpanded ? '▲' : '▼'} Wallet
                          </button>
                        </>
                      )}
                    </div>
                  </div>

                  {/* Wallet address */}
                  {agent.wallet_public_key && (
                    <div style={{ display: 'flex', alignItems: 'center', gap: '4px', marginBottom: '8px' }}>
                      <span style={{ fontSize: '11px', fontFamily: 'monospace', color: 'var(--muted-foreground)', cursor: 'pointer' }} onClick={() => copyToClipboard(agent.wallet_public_key!)}>
                        {agent.wallet_public_key.slice(0, 6)}...{agent.wallet_public_key.slice(-4)} 📋
                      </span>
                      <a href={`https://solscan.io/account/${agent.wallet_public_key}`} target="_blank" rel="noopener noreferrer" style={{ fontSize: '11px', color: 'var(--secondary)', textDecoration: 'none' }}>↗</a>
                    </div>
                  )}

                  {/* Token Holdings */}
                  {tokens.length > 0 && (
                    <div style={{ marginBottom: '8px', background: 'var(--background)', borderRadius: '8px', padding: '8px' }}>
                      <div style={{ fontSize: '11px', color: 'var(--muted-foreground)', marginBottom: '4px' }}>Token Holdings ({tokens.length})</div>
                      {tokens.slice(0, 5).map((tok: any, idx: number) => (
                        <div key={idx} style={{ display: 'flex', justifyContent: 'space-between', fontSize: '12px', padding: '2px 0' }}>
                          <span style={{ color: 'var(--foreground)', fontWeight: 600 }}>{tok.symbol || tok.mint?.slice(0, 6)}</span>
                          <span style={{ color: 'var(--muted-foreground)' }}>{typeof tok.amount === 'number' ? tok.amount.toFixed(2) : tok.amount} {tok.usdValue ? `($${tok.usdValue.toFixed(2)})` : ''}</span>
                        </div>
                      ))}
                      {tokens.length > 5 && <div style={{ fontSize: '11px', color: 'var(--muted-foreground)', marginTop: '2px' }}>+{tokens.length - 5} more</div>}
                    </div>
                  )}

                  {/* Chain badges + risk */}
                  <div style={{ display: 'flex', gap: '4px', marginBottom: '10px', flexWrap: 'wrap', alignItems: 'center' }}>
                    {(agent.preferred_chains || []).map(c => <span key={c} style={s.chainBadge(c)}>{CHAIN_LABELS[c] || c}</span>)}
                    <span style={{ ...s.badge(agent.risk_tolerance === 'aggressive' ? 'var(--trading-loss)' : agent.risk_tolerance === 'medium' ? 'var(--accent)' : 'var(--trading-profit)'), marginLeft: '4px' }}>
                      {agent.risk_tolerance}
                    </span>
                  </div>

                  {/* Expanded Wallet Panel */}
                  {isExpanded && (
                    <div style={{ background: 'var(--background)', borderRadius: '10px', padding: '12px', marginBottom: '10px', border: '1px solid var(--border)' }}>
                      {!agent.wallet_public_key ? (
                        <button onClick={() => generateAgentWallet(agent.id)} disabled={walletActionLoading[agent.id + '_gen']}
                          style={{ ...s.btn('#9945FF'), width: '100%', opacity: walletActionLoading[agent.id + '_gen'] ? 0.5 : 1 }}>
                          {walletActionLoading[agent.id + '_gen'] ? '⏳ Generating...' : '🔑 Generate Wallet'}
                        </button>
                      ) : (
                        <>
                          {/* QR Toggle */}
                          <div style={{ marginBottom: '10px' }}>
                            <button onClick={() => setShowQR(prev => ({ ...prev, [agent.id]: !prev[agent.id] }))} style={s.btnSm('var(--border)', 'var(--muted-foreground)')}>
                              {showQR[agent.id] ? '🔽 Hide QR Code' : '📱 Show QR Code'}
                            </button>
                            {showQR[agent.id] && (
                              <div style={{ marginTop: '8px', textAlign: 'center' as const }}>
                                <img src={`https://api.qrserver.com/v1/create-qr-code/?size=200x200&data=solana:${agent.wallet_public_key}`} alt="QR" style={{ borderRadius: '8px', background: 'var(--foreground)', padding: '8px' }} />
                              </div>
                            )}
                          </div>
                          {/* Full address */}
                          <div style={{ marginBottom: '10px' }}>
                            <div style={{ fontSize: '11px', color: 'var(--muted-foreground)', marginBottom: '4px' }}>Wallet Address</div>
                            <div style={{ display: 'flex', gap: '4px', alignItems: 'center' }}>
                              <code style={{ fontSize: '11px', color: 'var(--foreground)', background: 'var(--border)', padding: '4px 8px', borderRadius: '4px', wordBreak: 'break-all' as const, flex: 1 }}>{agent.wallet_public_key}</code>
                              <button onClick={() => copyToClipboard(agent.wallet_public_key!)} style={s.btnSm('var(--border)', 'var(--muted-foreground)')}>📋</button>
                            </div>
                          </div>
                          {/* SOL Balance */}
                          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '10px', background: 'var(--card)', borderRadius: '8px', padding: '8px' }}>
                            <div>
                              <div style={{ fontSize: '11px', color: 'var(--muted-foreground)' }}>SOL Balance</div>
                              <div style={{ fontSize: '16px', fontWeight: 700, color: '#9945FF' }}>{solBal.toFixed(6)} SOL</div>
                              {solUsdPrice > 0 && <div style={{ fontSize: '12px', color: 'var(--muted-foreground)' }}>≈ ${(solBal * solUsdPrice).toFixed(2)} USD</div>}
                            </div>
                            <div style={{ display: 'flex', gap: '4px' }}>
                              <button onClick={() => fetchAgentWalletBalance(agent.id)} style={s.btnSm('var(--border)', 'var(--muted-foreground)')}>🔄</button>
                              <a href={`https://solscan.io/account/${agent.wallet_public_key}`} target="_blank" rel="noopener noreferrer" style={{ ...s.btnSm('var(--border)', 'var(--secondary)'), textDecoration: 'none' }}>↗ Solscan</a>
                            </div>
                          </div>
                          {/* Fund */}
                          <div style={{ marginBottom: '10px' }}>
                            <div style={{ fontSize: '11px', color: 'var(--muted-foreground)', marginBottom: '4px' }}>Fund (Internal Transfer)</div>
                            <div style={{ display: 'flex', gap: '4px' }}>
                              <input type="number" value={walletFundAmount} onChange={e => setWalletFundAmount(e.target.value)} placeholder="SOL amount" style={{ ...s.input, fontSize: '12px', padding: '4px 8px' }} />
                              <button onClick={() => fundAgentWallet(agent.id)} disabled={walletActionLoading[agent.id + '_fund']}
                                style={{ ...s.btnSm('#9945FF'), opacity: walletActionLoading[agent.id + '_fund'] ? 0.5 : 1 }}>
                                {walletActionLoading[agent.id + '_fund'] ? '...' : '💸 Fund'}
                              </button>
                            </div>
                          </div>
                          {/* Withdraw */}
                          <div>
                            <div style={{ fontSize: '11px', color: 'var(--muted-foreground)', marginBottom: '4px' }}>Withdraw</div>
                            <div style={{ display: 'flex', flexDirection: 'column' as const, gap: '4px' }}>
                              <input value={walletWithdrawAddr} onChange={e => setWalletWithdrawAddr(e.target.value)} placeholder="Destination address" style={{ ...s.input, fontSize: '12px', padding: '4px 8px' }} />
                              <div style={{ display: 'flex', gap: '4px' }}>
                                <input type="number" value={walletWithdrawAmount} onChange={e => setWalletWithdrawAmount(e.target.value)} placeholder="SOL amount" style={{ ...s.input, fontSize: '12px', padding: '4px 8px' }} />
                                <button onClick={() => withdrawAgentWallet(agent.id)} disabled={walletActionLoading[agent.id + '_withdraw']}
                                  style={{ ...s.btnSm('var(--trading-loss)'), opacity: walletActionLoading[agent.id + '_withdraw'] ? 0.5 : 1 }}>
                                  {walletActionLoading[agent.id + '_withdraw'] ? '...' : '📤 Withdraw'}
                                </button>
                              </div>
                            </div>
                          </div>
                        </>
                      )}
                    </div>
                  )}

                  {/* Action buttons */}
                  <div style={{ display: 'flex', gap: '6px', flexWrap: 'wrap' }}>
                    <button onClick={() => runAgentCycle(agent.id)} disabled={memeAgentCycleLoading[agent.id]}
                      style={{ ...s.btn('var(--secondary)'), flex: 1, padding: '6px 8px', fontSize: '12px', opacity: memeAgentCycleLoading[agent.id] ? 0.5 : 1 }}>
                      {memeAgentCycleLoading[agent.id] ? '⏳ Running...' : '🔄 Run Cycle'}
                    </button>
                    <button onClick={() => toggleAgentStatus(agent)}
                      style={{ ...s.btn(agent.status === 'active' ? 'var(--accent)' : 'var(--trading-profit)', '#000'), flex: 1, padding: '6px 8px', fontSize: '12px' }}>
                      {agent.status === 'active' ? '⏸ Pause' : '▶ Activate'}
                    </button>
                    <button onClick={() => { fetchAgentDetail(agent.id) }}
                      style={{ ...s.btn('var(--border)', 'var(--secondary)'), padding: '6px 8px', fontSize: '12px' }}>
                      📋 Details
                    </button>
                    <button onClick={() => deleteAgent(agent.id)} style={{ ...s.btn('var(--border)', 'var(--trading-loss)'), padding: '6px 8px', fontSize: '12px' }}>
                      🗑
                    </button>
                  </div>
                </div>
              )
            })}
          </div>
        )}

        {/* Agent Thought Stream */}
        {memeAgentThoughts.length > 0 && (
          <div style={{ ...s.section, marginTop: '8px' }}>
            <div style={s.sectionTitle}>🧠 Agent Thought Stream</div>
            <div style={{ ...s.card, maxHeight: '400px', overflowY: 'auto' as const }}>
              {memeAgentThoughts.slice(0, 50).map((thought, i) => {
                const icon = THOUGHT_TYPE_ICONS[thought.thought_type] || '💭'
                return (
                  <div key={thought.id || i} style={{ padding: '8px 0', borderBottom: i < memeAgentThoughts.length - 1 ? '1px solid var(--border)' : 'none', display: 'flex', gap: '8px', alignItems: 'flex-start' }}>
                    <span style={{ fontSize: '16px', flexShrink: 0 }}>{icon}</span>
                    <div style={{ flex: 1, minWidth: 0 }}>
                      <div style={{ display: 'flex', gap: '8px', alignItems: 'center', marginBottom: '2px', flexWrap: 'wrap' }}>
                        <span style={{ fontSize: '12px', fontWeight: 700, color: 'var(--secondary)' }}>{thought.agent_name || 'Agent'}</span>
                        <span style={{ ...s.badge('var(--surface-alt)'), fontSize: '10px' }}>{thought.thought_type}</span>
                        {thought.confidence != null && <span style={{ fontSize: '10px', color: 'var(--muted-foreground)' }}>conf: {(thought.confidence * 100).toFixed(0)}%</span>}
                        <span style={{ fontSize: '10px', color: 'var(--muted-foreground)', marginLeft: 'auto' }}>{agentTimeAgo(thought.created_at)}</span>
                      </div>
                      <div style={{ fontSize: '12px', color: 'var(--foreground)', lineHeight: '1.4', wordBreak: 'break-word' as const }}>{thought.content}</div>
                    </div>
                  </div>
                )
              })}
            </div>
          </div>
        )}

        {/* Agent Trades Table */}
        {memeAgentTrades.length > 0 && (
          <div style={s.section}>
            <div style={s.sectionTitle}>📊 Agent Trades</div>
            <div style={{ overflowX: 'auto' }}>
              <table style={{ ...s.table, minWidth: '800px' }}>
                <thead>
                  <tr>
                    <th style={s.th}>Agent</th><th style={s.th}>Token</th><th style={s.th}>Side</th>
                    <th style={s.th}>Amount</th><th style={s.th}>Price</th><th style={s.th}>P&L</th>
                    <th style={s.th}>Reason</th><th style={s.th}>Time</th>
                  </tr>
                </thead>
                <tbody>
                  {memeAgentTrades.slice(0, 50).map((trade, i) => (
                    <tr key={trade.id || i} style={{ background: i % 2 === 0 ? 'transparent' : 'color-mix(in srgb, var(--border) 20%, transparent)' }}>
                      <td style={{ ...s.td, fontWeight: 600, fontSize: '12px' }}>{trade.agent_name || trade.agent_id?.slice(0, 8)}</td>
                      <td style={{ ...s.td, fontWeight: 600 }}>{trade.token_symbol}</td>
                      <td style={s.td}><span style={s.badge(trade.side === 'buy' ? 'var(--trading-profit)' : 'var(--trading-loss)')}>{trade.side?.toUpperCase()}</span></td>
                      <td style={s.td}>{typeof trade.amount === 'number' ? trade.amount.toFixed(4) : trade.amount}</td>
                      <td style={s.td}>{typeof trade.price === 'number' ? fmtPrice(trade.price) : trade.price}</td>
                      <td style={{ ...s.td, color: pctColor(trade.pnl || 0), fontWeight: 600 }}>{trade.pnl != null ? `${trade.pnl >= 0 ? '+' : ''}${fmtUSD(trade.pnl)}` : '—'}</td>
                      <td style={{ ...s.td, fontSize: '11px', color: 'var(--muted-foreground)', maxWidth: '200px', overflow: 'hidden' as const, textOverflow: 'ellipsis' as const, whiteSpace: 'nowrap' as const }}>{trade.reason || '—'}</td>
                      <td style={{ ...s.td, fontSize: '11px', color: 'var(--muted-foreground)' }}>{agentTimeAgo(trade.created_at)}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}
      </div>
    )
  }

  // ── Tab: Settings ─────────────────────────────────────────────────────
  const renderSettings = () => (
    <div style={{ maxWidth: '600px' }}>
      <div style={s.section}>
        <div style={s.sectionTitle}>Budget</div>
        <div style={{ ...s.card, display: 'flex', flexDirection: 'column', gap: '14px' }}>
          <div style={s.formGroup}>
            <label style={s.label}>Total Meme Coin Budget ($)</label>
            <input type="number" value={settings.totalBudget} onChange={e => saveSettings({ ...settings, totalBudget: parseFloat(e.target.value) || 0 })} style={s.input} />
          </div>
          <div style={s.formGroup}>
            <label style={s.label}>Max Allocation Per Token ($)</label>
            <input type="number" value={settings.maxPerToken} onChange={e => saveSettings({ ...settings, maxPerToken: parseFloat(e.target.value) || 0 })} style={s.input} />
          </div>
        </div>
      </div>
      <div style={s.section}>
        <div style={s.sectionTitle}>Scanner</div>
        <div style={{ ...s.card, display: 'flex', flexDirection: 'column', gap: '14px' }}>
          <div style={s.formGroup}>
            <label style={s.label}>Auto-Scan Interval (seconds)</label>
            <input type="number" value={settings.scanInterval} onChange={e => saveSettings({ ...settings, scanInterval: Math.max(10, parseInt(e.target.value) || 30) })} style={s.input} />
          </div>
          <div style={s.formGroup}>
            <label style={s.label}>Chains to Scan</label>
            <div style={{ display: 'flex', gap: '8px', flexWrap: 'wrap' }}>
              {['solana', 'base', 'ethereum', 'bsc', 'arbitrum', 'polygon'].map(c => (
                <label key={c} style={{ display: 'flex', alignItems: 'center', gap: '4px', fontSize: '13px', cursor: 'pointer' }}>
                  <input type="checkbox" checked={settings.chains.includes(c)}
                    onChange={e => {
                      const chains = e.target.checked ? [...settings.chains, c] : settings.chains.filter(x => x !== c)
                      saveSettings({ ...settings, chains })
                    }} />
                  {CHAIN_LABELS[c] || c}
                </label>
              ))}
            </div>
          </div>
        </div>
      </div>
      <div style={s.section}>
        <div style={s.sectionTitle}>Risk Filters</div>
        <div style={{ ...s.card, display: 'flex', flexDirection: 'column', gap: '14px' }}>
          <div style={s.formGroup}>
            <label style={s.label}>Min Liquidity ($)</label>
            <input type="number" value={settings.minLiquidity} onChange={e => saveSettings({ ...settings, minLiquidity: parseFloat(e.target.value) || 0 })} style={s.input} />
          </div>
          <div style={s.formGroup}>
            <label style={s.label}>Min Volume 24h ($)</label>
            <input type="number" value={settings.minVolume} onChange={e => saveSettings({ ...settings, minVolume: parseFloat(e.target.value) || 0 })} style={s.input} />
          </div>
          <div style={s.formGroup}>
            <label style={s.label}>Max Token Age (days, 0 = no limit)</label>
            <input type="number" value={settings.maxAgeDays} onChange={e => saveSettings({ ...settings, maxAgeDays: parseInt(e.target.value) || 0 })} style={s.input} />
          </div>
        </div>
      </div>
    </div>
  )

  // ── Modals ─────────────────────────────────────────────────────────────

  // Token Detail Modal
  const renderTokenDetailModal = () => {
    if (!tokenDetailPair) return null
    const t = tokenDetailPair
    const secKey = `${t.chainId}:${t.baseToken?.address}`
    const sec = securityResults[secKey]
    return (
      <div style={s.modal} onClick={() => { setTokenDetailPair(null); setShowChart(false) }}>
        <div style={s.modalContent} onClick={e => e.stopPropagation()}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '16px' }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
              {t.info?.imageUrl && <img src={t.info.imageUrl} alt="" style={{ width: '32px', height: '32px', borderRadius: '50%' }} />}
              <div>
                <div style={{ fontSize: '18px', fontWeight: 700 }}>{t.baseToken?.symbol}</div>
                <div style={{ fontSize: '13px', color: 'var(--muted-foreground)' }}>{t.baseToken?.name}</div>
              </div>
            </div>
            <button onClick={() => { setTokenDetailPair(null); setShowChart(false) }} style={{ ...s.btn('var(--border)'), padding: '4px 12px' }}>✕</button>
          </div>

          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(150px, 1fr))', gap: '10px', marginBottom: '16px' }}>
            <div style={{ background: 'var(--background)', borderRadius: '8px', padding: '10px' }}>
              <div style={{ fontSize: '11px', color: 'var(--muted-foreground)' }}>Price</div>
              <div style={{ fontSize: '16px', fontWeight: 700 }}>{fmtPrice(t.priceUsd)}</div>
            </div>
            <div style={{ background: 'var(--background)', borderRadius: '8px', padding: '10px' }}>
              <div style={{ fontSize: '11px', color: 'var(--muted-foreground)' }}>24h Change</div>
              <div style={{ fontSize: '16px', fontWeight: 700, color: pctColor(t.priceChange?.h24 || 0) }}>{(t.priceChange?.h24 || 0) >= 0 ? '+' : ''}{fmt(t.priceChange?.h24 || 0)}%</div>
            </div>
            <div style={{ background: 'var(--background)', borderRadius: '8px', padding: '10px' }}>
              <div style={{ fontSize: '11px', color: 'var(--muted-foreground)' }}>Volume 24h</div>
              <div style={{ fontSize: '16px', fontWeight: 700 }}>{fmtCompact(t.volume?.h24 || 0)}</div>
            </div>
            <div style={{ background: 'var(--background)', borderRadius: '8px', padding: '10px' }}>
              <div style={{ fontSize: '11px', color: 'var(--muted-foreground)' }}>Liquidity</div>
              <div style={{ fontSize: '16px', fontWeight: 700 }}>{fmtCompact(t.liquidity?.usd || 0)}</div>
            </div>
            <div style={{ background: 'var(--background)', borderRadius: '8px', padding: '10px' }}>
              <div style={{ fontSize: '11px', color: 'var(--muted-foreground)' }}>Market Cap</div>
              <div style={{ fontSize: '16px', fontWeight: 700 }}>{t.marketCap ? fmtCompact(t.marketCap) : '—'}</div>
            </div>
            <div style={{ background: 'var(--background)', borderRadius: '8px', padding: '10px' }}>
              <div style={{ fontSize: '11px', color: 'var(--muted-foreground)' }}>Age</div>
              <div style={{ fontSize: '16px', fontWeight: 700 }}>{ageStr(t.pairCreatedAt)}</div>
            </div>
          </div>

          {/* Price changes */}
          <div style={{ display: 'flex', gap: '8px', marginBottom: '16px', flexWrap: 'wrap' }}>
            {[{ label: '5m', val: t.priceChange?.m5 }, { label: '1h', val: t.priceChange?.h1 }, { label: '6h', val: t.priceChange?.h6 }, { label: '24h', val: t.priceChange?.h24 }].map(p => (
              <span key={p.label} style={{ ...s.badge(pctColor(p.val || 0)), fontSize: '12px' }}>{p.label}: {(p.val || 0) >= 0 ? '+' : ''}{fmt(p.val || 0)}%</span>
            ))}
          </div>

          {/* Address */}
          <div style={{ marginBottom: '12px', display: 'flex', alignItems: 'center', gap: '8px' }}>
            <span style={{ fontSize: '12px', color: 'var(--muted-foreground)' }}>Contract:</span>
            <code style={{ fontSize: '11px', color: 'var(--foreground)', background: 'var(--border)', padding: '4px 8px', borderRadius: '4px', cursor: 'pointer' }} onClick={() => copyToClipboard(t.baseToken?.address)}>
              {t.baseToken?.address} 📋
            </code>
          </div>

          {/* Chart toggle */}
          <div style={{ marginBottom: '12px' }}>
            <button onClick={() => setShowChart(!showChart)} style={s.btn('var(--primary)')}>
              {showChart ? '🔽 Hide Chart' : '📊 Show Chart'}
            </button>
          </div>
          {showChart && (
            <div style={{ marginBottom: '16px', borderRadius: '8px', overflow: 'hidden', border: '1px solid var(--border)' }}>
              <iframe
                src={`https://dexscreener.com/${t.chainId}/${t.pairAddress}?embed=1&theme=dark`}
                style={{ width: '100%', height: '400px', border: 'none' }}
                title="DexScreener Chart"
              />
            </div>
          )}

          {/* Security */}
          <div style={{ display: 'flex', gap: '8px', flexWrap: 'wrap', marginBottom: '12px' }}>
            <button onClick={() => fetchSecurityScan(t.baseToken?.address, t.chainId)} style={s.btn('var(--border)', 'var(--muted-foreground)')}>
              {sec?.loading ? '⏳ Scanning...' : '🛡️ Run Security Scan'}
            </button>
            {sec && !sec.loading && sec.goplus && (
              <div style={{ display: 'flex', gap: '4px', flexWrap: 'wrap', alignItems: 'center' }}>
                <span style={s.badge(sec.goplus.isHoneypot ? 'var(--trading-loss)' : 'var(--trading-profit)')}>{sec.goplus.isHoneypot ? '🍯 Honeypot!' : '✅ Safe'}</span>
                <span style={s.badge(sec.goplus.isOpenSource ? 'var(--trading-profit)' : 'var(--accent)')}>{sec.goplus.isOpenSource ? '📖 Open' : '🔒 Closed'}</span>
                {sec.goplus.holderCount && <span style={s.badge('var(--surface-alt)')}>Holders: {sec.goplus.holderCount}</span>}
                {sec.goplus.buyTax && <span style={s.badge('var(--surface-alt)')}>Buy Tax: {sec.goplus.buyTax}%</span>}
                {sec.goplus.sellTax && <span style={s.badge('var(--surface-alt)')}>Sell Tax: {sec.goplus.sellTax}%</span>}
              </div>
            )}
            {sec && !sec.loading && sec.rugcheck && (
              <span style={s.badge(sec.rugcheck.score >= 70 ? 'var(--trading-profit)' : sec.rugcheck.score >= 40 ? 'var(--accent)' : 'var(--trading-loss)')}>
                RugCheck: {sec.rugcheck.score}/100
              </span>
            )}
          </div>

          {/* Links */}
          <div style={{ display: 'flex', gap: '8px', flexWrap: 'wrap' }}>
            {t.url && <a href={t.url} target="_blank" rel="noopener noreferrer" style={{ ...s.btn('var(--border)', 'var(--secondary)'), textDecoration: 'none' }}>🔗 DexScreener</a>}
            <a href={`https://dexscreener.com/${t.chainId}/${t.pairAddress}`} target="_blank" rel="noopener noreferrer" style={{ ...s.btn('var(--border)', 'var(--secondary)'), textDecoration: 'none' }}>📊 Full Chart</a>
            {t.chainId === 'solana' && <a href={`https://solscan.io/token/${t.baseToken?.address}`} target="_blank" rel="noopener noreferrer" style={{ ...s.btn('var(--border)', '#9945FF'), textDecoration: 'none' }}>Solscan</a>}
            {t.chainId === 'ethereum' && <a href={`https://etherscan.io/token/${t.baseToken?.address}`} target="_blank" rel="noopener noreferrer" style={{ ...s.btn('var(--border)', '#627EEA'), textDecoration: 'none' }}>Etherscan</a>}
            {t.chainId === 'base' && <a href={`https://basescan.org/token/${t.baseToken?.address}`} target="_blank" rel="noopener noreferrer" style={{ ...s.btn('var(--border)', '#0052FF'), textDecoration: 'none' }}>Basescan</a>}
            {t.info?.websites?.map((w, i) => <a key={i} href={w.url} target="_blank" rel="noopener noreferrer" style={{ ...s.btn('var(--border)', 'var(--muted-foreground)'), textDecoration: 'none' }}>🌐 {w.label || 'Website'}</a>)}
            {t.info?.socials?.map((soc, i) => <a key={i} href={soc.url} target="_blank" rel="noopener noreferrer" style={{ ...s.btn('var(--border)', 'var(--muted-foreground)'), textDecoration: 'none' }}>{soc.type === 'twitter' ? '🐦' : '💬'} {soc.type}</a>)}
          </div>
        </div>
      </div>
    )
  }

  // Create Agent Modal
  const renderCreateAgentModal = () => {
    if (!showCreateAgent) return null
    return (
      <div style={s.modal} onClick={() => setShowCreateAgent(false)}>
        <div style={{ ...s.modalContent, maxWidth: '500px' }} onClick={e => e.stopPropagation()}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '20px' }}>
            <div style={{ fontSize: '18px', fontWeight: 700 }}>🤖 Create Trading Agent</div>
            <button onClick={() => setShowCreateAgent(false)} style={{ ...s.btn('var(--border)'), padding: '4px 12px' }}>✕</button>
          </div>

          <div style={{ display: 'flex', flexDirection: 'column', gap: '14px' }}>
            <div style={s.formGroup}>
              <label style={s.label}>Agent Name</label>
              <input value={newAgentName} onChange={e => setNewAgentName(e.target.value)} placeholder="e.g. Alpha Hunter" style={s.input} />
            </div>

            <div style={s.formGroup}>
              <label style={s.label}>Strategy</label>
              <select value={newAgentStrategy} onChange={e => setNewAgentStrategy(e.target.value)} style={s.select}>
                {Object.entries(AGENT_STRATEGIES).map(([key, info]) => (
                  <option key={key} value={key}>{info.emoji} {info.name}</option>
                ))}
              </select>
            </div>

            <div style={s.formGroup}>
              <label style={s.label}>Budget ($)</label>
              <input type="number" value={newAgentBudget} onChange={e => setNewAgentBudget(e.target.value)} placeholder="100" style={s.input} />
            </div>

            <div style={s.formGroup}>
              <label style={s.label}>Risk Tolerance</label>
              <select value={newAgentRisk} onChange={e => setNewAgentRisk(e.target.value)} style={s.select}>
                <option value="conservative">Conservative</option>
                <option value="medium">Medium</option>
                <option value="aggressive">Aggressive</option>
              </select>
            </div>

            <div style={s.formGroup}>
              <label style={s.label}>Chains</label>
              <div style={{ display: 'flex', gap: '8px', flexWrap: 'wrap' }}>
                {['solana', 'base', 'ethereum', 'bsc'].map(c => (
                  <label key={c} style={{ display: 'flex', alignItems: 'center', gap: '4px', fontSize: '13px', cursor: 'pointer' }}>
                    <input type="checkbox" checked={newAgentChains.includes(c)}
                      onChange={e => {
                        setNewAgentChains(e.target.checked ? [...newAgentChains, c] : newAgentChains.filter(x => x !== c))
                      }} />
                    {CHAIN_LABELS[c] || c}
                  </label>
                ))}
              </div>
            </div>

            <div style={s.formGroup}>
              <label style={s.label}>Execution Mode</label>
              <div style={{ display: 'flex', gap: '8px' }}>
                <button onClick={() => setNewAgentMode('simulation')}
                  style={{ ...s.btn(newAgentMode === 'simulation' ? 'var(--trading-profit)' : 'var(--border)', newAgentMode === 'simulation' ? '#000' : 'var(--muted-foreground)'), flex: 1 }}>
                  🟢 Simulation
                </button>
                <button onClick={() => setNewAgentMode('live')}
                  style={{ ...s.btn(newAgentMode === 'live' ? 'var(--trading-loss)' : 'var(--border)', newAgentMode === 'live' ? 'var(--foreground)' : 'var(--muted-foreground)'), flex: 1 }}>
                  🔴 Live
                </button>
              </div>
              {newAgentMode === 'live' && <div style={{ fontSize: '11px', color: 'var(--trading-loss)', marginTop: '4px' }}>⚠️ Live mode uses real funds!</div>}
            </div>

            <button onClick={createAgent} disabled={createAgentLoading || !newAgentName.trim()}
              style={{ ...s.btn('var(--primary)'), padding: '10px', fontSize: '14px', opacity: createAgentLoading || !newAgentName.trim() ? 0.5 : 1, marginTop: '8px' }}>
              {createAgentLoading ? '⏳ Creating...' : '🤖 Create Agent'}
            </button>
          </div>
        </div>
      </div>
    )
  }

  // Agent Detail Modal
  const renderAgentDetailModal = () => {
    if (!agentDetailData) return null
    const d = agentDetailData
    const agent = d.agent || {}
    const thoughts = d.thoughts || []
    const detailTrades = d.trades || []
    const positions = d.positions || []
    const stratInfo = getAgentStrategyInfo(agent.strategy)
    const detailWb = agentWalletBalances[agent.id]
    const detailSolBal = detailWb?.sol || 0
    const detailTokens = detailWb?.tokens || []

    return (
      <div style={s.modal} onClick={() => setAgentDetailData(null)}>
        <div style={{ ...s.modalContent, maxWidth: '800px' }} onClick={e => e.stopPropagation()}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '16px' }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
              <span style={{ fontSize: '24px' }}>{stratInfo.emoji}</span>
              <div>
                <div style={{ fontSize: '18px', fontWeight: 700 }}>{agent.name || 'Agent'}</div>
                <div style={{ fontSize: '12px', color: 'var(--muted-foreground)' }}>{stratInfo.name} • {agent.status}</div>
              </div>
            </div>
            <button onClick={() => setAgentDetailData(null)} style={{ ...s.btn('var(--border)'), padding: '4px 12px' }}>✕</button>
          </div>

          {/* QR + Wallet */}
          {agent.wallet_public_key && (
            <div style={{ ...s.card, marginBottom: '16px' }}>
              <div style={{ marginBottom: '8px' }}>
                <button onClick={() => setShowQR(prev => ({ ...prev, ['detail']: !prev['detail'] }))} style={s.btnSm('var(--border)', 'var(--muted-foreground)')}>
                  {showQR['detail'] ? '🔽 Hide QR' : '📱 Deposit QR'}
                </button>
                {showQR['detail'] && (
                  <div style={{ marginTop: '8px', textAlign: 'center' as const }}>
                    <img src={`https://api.qrserver.com/v1/create-qr-code/?size=200x200&data=solana:${agent.wallet_public_key}`} alt="QR" style={{ borderRadius: '8px', background: 'var(--foreground)', padding: '8px' }} />
                  </div>
                )}
              </div>
              <div style={{ display: 'flex', alignItems: 'center', gap: '4px', marginBottom: '8px' }}>
                <code style={{ fontSize: '11px', color: 'var(--foreground)', background: 'var(--border)', padding: '4px 8px', borderRadius: '4px', wordBreak: 'break-all' as const }}>{agent.wallet_public_key}</code>
                <button onClick={() => copyToClipboard(agent.wallet_public_key)} style={s.btnSm('var(--border)', 'var(--muted-foreground)')}>📋</button>
              </div>
              <div style={{ fontSize: '14px', fontWeight: 700, color: '#9945FF' }}>
                {detailSolBal.toFixed(6)} SOL {solUsdPrice > 0 && <span style={{ color: 'var(--muted-foreground)', fontWeight: 400, fontSize: '12px' }}>(${(detailSolBal * solUsdPrice).toFixed(2)})</span>}
              </div>
              {/* Token holdings */}
              {detailTokens.length > 0 && (
                <div style={{ marginTop: '8px' }}>
                  <div style={{ fontSize: '11px', color: 'var(--muted-foreground)', marginBottom: '4px' }}>Token Holdings ({detailTokens.length})</div>
                  {detailTokens.map((tok: any, idx: number) => (
                    <div key={idx} style={{ display: 'flex', justifyContent: 'space-between', fontSize: '12px', padding: '2px 0' }}>
                      <span style={{ color: 'var(--foreground)', fontWeight: 600 }}>{tok.symbol || tok.mint?.slice(0, 8)}</span>
                      <span style={{ color: 'var(--muted-foreground)' }}>{typeof tok.amount === 'number' ? tok.amount.toFixed(4) : tok.amount} {tok.usdValue ? `($${tok.usdValue.toFixed(2)})` : ''}</span>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          {/* Thoughts */}
          {thoughts.length > 0 && (
            <div style={{ marginBottom: '16px' }}>
              <div style={{ fontSize: '14px', fontWeight: 600, marginBottom: '8px' }}>🧠 Recent Thoughts</div>
              <div style={{ ...s.card, maxHeight: '250px', overflowY: 'auto' as const }}>
                {thoughts.slice(0, 20).map((thought: any, i: number) => (
                  <div key={i} style={{ padding: '6px 0', borderBottom: i < thoughts.length - 1 ? '1px solid var(--border)' : 'none', fontSize: '12px' }}>
                    <div style={{ display: 'flex', gap: '6px', alignItems: 'center', marginBottom: '2px' }}>
                      <span>{THOUGHT_TYPE_ICONS[thought.thought_type] || '💭'}</span>
                      <span style={s.badge('var(--surface-alt)')}>{thought.thought_type}</span>
                      {thought.confidence != null && <span style={{ fontSize: '10px', color: 'var(--muted-foreground)' }}>{(thought.confidence * 100).toFixed(0)}%</span>}
                      <span style={{ fontSize: '10px', color: 'var(--muted-foreground)', marginLeft: 'auto' }}>{agentTimeAgo(thought.created_at)}</span>
                    </div>
                    <div style={{ color: 'var(--foreground)', lineHeight: '1.4' }}>{thought.content}</div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Trades */}
          {detailTrades.length > 0 && (
            <div style={{ marginBottom: '16px' }}>
              <div style={{ fontSize: '14px', fontWeight: 600, marginBottom: '8px' }}>📊 Trades</div>
              <div style={{ overflowX: 'auto' }}>
                <table style={{ ...s.table, minWidth: '600px' }}>
                  <thead><tr>{['Token', 'Side', 'Amount', 'Price', 'P&L', 'Time'].map(h => <th key={h} style={s.th}>{h}</th>)}</tr></thead>
                  <tbody>
                    {detailTrades.slice(0, 20).map((trade: any, i: number) => (
                      <tr key={i} style={{ background: i % 2 === 0 ? 'transparent' : 'color-mix(in srgb, var(--border) 20%, transparent)' }}>
                        <td style={{ ...s.td, fontWeight: 600 }}>{trade.token_symbol}</td>
                        <td style={s.td}><span style={s.badge(trade.side === 'buy' ? 'var(--trading-profit)' : 'var(--trading-loss)')}>{trade.side?.toUpperCase()}</span></td>
                        <td style={s.td}>{typeof trade.amount === 'number' ? trade.amount.toFixed(4) : trade.amount}</td>
                        <td style={s.td}>{typeof trade.price === 'number' ? fmtPrice(trade.price) : trade.price}</td>
                        <td style={{ ...s.td, color: pctColor(trade.pnl || 0), fontWeight: 600 }}>{trade.pnl != null ? `${trade.pnl >= 0 ? '+' : ''}$${fmt(trade.pnl)}` : '—'}</td>
                        <td style={{ ...s.td, fontSize: '11px', color: 'var(--muted-foreground)' }}>{agentTimeAgo(trade.created_at)}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {/* Positions */}
          {positions.length > 0 && (
            <div>
              <div style={{ fontSize: '14px', fontWeight: 600, marginBottom: '8px' }}>📈 Open Positions</div>
              <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))', gap: '8px' }}>
                {positions.map((pos: any, i: number) => (
                  <div key={i} style={{ background: 'var(--background)', borderRadius: '8px', padding: '10px', border: '1px solid var(--border)' }}>
                    <div style={{ fontWeight: 600, fontSize: '13px', marginBottom: '4px' }}>{pos.token_symbol || pos.token_address?.slice(0, 8)}</div>
                    <div style={{ fontSize: '12px', color: 'var(--muted-foreground)' }}>
                      Entry: {pos.entry_price ? fmtPrice(pos.entry_price) : '—'}
                    </div>
                    <div style={{ fontSize: '12px', color: 'var(--muted-foreground)' }}>
                      Amount: {typeof pos.amount === 'number' ? pos.amount.toFixed(4) : pos.amount}
                    </div>
                    {pos.current_pnl != null && (
                      <div style={{ fontSize: '12px', color: pctColor(pos.current_pnl), fontWeight: 600, marginTop: '4px' }}>
                        P&L: {pos.current_pnl >= 0 ? '+' : ''}{fmtUSD(pos.current_pnl)}
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    )
  }

  const tabContent = [renderScanner, renderNewPairs, renderWatchlist, renderSearch, renderTrades, renderAlerts, renderSmartMoney, renderAgents, renderSettings]

  return (
    <div style={s.page}>
      {/* Toast */}
      {toastMessage && <div style={s.toast(toastMessage.type)}>{toastMessage.text}</div>}

      {/* Modals */}
      {renderTokenDetailModal()}
      {renderCreateAgentModal()}
      {renderAgentDetailModal()}

      {/* Header */}
      <div style={s.header}>
        <h1 style={s.title}>🚀 Meme Coin Scanner</h1>
        <div style={s.headerRight}>
          <span style={{ fontSize: '12px', color: 'var(--muted-foreground)' }}>Powered by DexScreener • Jupiter</span>
        </div>
      </div>

      {/* Stats Cards */}
      <div style={s.cards}>
        {[
          { label: 'Total Budget', value: fmtUSD(settings.totalBudget), color: 'var(--foreground)' },
          { label: 'Allocated', value: fmtUSD(totalAllocated), color: 'var(--secondary)' },
          { label: 'Available', value: fmtUSD(available), color: available >= 0 ? 'var(--trading-profit)' : 'var(--trading-loss)' },
          { label: 'Watching', value: String(watchlist.length), color: 'var(--primary)' },
          { label: 'Trades', value: String(trades.length), color: 'var(--accent)' },
          { label: 'Agents', value: `${agentStats.active}/${agentStats.total}`, color: 'var(--secondary)' },
          { label: 'Best 24h', value: bestPerformer ? `${bestPerformer.baseToken?.symbol} +${fmt(bestPerformer.priceChange?.h24 || 0)}%` : '—', color: 'var(--trading-profit)' },
        ].map(c => (
          <div key={c.label} style={s.card}>
            <div style={s.cardLabel}>{c.label}</div>
            <div style={{ ...s.cardValue, color: c.color }}>{c.value}</div>
          </div>
        ))}
      </div>

      {/* Tabs */}
      <div style={s.tabs}>
        {TAB_NAMES.map((name, i) => (
          <button key={name} onClick={() => setTab(i)} style={s.tab(tab === i)}>{name}</button>
        ))}
      </div>

      {/* Content */}
      <div style={s.content}>
        {tabContent[tab]()}
      </div>
    </div>
  )
}