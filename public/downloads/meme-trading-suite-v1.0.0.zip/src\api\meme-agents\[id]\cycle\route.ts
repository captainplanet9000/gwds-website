export const dynamic = 'force-dynamic';
import { NextRequest, NextResponse } from 'next/server';
import { runAgentCycle } from '@/lib/meme-agent-engine';

export async function POST(request: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  try {
    const { id } = await params;
    const result = await runAgentCycle(id);
    return NextResponse.json({ result });
  } catch (e: any) {
    return NextResponse.json({ error: e.message }, { status: 500 });
  }
}
