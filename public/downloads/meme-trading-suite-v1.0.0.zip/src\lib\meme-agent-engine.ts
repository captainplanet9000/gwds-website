// Meme Agent Engine — Autonomous trading cycle
import * as db from './meme-agents-db';
import { getStrategy, type TokenData, type SecurityInfo } from './meme-agent-strategies';
import { buyToken, sellToken, getTokenPrice as getJupiterPrice, SOL_MINT } from './solana-trade-executor';
import { getBalance } from './solana-wallet-manager';
import { sendNotification, NotificationChannel } from './notifications';
import {
  enhancedEntryAnalysis,
  enhancedExitAnalysis,
  detectMarketRegime,
  analyzeMultiTimeframe,
  calculateAdaptiveStopLevels,
  type EnhancedEntrySignal,
  type EnhancedExitSignal,
} from './meme-agent-signal-engine';

// ─── Live SOL/USD price lookup ───
let cachedSolPrice: { price: number; fetchedAt: number } | null = null;
const SOL_PRICE_CACHE_MS = 30_000; // 30s cache

async function getSolUsdPrice(): Promise<number> {
  if (cachedSolPrice && Date.now() - cachedSolPrice.fetchedAt < SOL_PRICE_CACHE_MS) {
    return cachedSolPrice.price;
  }
  try {
    const res = await fetch(`https://api.jup.ag/price/v2?ids=${SOL_MINT}`);
    if (res.ok) {
      const data = await res.json();
      const price = data.data?.[SOL_MINT]?.price;
      if (price && price > 0) {
        cachedSolPrice = { price, fetchedAt: Date.now() };
        return price;
      }
    }
  } catch {}
  // Fallback to cached or reasonable default
  return cachedSolPrice?.price || 150;
}

function usdToSol(usdAmount: number, solPrice: number): number {
  return usdAmount / solPrice;
}

// Circuit breaker state (in-memory, resets on server restart)
const tradeCounters: Record<string, { count: number; hourStart: number }> = {};
const dailyPnL: Record<string, { pnl: number; dayStart: number }> = {};

// ─── Trailing Stop State (in-memory per position) ──────────────────
interface TrailingStopState {
  highWaterMark: number;   // highest price since entry
  trailingStopPct: number; // trailing stop distance %
  trailingStopPrice: number; // computed trailing stop price
  partialTakeProfitPct: number | null; // partial TP level as % above entry
  partialExitDone: boolean; // whether partial exit already happened
}

const trailingStops: Record<string, TrailingStopState> = {}; // keyed by position ID

function updateTrailingStop(posId: string, currentPrice: number, entryPrice: number, trailingPct: number, partialTPPct: number | null): TrailingStopState {
  if (!trailingStops[posId]) {
    trailingStops[posId] = {
      highWaterMark: currentPrice,
      trailingStopPct: trailingPct,
      trailingStopPrice: currentPrice * (1 - trailingPct),
      partialTakeProfitPct: partialTPPct,
      partialExitDone: false,
    };
  }
  const state = trailingStops[posId];
  // Update high water mark
  if (currentPrice > state.highWaterMark) {
    state.highWaterMark = currentPrice;
    state.trailingStopPrice = currentPrice * (1 - state.trailingStopPct);
  }
  return state;
}

function clearTrailingStop(posId: string) {
  delete trailingStops[posId];
}

// Failed token blocklist — skip tokens that fail 3+ times (resets after 1 hour)
const failedTokens: Record<string, { count: number; lastFail: number }> = {};
const FAIL_THRESHOLD = 3;
const FAIL_COOLDOWN_MS = 3600000; // 1 hour

function isTokenBlocked(tokenAddress: string): boolean {
  const entry = failedTokens[tokenAddress];
  if (!entry) return false;
  if (Date.now() - entry.lastFail > FAIL_COOLDOWN_MS) {
    delete failedTokens[tokenAddress];
    return false;
  }
  return entry.count >= FAIL_THRESHOLD;
}

function recordTokenFailure(tokenAddress: string) {
  if (!failedTokens[tokenAddress]) {
    failedTokens[tokenAddress] = { count: 0, lastFail: 0 };
  }
  failedTokens[tokenAddress].count++;
  failedTokens[tokenAddress].lastFail = Date.now();
}

function checkCircuitBreaker(agentId: string, agent: db.MemeAgent): string | null {
  const now = Date.now();

  // Max 10 trades/hour
  if (!tradeCounters[agentId] || now - tradeCounters[agentId].hourStart > 3600000) {
    tradeCounters[agentId] = { count: 0, hourStart: now };
  }
  if (tradeCounters[agentId].count >= 10) {
    return 'Circuit breaker: max 10 trades/hour reached';
  }

  // Auto-pause if daily loss > 20%
  if (!dailyPnL[agentId] || now - dailyPnL[agentId].dayStart > 86400000) {
    dailyPnL[agentId] = { pnl: 0, dayStart: now };
  }
  if (agent.allocated_budget > 0 && dailyPnL[agentId].pnl < -(agent.allocated_budget * 0.2)) {
    db.updateAgent(agentId, { status: 'paused' } as any);
    return 'Circuit breaker: daily loss > 20%, agent auto-paused';
  }

  return null;
}

function recordTrade(agentId: string, pnl: number) {
  if (tradeCounters[agentId]) tradeCounters[agentId].count++;
  if (dailyPnL[agentId]) dailyPnL[agentId].pnl += pnl;
}

export interface CycleResult {
  agentId: string;
  tokensAnalyzed: number;
  buysExecuted: number;
  sellsExecuted: number;
  thoughtsGenerated: number;
  errors: string[];
  duration: number;
}

// Fetch trending tokens from DexScreener
async function fetchDexScreenerTokens(chains: string[]): Promise<TokenData[]> {
  const tokens: TokenData[] = [];
  try {
    // Boosted tokens
    const boostRes = await fetch('https://api.dexscreener.com/token-boosts/latest/v1');
    if (boostRes.ok) {
      const boosts = await boostRes.json();
      if (Array.isArray(boosts)) {
        for (const b of boosts.slice(0, 20)) {
          if (chains.length && !chains.some(c => b.chainId?.toLowerCase().includes(c.toLowerCase()))) continue;
          try {
            const pairRes = await fetch(`https://api.dexscreener.com/latest/dex/tokens/${b.tokenAddress}`);
            if (pairRes.ok) {
              const pd = await pairRes.json();
              if (pd.pairs?.[0]) tokens.push({ ...pd.pairs[0], boostAmount: b.amount || 0 });
            }
          } catch {}
        }
      }
    }
  } catch {}

  try {
    // Trending tokens
    const trendRes = await fetch('https://api.dexscreener.com/token-boosts/top/v1');
    if (trendRes.ok) {
      const trends = await trendRes.json();
      if (Array.isArray(trends)) {
        const existing = new Set(tokens.map(t => t.baseToken?.address));
        for (const t of trends.slice(0, 15)) {
          if (existing.has(t.tokenAddress)) continue;
          if (chains.length && !chains.some(c => t.chainId?.toLowerCase().includes(c.toLowerCase()))) continue;
          try {
            const pairRes = await fetch(`https://api.dexscreener.com/latest/dex/tokens/${t.tokenAddress}`);
            if (pairRes.ok) {
              const pd = await pairRes.json();
              if (pd.pairs?.[0]) { tokens.push({ ...pd.pairs[0], boostAmount: t.totalAmount || 0 }); existing.add(pd.pairs[0].baseToken?.address); }
            }
          } catch {}
        }
      }
    }
  } catch {}

  return tokens;
}

// Simple security scan (simulated — uses heuristics since we can't always hit GoPlus)
function quickSecurityScan(token: TokenData): SecurityInfo {
  const age = (Date.now() - (token.pairCreatedAt || 0)) / 3600000;
  const liq = token.liquidity?.usd || 0;
  const vol = token.volume?.h24 || 0;

  let score: SecurityInfo['overallScore'] = 'safe';
  const honeypot = false;
  const mintable = age < 1 ? null : false;
  const lpLocked = liq > 100000 ? true : null;
  const contractVerified = age > 24 ? true : null;

  if (age < 1 && liq < 5000) score = 'danger';
  else if (age < 6 && liq < 20000) score = 'warning';
  else if (liq < 10000) score = 'warning';

  return {
    overallScore: score,
    details: {
      honeypot, mintable, lpLocked, contractVerified,
      taxInfo: { buyTax: null, sellTax: null },
      topHolderPct: null,
    },
  };
}

// Execute simulated buy — accepts optional enhanced SL/TP levels
function simulateBuy(agent: db.MemeAgent, token: TokenData, amount: number, reason: string, secScore: string, customStopLoss?: number, customTakeProfit?: number): { trade: db.MemeAgentTrade; position: db.MemeAgentPosition } | null {
  const price = parseFloat(token.priceUsd || '0');
  if (price <= 0 || amount <= 0) return null;
  if (amount > agent.current_balance) amount = agent.current_balance * 0.9;
  if (amount < 1) return null;

  const quantity = amount / price;
  // Simulate slippage (0.5-2%)
  const slippage = 1 + (Math.random() * 0.015 + 0.005);
  const fillPrice = price * slippage;

  const trade = db.createTrade({
    agent_id: agent.id, token_address: token.baseToken.address, chain_id: token.chainId,
    symbol: token.baseToken.symbol, name: token.baseToken.name, side: 'buy',
    amount_usd: amount, price: fillPrice, quantity: amount / fillPrice,
    pnl: 0, pnl_pct: 0, entry_reason: reason, exit_reason: '', security_score: secScore,
  });

  // Use custom SL/TP from enhanced signal engine if provided, otherwise fallback to risk-based
  const riskMult = agent.risk_tolerance === 'aggressive' ? 1.5 : agent.risk_tolerance === 'conservative' ? 0.6 : 1;
  const stopLoss = customStopLoss ?? fillPrice * (1 - 0.15 * riskMult);
  const takeProfit = customTakeProfit ?? fillPrice * (1 + 0.4 * riskMult);
  const position = db.createPosition({
    agent_id: agent.id, token_address: token.baseToken.address, chain_id: token.chainId,
    symbol: token.baseToken.symbol, name: token.baseToken.name,
    entry_price: fillPrice, current_price: fillPrice,
    quantity: amount / fillPrice, amount_usd: amount,
    unrealized_pnl: 0, unrealized_pnl_pct: 0,
    stop_loss: stopLoss,
    take_profit: takeProfit,
  });

  // Update agent balance
  db.updateAgent(agent.id, {
    current_balance: agent.current_balance - amount,
    total_trades: agent.total_trades + 1,
  } as any);

  return { trade, position };
}

// Execute simulated PARTIAL sell — sells a percentage of the position
function simulatePartialSell(agent: db.MemeAgent, position: db.MemeAgentPosition, token: TokenData, reason: string, exitPercent: number): db.MemeAgentTrade | null {
  const price = parseFloat(token.priceUsd || '0');
  if (price <= 0 || exitPercent <= 0 || exitPercent > 100) return null;

  const fraction = exitPercent / 100;
  const sellQty = position.quantity * fraction;
  const sellAmountUsd = position.amount_usd * fraction;

  const slippage = 1 - (Math.random() * 0.015 + 0.005);
  const fillPrice = price * slippage;
  const proceeds = sellQty * fillPrice;
  const pnl = proceeds - sellAmountUsd;
  const pnlPct = (pnl / sellAmountUsd) * 100;

  const trade = db.createTrade({
    agent_id: agent.id, token_address: position.token_address, chain_id: position.chain_id,
    symbol: position.symbol, name: position.name, side: 'sell',
    amount_usd: proceeds, price: fillPrice, quantity: sellQty,
    pnl, pnl_pct: pnlPct, entry_reason: '', exit_reason: `${reason} (${exitPercent}% partial)`, security_score: '',
  });

  // Update agent P&L
  const wins = pnl > 0 ? 1 : 0;
  const newTotalTrades = agent.total_trades + 1;
  const oldWins = Math.round(agent.win_rate * agent.total_trades / 100);
  const newWinRate = newTotalTrades > 0 ? ((oldWins + wins) / newTotalTrades) * 100 : 0;

  db.updateAgent(agent.id, {
    current_balance: agent.current_balance + proceeds,
    total_pnl: agent.total_pnl + pnl,
    total_trades: newTotalTrades,
    win_rate: newWinRate,
  } as any);

  // Reduce position (don't delete — partial exit)
  const remainingQty = position.quantity - sellQty;
  const remainingAmountUsd = position.amount_usd - sellAmountUsd;
  db.updatePosition(position.id, {
    quantity: remainingQty,
    amount_usd: remainingAmountUsd,
    current_price: fillPrice,
    unrealized_pnl: (fillPrice - position.entry_price) * remainingQty,
    unrealized_pnl_pct: ((fillPrice - position.entry_price) / position.entry_price) * 100,
  });

  return trade;
}

// Execute simulated sell
function simulateSell(agent: db.MemeAgent, position: db.MemeAgentPosition, token: TokenData, reason: string): db.MemeAgentTrade | null {
  const price = parseFloat(token.priceUsd || '0');
  if (price <= 0) return null;

  const slippage = 1 - (Math.random() * 0.015 + 0.005);
  const fillPrice = price * slippage;
  const proceeds = position.quantity * fillPrice;
  const pnl = proceeds - position.amount_usd;
  const pnlPct = (pnl / position.amount_usd) * 100;

  const trade = db.createTrade({
    agent_id: agent.id, token_address: position.token_address, chain_id: position.chain_id,
    symbol: position.symbol, name: position.name, side: 'sell',
    amount_usd: proceeds, price: fillPrice, quantity: position.quantity,
    pnl, pnl_pct: pnlPct, entry_reason: '', exit_reason: reason, security_score: '',
  });

  // Update agent
  const wins = pnl > 0 ? 1 : 0;
  const newTotalTrades = agent.total_trades + 1;
  const oldWins = Math.round(agent.win_rate * agent.total_trades / 100);
  const newWinRate = newTotalTrades > 0 ? ((oldWins + wins) / newTotalTrades) * 100 : 0;

  db.updateAgent(agent.id, {
    current_balance: agent.current_balance + proceeds,
    total_pnl: agent.total_pnl + pnl,
    total_trades: newTotalTrades,
    win_rate: newWinRate,
  } as any);

  db.deletePosition(position.id);
  return trade;
}

export async function runAgentCycle(agentId: string): Promise<CycleResult> {
  const start = Date.now();
  const result: CycleResult = { agentId, tokensAnalyzed: 0, buysExecuted: 0, sellsExecuted: 0, thoughtsGenerated: 0, errors: [], duration: 0 };

  const agent = db.getAgent(agentId);
  if (!agent) { result.errors.push('Agent not found'); return result; }
  if (agent.status !== 'active') { result.errors.push(`Agent is ${agent.status}`); return result; }

  const strategy = getStrategy(agent.strategy);
  const isLive = agent.execution_mode === 'live';
  const wallet = isLive ? db.getAgentWallet(agentId) : null;

  // Sync on-chain balance to DB for live agents
  if (isLive && wallet) {
    try {
      const realSolBalance = await getBalance(wallet.publicKey);
      const solPrice = await getSolUsdPrice();
      const realUsdBalance = realSolBalance * solPrice;
      db.updateAgent(agentId, { current_balance: realUsdBalance, allocated_budget: Math.max(agent.allocated_budget, realUsdBalance) } as any);
      // Re-read agent with updated balance
      Object.assign(agent, { current_balance: realUsdBalance, allocated_budget: Math.max(agent.allocated_budget, realUsdBalance) });
    } catch (err: any) {
      db.createThought({ agent_id: agentId, thought_type: 'observation', content: `⚠️ Failed to sync on-chain balance: ${err.message}` });
    }
  }

  // Circuit breaker check for live agents
  if (isLive) {
    const cbError = checkCircuitBreaker(agentId, agent);
    if (cbError) {
      db.createThought({ agent_id: agentId, thought_type: 'observation', content: `🛑 ${cbError}` });
      sendNotification({ title: `🛑 CIRCUIT BREAKER: ${agent.name}`, message: cbError, type: 'alert', channels: [NotificationChannel.LOG, NotificationChannel.TELEGRAM_PREP] });
      result.errors.push(cbError);
      result.duration = Date.now() - start;
      return result;
    }
  }

  // Step 1: Observation — fetch market data
  db.createThought({ agent_id: agentId, thought_type: 'observation', content: `Starting cycle. Strategy: ${strategy.name}. Balance: $${agent.current_balance.toFixed(2)}`, confidence: null });
  result.thoughtsGenerated++;

  let tokens: TokenData[] = [];
  try {
    tokens = await fetchDexScreenerTokens(agent.preferred_chains);
    db.createThought({ agent_id: agentId, thought_type: 'observation', content: `Fetched ${tokens.length} tokens from DexScreener`, confidence: null, market_context: { tokenCount: tokens.length, chains: agent.preferred_chains } });
    result.thoughtsGenerated++;
  } catch (err: any) {
    result.errors.push(`Fetch error: ${err.message}`);
    db.createThought({ agent_id: agentId, thought_type: 'observation', content: `Failed to fetch market data: ${err.message}`, confidence: null });
    result.thoughtsGenerated++;
    result.duration = Date.now() - start;
    return result;
  }

  result.tokensAnalyzed = tokens.length;
  if (tokens.length === 0) {
    db.createThought({ agent_id: agentId, thought_type: 'observation', content: 'No tokens found. Market quiet or API issue.', confidence: null });
    result.thoughtsGenerated++;
    result.duration = Date.now() - start;
    return result;
  }

  // Step 2: Analysis
  const agentConfig = {
    risk_tolerance: agent.risk_tolerance, max_position_size: agent.max_position_size,
    min_liquidity: agent.min_liquidity, min_volume: agent.min_volume,
    max_token_age_hours: agent.max_token_age_hours, security_min_score: agent.security_min_score,
    current_balance: agent.current_balance, allocated_budget: agent.allocated_budget,
    preferred_chains: agent.preferred_chains,
  };

  const analysis = strategy.analyzeMarket(tokens, agentConfig);
  const topCandidates = analysis.scores.filter(s => s.score > 30).slice(0, 5);

  db.createThought({
    agent_id: agentId, thought_type: 'analysis',
    content: `${analysis.summary}. Top candidates: ${topCandidates.map(c => `${c.token.baseToken?.symbol} (${c.score}pts)`).join(', ') || 'none'}`,
    confidence: topCandidates.length > 0 ? topCandidates[0].score : 10,
    market_context: { candidateCount: topCandidates.length },
  });
  result.thoughtsGenerated++;

  // Step 3: Check existing positions for sell signals (with trailing stops + partial exits)
  const positions = db.getAgentPositions(agentId);
  for (const pos of positions) {
    const matchingToken = tokens.find(t => t.baseToken?.address === pos.token_address);
    if (matchingToken) {
      const currentPrice = parseFloat(matchingToken.priceUsd || '0');
      if (currentPrice > 0) {
        const pnl = (currentPrice - pos.entry_price) * pos.quantity;
        const pnlPct = ((currentPrice - pos.entry_price) / pos.entry_price) * 100;
        db.updatePosition(pos.id, { current_price: currentPrice, unrealized_pnl: pnl, unrealized_pnl_pct: pnlPct });

        const posData = { ...pos, current_price: currentPrice, unrealized_pnl: pnl, unrealized_pnl_pct: pnlPct };

        // ── Trailing stop management ──
        // Get the adaptive stop levels for this position's regime
        const posRegime = detectMarketRegime(matchingToken);
        const adaptiveStops = calculateAdaptiveStopLevels(pos.entry_price, 70, posRegime, agentConfig);

        // Update trailing stop (uses trailingStopPct if in uptrend with decent confidence)
        let trailingTriggered = false;
        if (adaptiveStops.trailingStopPct && pnlPct > 5) {
          // Only activate trailing after 5% profit
          const tsState = updateTrailingStop(pos.id, currentPrice, pos.entry_price, adaptiveStops.trailingStopPct, adaptiveStops.partialTakeProfitPct);

          // Check if trailing stop is hit
          if (currentPrice <= tsState.trailingStopPrice) {
            trailingTriggered = true;
            const trailingReason = `Trailing stop hit (HWM: $${tsState.highWaterMark.toFixed(6)}, trail: ${(tsState.trailingStopPct * 100).toFixed(1)}%)`;
            db.createThought({ agent_id: agentId, thought_type: 'decision', content: `📉 TRAILING STOP ${pos.symbol}: ${trailingReason} — locking +${pnlPct.toFixed(1)}%`, confidence: 90, token_data: { symbol: pos.symbol, pnlPct, highWaterMark: tsState.highWaterMark } });
            result.thoughtsGenerated++;

            if (isLive && wallet) {
              try {
                const liveResult = await sellToken(wallet.encryptedKey, pos.token_address, pos.quantity, 150);
                if (liveResult.success) {
                  result.sellsExecuted++;
                  recordTrade(agentId, pnl);
                  db.createTrade({ agent_id: agentId, token_address: pos.token_address, chain_id: 'solana', symbol: pos.symbol, name: pos.name, side: 'sell', amount_usd: pos.amount_usd + pnl, price: currentPrice, quantity: pos.quantity, pnl, pnl_pct: pnlPct, entry_reason: '', exit_reason: trailingReason, security_score: '', tx_hash: liveResult.txHash || '' });
                  db.deletePosition(pos.id);
                  clearTrailingStop(pos.id);
                  sendNotification({ title: `📉 TRAILING STOP: ${pos.symbol}`, message: `Agent ${agent.name} — trailing stop sold ${pos.symbol} — P&L: +$${pnl.toFixed(2)} — tx: ${liveResult.txHash?.slice(0,8)}...`, type: 'trade', channels: [NotificationChannel.LOG, NotificationChannel.TELEGRAM_PREP] });
                  result.thoughtsGenerated++;
                }
              } catch (err: any) {
                db.createThought({ agent_id: agentId, thought_type: 'execution', content: `❌ TRAILING SELL ERROR: ${err.message}`, confidence: 0 });
                result.thoughtsGenerated++;
              }
            } else {
              const freshAgent = db.getAgent(agentId)!;
              const sellTrade = simulateSell(freshAgent, pos, matchingToken, trailingReason);
              if (sellTrade) {
                result.sellsExecuted++;
                clearTrailingStop(pos.id);
                db.createThought({ agent_id: agentId, thought_type: 'execution', content: `📉 Trailing stop sold ${pos.symbol} at $${currentPrice.toFixed(6)} — P&L: +$${sellTrade.pnl.toFixed(2)} (${sellTrade.pnl_pct.toFixed(1)}%)`, confidence: 90 });
                sendNotification({ title: `⚪ SIM TRAILING STOP: ${pos.symbol}`, message: `Agent ${agent.name} trailing stop ${pos.symbol} — P&L: +$${sellTrade.pnl.toFixed(2)}`, type: 'trade', channels: [NotificationChannel.LOG] });
                result.thoughtsGenerated++;
              }
            }
            continue; // Position handled by trailing stop, skip other checks
          }

          // ── Partial exit at partial TP level ──
          if (!tsState.partialExitDone && tsState.partialTakeProfitPct && pnlPct >= tsState.partialTakeProfitPct * 100) {
            tsState.partialExitDone = true;
            const partialReason = `Partial TP at +${pnlPct.toFixed(1)}% (target was ${(tsState.partialTakeProfitPct * 100).toFixed(1)}%)`;
            db.createThought({ agent_id: agentId, thought_type: 'decision', content: `🎯 PARTIAL EXIT 50% ${pos.symbol}: ${partialReason}`, confidence: 80, token_data: { symbol: pos.symbol, pnlPct } });
            result.thoughtsGenerated++;

            if (!isLive) {
              // Simulated partial exit — sell 50%
              const freshAgent = db.getAgent(agentId)!;
              const partialTrade = simulatePartialSell(freshAgent, pos, matchingToken, partialReason, 50);
              if (partialTrade) {
                result.sellsExecuted++;
                db.createThought({ agent_id: agentId, thought_type: 'execution', content: `🎯 Partial sold 50% ${pos.symbol} — locked +$${partialTrade.pnl.toFixed(2)}. Trailing remainder.`, confidence: 80 });
                sendNotification({ title: `⚪ SIM PARTIAL TP: ${pos.symbol}`, message: `Agent ${agent.name} partial exit 50% ${pos.symbol} — +$${partialTrade.pnl.toFixed(2)}`, type: 'trade', channels: [NotificationChannel.LOG] });
                result.thoughtsGenerated++;
                // Move stop loss to breakeven after partial exit
                db.updatePosition(pos.id, { stop_loss: pos.entry_price });
              }
            } else if (wallet) {
              // Live partial exit — sell half the quantity
              try {
                const halfQty = pos.quantity * 0.5;
                const liveResult = await sellToken(wallet.encryptedKey, pos.token_address, halfQty, 150);
                if (liveResult.success) {
                  result.sellsExecuted++;
                  const partialPnl = pnl * 0.5;
                  recordTrade(agentId, partialPnl);
                  db.createTrade({ agent_id: agentId, token_address: pos.token_address, chain_id: 'solana', symbol: pos.symbol, name: pos.name, side: 'sell', amount_usd: pos.amount_usd * 0.5 + partialPnl, price: currentPrice, quantity: halfQty, pnl: partialPnl, pnl_pct: pnlPct, entry_reason: '', exit_reason: partialReason, security_score: '', tx_hash: liveResult.txHash || '' });
                  db.updatePosition(pos.id, { quantity: pos.quantity - halfQty, amount_usd: pos.amount_usd * 0.5, stop_loss: pos.entry_price });
                  sendNotification({ title: `🎯 PARTIAL TP: ${pos.symbol}`, message: `Agent ${agent.name} partial exit 50% ${pos.symbol} — +$${partialPnl.toFixed(2)} — tx: ${liveResult.txHash?.slice(0,8)}...`, type: 'trade', channels: [NotificationChannel.LOG, NotificationChannel.TELEGRAM_PREP] });
                  result.thoughtsGenerated++;
                }
              } catch (err: any) {
                db.createThought({ agent_id: agentId, thought_type: 'execution', content: `❌ PARTIAL SELL ERROR: ${err.message}`, confidence: 0 });
                result.thoughtsGenerated++;
              }
            }
            continue; // Handled partial exit this cycle, skip remaining checks for this position
          }
        }

        // ── Regular exit analysis (only if trailing stop didn't trigger) ──
        if (!trailingTriggered) {
          const sellSignal = strategy.shouldSell(posData, matchingToken, agentConfig);
          const enhancedExit: EnhancedExitSignal = enhancedExitAnalysis(posData, matchingToken, agentConfig);

          // Combine: exit if either strategy or enhanced analysis says so
          const shouldSell = sellSignal.sell || enhancedExit.shouldExit;
          const exitReason = sellSignal.sell ? sellSignal.reason : enhancedExit.reason;
          const exitConfidence = sellSignal.sell ? sellSignal.confidence : (enhancedExit.urgency === 'critical' ? 95 : enhancedExit.urgency === 'high' ? 85 : 70);

          // ── Respect partial exit percentage from enhanced analysis ──
          const exitPercent = enhancedExit.exitPercent > 0 && enhancedExit.exitPercent < 100 && !sellSignal.sell
            ? enhancedExit.exitPercent : 100;

          if (shouldSell) {
            db.createThought({ agent_id: agentId, thought_type: 'decision', content: `${exitPercent < 100 ? `PARTIAL SELL ${exitPercent}%` : 'SELL'} ${pos.symbol}: ${exitReason}${enhancedExit.shouldExit && !sellSignal.sell ? ' [enhanced exit]' : ''}`, confidence: exitConfidence, token_data: { symbol: pos.symbol, pnlPct, exitUrgency: enhancedExit.urgency, exitPercent } });
            result.thoughtsGenerated++;

            if (isLive && wallet) {
              // LIVE sell (full or partial based on exitPercent)
              try {
                const sellQty = exitPercent < 100 ? pos.quantity * (exitPercent / 100) : pos.quantity;
                const liveResult = await sellToken(wallet.encryptedKey, pos.token_address, sellQty, 150);
                if (liveResult.success) {
                  result.sellsExecuted++;
                  const sellPnl = pnl * (exitPercent / 100);
                  recordTrade(agentId, sellPnl);
                  db.createTrade({
                    agent_id: agentId, token_address: pos.token_address, chain_id: 'solana',
                    symbol: pos.symbol, name: pos.name, side: 'sell',
                    amount_usd: (pos.amount_usd + pnl) * (exitPercent / 100), price: currentPrice, quantity: sellQty,
                    pnl: sellPnl, pnl_pct: pnlPct, entry_reason: '', exit_reason: exitReason,
                    security_score: '', tx_hash: liveResult.txHash || '',
                  });
                  if (exitPercent >= 100) {
                    db.deletePosition(pos.id);
                    clearTrailingStop(pos.id);
                  } else {
                    db.updatePosition(pos.id, { quantity: pos.quantity - sellQty, amount_usd: pos.amount_usd * (1 - exitPercent / 100) });
                  }
                  db.createThought({ agent_id: agentId, thought_type: 'execution', content: `🔴 LIVE ${exitPercent < 100 ? `PARTIAL ${exitPercent}% ` : ''}SELL ${pos.symbol} — tx: ${liveResult.txHash} — P&L: ${sellPnl >= 0 ? '+' : ''}$${sellPnl.toFixed(2)}`, confidence: exitConfidence });
                  sendNotification({ title: `🔴 LIVE ${exitPercent < 100 ? 'PARTIAL ' : ''}SELL: ${pos.symbol}`, message: `Agent ${agent.name} sold ${exitPercent}% of ${pos.symbol} — P&L: ${sellPnl >= 0 ? '+' : ''}$${sellPnl.toFixed(2)} — tx: ${liveResult.txHash?.slice(0,8)}...`, type: 'trade', channels: [NotificationChannel.LOG, NotificationChannel.TELEGRAM_PREP] });
                  result.thoughtsGenerated++;
                } else {
                  db.createThought({ agent_id: agentId, thought_type: 'execution', content: `❌ LIVE SELL FAILED ${pos.symbol}: ${liveResult.error}`, confidence: 0 });
                  sendNotification({ title: `❌ TRADE FAILED: ${pos.symbol}`, message: `Agent ${agent.name} failed to sell ${pos.symbol}: ${liveResult.error}`, type: 'alert', channels: [NotificationChannel.LOG, NotificationChannel.TELEGRAM_PREP] });
                  result.thoughtsGenerated++;
                }
              } catch (err: any) {
                db.createThought({ agent_id: agentId, thought_type: 'execution', content: `❌ LIVE SELL ERROR: ${err.message}`, confidence: 0 });
                sendNotification({ title: `❌ TRADE FAILED: ${pos.symbol}`, message: `Agent ${agent.name} failed to sell ${pos.symbol}: ${err.message}`, type: 'alert', channels: [NotificationChannel.LOG, NotificationChannel.TELEGRAM_PREP] });
                result.thoughtsGenerated++;
              }
            } else {
              // Simulated sell (full or partial)
              const freshAgent = db.getAgent(agentId)!;
              if (exitPercent < 100) {
                const partialTrade = simulatePartialSell(freshAgent, pos, matchingToken, exitReason, exitPercent);
                if (partialTrade) {
                  result.sellsExecuted++;
                  db.createThought({ agent_id: agentId, thought_type: 'execution', content: `Partial sold ${exitPercent}% ${pos.symbol} at $${currentPrice.toFixed(6)} — P&L: ${partialTrade.pnl >= 0 ? '+' : ''}$${partialTrade.pnl.toFixed(2)} (${partialTrade.pnl_pct.toFixed(1)}%)`, confidence: exitConfidence });
                  sendNotification({ title: `⚪ SIM PARTIAL SELL: ${pos.symbol}`, message: `Agent ${agent.name} partial sold ${exitPercent}% ${pos.symbol} — P&L: ${partialTrade.pnl >= 0 ? '+' : ''}$${partialTrade.pnl.toFixed(2)}`, type: 'trade', channels: [NotificationChannel.LOG] });
                  result.thoughtsGenerated++;
                }
              } else {
                const sellTrade = simulateSell(freshAgent, pos, matchingToken, exitReason);
                if (sellTrade) {
                  result.sellsExecuted++;
                  clearTrailingStop(pos.id);
                  db.createThought({ agent_id: agentId, thought_type: 'execution', content: `Sold ${pos.symbol} at $${parseFloat(matchingToken.priceUsd).toFixed(6)} — P&L: ${sellTrade.pnl >= 0 ? '+' : ''}$${sellTrade.pnl.toFixed(2)} (${sellTrade.pnl_pct.toFixed(1)}%)`, confidence: exitConfidence });
                  sendNotification({ title: `⚪ SIM SELL: ${pos.symbol}`, message: `Agent ${agent.name} sold ${pos.symbol} — P&L: ${sellTrade.pnl >= 0 ? '+' : ''}$${sellTrade.pnl.toFixed(2)} (${sellTrade.pnl_pct.toFixed(1)}%)`, type: 'trade', channels: [NotificationChannel.LOG] });
                  result.thoughtsGenerated++;
                }
              }
            }
          }
        }
      }
    }
    // SL/TP check even without matching token data
    if (pos.stop_loss && pos.current_price <= pos.stop_loss) {
      const freshAgent = db.getAgent(agentId)!;
      const fakeToken = tokens[0]; // fallback
      if (fakeToken) {
        db.createThought({ agent_id: agentId, thought_type: 'decision', content: `Stop loss triggered for ${pos.symbol}`, confidence: 95 });
        result.thoughtsGenerated++;
      }
    }
  }

  // Step 4: Buy signals for top candidates
  const currentPositions = db.getAgentPositions(agentId);
  const positionTokens = new Set(currentPositions.map(p => p.token_address));
  const freshAgent = db.getAgent(agentId)!;

  // Max 3 open positions based on risk
  const maxPositions = freshAgent.risk_tolerance === 'aggressive' ? 5 : freshAgent.risk_tolerance === 'conservative' ? 2 : 3;

  for (const candidate of topCandidates) {
    if (currentPositions.length >= maxPositions) break;
    if (positionTokens.has(candidate.token.baseToken?.address)) continue;
    if (freshAgent.current_balance < 5) break;

    const secScan = quickSecurityScan(candidate.token);
    const buySignal = strategy.shouldBuy(candidate.token, secScan, agentConfig);

    if (buySignal.buy && buySignal.confidence > 40) {
      // ── Enhanced signal analysis (multi-timeframe, regime, adaptive sizing) ──
      const enhancedSignal: EnhancedEntrySignal = enhancedEntryAnalysis(
        candidate.token, secScan, agentConfig, buySignal.confidence, buySignal.suggestedAmount
      );

      // Use enhanced confidence and position size
      const finalConfidence = enhancedSignal.confidence;
      const finalAmount = enhancedSignal.adjustedAmount;
      const finalStopLoss = enhancedSignal.stopLevels.stopLoss;
      const finalTakeProfit = enhancedSignal.stopLevels.takeProfit;

      // Log enhanced analysis
      const enhancedReasons = enhancedSignal.reasons.length > 0 ? ` | Enhanced: ${enhancedSignal.reasons.join(', ')}` : '';
      const enhancedWarnings = enhancedSignal.warnings.length > 0 ? ` | ⚠️ ${enhancedSignal.warnings.join(', ')}` : '';

      db.createThought({
        agent_id: agentId, thought_type: 'decision',
        content: `BUY ${candidate.token.baseToken?.symbol}: ${buySignal.reason} (${finalConfidence.toFixed(0)}% enhanced conf, $${finalAmount.toFixed(2)}, regime=${enhancedSignal.regime.regime})${enhancedReasons}${enhancedWarnings}`,
        confidence: finalConfidence,
        token_data: { symbol: candidate.token.baseToken?.symbol, price: candidate.token.priceUsd, score: candidate.score, regime: enhancedSignal.regime.regime, mtfDirection: enhancedSignal.mtfSignal.direction },
      });
      result.thoughtsGenerated++;

      // Skip if enhanced analysis says no
      if (!enhancedSignal.shouldEnter) {
        db.createThought({ agent_id: agentId, thought_type: 'analysis', content: `⏭️ Enhanced filter rejected ${candidate.token.baseToken?.symbol}: conf=${finalConfidence.toFixed(0)}%, MTF=${enhancedSignal.mtfSignal.direction}`, confidence: finalConfidence });
        result.thoughtsGenerated++;
        continue;
      }

      const latestAgent = db.getAgent(agentId)!;

      if (isLive && wallet) {
        // Skip blocked tokens (failed 3+ times recently)
        if (isTokenBlocked(candidate.token.baseToken.address)) {
          db.createThought({ agent_id: agentId, thought_type: 'observation', content: `⏭️ Skipping ${candidate.token.baseToken.symbol} — blocked after repeated failures (cooldown 1h)`, confidence: 0 });
          result.thoughtsGenerated++;
          continue;
        }
        // LIVE execution via Jupiter
        try {
          const solPrice = await getSolUsdPrice();
          const solAmount = usdToSol(buySignal.suggestedAmount, solPrice);
          const liveResult = await buyToken(wallet.encryptedKey, candidate.token.baseToken.address, Math.min(solAmount, 5), 100);
          if (liveResult.success) {
            result.buysExecuted++;
            positionTokens.add(candidate.token.baseToken?.address);
            recordTrade(agentId, 0);
            db.createTrade({
              agent_id: agentId, token_address: candidate.token.baseToken.address, chain_id: 'solana',
              symbol: candidate.token.baseToken.symbol, name: candidate.token.baseToken.name, side: 'buy',
              amount_usd: buySignal.suggestedAmount, price: parseFloat(candidate.token.priceUsd || '0'),
              quantity: liveResult.outputAmount || 0, pnl: 0, pnl_pct: 0,
              entry_reason: buySignal.reason, exit_reason: '', security_score: secScan.overallScore,
              tx_hash: liveResult.txHash || '',
            });
            const fillPrice = parseFloat(candidate.token.priceUsd || '0');
            db.createPosition({
              agent_id: agentId, token_address: candidate.token.baseToken.address, chain_id: 'solana',
              symbol: candidate.token.baseToken.symbol, name: candidate.token.baseToken.name,
              entry_price: fillPrice, current_price: fillPrice, quantity: liveResult.outputAmount || 0,
              amount_usd: finalAmount, unrealized_pnl: 0, unrealized_pnl_pct: 0,
              stop_loss: finalStopLoss, take_profit: finalTakeProfit,
            });
            db.createThought({ agent_id: agentId, thought_type: 'execution', content: `🟢 LIVE BUY ${candidate.token.baseToken.symbol} — tx: ${liveResult.txHash}`, confidence: buySignal.confidence });
            sendNotification({ title: `🟢 LIVE BUY: ${candidate.token.baseToken.symbol}`, message: `Agent ${agent.name} bought ${candidate.token.baseToken.symbol} for ${solAmount.toFixed(4)} SOL — tx: ${liveResult.txHash?.slice(0,8)}...`, type: 'trade', channels: [NotificationChannel.LOG, NotificationChannel.TELEGRAM_PREP] });
            result.thoughtsGenerated++;
          } else {
            recordTokenFailure(candidate.token.baseToken.address);
            db.createThought({ agent_id: agentId, thought_type: 'execution', content: `❌ LIVE BUY FAILED ${candidate.token.baseToken.symbol}: ${liveResult.error}`, confidence: 0 });
            sendNotification({ title: `❌ TRADE FAILED: ${candidate.token.baseToken.symbol}`, message: `Agent ${agent.name} failed to buy ${candidate.token.baseToken.symbol}: ${liveResult.error}`, type: 'alert', channels: [NotificationChannel.LOG, NotificationChannel.TELEGRAM_PREP] });
            result.thoughtsGenerated++;
          }
        } catch (err: any) {
          recordTokenFailure(candidate.token.baseToken.address);
          db.createThought({ agent_id: agentId, thought_type: 'execution', content: `❌ LIVE BUY ERROR: ${err.message}`, confidence: 0 });
          sendNotification({ title: `❌ TRADE FAILED: ${candidate.token.baseToken.symbol}`, message: `Agent ${agent.name} failed to buy ${candidate.token.baseToken.symbol}: ${err.message}`, type: 'alert', channels: [NotificationChannel.LOG, NotificationChannel.TELEGRAM_PREP] });
          result.thoughtsGenerated++;
        }
      } else {
        // SIMULATED execution — uses enhanced position sizing and stop levels
        const buyResult = simulateBuy(latestAgent, candidate.token, finalAmount, buySignal.reason, secScan.overallScore, finalStopLoss, finalTakeProfit);
        if (buyResult) {
          result.buysExecuted++;
          positionTokens.add(candidate.token.baseToken?.address);
          db.createThought({ agent_id: agentId, thought_type: 'execution', content: `Bought ${candidate.token.baseToken?.symbol} — $${finalAmount.toFixed(2)} at $${buyResult.trade.price.toFixed(6)} | SL=$${finalStopLoss.toFixed(6)} TP=$${finalTakeProfit.toFixed(6)} | Regime: ${enhancedSignal.regime.regime}`, confidence: finalConfidence });
          sendNotification({ title: `⚪ SIM BUY: ${candidate.token.baseToken?.symbol}`, message: `Agent ${agent.name} bought ${candidate.token.baseToken?.symbol} — $${finalAmount.toFixed(2)} at $${buyResult.trade.price.toFixed(6)} (${enhancedSignal.regime.regime} regime)`, type: 'trade', channels: [NotificationChannel.LOG] });
          result.thoughtsGenerated++;
        }
      }
    } else if (candidate.score > 50) {
      db.createThought({ agent_id: agentId, thought_type: 'analysis', content: `Skipped ${candidate.token.baseToken?.symbol}: ${buySignal.reason}`, confidence: buySignal.confidence });
      result.thoughtsGenerated++;
    }
  }

  result.duration = Date.now() - start;
  db.createThought({ agent_id: agentId, thought_type: 'observation', content: `Cycle complete in ${(result.duration/1000).toFixed(1)}s — ${result.buysExecuted} buys, ${result.sellsExecuted} sells, ${result.tokensAnalyzed} analyzed`, confidence: null });
  result.thoughtsGenerated++;

  return result;
}

export function getAgentStatus(agentId: string) {
  const agent = db.getAgent(agentId);
  if (!agent) return null;
  const positions = db.getAgentPositions(agentId);
  const recentThoughts = db.getAgentThoughts(agentId, 5);
  return { agent, positions, recentThoughts, openPositionCount: positions.length };
}

// Monitor live positions — check prices, execute SL/TP sells
export async function monitorPositions(agentId: string): Promise<{ checked: number; sold: number; errors: string[] }> {
  const result = { checked: 0, sold: 0, errors: [] as string[] };
  const agent = db.getAgent(agentId);
  if (!agent || agent.execution_mode !== 'live') return result;

  const wallet = db.getAgentWallet(agentId);
  if (!wallet) return result;

  const positions = db.getAgentPositions(agentId);
  for (const pos of positions) {
    result.checked++;
    try {
      const price = await getJupiterPrice(pos.token_address);
      if (!price) continue;

      db.updatePosition(pos.id, {
        current_price: price,
        unrealized_pnl: (price - pos.entry_price) * pos.quantity,
        unrealized_pnl_pct: ((price - pos.entry_price) / pos.entry_price) * 100,
      });

      // Check stop loss
      if (pos.stop_loss && price <= pos.stop_loss) {
        const sellResult = await sellToken(wallet.encryptedKey, pos.token_address, pos.quantity, 200);
        if (sellResult.success) {
          const pnl = (price - pos.entry_price) * pos.quantity;
          recordTrade(agentId, pnl);
          db.createTrade({
            agent_id: agentId, token_address: pos.token_address, chain_id: 'solana',
            symbol: pos.symbol, name: pos.name, side: 'sell',
            amount_usd: pos.amount_usd + pnl, price, quantity: pos.quantity,
            pnl, pnl_pct: ((price - pos.entry_price) / pos.entry_price) * 100,
            entry_reason: '', exit_reason: 'Stop loss triggered',
            security_score: '', tx_hash: sellResult.txHash || '',
          });
          db.deletePosition(pos.id);
          db.createThought({ agent_id: agentId, thought_type: 'execution', content: `🛑 SL TRIGGERED ${pos.symbol} — tx: ${sellResult.txHash}` });
          sendNotification({ title: `🛑 STOP LOSS: ${pos.symbol}`, message: `Agent ${agent.name} — SL triggered for ${pos.symbol} at $${price.toFixed(6)} — P&L: $${pnl.toFixed(2)} — tx: ${sellResult.txHash?.slice(0,8)}...`, type: 'alert', channels: [NotificationChannel.LOG, NotificationChannel.TELEGRAM_PREP] });
          result.sold++;
        }
      }

      // Check take profit
      if (pos.take_profit && price >= pos.take_profit) {
        const sellResult = await sellToken(wallet.encryptedKey, pos.token_address, pos.quantity, 200);
        if (sellResult.success) {
          const pnl = (price - pos.entry_price) * pos.quantity;
          recordTrade(agentId, pnl);
          db.createTrade({
            agent_id: agentId, token_address: pos.token_address, chain_id: 'solana',
            symbol: pos.symbol, name: pos.name, side: 'sell',
            amount_usd: pos.amount_usd + pnl, price, quantity: pos.quantity,
            pnl, pnl_pct: ((price - pos.entry_price) / pos.entry_price) * 100,
            entry_reason: '', exit_reason: 'Take profit hit',
            security_score: '', tx_hash: sellResult.txHash || '',
          });
          db.deletePosition(pos.id);
          db.createThought({ agent_id: agentId, thought_type: 'execution', content: `🎯 TP HIT ${pos.symbol} — tx: ${sellResult.txHash}` });
          sendNotification({ title: `🎯 TAKE PROFIT: ${pos.symbol}`, message: `Agent ${agent.name} — TP hit for ${pos.symbol} at $${price.toFixed(6)} — P&L: $${pnl.toFixed(2)} — tx: ${sellResult.txHash?.slice(0,8)}...`, type: 'trade', channels: [NotificationChannel.LOG, NotificationChannel.TELEGRAM_PREP] });
          result.sold++;
        }
      }
    } catch (err: any) {
      result.errors.push(`${pos.symbol}: ${err.message}`);
    }
  }
  return result;
}
