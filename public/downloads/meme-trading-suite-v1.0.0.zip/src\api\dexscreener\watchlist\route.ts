import { NextResponse } from 'next/server'
export const dynamic = 'force-dynamic'
export async function GET() {
  return NextResponse.json({ watchlist: [], count: 0 })
}
export async function POST(req: Request) {
  const body = await req.json().catch(() => ({}))
  return NextResponse.json({ success: true, action: body.action || 'add', watchlist: [] })
}
