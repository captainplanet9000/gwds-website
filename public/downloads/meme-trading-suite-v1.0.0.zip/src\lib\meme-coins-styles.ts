/**
 * Theme-aware styles for Meme Coins page
 * Replaces hardcoded hex colors with CSS variables for theme support
 */
import React from 'react'

// CSS variable references for theming
const cssVar = {
  background: 'var(--background)',
  surface: 'var(--surface)', 
  surfaceAlt: 'var(--surface-alt)',
  border: 'var(--border)',
  borderStrong: 'var(--border-strong)',
  foreground: 'var(--foreground)',
  muted: 'var(--muted)',
  accent: 'var(--accent)',
  accentHover: 'var(--accent-hover)',
  secondary: 'var(--secondary)',
  success: 'var(--success)',
  danger: 'var(--danger)',
  warning: 'var(--warning)',
}

// ── Theme-Aware Styles ─────────────────────────────────────────────────────
export const s = {
  page: { 
    minHeight: '100vh', 
    background: cssVar.background, 
    color: cssVar.foreground, 
    fontFamily: '-apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif', 
    paddingBottom: '40px', 
    boxSizing: 'border-box' as const, 
    maxWidth: '100%', 
    overflowX: 'hidden' as const 
  } as React.CSSProperties,
  
  header: { 
    display: 'flex', 
    alignItems: 'center', 
    justifyContent: 'space-between', 
    padding: '16px', 
    flexWrap: 'wrap' as const, 
    gap: '12px', 
    borderBottom: `1px solid ${cssVar.border}`, 
    boxSizing: 'border-box' as const, 
    maxWidth: '100%' 
  } as React.CSSProperties,
  
  title: { 
    fontSize: 'clamp(16px, 4vw, 24px)', 
    fontWeight: 700, 
    margin: 0, 
    background: `linear-gradient(135deg, ${cssVar.accent}, ${cssVar.secondary})`, 
    WebkitBackgroundClip: 'text', 
    WebkitTextFillColor: 'transparent' 
  } as React.CSSProperties,
  
  headerRight: { 
    display: 'flex', 
    alignItems: 'center', 
    gap: '12px', 
    flexWrap: 'wrap' as const 
  } as React.CSSProperties,
  
  cards: { 
    display: 'grid', 
    gridTemplateColumns: 'repeat(auto-fit, minmax(min(100%, 150px), 1fr))', 
    gap: '12px', 
    padding: '16px', 
    boxSizing: 'border-box' as const, 
    maxWidth: '100%' 
  } as React.CSSProperties,
  
  card: { 
    background: cssVar.surface, 
    borderRadius: '12px', 
    padding: '14px', 
    border: `1px solid ${cssVar.border}`, 
    boxSizing: 'border-box' as const, 
    overflow: 'hidden' as const, 
    minWidth: 0 
  } as React.CSSProperties,
  
  cardLabel: { 
    fontSize: '12px', 
    color: cssVar.muted, 
    marginBottom: '4px' 
  } as React.CSSProperties,
  
  cardValue: { 
    fontSize: 'clamp(14px, 3.5vw, 20px)', 
    fontWeight: 700, 
    wordBreak: 'break-word' as const, 
    overflowWrap: 'break-word' as const 
  } as React.CSSProperties,
  
  tabs: { 
    display: 'flex', 
    gap: '0', 
    padding: '0 16px', 
    borderBottom: `1px solid ${cssVar.border}`, 
    overflowX: 'auto' as const, 
    maxWidth: '100%', 
    boxSizing: 'border-box' as const 
  } as React.CSSProperties,
  
  tab: (active: boolean) => ({ 
    padding: '10px 20px', 
    cursor: 'pointer', 
    fontSize: '14px', 
    fontWeight: active ? 600 : 400, 
    color: active ? cssVar.accent : cssVar.muted, 
    background: 'none', 
    border: 'none', 
    borderBottomStyle: 'solid' as const, 
    borderBottomWidth: '2px', 
    borderBottomColor: active ? cssVar.accent : 'transparent', 
    whiteSpace: 'nowrap' as const 
  }) as React.CSSProperties,
  
  content: { 
    padding: '16px', 
    boxSizing: 'border-box' as const, 
    maxWidth: '100%', 
    overflowX: 'auto' as const 
  } as React.CSSProperties,
  
  table: { 
    width: '100%', 
    borderCollapse: 'collapse' as const, 
    fontSize: '13px', 
    minWidth: '900px' 
  } as React.CSSProperties,
  
  th: { 
    textAlign: 'left' as const, 
    padding: '10px 12px', 
    color: cssVar.muted, 
    borderBottom: `1px solid ${cssVar.border}`, 
    fontSize: '12px', 
    fontWeight: 600, 
    cursor: 'pointer', 
    userSelect: 'none' as const 
  } as React.CSSProperties,
  
  td: { 
    padding: '10px 12px', 
    borderBottom: `1px solid color-mix(in srgb, ${cssVar.border} 50%, transparent)` 
  } as React.CSSProperties,
  
  badge: (color: string) => ({ 
    display: 'inline-block', 
    padding: '2px 8px', 
    borderRadius: '4px', 
    fontSize: '11px', 
    fontWeight: 600, 
    background: color + '22', 
    color 
  }) as React.CSSProperties,
  
  pnl: (v: number) => ({ 
    color: v >= 0 ? cssVar.success : cssVar.danger, 
    fontWeight: 600 
  }) as React.CSSProperties,
  
  btn: (bg: string, color = '#fff') => ({ 
    background: bg, 
    color, 
    border: 'none', 
    borderRadius: '6px', 
    padding: '6px 14px', 
    cursor: 'pointer', 
    fontSize: '13px', 
    fontWeight: 600, 
    transition: 'opacity .15s' 
  }) as React.CSSProperties,
  
  btnSm: (bg: string, fg = '#fff') => ({ 
    background: bg, 
    color: fg, 
    border: 'none', 
    borderRadius: '4px', 
    padding: '3px 8px', 
    cursor: 'pointer', 
    fontSize: '11px', 
    fontWeight: 600, 
    transition: 'opacity .15s' 
  }) as React.CSSProperties,
  
  // Theme-aware button styles
  btnPrimary: { 
    background: cssVar.accent, 
    color: '#000', 
    border: 'none', 
    borderRadius: '6px', 
    padding: '6px 14px', 
    cursor: 'pointer', 
    fontSize: '13px', 
    fontWeight: 600, 
    transition: 'opacity .15s' 
  } as React.CSSProperties,
  
  btnSecondary: { 
    background: cssVar.secondary, 
    color: '#fff', 
    border: 'none', 
    borderRadius: '6px', 
    padding: '6px 14px', 
    cursor: 'pointer', 
    fontSize: '13px', 
    fontWeight: 600, 
    transition: 'opacity .15s' 
  } as React.CSSProperties,
  
  btnSuccess: { 
    background: cssVar.success, 
    color: '#000', 
    border: 'none', 
    borderRadius: '6px', 
    padding: '6px 14px', 
    cursor: 'pointer', 
    fontSize: '13px', 
    fontWeight: 600, 
    transition: 'opacity .15s' 
  } as React.CSSProperties,
  
  btnDanger: { 
    background: cssVar.danger, 
    color: '#fff', 
    border: 'none', 
    borderRadius: '6px', 
    padding: '6px 14px', 
    cursor: 'pointer', 
    fontSize: '13px', 
    fontWeight: 600, 
    transition: 'opacity .15s' 
  } as React.CSSProperties,
  
  input: { 
    background: cssVar.surfaceAlt, 
    border: `1px solid ${cssVar.border}`, 
    borderRadius: '6px', 
    padding: '8px 12px', 
    color: cssVar.foreground, 
    fontSize: '14px', 
    outline: 'none', 
    width: '100%', 
    boxSizing: 'border-box' as const 
  } as React.CSSProperties,
  
  select: { 
    background: cssVar.surfaceAlt, 
    border: `1px solid ${cssVar.border}`, 
    borderRadius: '6px', 
    padding: '8px 12px', 
    color: cssVar.foreground, 
    fontSize: '14px', 
    outline: 'none' 
  } as React.CSSProperties,
  
  emptyState: { 
    textAlign: 'center' as const, 
    padding: '60px 20px', 
    color: cssVar.muted 
  } as React.CSSProperties,
  
  section: { 
    marginBottom: '20px' 
  } as React.CSSProperties,
  
  sectionTitle: { 
    fontSize: '16px', 
    fontWeight: 600, 
    marginBottom: '12px', 
    color: cssVar.foreground 
  } as React.CSSProperties,
  
  formGroup: { 
    display: 'flex', 
    flexDirection: 'column' as const, 
    gap: '4px' 
  } as React.CSSProperties,
  
  label: { 
    fontSize: '12px', 
    color: cssVar.muted, 
    fontWeight: 600 
  } as React.CSSProperties,
  
  dot: (on: boolean) => ({ 
    width: '8px', 
    height: '8px', 
    borderRadius: '50%', 
    background: on ? cssVar.success : cssVar.danger, 
    display: 'inline-block', 
    marginRight: '4px' 
  }) as React.CSSProperties,
  
  chainBadge: (chain: string) => {
    const colors: Record<string, string> = { 
      solana: '#9945FF', 
      base: '#0052FF', 
      ethereum: '#627EEA', 
      bsc: '#F0B90B', 
      arbitrum: '#28A0F0', 
      polygon: '#8247E5' 
    }
    const c = colors[chain] || cssVar.secondary
    return { 
      display: 'inline-block', 
      padding: '2px 8px', 
      borderRadius: '4px', 
      fontSize: '10px', 
      fontWeight: 600, 
      background: c + '22', 
      color: c, 
      marginRight: '4px' 
    } as React.CSSProperties
  },
  
  modal: { 
    position: 'fixed' as const, 
    top: 0, 
    left: 0, 
    right: 0, 
    bottom: 0, 
    background: 'rgba(0,0,0,0.7)', 
    display: 'flex', 
    alignItems: 'center', 
    justifyContent: 'center', 
    zIndex: 1000, 
    padding: '20px' 
  } as React.CSSProperties,
  
  modalContent: { 
    background: cssVar.surface, 
    borderRadius: '16px', 
    padding: '24px', 
    border: `1px solid ${cssVar.border}`, 
    maxWidth: '700px', 
    width: '100%', 
    maxHeight: '85vh', 
    overflowY: 'auto' as const 
  } as React.CSSProperties,
  
  toast: (type: 'success' | 'error' | 'info') => {
    const colors = {
      success: { bg: `color-mix(in srgb, ${cssVar.success} 15%, transparent)`, border: cssVar.success },
      error: { bg: `color-mix(in srgb, ${cssVar.danger} 15%, transparent)`, border: cssVar.danger },
      info: { bg: `color-mix(in srgb, ${cssVar.accent} 15%, transparent)`, border: cssVar.accent }
    }
    const { bg, border } = colors[type]
    return { 
      position: 'fixed' as const, 
      top: '20px', 
      right: '20px', 
      background: bg, 
      border: `1px solid ${border}`, 
      borderRadius: '8px', 
      padding: '12px 20px', 
      zIndex: 2000, 
      color: cssVar.foreground, 
      fontSize: '14px', 
      fontWeight: 600 
    } as React.CSSProperties
  },
  
  // Agent-specific styles
  agentCard: { 
    background: cssVar.surface, 
    borderRadius: '12px', 
    padding: '16px', 
    border: `1px solid ${cssVar.border}` 
  } as React.CSSProperties,
  
  agentHeader: { 
    display: 'flex', 
    justifyContent: 'space-between', 
    alignItems: 'center', 
    marginBottom: '12px' 
  } as React.CSSProperties,
  
  agentName: { 
    fontSize: '16px', 
    fontWeight: 600, 
    color: cssVar.foreground 
  } as React.CSSProperties,
  
  agentStats: { 
    display: 'grid', 
    gridTemplateColumns: 'repeat(3, 1fr)', 
    gap: '12px' 
  } as React.CSSProperties,
  
  thoughtBubble: { 
    background: cssVar.surfaceAlt, 
    borderRadius: '8px', 
    padding: '12px', 
    marginBottom: '8px', 
    borderLeft: `3px solid ${cssVar.accent}` 
  } as React.CSSProperties,
}

// Color constants for use in dynamic styles
export const colors = {
  accent: cssVar.accent,
  secondary: cssVar.secondary,
  success: cssVar.success,
  danger: cssVar.danger,
  warning: cssVar.warning,
  muted: cssVar.muted,
  foreground: cssVar.foreground,
  background: cssVar.background,
  surface: cssVar.surface,
  border: cssVar.border,
}

// Helper for PnL colors
export const pctColor = (v: number) => v >= 0 ? cssVar.success : cssVar.danger

// Agent status colors (these are brand-specific, keep hardcoded)
export const AGENT_STATUS_COLORS: Record<string, string> = {
  active: '#00ff88', 
  paused: '#f59e0b', 
  stopped: '#ff4444', 
  error: '#ff4444', 
  idle: '#94a3b8'
}

// Strategy colors (brand-specific)
export const AGENT_STRATEGIES: Record<string, { name: string; emoji: string; color: string }> = {
  safety_first: { name: 'Safety First', emoji: '🛡️', color: '#22c55e' },
  momentum_surfer: { name: 'Momentum Surfer', emoji: '🏄', color: '#3b82f6' },
  dip_buyer: { name: 'Dip Buyer', emoji: '📉', color: '#f59e0b' },
  whale_follower: { name: 'Whale Follower', emoji: '🐋', color: '#8b5cf6' },
  volume_spike: { name: 'Volume Spike', emoji: '📊', color: '#ef4444' },
}

export const getAgentStrategyInfo = (strategy: string) => 
  AGENT_STRATEGIES[strategy] || { name: strategy, emoji: '🤖', color: '#94a3b8' }
