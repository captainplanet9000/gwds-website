import { NextResponse } from 'next/server';
import { getAgent, getAgentWallet, setAgentWallet } from '@/lib/meme-agents-db';
import { getBalance, getSPLBalances, transferSOL, keypairFromEncrypted, generateWallet } from '@/lib/solana-wallet-manager';

// GET — wallet balance (SOL + tokens)
export async function GET(_req: Request, { params }: { params: { id: string } }) {
  try {
    const agent = getAgent(params.id);
    if (!agent) return NextResponse.json({ error: 'Agent not found' }, { status: 404 });

    const wallet = getAgentWallet(params.id);
    if (!wallet) return NextResponse.json({ error: 'No wallet assigned' }, { status: 404 });

    const [solBalance, tokenBalances] = await Promise.all([
      getBalance(wallet.publicKey),
      getSPLBalances(wallet.publicKey),
    ]);

    return NextResponse.json({
      publicKey: wallet.publicKey,
      solBalance,
      tokens: tokenBalances,
      executionMode: wallet.executionMode,
    });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}

// POST — fund or withdraw
export async function POST(req: Request, { params }: { params: { id: string } }) {
  try {
    const body = await req.json();
    const { action } = body;

    const agent = getAgent(params.id);
    if (!agent) return NextResponse.json({ error: 'Agent not found' }, { status: 404 });

    const wallet = getAgentWallet(params.id);

    if (action === 'generate') {
      if (wallet) return NextResponse.json({ error: 'Wallet already exists', publicKey: wallet.publicKey }, { status: 400 });
      const newWallet = generateWallet();
      setAgentWallet(params.id, newWallet.publicKey, newWallet.encryptedSecret);
      return NextResponse.json({ success: true, publicKey: newWallet.publicKey });
    }

    if (!wallet) return NextResponse.json({ error: 'No wallet assigned' }, { status: 404 });

    if (action === 'fund') {
      const { amount } = body;
      if (!amount || amount <= 0) return NextResponse.json({ error: 'Invalid amount' }, { status: 400 });

      const mainWalletKey = process.env.MAIN_WALLET_KEY;
      if (!mainWalletKey) return NextResponse.json({ error: 'Main wallet not configured (MAIN_WALLET_KEY)' }, { status: 500 });

      const txHash = await transferSOL(mainWalletKey, wallet.publicKey, amount);
      return NextResponse.json({ success: true, txHash, amount });
    }

    if (action === 'withdraw') {
      const { amount, to } = body;
      if (!amount || amount <= 0) return NextResponse.json({ error: 'Invalid amount' }, { status: 400 });
      if (!to) return NextResponse.json({ error: 'Destination address required' }, { status: 400 });

      const txHash = await transferSOL(wallet.encryptedKey, to, amount);
      return NextResponse.json({ success: true, txHash, amount });
    }

    return NextResponse.json({ error: 'Invalid action. Use "fund" or "withdraw"' }, { status: 400 });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}
