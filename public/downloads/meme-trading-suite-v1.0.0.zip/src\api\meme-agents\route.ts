export const dynamic = 'force-dynamic';
import { NextRequest, NextResponse } from 'next/server';
import * as db from '@/lib/meme-agents-db';
import { getAllStrategies } from '@/lib/meme-agent-strategies';
import { generateWallet } from '@/lib/solana-wallet-manager';

export async function GET() {
  try {
    const agents = db.getAllAgents();
    const allPositions = db.getAllPositions();
    const enriched = agents.map(a => ({
      ...a,
      positions: allPositions.filter(p => p.agent_id === a.id),
      openPositionCount: allPositions.filter(p => p.agent_id === a.id).length,
    }));
    const strategies = getAllStrategies().map(s => ({ id: s.id, name: s.name, emoji: s.emoji, color: s.color, description: s.getDescription() }));
    return NextResponse.json({ agents: enriched, strategies });
  } catch (e: any) {
    return NextResponse.json({ error: e.message }, { status: 500 });
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { name, strategy, allocated_budget, risk_tolerance, preferred_chains, min_liquidity, min_volume, max_token_age_hours, security_min_score, max_position_size, wallet_address } = body;
    if (!name || !strategy || !allocated_budget) {
      return NextResponse.json({ error: 'name, strategy, and allocated_budget required' }, { status: 400 });
    }
    const agent = db.createAgent({ name, strategy, allocated_budget, risk_tolerance, preferred_chains, min_liquidity, min_volume, max_token_age_hours, security_min_score, max_position_size, wallet_address });
    
    // Auto-generate wallet for the new agent
    try {
      const wallet = generateWallet();
      db.setAgentWallet(agent.id, wallet.publicKey, wallet.encryptedSecret);
    } catch (err: any) {
      console.error(`[meme-agents] Failed to auto-generate wallet for ${agent.id}: ${err.message}`);
    }

    const updatedAgent = db.getAgent(agent.id);
    return NextResponse.json({ agent: updatedAgent || agent });
  } catch (e: any) {
    return NextResponse.json({ error: e.message }, { status: 500 });
  }
}

export async function DELETE(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const id = searchParams.get('id');
    if (!id) return NextResponse.json({ error: 'id required' }, { status: 400 });
    db.deleteAgent(id);
    return NextResponse.json({ success: true });
  } catch (e: any) {
    return NextResponse.json({ error: e.message }, { status: 500 });
  }
}

export async function PATCH(request: NextRequest) {
  try {
    const body = await request.json();
    const { id, ...updates } = body;
    if (!id) return NextResponse.json({ error: 'id required' }, { status: 400 });
    const agent = db.updateAgent(id, updates);
    if (!agent) return NextResponse.json({ error: 'Agent not found' }, { status: 404 });
    return NextResponse.json({ agent });
  } catch (e: any) {
    return NextResponse.json({ error: e.message }, { status: 500 });
  }
}
