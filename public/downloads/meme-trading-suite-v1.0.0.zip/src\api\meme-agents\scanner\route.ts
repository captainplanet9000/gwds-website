import { NextRequest, NextResponse } from 'next/server';

export const dynamic = 'force-dynamic';

const HL_API = 'https://api.hyperliquid.xyz';

export async function GET() {
  try {
    // Get all mids and find top movers (potential meme opportunities)
    const [midsRes, metaRes] = await Promise.all([
      fetch(`${HL_API}/info`, {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ type: 'allMids' }),
      }),
      fetch(`${HL_API}/info`, {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ type: 'meta' }),
      }),
    ]);

    const mids = await midsRes.json();
    const meta = await metaRes.json();

    // Known meme coins on Hyperliquid
    const memeCoins = ['DOGE', 'SHIB', 'PEPE', 'WIF', 'BONK', 'FLOKI', 'MEME', 'MYRO', 'MAGA',
      'TRUMP', 'POPCAT', 'MOG', 'NEIRO', 'GOAT', 'PNUT', 'ACT', 'FARTCOIN', 'AI16Z', 'GRIFFAIN',
      'ZEREBRO', 'PENGU', 'SPX', 'HPOS', 'MON', 'BERA', 'KAITO', 'IP', 'TST', 'ANIME', 'VINE'];

    const universe = meta.universe || [];
    const scanned: any[] = [];

    for (const coin of memeCoins) {
      const price = parseFloat(mids[coin]);
      if (!price) continue;

      const assetInfo = universe.find((u: any) => u.name === coin);
      scanned.push({
        coin,
        price,
        maxLeverage: assetInfo?.maxLeverage || 'unknown',
        available: !!assetInfo,
      });
    }

    return NextResponse.json({
      success: true,
      scanned: scanned.length,
      memeCoins: scanned.sort((a, b) => (b.available ? 1 : 0) - (a.available ? 1 : 0)),
      totalSymbols: Object.keys(mids).length,
    });
  } catch (error: any) {
    return NextResponse.json({ success: false, error: error.message }, { status: 500 });
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { action } = body;

    if (action === 'scan') {
      // Trigger a manual scan — same as GET but with scan metadata
      const response = await fetch(`${process.env.NEXT_PUBLIC_APP_URL || 'http://localhost:9005'}/api/meme-agents/scanner`);
      const data = await response.json();
      return NextResponse.json({ ...data, action: 'scan', timestamp: new Date().toISOString() });
    }

    return NextResponse.json({ error: 'Invalid action. Use: scan' }, { status: 400 });
  } catch (error: any) {
    return NextResponse.json({ success: false, error: error.message }, { status: 500 });
  }
}
