export const dynamic = 'force-dynamic';
import { NextRequest, NextResponse } from 'next/server';
import * as db from '@/lib/meme-agents-db';
import { runAgentCycle } from '@/lib/meme-agent-engine';
import * as fs from 'fs';
import * as path from 'path';

const STATE_FILE = path.join(process.cwd(), 'data', 'scheduler-state.json');

interface SchedulerState {
  running: boolean;
  intervalMs: number;
  lastRunTimes: Record<string, string>;
  startedAt: string | null;
  cycleCount: number;
  lastCycleAt: string | null;
}

function loadState(): SchedulerState {
  try {
    if (fs.existsSync(STATE_FILE)) {
      return JSON.parse(fs.readFileSync(STATE_FILE, 'utf-8'));
    }
  } catch {}
  return { running: false, intervalMs: 300000, lastRunTimes: {}, startedAt: null, cycleCount: 0, lastCycleAt: null };
}

function saveState(state: SchedulerState) {
  const dir = path.dirname(STATE_FILE);
  if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
  fs.writeFileSync(STATE_FILE, JSON.stringify(state, null, 2));
}

// In-memory interval handle
let schedulerInterval: ReturnType<typeof setInterval> | null = null;
let isRunningCycle = false;

async function runAllAgents(): Promise<Record<string, any>> {
  if (isRunningCycle) return { skipped: 'cycle already running' };
  isRunningCycle = true;
  const results: Record<string, any> = {};
  try {
    const agents = db.getAllAgents().filter(a => a.status === 'active');
    const state = loadState();
    for (const agent of agents) {
      try {
        const result = await runAgentCycle(agent.id);
        results[agent.id] = { name: agent.name, ...result };
        state.lastRunTimes[agent.id] = new Date().toISOString();
      } catch (err: any) {
        results[agent.id] = { name: agent.name, error: err.message };
      }
    }
    state.cycleCount = (state.cycleCount || 0) + 1;
    state.lastCycleAt = new Date().toISOString();
    saveState(state);
  } finally {
    isRunningCycle = false;
  }
  return results;
}

function startScheduler(intervalMs: number) {
  stopScheduler();
  const state = loadState();
  state.running = true;
  state.intervalMs = intervalMs;
  state.startedAt = new Date().toISOString();
  state.cycleCount = 0;
  state.lastCycleAt = null;
  saveState(state);

  schedulerInterval = setInterval(() => {
    runAllAgents().catch(console.error);
  }, intervalMs);
}

function stopScheduler() {
  if (schedulerInterval) {
    clearInterval(schedulerInterval);
    schedulerInterval = null;
  }
  const state = loadState();
  state.running = false;
  state.startedAt = null;
  saveState(state);
}

// Auto-restore scheduler on module load
(() => {
  const state = loadState();
  if (state.running) {
    schedulerInterval = setInterval(() => {
      runAllAgents().catch(console.error);
    }, state.intervalMs);
  }
})();

export async function GET() {
  const state = loadState();
  const agents = db.getAllAgents();
  const activeCount = agents.filter(a => a.status === 'active').length;
  return NextResponse.json({
    ...state,
    running: !!schedulerInterval,
    cycleCount: state.cycleCount || 0,
    lastCycleAt: state.lastCycleAt || null,
    activeAgents: activeCount,
    totalAgents: agents.length,
    isRunningCycle,
  });
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { action, intervalMs } = body;

    if (action === 'start') {
      const interval = intervalMs || 300000;
      startScheduler(interval);
      return NextResponse.json({ success: true, message: 'Scheduler started', intervalMs: interval });
    }

    if (action === 'stop') {
      stopScheduler();
      return NextResponse.json({ success: true, message: 'Scheduler stopped' });
    }

    if (action === 'runAll') {
      const results = await runAllAgents();
      return NextResponse.json({ success: true, results });
    }

    if (action === 'setInterval') {
      const interval = intervalMs || 300000;
      const state = loadState();
      if (schedulerInterval) {
        startScheduler(interval); // restart with new interval
      } else {
        state.intervalMs = interval;
        saveState(state);
      }
      return NextResponse.json({ success: true, intervalMs: interval });
    }

    return NextResponse.json({ error: 'Invalid action. Use start, stop, runAll, or setInterval' }, { status: 400 });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}
