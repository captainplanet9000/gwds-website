// Solana Wallet Manager — Keypair management with AES-256-GCM encryption
import { Keypair, Connection, PublicKey, LAMPORTS_PER_SOL, Transaction, SystemProgram, sendAndConfirmTransaction } from '@solana/web3.js';
import bs58 from 'bs58';
import crypto from 'crypto';

const DEFAULT_RPC = 'https://api.mainnet-beta.solana.com';

let _connection: Connection | null = null;

export function getConnection(): Connection {
  if (!_connection) {
    const rpcUrl = process.env.SOLANA_RPC_URL || DEFAULT_RPC;
    _connection = new Connection(rpcUrl, 'confirmed');
  }
  return _connection;
}

function getEncryptionKey(): Buffer {
  let key = process.env.WALLET_ENCRYPTION_KEY;
  if (!key) {
    // Auto-generate and warn — in production this should be set
    console.warn('[wallet-manager] WALLET_ENCRYPTION_KEY not set, using fallback. SET THIS IN PRODUCTION!');
    key = 'cival-dashboard-default-key-change-me-in-prod!!';
  }
  // Derive a 32-byte key from whatever string is provided
  return crypto.createHash('sha256').update(key).digest();
}

export function generateWallet(): { publicKey: string; encryptedSecret: string } {
  const keypair = Keypair.generate();
  const secretBase58 = bs58.encode(keypair.secretKey);
  const encryptedSecret = encryptSecret(secretBase58);
  return {
    publicKey: keypair.publicKey.toBase58(),
    encryptedSecret,
  };
}

function encryptSecret(secret: string): string {
  const key = getEncryptionKey();
  const iv = crypto.randomBytes(12);
  const cipher = crypto.createCipheriv('aes-256-gcm', key, iv);
  let encrypted = cipher.update(secret, 'utf8', 'hex');
  encrypted += cipher.final('hex');
  const authTag = cipher.getAuthTag().toString('hex');
  // Format: iv:authTag:ciphertext
  return `${iv.toString('hex')}:${authTag}:${encrypted}`;
}

export function decryptSecret(encrypted: string): Uint8Array {
  try {
    const key = getEncryptionKey();
    const [ivHex, authTagHex, ciphertext] = encrypted.split(':');
    const iv = Buffer.from(ivHex, 'hex');
    const authTag = Buffer.from(authTagHex, 'hex');
    const decipher = crypto.createDecipheriv('aes-256-gcm', key, iv);
    decipher.setAuthTag(authTag);
    let decrypted = decipher.update(ciphertext, 'hex', 'utf8');
    decrypted += decipher.final('utf8');
    return bs58.decode(decrypted);
  } catch (err: any) {
    throw new Error(`Failed to decrypt wallet secret: ${err.message}`);
  }
}

export function keypairFromEncrypted(encrypted: string): Keypair {
  const secretKey = decryptSecret(encrypted);
  return Keypair.fromSecretKey(secretKey);
}

export async function getBalance(publicKey: string): Promise<number> {
  try {
    const conn = getConnection();
    const balance = await conn.getBalance(new PublicKey(publicKey));
    return balance / LAMPORTS_PER_SOL;
  } catch (err: any) {
    console.error(`[wallet-manager] getBalance error: ${err.message}`);
    return 0;
  }
}

export async function getSPLBalances(publicKey: string): Promise<{ mint: string; amount: number; decimals: number }[]> {
  try {
    const conn = getConnection();
    const pubkey = new PublicKey(publicKey);
    const tokenAccounts = await conn.getTokenAccountsByOwner(pubkey, {
      programId: new PublicKey('TokenkegQfeZyiNwAJbNbGKPFXCWuBvf9Ss623VQ5DA'),
    });

    const balances: { mint: string; amount: number; decimals: number }[] = [];

    for (const { account } of tokenAccounts.value) {
      try {
        // Parse token account data (SPL Token layout)
        const data = account.data;
        const mint = new PublicKey(data.slice(0, 32)).toBase58();
        // amount is at offset 64, 8 bytes LE
        const amountBuf = data.slice(64, 72);
        const rawAmount = Number(amountBuf.readBigUInt64LE(0));
        // decimals from mint - we'll use a simpler approach
        // For now read from parsed data if available
        if (rawAmount > 0) {
          balances.push({ mint, amount: rawAmount, decimals: 0 }); // decimals resolved later
        }
      } catch {}
    }

    // Resolve decimals via getParsedTokenAccountsByOwner for non-zero balances
    if (balances.length > 0) {
      try {
        const parsed = await conn.getParsedTokenAccountsByOwner(pubkey, {
          programId: new PublicKey('TokenkegQfeZyiNwAJbNbGKPFXCWuBvf9Ss623VQ5DA'),
        });
        const parsedMap = new Map<string, { amount: number; decimals: number }>();
        for (const { account } of parsed.value) {
          const info = (account.data as any)?.parsed?.info;
          if (info) {
            parsedMap.set(info.mint, {
              amount: parseFloat(info.tokenAmount?.uiAmount || '0'),
              decimals: info.tokenAmount?.decimals || 0,
            });
          }
        }
        return Array.from(parsedMap.entries())
          .filter(([, v]) => v.amount > 0)
          .map(([mint, v]) => ({ mint, amount: v.amount, decimals: v.decimals }));
      } catch {}
    }

    return balances;
  } catch (err: any) {
    console.error(`[wallet-manager] getSPLBalances error: ${err.message}`);
    return [];
  }
}

export async function transferSOL(
  fromEncryptedKey: string,
  toPublicKey: string,
  amountSOL: number
): Promise<string> {
  const conn = getConnection();
  const fromKeypair = keypairFromEncrypted(fromEncryptedKey);
  const toPubkey = new PublicKey(toPublicKey);

  // Check balance
  const balance = await conn.getBalance(fromKeypair.publicKey);
  const lamports = Math.round(amountSOL * LAMPORTS_PER_SOL);
  if (balance < lamports + 5000) {
    throw new Error(`Insufficient balance: have ${balance / LAMPORTS_PER_SOL} SOL, need ${amountSOL} + fees`);
  }

  const tx = new Transaction().add(
    SystemProgram.transfer({
      fromPubkey: fromKeypair.publicKey,
      toPubkey,
      lamports,
    })
  );

  const sig = await sendAndConfirmTransaction(conn, tx, [fromKeypair], {
    commitment: 'confirmed',
  });

  return sig;
}
