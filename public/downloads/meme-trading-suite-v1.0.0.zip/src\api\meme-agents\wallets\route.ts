import { NextResponse } from 'next/server';
import { getAllAgents, getAgent, setAgentWallet } from '@/lib/meme-agents-db';
import { generateWallet } from '@/lib/solana-wallet-manager';

// GET — list agent wallets
export async function GET() {
  try {
    const agents = getAllAgents();
    const wallets = agents
      .filter(a => a.wallet_public_key)
      .map(a => ({
        agentId: a.id,
        agentName: a.name,
        publicKey: a.wallet_public_key,
        executionMode: a.execution_mode || 'simulated',
      }));
    return NextResponse.json({ wallets });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}

// POST — generate wallet for agent
export async function POST(req: Request) {
  try {
    const { agentId } = await req.json();
    if (!agentId) return NextResponse.json({ error: 'agentId required' }, { status: 400 });

    const agent = getAgent(agentId);
    if (!agent) return NextResponse.json({ error: 'Agent not found' }, { status: 404 });

    if (agent.wallet_public_key) {
      return NextResponse.json({ error: 'Agent already has a wallet', publicKey: agent.wallet_public_key }, { status: 400 });
    }

    const wallet = generateWallet();
    setAgentWallet(agentId, wallet.publicKey, wallet.encryptedSecret);

    return NextResponse.json({ publicKey: wallet.publicKey });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}
