export const dynamic = 'force-dynamic';
import { NextRequest, NextResponse } from 'next/server';
import * as db from '@/lib/meme-agents-db';
import { getAgentWallet } from '@/lib/meme-agents-db';
import { syncPositionsWithOnChain } from '@/lib/meme-agent-sync';

/**
 * POST /api/meme-agents/[id]/sync
 * Sync DB positions with on-chain wallet balances.
 */
export async function POST(request: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  try {
    const { id } = await params;
    const agent = db.getAgent(id);
    if (!agent) return NextResponse.json({ error: 'Agent not found' }, { status: 404 });

    const wallet = getAgentWallet(id);
    if (!wallet) return NextResponse.json({ error: 'No wallet assigned' }, { status: 404 });

    const changes = await syncPositionsWithOnChain(id, wallet.publicKey);

    return NextResponse.json({
      ok: true,
      synced: changes.length,
      changes,
    });
  } catch (e: any) {
    return NextResponse.json({ error: e.message }, { status: 500 });
  }
}
