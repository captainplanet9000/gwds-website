// Meme Agent Database Layer — SQLite via better-sqlite3
import * as Database from 'better-sqlite3';
import * as path from 'path';
import { randomUUID } from 'crypto';

const DB_PATH = path.join(process.cwd(), 'data', 'meme-agents.db');

let _db: Database.Database | null = null;

function getDb(): Database.Database {
  if (!_db) {
    const fs = require('fs');
    const dir = path.dirname(DB_PATH);
    if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
    _db = new Database(DB_PATH);
    _db.pragma('journal_mode = WAL');
    _db.pragma('foreign_keys = ON');
    initTables(_db);
    migrateSchema(_db);
  }
  return _db;
}

function initTables(db: Database.Database) {
  db.exec(`
    CREATE TABLE IF NOT EXISTS meme_agents (
      id TEXT PRIMARY KEY,
      name TEXT NOT NULL,
      strategy TEXT NOT NULL,
      status TEXT NOT NULL DEFAULT 'paused',
      allocated_budget REAL NOT NULL DEFAULT 0,
      current_balance REAL NOT NULL DEFAULT 0,
      total_pnl REAL NOT NULL DEFAULT 0,
      total_trades INTEGER NOT NULL DEFAULT 0,
      win_rate REAL NOT NULL DEFAULT 0,
      risk_tolerance TEXT NOT NULL DEFAULT 'medium',
      max_position_size REAL NOT NULL DEFAULT 100,
      preferred_chains TEXT NOT NULL DEFAULT '["solana"]',
      min_liquidity REAL NOT NULL DEFAULT 10000,
      min_volume REAL NOT NULL DEFAULT 5000,
      max_token_age_hours REAL NOT NULL DEFAULT 72,
      security_min_score TEXT NOT NULL DEFAULT 'warning',
      wallet_address TEXT,
      wallet_public_key TEXT,
      wallet_encrypted_key TEXT,
      execution_mode TEXT NOT NULL DEFAULT 'simulated',
      created_at TEXT NOT NULL DEFAULT (datetime('now')),
      updated_at TEXT NOT NULL DEFAULT (datetime('now'))
    );

    CREATE TABLE IF NOT EXISTS meme_agent_trades (
      id TEXT PRIMARY KEY,
      agent_id TEXT NOT NULL,
      token_address TEXT NOT NULL,
      chain_id TEXT NOT NULL,
      symbol TEXT NOT NULL,
      name TEXT,
      side TEXT NOT NULL,
      amount_usd REAL NOT NULL,
      price REAL NOT NULL,
      quantity REAL NOT NULL DEFAULT 0,
      pnl REAL NOT NULL DEFAULT 0,
      pnl_pct REAL NOT NULL DEFAULT 0,
      entry_reason TEXT,
      exit_reason TEXT,
      security_score TEXT,
      tx_hash TEXT,
      timestamp TEXT NOT NULL DEFAULT (datetime('now')),
      FOREIGN KEY (agent_id) REFERENCES meme_agents(id)
    );

    CREATE TABLE IF NOT EXISTS meme_agent_positions (
      id TEXT PRIMARY KEY,
      agent_id TEXT NOT NULL,
      token_address TEXT NOT NULL,
      chain_id TEXT NOT NULL,
      symbol TEXT NOT NULL,
      name TEXT,
      entry_price REAL NOT NULL,
      current_price REAL NOT NULL,
      quantity REAL NOT NULL,
      amount_usd REAL NOT NULL,
      unrealized_pnl REAL NOT NULL DEFAULT 0,
      unrealized_pnl_pct REAL NOT NULL DEFAULT 0,
      stop_loss REAL,
      take_profit REAL,
      opened_at TEXT NOT NULL DEFAULT (datetime('now')),
      FOREIGN KEY (agent_id) REFERENCES meme_agents(id)
    );

    CREATE TABLE IF NOT EXISTS meme_agent_thoughts (
      id TEXT PRIMARY KEY,
      agent_id TEXT NOT NULL,
      thought_type TEXT NOT NULL,
      content TEXT NOT NULL,
      confidence REAL,
      market_context TEXT,
      token_data TEXT,
      created_at TEXT NOT NULL DEFAULT (datetime('now')),
      FOREIGN KEY (agent_id) REFERENCES meme_agents(id)
    );

    CREATE TABLE IF NOT EXISTS meme_agent_config (
      id TEXT PRIMARY KEY,
      agent_id TEXT NOT NULL,
      key TEXT NOT NULL,
      value TEXT,
      FOREIGN KEY (agent_id) REFERENCES meme_agents(id),
      UNIQUE(agent_id, key)
    );

    CREATE INDEX IF NOT EXISTS idx_trades_agent ON meme_agent_trades(agent_id);
    CREATE INDEX IF NOT EXISTS idx_positions_agent ON meme_agent_positions(agent_id);
    CREATE INDEX IF NOT EXISTS idx_thoughts_agent ON meme_agent_thoughts(agent_id, created_at);
    CREATE INDEX IF NOT EXISTS idx_config_agent ON meme_agent_config(agent_id);
  `);
}

function migrateSchema(db: Database.Database) {
  // Add wallet columns if missing (migration for DBs created before wallet support)
  const cols = db.prepare("PRAGMA table_info(meme_agents)").all().map((c: any) => c.name);
  if (!cols.includes('wallet_public_key')) {
    db.exec("ALTER TABLE meme_agents ADD COLUMN wallet_public_key TEXT");
  }
  if (!cols.includes('wallet_encrypted_key')) {
    db.exec("ALTER TABLE meme_agents ADD COLUMN wallet_encrypted_key TEXT");
  }
  if (!cols.includes('execution_mode')) {
    db.exec("ALTER TABLE meme_agents ADD COLUMN execution_mode TEXT NOT NULL DEFAULT 'simulated'");
  }
  // Add tx_hash to trades if missing
  const tradeCols = db.prepare("PRAGMA table_info(meme_agent_trades)").all().map((c: any) => c.name);
  if (!tradeCols.includes('tx_hash')) {
    db.exec("ALTER TABLE meme_agent_trades ADD COLUMN tx_hash TEXT");
  }
}

// ═══════════════ Types
export interface MemeAgent {
  id: string; name: string; strategy: string; status: string;
  allocated_budget: number; current_balance: number; total_pnl: number;
  total_trades: number; win_rate: number; risk_tolerance: string;
  max_position_size: number; preferred_chains: string[];
  min_liquidity: number; min_volume: number; max_token_age_hours: number;
  security_min_score: string; wallet_address: string | null;
  wallet_public_key: string | null; wallet_encrypted_key: string | null;
  execution_mode: string;
  created_at: string; updated_at: string;
}

export interface MemeAgentTrade {
  id: string; agent_id: string; token_address: string; chain_id: string;
  symbol: string; name: string; side: string; amount_usd: number;
  price: number; quantity: number; pnl: number; pnl_pct: number;
  entry_reason: string; exit_reason: string; security_score: string;
  tx_hash?: string; timestamp: string;
}

export interface MemeAgentPosition {
  id: string; agent_id: string; token_address: string; chain_id: string;
  symbol: string; name: string; entry_price: number; current_price: number;
  quantity: number; amount_usd: number; unrealized_pnl: number;
  unrealized_pnl_pct: number; stop_loss: number | null; take_profit: number | null;
  opened_at: string;
}

export interface MemeAgentThought {
  id: string; agent_id: string; thought_type: string; content: string;
  confidence: number | null; market_context: any; token_data: any;
  created_at: string;
}

// ═══════════════ Helpers
function parseAgent(row: any): MemeAgent {
  if (!row) return row;
  return { ...row, preferred_chains: JSON.parse(row.preferred_chains || '[]') };
}

function parseThought(row: any): MemeAgentThought {
  if (!row) return row;
  return {
    ...row,
    market_context: row.market_context ? JSON.parse(row.market_context) : null,
    token_data: row.token_data ? JSON.parse(row.token_data) : null,
  };
}

// ═══════════════ Agent CRUD
export function getAllAgents(): MemeAgent[] {
  return getDb().prepare('SELECT * FROM meme_agents ORDER BY created_at DESC').all().map(parseAgent);
}

export function getAgent(id: string): MemeAgent | null {
  const row = getDb().prepare('SELECT * FROM meme_agents WHERE id = ?').get(id);
  return row ? parseAgent(row) : null;
}

export function createAgent(data: {
  name: string; strategy: string; allocated_budget: number;
  risk_tolerance?: string; preferred_chains?: string[];
  min_liquidity?: number; min_volume?: number; max_token_age_hours?: number;
  security_min_score?: string; max_position_size?: number; wallet_address?: string;
}): MemeAgent {
  const id = randomUUID();
  const chains = JSON.stringify(data.preferred_chains || ['solana']);
  getDb().prepare(`
    INSERT INTO meme_agents (id, name, strategy, status, allocated_budget, current_balance,
      risk_tolerance, max_position_size, preferred_chains, min_liquidity, min_volume,
      max_token_age_hours, security_min_score, wallet_address)
    VALUES (?, ?, ?, 'paused', ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
  `).run(
    id, data.name, data.strategy, data.allocated_budget, data.allocated_budget,
    data.risk_tolerance || 'medium', data.max_position_size || 100,
    chains, data.min_liquidity || 10000, data.min_volume || 5000,
    data.max_token_age_hours || 72, data.security_min_score || 'warning',
    data.wallet_address || null
  );
  return getAgent(id)!;
}

export function updateAgent(id: string, data: Partial<MemeAgent>): MemeAgent | null {
  const fields: string[] = [];
  const values: any[] = [];
  const allowed = ['name', 'strategy', 'status', 'allocated_budget', 'current_balance',
    'total_pnl', 'total_trades', 'win_rate', 'risk_tolerance', 'max_position_size',
    'min_liquidity', 'min_volume', 'max_token_age_hours', 'security_min_score', 'wallet_address',
    'wallet_public_key', 'wallet_encrypted_key', 'execution_mode'];
  for (const key of allowed) {
    if (key in data) {
      fields.push(`${key} = ?`);
      values.push((data as any)[key]);
    }
  }
  if ('preferred_chains' in data) {
    fields.push('preferred_chains = ?');
    values.push(JSON.stringify(data.preferred_chains));
  }
  if (fields.length === 0) return getAgent(id);
  fields.push("updated_at = datetime('now')");
  values.push(id);
  getDb().prepare(`UPDATE meme_agents SET ${fields.join(', ')} WHERE id = ?`).run(...values);
  return getAgent(id);
}

export function deleteAgent(id: string): void {
  const db = getDb();
  db.prepare("DELETE FROM meme_agent_thoughts WHERE agent_id = ?").run(id);
  db.prepare("DELETE FROM meme_agent_trades WHERE agent_id = ?").run(id);
  db.prepare("DELETE FROM meme_agent_positions WHERE agent_id = ?").run(id);
  db.prepare("DELETE FROM meme_agent_config WHERE agent_id = ?").run(id);
  db.prepare("DELETE FROM meme_agents WHERE id = ?").run(id);
}

// ═══════════════ Trades CRUD
export function getAgentTrades(agentId: string, limit = 50): MemeAgentTrade[] {
  return getDb().prepare('SELECT * FROM meme_agent_trades WHERE agent_id = ? ORDER BY timestamp DESC LIMIT ?').all(agentId, limit) as MemeAgentTrade[];
}

export function getAllTrades(limit = 100): MemeAgentTrade[] {
  return getDb().prepare('SELECT * FROM meme_agent_trades ORDER BY timestamp DESC LIMIT ?').all(limit) as MemeAgentTrade[];
}

export function createTrade(data: Omit<MemeAgentTrade, 'id' | 'timestamp'>): MemeAgentTrade {
  const id = randomUUID();
  getDb().prepare(`
    INSERT INTO meme_agent_trades (id, agent_id, token_address, chain_id, symbol, name, side,
      amount_usd, price, quantity, pnl, pnl_pct, entry_reason, exit_reason, security_score, tx_hash)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
  `).run(id, data.agent_id, data.token_address, data.chain_id, data.symbol, data.name || '',
    data.side, data.amount_usd, data.price, data.quantity, data.pnl, data.pnl_pct,
    data.entry_reason || '', data.exit_reason || '', data.security_score || '', data.tx_hash || '');
  return getDb().prepare('SELECT * FROM meme_agent_trades WHERE id = ?').get(id) as MemeAgentTrade;
}

// ═══════════════ Positions CRUD
export function getAgentPositions(agentId: string): MemeAgentPosition[] {
  return getDb().prepare('SELECT * FROM meme_agent_positions WHERE agent_id = ? ORDER BY opened_at DESC').all(agentId) as MemeAgentPosition[];
}

export function getAllPositions(): MemeAgentPosition[] {
  return getDb().prepare('SELECT * FROM meme_agent_positions ORDER BY opened_at DESC').all() as MemeAgentPosition[];
}

export function createPosition(data: Omit<MemeAgentPosition, 'id' | 'opened_at'> & { stop_loss?: number | null; take_profit?: number | null }): MemeAgentPosition {
  const id = randomUUID();
  getDb().prepare(`
    INSERT INTO meme_agent_positions (id, agent_id, token_address, chain_id, symbol, name,
      entry_price, current_price, quantity, amount_usd, unrealized_pnl, unrealized_pnl_pct,
      stop_loss, take_profit)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
  `).run(id, data.agent_id, data.token_address, data.chain_id, data.symbol, data.name || '',
    data.entry_price, data.current_price, data.quantity, data.amount_usd,
    data.unrealized_pnl, data.unrealized_pnl_pct, data.stop_loss, data.take_profit);
  return getDb().prepare('SELECT * FROM meme_agent_positions WHERE id = ?').get(id) as MemeAgentPosition;
}

export function updatePosition(id: string, data: Partial<MemeAgentPosition>): void {
  const fields: string[] = [];
  const values: any[] = [];
  for (const [k, v] of Object.entries(data)) {
    if (k !== 'id') { fields.push(`${k} = ?`); values.push(v); }
  }
  if (fields.length === 0) return;
  values.push(id);
  getDb().prepare(`UPDATE meme_agent_positions SET ${fields.join(', ')} WHERE id = ?`).run(...values);
}

export function deletePosition(id: string): void {
  getDb().prepare('DELETE FROM meme_agent_positions WHERE id = ?').run(id);
}

export function deletePositionByToken(agentId: string, tokenAddress: string): void {
  getDb().prepare('DELETE FROM meme_agent_positions WHERE agent_id = ? AND token_address = ?').run(agentId, tokenAddress);
}

// ═══════════════ Thoughts CRUD
export function getAgentThoughts(agentId: string, limit = 50): MemeAgentThought[] {
  return getDb().prepare('SELECT * FROM meme_agent_thoughts WHERE agent_id = ? ORDER BY created_at DESC LIMIT ?').all(agentId, limit).map(parseThought);
}

export function getAllThoughts(limit = 100): MemeAgentThought[] {
  return getDb().prepare('SELECT * FROM meme_agent_thoughts ORDER BY created_at DESC LIMIT ?').all(limit).map(parseThought);
}

export function createThought(data: { agent_id: string; thought_type: string; content: string; confidence?: number; market_context?: any; token_data?: any }): MemeAgentThought {
  const id = randomUUID();
  getDb().prepare(`
    INSERT INTO meme_agent_thoughts (id, agent_id, thought_type, content, confidence, market_context, token_data)
    VALUES (?, ?, ?, ?, ?, ?, ?)
  `).run(id, data.agent_id, data.thought_type, data.content,
    data.confidence ?? null,
    data.market_context ? JSON.stringify(data.market_context) : null,
    data.token_data ? JSON.stringify(data.token_data) : null);
  return parseThought(getDb().prepare('SELECT * FROM meme_agent_thoughts WHERE id = ?').get(id));
}

// ═══════════════ Config CRUD
export function getAgentConfig(agentId: string): Record<string, string> {
  const rows = getDb().prepare('SELECT key, value FROM meme_agent_config WHERE agent_id = ?').all(agentId) as { key: string; value: string }[];
  const config: Record<string, string> = {};
  for (const r of rows) config[r.key] = r.value;
  return config;
}

export function setAgentConfig(agentId: string, key: string, value: string): void {
  getDb().prepare(`
    INSERT INTO meme_agent_config (id, agent_id, key, value) VALUES (?, ?, ?, ?)
    ON CONFLICT(agent_id, key) DO UPDATE SET value = excluded.value
  `).run(randomUUID(), agentId, key, value);
}

// ═══════════════ Wallet Management
export function setAgentWallet(agentId: string, publicKey: string, encryptedKey: string): void {
  getDb().prepare(`
    UPDATE meme_agents SET wallet_public_key = ?, wallet_encrypted_key = ?, updated_at = datetime('now') WHERE id = ?
  `).run(publicKey, encryptedKey, agentId);
}

export function getAgentWallet(agentId: string): { publicKey: string; encryptedKey: string; executionMode: string } | null {
  const row = getDb().prepare('SELECT wallet_public_key, wallet_encrypted_key, execution_mode FROM meme_agents WHERE id = ?').get(agentId) as any;
  if (!row || !row.wallet_public_key) return null;
  return { publicKey: row.wallet_public_key, encryptedKey: row.wallet_encrypted_key, executionMode: row.execution_mode };
}

export function setExecutionMode(agentId: string, mode: 'simulated' | 'live'): void {
  getDb().prepare(`UPDATE meme_agents SET execution_mode = ?, updated_at = datetime('now') WHERE id = ?`).run(mode, agentId);
}
