# Meme Trading Suite v1.0.0

A comprehensive meme coin trading plugin for the [AI Trading Dashboard](https://gwds.dev). Includes a full 9-tab interface, DexScreener integration, autonomous trading agents, smart money tracking, and Solana trade execution.

## What's Included

### Dashboard (9 Tabs)
- **Scanner** — Real-time DexScreener token scanner with trending detection, volume analysis, and market cap filtering
- **New Pairs** — Discover tokens less than 24 hours old across all chains
- **Watchlist** — Track tokens with price alerts and portfolio monitoring
- **Search** — Search any token across all supported chains
- **Trades** — Full trade history with P&L tracking and analytics
- **Alerts** — Configurable price, volume, and market cap alerts
- **Smart Money** — Track whale wallets and smart money movements
- **Agents** — Autonomous meme trading agents with configurable strategies
- **Settings** — Agent configuration, wallet management, risk parameters

### Engine & Backend
- **Meme Agent Engine** — Core autonomous trading logic with cycle management
- **Signal Engine** — Multi-factor scoring system for trade signals
- **Strategy Library** — Pre-built strategies for meme trading (momentum, sniper, scalper)
- **Solana Executor** — Direct on-chain trade execution via Jupiter aggregator
- **Wallet Manager** — Encrypted wallet storage and management
- **DexScreener API** — Real-time token data, new pairs, and trade feeds

## Installation

### Prerequisites
- AI Trading Dashboard v9.0+ installed and running
- Supabase project with service role access
- Solana RPC endpoint
- Node.js 18+

### Quick Install

1. **Copy files to your dashboard:**

```bash
# From your dashboard root directory:
cp -r meme-trading-suite/src/pages/meme-coins/ src/app/dashboard/meme-coins/
cp -r meme-trading-suite/src/api/meme-agents/ src/app/api/meme-agents/
cp -r meme-trading-suite/src/api/dexscreener/ src/app/api/dexscreener/
cp -r meme-trading-suite/src/lib/* src/lib/
```

2. **Install dependencies:**

```bash
npm install @solana/web3.js @solana/spl-token bs58
```

3. **Set environment variables** in your `.env.local`:

```env
# Required
SUPABASE_URL=https://your-project.supabase.co
SUPABASE_SERVICE_ROLE_KEY=your-service-role-key
NEXT_PUBLIC_SUPABASE_URL=https://your-project.supabase.co
NEXT_PUBLIC_SUPABASE_ANON_KEY=your-anon-key
SOLANA_RPC_URL=https://mainnet.helius-rpc.com/?api-key=YOUR_KEY
SOLANA_PRIVATE_KEY=your-base58-private-key
ENCRYPTION_KEY=your-32-byte-hex-key

# Optional
DEXSCREENER_API_KEY=your-dexscreener-key
HELIUS_API_KEY=your-helius-key
```

4. **Run Supabase migrations** — see `INSTALL.md` for table schemas.

5. **Add navigation link** to your dashboard sidebar:

```tsx
{ name: "Meme Coins", href: "/dashboard/meme-coins", icon: "🚀" }
```

6. **Restart your dev server:**

```bash
npm run dev
```

## Required Supabase Tables

Run the SQL in `INSTALL.md` to create these tables:
- `meme_agents` — Agent configuration and state
- `meme_agent_trades` — Trade history
- `meme_agent_thoughts` — Agent reasoning logs
- `meme_agent_positions` — Open positions
- `meme_watchlist` — Watched tokens
- `meme_alerts` — Price/volume alerts
- `meme_wallets` — Encrypted wallet storage
- `smart_money_wallets` — Tracked whale addresses

## File Structure

```
src/
  pages/meme-coins/page.tsx          # Full 9-tab dashboard UI (1960 lines)
  api/
    meme-agents/
      route.ts                        # CRUD for meme agents
      scanner/route.ts                # DexScreener scanner endpoint
      scheduler/route.ts              # Agent scheduling
      monitor/route.ts                # Agent health monitoring
      wallets/route.ts                # Wallet management
      [id]/
        route.ts                      # Single agent CRUD
        cycle/route.ts                # Run agent cycle
        execute/route.ts              # Execute trades
        positions/route.ts            # Agent positions
        sync/route.ts                 # Sync agent state
        thoughts/route.ts             # Agent thought log
        trades/route.ts               # Agent trade history
        wallet/route.ts               # Agent wallet ops
    dexscreener/
      route.ts                        # Token search
      new-pairs/route.ts              # New token pairs
      trades/route.ts                 # Recent trades
      watchlist/route.ts              # Watchlist data
  lib/
    meme-agent-engine.ts              # Core agent engine
    meme-agent-signal-engine.ts       # Signal scoring system
    meme-agent-strategies.ts          # Trading strategies
    meme-agent-sync.ts                # State synchronization
    meme-agents-db.ts                 # Database operations
    meme-coins-styles.ts              # UI theme styles
    meme-db.ts                        # Meme data layer
    solana-trade-executor.ts          # On-chain execution
    solana-wallet-manager.ts          # Wallet management
    services/
      solana-wallet-service.ts        # Wallet service layer
```

## Tech Stack

- Next.js 15 (App Router)
- TypeScript
- Supabase (PostgreSQL)
- @solana/web3.js
- DexScreener API
- TailwindCSS (inline styles)

## Support

Questions? Email support@gwds.dev

## License

Commercial license. Single-seat. Do not redistribute.
