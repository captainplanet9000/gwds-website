export const dynamic = 'force-dynamic';
import { NextRequest, NextResponse } from 'next/server';
import * as db from '@/lib/meme-agents-db';
import { monitorPositions } from '@/lib/meme-agent-engine';
import * as fs from 'fs';
import * as path from 'path';

const STATE_FILE = path.join(process.cwd(), 'data', 'monitor-state.json');

interface MonitorState {
  running: boolean;
  intervalMs: number;
  lastRunTime: string | null;
  lastResults: Record<string, any>;
}

function loadState(): MonitorState {
  try {
    if (fs.existsSync(STATE_FILE)) {
      return JSON.parse(fs.readFileSync(STATE_FILE, 'utf-8'));
    }
  } catch {}
  return { running: false, intervalMs: 60000, lastRunTime: null, lastResults: {} };
}

function saveState(state: MonitorState) {
  const dir = path.dirname(STATE_FILE);
  if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
  fs.writeFileSync(STATE_FILE, JSON.stringify(state, null, 2));
}

let monitorInterval: ReturnType<typeof setInterval> | null = null;
let isMonitoring = false;

async function runMonitorCycle(): Promise<Record<string, any>> {
  if (isMonitoring) return { skipped: 'already monitoring' };
  isMonitoring = true;
  const results: Record<string, any> = {};
  try {
    const agents = db.getAllAgents().filter(a => a.status === 'active' && a.execution_mode === 'live');
    for (const agent of agents) {
      try {
        const result = await monitorPositions(agent.id);
        results[agent.id] = { name: agent.name, ...result };
      } catch (err: any) {
        results[agent.id] = { name: agent.name, error: err.message };
      }
    }
    const state = loadState();
    state.lastRunTime = new Date().toISOString();
    state.lastResults = results;
    saveState(state);
  } finally {
    isMonitoring = false;
  }
  return results;
}

function startMonitor(intervalMs: number) {
  stopMonitor();
  const state = loadState();
  state.running = true;
  state.intervalMs = intervalMs;
  saveState(state);
  monitorInterval = setInterval(() => {
    runMonitorCycle().catch(console.error);
  }, intervalMs);
}

function stopMonitor() {
  if (monitorInterval) {
    clearInterval(monitorInterval);
    monitorInterval = null;
  }
  const state = loadState();
  state.running = false;
  saveState(state);
}

// Auto-restore
(() => {
  const state = loadState();
  if (state.running) {
    monitorInterval = setInterval(() => {
      runMonitorCycle().catch(console.error);
    }, state.intervalMs);
  }
})();

export async function GET() {
  const state = loadState();
  return NextResponse.json({
    ...state,
    running: !!monitorInterval,
    isMonitoring,
  });
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { action, intervalMs } = body;

    if (action === 'start') {
      const interval = intervalMs || 60000;
      startMonitor(interval);
      return NextResponse.json({ success: true, message: 'Monitor started', intervalMs: interval });
    }

    if (action === 'stop') {
      stopMonitor();
      return NextResponse.json({ success: true, message: 'Monitor stopped' });
    }

    if (action === 'runNow') {
      const results = await runMonitorCycle();
      return NextResponse.json({ success: true, results });
    }

    return NextResponse.json({ error: 'Invalid action. Use start, stop, or runNow' }, { status: 400 });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}
