import { NextResponse } from 'next/server'
export const dynamic = 'force-dynamic'
export async function GET() {
  try {
    const res = await fetch('https://api.dexscreener.com/token-profiles/latest/v1', { next: { revalidate: 60 } })
    if (!res.ok) throw new Error(`DexScreener ${res.status}`)
    const data = await res.json()
    return NextResponse.json({ pairs: data.slice(0, 50) })
  } catch (err: any) {
    return NextResponse.json({ pairs: [], error: err.message })
  }
}
