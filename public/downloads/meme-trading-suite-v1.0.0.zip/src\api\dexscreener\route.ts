import { NextResponse } from 'next/server'

export const dynamic = 'force-dynamic'

export async function GET(req: Request) {
  const { searchParams } = new URL(req.url)
  const action = searchParams.get('action') || 'trending'
  const chain = searchParams.get('chain') || 'solana'
  const address = searchParams.get('address') || ''

  try {
    if (action === 'trending') {
      const res = await fetch('https://api.dexscreener.com/token-boosts/top/v1', { next: { revalidate: 60 } })
      if (!res.ok) throw new Error(`DexScreener ${res.status}`)
      const data = await res.json()
      return NextResponse.json({ tokens: data.slice(0, 50), source: 'dexscreener' })
    }

    if (action === 'token' && address) {
      const addrs = address.split(',').slice(0, 10)
      const results = await Promise.all(
        addrs.map(async (addr: string) => {
          const res = await fetch(`https://api.dexscreener.com/tokens/v1/${chain}/${addr.trim()}`)
          return res.ok ? res.json() : []
        })
      )
      return NextResponse.json({ pairs: results.flat() })
    }

    if (action === 'search') {
      const q = searchParams.get('q') || ''
      const res = await fetch(`https://api.dexscreener.com/latest/dex/search?q=${encodeURIComponent(q)}`)
      if (!res.ok) throw new Error(`DexScreener ${res.status}`)
      const data = await res.json()
      return NextResponse.json(data)
    }

    return NextResponse.json({ tokens: [], message: `Unknown action: ${action}` })
  } catch (err: any) {
    return NextResponse.json({ tokens: [], error: err.message })
  }
}
