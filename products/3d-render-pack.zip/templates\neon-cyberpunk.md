# Blender Scene Template: Neon Cyberpunk

**Use Case:** Tech launches, gaming products, futuristic branding, music/entertainment marketing

## Scene Setup

### Camera
- **Type:** Perspective
- **Focal Length:** 35mm (slightly wide, immersive)
- **Position:** Eye-level or slightly low angle (heroic feel)
- **Framing:** Product centered or in thirds, tight crop with energy
- **Depth of Field:** Shallow (F/2.8), background elements blurred, bokeh visible

### Multi-Color Lighting Rig

**Key Light (Cyan):**
- Type: Area light (2m x 2m)
- Position: Camera left, 45° horizontal, eye-level
- Strength: 80W
- Color: Electric Cyan RGB(0, 1, 1) or Hex #00FFFF
- Purpose: Primary illumination, cool tech feel

**Rim Light (Magenta):**
- Type: Area light (1m x 3m, vertical strip)
- Position: Behind product, camera right
- Strength: 100W (slightly stronger than key)
- Color: Hot Magenta RGB(1, 0, 1) or Hex #FF00FF
- Purpose: Edge lighting, separates product from background

**Fill Light (White - Subtle):**
- Type: Area light (3m x 3m, very soft)
- Position: Camera position (frontal)
- Strength: 20W (just lifts shadows)
- Color: Neutral white 5500K
- Purpose: Prevents total black crush, shows product detail

**Accent Lights (Optional - In-Scene Practical):**
- Small area lights as "neon tubes" or LED strips
- Colors: Pink, green, orange (additional variety)
- Strength: 50-200W depending on desired intensity
- Positioned as set dressing (visible in shot)

### Environment

**Background:**
- Dark void (pure black) OR
- Cyberpunk environment (blurred city, tech grid, etc.)
- Fog/volumetric scattering for atmosphere

**Ground Plane:**
- Black glossy surface (Roughness: 0.05-0.1)
- Reflects colored lights from above
- Creates neon puddle effect beneath product

**Volumetric Atmosphere:**
- Enable Volume Scatter in World settings
- Density: 0.001-0.005 (subtle haze)
- Allows light beams to be visible (god rays from colored lights)

### Product Positioning

**Placement:**
- Center or dynamic off-center
- Slight rotation (15-30°) for energy
- Elevated slightly to show reflections in glossy ground

**Interaction with Lights:**
- Colored lights should create gradient reflections on product surfaces
- Glowing elements on product (screens, LEDs) should be emission shaders

## Render Settings

**Cycles Engine (Required for Quality):**
- Samples: 512-1024 (volumetrics need more samples)
- Max Bounces: 12 (colored light bouncing creates richness)
- Volume Bounces: 4 (for fog interaction)
- Denoising: OptiX or OpenImageDenoise (essential)

**Output:**
- Resolution: 2000x2000px (1:1) or 1920x1080 (16:9)
- Color Management: Filmic, High Contrast (makes colors pop)
- Format: PNG or JPG

**Effects:**
- Bloom/Glare: Essential in compositor
- Motion Blur: Optional (if product has implied motion)

## Material Guidelines

**Product Materials:**

**Glass/Screens:**
- Transmission: 1.0
- IOR: 1.45
- Roughness: 0.03
- Add emission shader for screen glow (blue/purple)

**Glossy Plastics:**
- Roughness: 0.2-0.3 (catches colored light reflections beautifully)
- Clear coat layer for extra pop

**Metals:**
- Metallic: 1.0
- Roughness: 0.15 (mirror-like but not perfect)
- Shows colored light gradients

**Background Plane (Glossy Black):**
```
Principled BSDF:
  Base Color: RGB(0.05, 0.05, 0.05) (not pure black)
  Metallic: 0.0
  Roughness: 0.05
  Clearcoat: 0.5 (extra gloss)
```

**Volumetric Fog (World Shader):**
```
Volume Scatter:
  Density: 0.003
  Anisotropy: 0.2
```

## Color Schemes

### Classic Cyberpunk (Default)
- Cyan (#00FFFF) + Magenta (#FF00FF)
- Optional accent: Purple (#8000FF)

### Blade Runner
- Orange (#FF6600) + Teal (#00CCAA)
- Warm + cool contrast

### Vaporwave
- Pink (#FF6FFF) + Purple (#9D00FF) + Cyan (#00DDFF)
- Pastel neon feel

### Matrix
- Green (#00FF00) + Dark Green (#003300)
- Monochromatic neon

### Custom
- Choose complementary colors on color wheel
- Keep one cool, one warm for contrast

## Compositor Setup (Blender)

**Node Stack:**
1. **Render Layers** input
2. **Denoise** node
3. **Glare** node:
   - Type: Fog Glow
   - Threshold: 1.0
   - Size: 9
   - (Creates neon bloom effect)
4. **RGB Curves**:
   - Slight S-curve for contrast
   - Crush blacks gently
5. **Color Balance**:
   - Push shadows toward blue/cyan
   - Highlights toward magenta
6. **Lens Distortion** (optional):
   - Slight chromatic aberration for lens realism
7. **Output** node

## Variations

### Intensity Levels
- **Subtle:** Lower light strengths, 1-2 colors, minimal bloom
- **Medium (Recommended):** 2-3 colors, moderate bloom, visible fog
- **Extreme:** 4+ colors, heavy bloom, thick fog, maximum contrast

### Movement/Energy
- Add motion blur (render at 2x resolution, blur in post)
- Slight camera shake (animate camera, render single frame mid-shake)
- Particle systems (sparks, digital rain, floating elements)

### Backgrounds
- **Black void** (current) — cleanest, product-focused
- **Blurred cityscape** — environmental context
- **Grid pattern** — retro-futuristic Tron vibe
- **Abstract tech textures** — digital/circuit board patterns

## Post-Processing

**Photoshop/GIMP:**
1. **Levels/Curves:** Ensure blacks are crushed (not gray)
2. **Selective Color:** Boost cyan and magenta saturation
3. **High Pass Sharpen:** Radius 1-2px, overlay blend
4. **Lens Flare (optional):** Subtle over bright lights
5. **Chromatic Aberration:** 1-2px RGB shift on edges (Photoshop: Lens Correction filter)

**Video Export (if animated):**
- After Effects: Add optical flares, more glow, grain
- DaVinci Resolve: Color grade for film look

## AI Prompt Equivalent

```
"Cyberpunk product photography of [PRODUCT] with dramatic neon lighting. Cyan key light from left, magenta rim light from right, glossy black reflective surface. Dark background with volumetric fog, high contrast, Blade Runner aesthetic. Octane render, 8K quality. --ar 16:9 --style raw"
```

## Use Cases

- Tech product launches (phones, gaming gear, peripherals)
- Music equipment (DJ gear, synthesizers, headphones)
- Gaming peripherals (keyboards, mice, controllers)
- Nightlife/entertainment brands
- Futuristic fashion accessories
- Album art, music videos, promotional materials

## Common Mistakes

❌ **Too many colors** — Stick to 2-3 max for cohesion  
❌ **Bloom too strong** — Should enhance, not obliterate detail  
❌ **Background too visible** — Keep dark, mysterious  
❌ **No volumetrics** — Fog sells the neon atmosphere  
❌ **Product too matte** — Glossy surfaces catch colored light best  

✅ **High contrast is your friend** — Deep blacks, bright neon  
✅ **Reflections matter** — Glossy ground doubles the visual impact  
✅ **Less is more with fog** — Subtle haze, not dense smoke  

---

**Pro Tip:** This aesthetic is LOUD and energetic. Perfect for grabbing attention in a crowded social feed. Pair with synthwave music or electronic beats for video presentations. Export in vertical 9:16 for Instagram Reels/TikTok — crop tight on product with colors popping.
