#!/usr/bin/env python3
"""
Custom Prompt Combiner
Mix and match your own product descriptions, styles, and colors
"""

import random
from pathlib import Path


class PromptBuilder:
    """Build custom AI prompts with modular components"""
    
    def __init__(self):
        self.products = []
        self.styles = []
        self.colors = []
        self.lighting = []
        self.backgrounds = []
        self.effects = []
        self.quality_tags = []
        
        self._load_defaults()
    
    def _load_defaults(self):
        """Load default component libraries"""
        # Product descriptors
        self.products = [
            "sleek {item}",
            "modern {item}",
            "premium {item}",
            "minimalist {item}",
            "luxury {item}",
            "futuristic {item}",
            "classic {item}",
        ]
        
        # Style components
        self.styles = [
            "floating weightlessly",
            "positioned on a geometric platform",
            "casting a dramatic shadow",
            "surrounded by botanical elements",
            "in a clean studio setup",
            "with neon accent lighting",
            "on a reflective black surface",
            "suspended in mid-air",
        ]
        
        # Color schemes
        self.colors = [
            "matte black with rose gold accents",
            "pure white with silver trim",
            "space gray aluminum finish",
            "electric blue and magenta gradient",
            "natural terracotta and sage green",
            "deep purple with gold details",
            "brushed titanium with copper",
            "glossy red with chrome",
        ]
        
        # Lighting setups
        self.lighting = [
            "soft studio lighting from above",
            "dramatic single-source spotlight",
            "warm golden hour sunlight",
            "cool neon glow (cyan and magenta)",
            "natural diffused window light",
            "high-contrast rim lighting",
            "volumetric fog with colored lights",
            "bright even illumination",
        ]
        
        # Backgrounds
        self.backgrounds = [
            "seamless white background",
            "gradient from dark to light",
            "pure black void",
            "out-of-focus botanical greenery",
            "abstract geometric shapes",
            "cyberpunk neon cityscape (blurred)",
            "wooden surface with natural texture",
            "black marble with gold veining",
        ]
        
        # Special effects
        self.effects = [
            "with bloom glow on highlights",
            "slight chromatic aberration",
            "shallow depth of field",
            "motion particles suspended around",
            "glitch effect on edges",
            "holographic shimmer",
            "film grain texture overlay",
            "lens flare from light source",
        ]
        
        # Quality/render tags
        self.quality_tags = [
            "octane render, 8K quality",
            "hyperrealistic product photography",
            "cinema 4D render, commercial quality",
            "photorealistic, studio grade",
            "professional advertising photography",
            "unreal engine 5 render, ray traced",
        ]
    
    def build_prompt(self, item, custom_components=None):
        """Build a complete prompt from components"""
        # Use custom components or defaults
        comp = custom_components or {}
        
        product = comp.get("product") or random.choice(self.products).format(item=item)
        style = comp.get("style") or random.choice(self.styles)
        color = comp.get("color") or random.choice(self.colors)
        lighting = comp.get("lighting") or random.choice(self.lighting)
        background = comp.get("background") or random.choice(self.backgrounds)
        effect = comp.get("effect") or random.choice(self.effects)
        quality = comp.get("quality") or random.choice(self.quality_tags)
        
        # Assemble prompt
        prompt = f"Isometric 3D render of a {product}, {style}. "
        prompt += f"Color scheme: {color}. {lighting}, {background}. "
        prompt += f"{effect}. {quality}, pristine and commercial."
        
        return prompt
    
    def generate_variations(self, item, count=10):
        """Generate multiple random variations for one item"""
        return [self.build_prompt(item) for _ in range(count)]
    
    def interactive_build(self):
        """Interactive prompt builder"""
        print("\n" + "="*70)
        print("  CUSTOM PROMPT BUILDER")
        print("="*70 + "\n")
        
        # Get product
        item = input("Enter product name (e.g., 'smartphone', 'watch'): ").strip()
        
        # Choose mode
        print("\nGeneration mode:")
        print("  1. Random variations (quick)")
        print("  2. Custom selection (detailed)")
        mode = input("> ").strip()
        
        if mode == "1":
            count = int(input("How many variations? (default 10): ") or "10")
            prompts = self.generate_variations(item, count)
            
            print(f"\n✨ Generated {len(prompts)} prompts for '{item}':\n")
            for i, p in enumerate(prompts, 1):
                print(f"{i}. {p}\n")
        
        elif mode == "2":
            print("\nSelect components (or press Enter for random):\n")
            
            # Product descriptor
            print("Product descriptors:")
            for i, p in enumerate(self.products, 1):
                print(f"  {i}. {p}")
            prod_choice = input("Select (or Enter for random): ").strip()
            product = self.products[int(prod_choice)-1].format(item=item) if prod_choice else None
            
            # Style
            print("\nStyles:")
            for i, s in enumerate(self.styles, 1):
                print(f"  {i}. {s}")
            style_choice = input("Select (or Enter for random): ").strip()
            style = self.styles[int(style_choice)-1] if style_choice else None
            
            # Color
            print("\nColors:")
            for i, c in enumerate(self.colors, 1):
                print(f"  {i}. {c}")
            color_choice = input("Select (or Enter for random): ").strip()
            color = self.colors[int(color_choice)-1] if color_choice else None
            
            # Lighting
            print("\nLighting:")
            for i, l in enumerate(self.lighting, 1):
                print(f"  {i}. {l}")
            light_choice = input("Select (or Enter for random): ").strip()
            lighting = self.lighting[int(light_choice)-1] if light_choice else None
            
            # Background
            print("\nBackgrounds:")
            for i, b in enumerate(self.backgrounds, 1):
                print(f"  {i}. {b}")
            bg_choice = input("Select (or Enter for random): ").strip()
            background = self.backgrounds[int(bg_choice)-1] if bg_choice else None
            
            # Effect
            print("\nEffects:")
            for i, e in enumerate(self.effects, 1):
                print(f"  {i}. {e}")
            effect_choice = input("Select (or Enter for random): ").strip()
            effect = self.effects[int(effect_choice)-1] if effect_choice else None
            
            # Build final prompt
            custom = {
                "product": product,
                "style": style,
                "color": color,
                "lighting": lighting,
                "background": background,
                "effect": effect,
            }
            
            prompt = self.build_prompt(item, custom)
            print(f"\n✨ Your custom prompt:\n\n{prompt}\n")
        
        # Save option
        save = input("Save prompt to file? (y/n): ").strip().lower()
        if save == "y":
            filename = input("Filename (default: custom_prompt.txt): ").strip() or "custom_prompt.txt"
            with open(filename, "w", encoding="utf-8") as f:
                if mode == "1":
                    for i, p in enumerate(prompts, 1):
                        f.write(f"Prompt {i}:\n{p}\n\n")
                else:
                    f.write(prompt)
            print(f"✅ Saved to {filename}")


def main():
    builder = PromptBuilder()
    
    print("\n" + "="*70)
    print("  3D PRODUCT RENDER - CUSTOM COMBINER")
    print("="*70)
    print("\n  Mix and match components to create unique prompts!")
    print("\n" + "="*70 + "\n")
    
    while True:
        builder.interactive_build()
        
        again = input("\nGenerate another prompt? (y/n): ").strip().lower()
        if again != "y":
            break
    
    print("\n✅ Thanks for using Custom Combiner!\n")


if __name__ == "__main__":
    main()
