# Luxury Dark Color Palette

**Brand Vibe:** Sophisticated, premium, exclusive, high-end editorial

---

## Core Colors

### Primary Dark Tones
- **Charcoal Black:** `#1A1A1A` | RGB(26, 26, 26)
  - Use for: Backgrounds, product bodies (stealth luxury)
  - Works with: Matte finishes, deep surfaces

- **Deep Burgundy:** `#3D1E1E` | RGB(61, 30, 30)
  - Use for: Accent backgrounds, leather textures
  - Works with: Leather, fabric, warm materials

### Metallic Accents
- **Brushed Gold:** `#B8956A` | RGB(184, 149, 106)
  - Use for: Hardware, logos, trim, caps
  - Works with: Metal components, engravings

- **Rose Gold:** `#B76E79` | RGB(183, 110, 121)
  - Use for: Modern luxury accents, feminine products
  - Works with: Jewelry, watches, beauty products

### Neutral Depth
- **Slate Gray:** `#4A4A4A` | RGB(74, 74, 74)
  - Use for: Shadows, secondary surfaces
  - Works with: Stone, concrete, metal

- **Warm Black:** `#0D0D0D` | RGB(13, 13, 13)
  - Use for: Pure blacks with warmth (not cold)
  - Works with: Deep shadows, voids

---

## Product Applications

### Perfume/Cologne Bottles
- Bottle: Charcoal glass or Deep Burgundy liquid
- Cap: Brushed Gold or Rose Gold
- Surface: Black marble with white/gold veining
- Background: Deep charcoal gradient

### Luxury Watches
- Case: Brushed Gold or Rose Gold
- Dial: Charcoal Black with gold markers
- Strap: Deep Burgundy leather or black
- Background: Slate Gray gradient to black

### Premium Headphones
- Body: Charcoal Black matte
- Accents: Brushed Gold hinges and logos
- Earpads: Deep Burgundy leather
- Background: Dark with gold rim light

### Jewelry/Accessories
- Metal: Rose Gold or Brushed Gold
- Stones/Details: Deep red (ruby tones) or black onyx
- Packaging: Charcoal with gold foil
- Background: Deep Burgundy or black velvet texture

---

## Background Recommendations

- **Black Marble:** Black base with white/gold veining
- **Deep Gradient:** Charcoal to Warm Black
- **Velvet Texture:** Deep Burgundy with soft pile texture
- **Matte Black:** Infinite void, pure luxury isolation
- **Wood:** Dark walnut or ebony (warm, rich)

---

## Lighting Setup

**Color Temperature:**
- Key Light: 3200K (warm tungsten, moody)
- Rim: 2800K (amber/gold glow for drama)
- Fill: 4000K (neutral warm, subtle)

**Mood:**
- High contrast (deep shadows, bright highlights)
- Dramatic single-source or Rembrandt lighting
- Specular highlights on gold/metal surfaces
- Low-key photography aesthetic

---

## Material Finishes

### Metals
- **Brushed Gold:** Anisotropic shader, linear grain
- **Rose Gold:** Slight pink tint, polished but not mirror
- **Gunmetal:** Dark gray metal, satin finish

### Fabrics/Leathers
- **Burgundy Leather:** Subsurface scattering, grain texture
- **Black Velvet:** Extremely matte (Roughness 1.0), pile bump map
- **Silk:** Subtle sheen, anisotropic highlights

### Glass
- **Smoked Glass:** Dark tint, translucent (Transmission 0.7)
- **Black Glass:** Opaque with slight reflection
- **Amber Glass:** Warm tint for bottles

### Stone
- **Black Marble:** Polished, white veins, realistic PBR
- **Slate:** Matte, rough, natural split texture

---

## Typography Pairing

**Fonts:**
- Playfair Display (serif, elegant)
- Cormorant Garamond (refined serif)
- Montserrat (modern sans, for contrast)
- Bodoni (high-fashion editorial)

**Usage:**
- Product names: Thin serif, 64-96pt, gold color
- Descriptions: Light sans, 10-12pt, slate gray
- Headlines: Bold serif, all caps, tight tracking

---

## Complementary Color Accents

**Jewel Tones (Use Sparingly):**
- Emerald Green: `#0B4F3F` (rare, editorial)
- Deep Sapphire: `#082440` (cool luxury alternative)
- Ruby Red: `#5C1A1A` (warmth, passion)

**When to Use:**
- Gemstone products (actual color)
- Luxury packaging accent (foil, ribbon)
- Editorial creative direction

---

## DO's and DON'Ts

✅ **DO:**
- Embrace deep shadows (luxury lives in mystery)
- Use gold sparingly (accents only, not primary)
- Layer textures (marble + leather + metal)
- Keep compositions tight (intimacy, exclusivity)
- Add subtle imperfections (patina, wear, grain)

❌ **DON'T:**
- Use bright white backgrounds (breaks mood)
- Over-saturate colors (keep muted, rich)
- Mix silver and gold (choose one metallic)
- Use flat lighting (need drama and contrast)
- Add neon or bright colors (gauche, not luxury)

---

## Lighting Variations

### Candlelight Intimacy
- Warm orange key (2200K), flickering simulation
- Deep shadows, very low fill
- Gold surfaces glow warmly

### Twilight Elegance
- Cool blue ambient (7000K) + warm gold practical lights
- Dusk color palette (deep blue shadows, warm highlights)
- Moody, cinematic

### Classic Studio Luxury (Default)
- Warm tungsten (3200K), controlled shadows
- Rembrandt triangle on product
- High contrast, editorial magazine quality

---

## Brand Examples

- **Tom Ford** (perfumes, beauty)
- **Rolex** (watch marketing)
- **Louis Vuitton** (leather goods campaigns)
- **Byredo** (fragrance photography)
- **Montblanc** (pens, accessories)
- **Aesop** (dark skincare imagery)

---

## AI Prompt Integration

```
"...luxury dark aesthetic, charcoal black background, brushed gold accents, warm tungsten lighting, black marble surface, high contrast, editorial perfume photography, sophisticated and moody, expensive materials, Vogue magazine style..."
```

**Keywords:**
- "Luxury dark"
- "Moody lighting"
- "Brushed gold" or "rose gold"
- "Black marble"
- "High-end editorial"
- "Deep shadows"

---

## Hex Color Quick Reference

| Color | Hex | RGB |
|-------|-----|-----|
| Charcoal Black | #1A1A1A | 26, 26, 26 |
| Deep Burgundy | #3D1E1E | 61, 30, 30 |
| Brushed Gold | #B8956A | 184, 149, 106 |
| Rose Gold | #B76E79 | 183, 110, 121 |
| Slate Gray | #4A4A4A | 74, 74, 74 |
| Warm Black | #0D0D0D | 13, 13, 13 |

---

**Pro Tip:** This palette screams "expensive" without saying a word. Perfect for premium products ($200+), luxury brand launches, and editorial campaigns. Print these renders large format (40x60 inches) for gallery-quality showroom displays. The darkness makes bright elements (gold, product labels) pop with maximum impact.
