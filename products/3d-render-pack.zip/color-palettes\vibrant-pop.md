# Vibrant Pop Color Palette

**Brand Vibe:** Energetic, playful, bold, Gen-Z appeal, Instagram-ready

---

## Core Colors

### Primary Brights
- **Hot Pink:** `#FF006E` | RGB(255, 0, 110)
  - Use for: Accent elements, bold statements, fashion products
  - Works with: Glossy plastics, neon effects

- **Electric Cyan:** `#00F5FF` | RGB(0, 245, 255)
  - Use for: Tech products, sporting goods, modern accents
  - Works with: Translucent materials, RGB lighting

- **Sunshine Yellow:** `#FFD60A` | RGB(255, 214, 10)
  - Use for: Cheerful products, summer vibes, attention-grabbing
  - Works with: Matte plastics, rubber

### Secondary Pops
- **Vivid Orange:** `#FF5A00` | RGB(255, 90, 0)
  - Use for: Energy, warmth, sporty products
  - Works with: Sneakers, outdoor gear

- **Neon Green:** `#39FF14` | RGB(57, 255, 20)
  - Use for: Gaming, tech, bold modern looks
  - Works with: Glossy surfaces, RGB setups

- **Deep Purple:** `#8338EC` | RGB(131, 56, 236)
  - Use for: Balance, sophistication within vibrancy
  - Works with: Gradients, nightlife products

### Neutrals (For Balance)
- **Pure White:** `#FFFFFF` | RGB(255, 255, 255)
  - Use for: Backgrounds, contrast, breathing room
  - Critical: Prevents overwhelming the eye

- **Cool Gray:** `#E8E8E8` | RGB(232, 232, 232)
  - Use for: Shadows, platforms, secondary backgrounds

---

## Product Applications

### Headphones/Earbuds
- Body: Hot Pink or Electric Cyan
- Accents: White plastic trim
- Packaging: Gradient (Pink to Purple or Cyan to Green)
- Background: Pure white or complementary color

### Sneakers
- Upper: Sunshine Yellow mesh
- Midsole: White
- Accent stripes: Hot Pink or Electric Cyan
- Laces: Neon Green
- Background: Gradient or solid contrasting color

### Tech Accessories (Phone Cases, Chargers)
- Primary: Electric Cyan or Deep Purple
- Secondary: Hot Pink details
- Screen/Interface: Neon Green UI elements
- Background: White or light gray

### Lifestyle Products (Water Bottles, Bags)
- Base color: Bold primary (Hot Pink, Sunshine Yellow)
- Logo/text: White or contrasting neon
- Handle/strap: Vivid Orange or Neon Green
- Background: Color-blocked (split 50/50 two colors)

---

## Background Recommendations

- **Pure White:** Clean, lets colors sing (most versatile)
- **Color Block:** Two solid colors split diagonally or horizontally
  - Example: Hot Pink (left) + Electric Cyan (right)
- **Gradient Blast:** 
  - Pink → Yellow → Cyan (rainbow energy)
  - Purple → Hot Pink (sunset vibe)
  - Cyan → Neon Green (fresh, sporty)
- **Pastel Base:** Light versions of vibrant colors (softer option)

---

## Lighting Setup

**Color Temperature:**
- Key Light: 6500K (bright daylight, crisp)
- Fill: 6000K (neutral, keeps colors true)
- Accent/Rim: Colored gels matching product (Hot Pink rim on Cyan product)

**Mood:**
- Bright, evenly lit (no moody shadows)
- High energy, high key photography
- Colored rim lights for extra pop
- Possible RGB cycling lights (if animated)

---

## Material Finishes

### Plastics
- **Glossy:** Catches light, vibrant reflections (headphones, tech)
- **Matte:** Pure color, no reflections (sporting goods, casual)
- **Translucent:** Neon glow effect (RGB peripherals, modern design)

### Rubber/Silicone
- Soft-touch matte in Sunshine Yellow or Neon Green
- Grippy texture, vibrant solid color

### Metals (Use Sparingly)
- Chrome: High-polish silver (accents only)
- Colored Anodized: Hot Pink or Electric Cyan aluminum (premium)

### Textiles
- Breathable mesh in Electric Cyan or Neon Green
- Woven fabric with color gradients

---

## Typography Pairing

**Fonts:**
- Montserrat (bold, geometric sans)
- Poppins (rounded, friendly)
- Bebas Neue (impact headlines, all caps)
- Gotham (clean, modern sans)

**Usage:**
- Headlines: Extra bold, vibrant color (Hot Pink, Electric Cyan)
- Body: Medium weight, black or dark gray
- CTAs: Bold, white text on vibrant button background

**Effects:**
- Slight drop shadow (neon glow effect)
- Outline stroke (white on colored text)
- Gradient text (Cyan to Purple)

---

## Color Combinations

### High Energy
- Hot Pink + Sunshine Yellow + White
- Use: Festival products, party supplies, bold fashion

### Cool Tech
- Electric Cyan + Deep Purple + White
- Use: Gaming gear, futuristic products, nightlife

### Sporty Fresh
- Neon Green + Vivid Orange + Cool Gray
- Use: Athletic wear, outdoor gear, energy drinks

### Maximum Pop (Use Carefully)
- Hot Pink + Electric Cyan + Sunshine Yellow + Neon Green
- Use: Only when "loud" is the goal (festivals, youth brands)
- Requires: White balance/breathing room

---

## DO's and DON'Ts

✅ **DO:**
- Use white space generously (prevents chaos)
- Limit to 2-3 vibrant colors per product
- Add colored shadows/reflections (pink shadow on cyan product)
- Saturate colors fully (go bold or go home)
- Use gradients between complementary colors

❌ **DON'T:**
- Use all 6 vibrant colors at once (overwhelming)
- Combine with earth tones (breaks vibe)
- Use dark backgrounds (kills energy)
- Under-saturate (muted = not vibrant pop)
- Forget white breathing room (critical!)

---

## Lighting Effects

### RGB Cycling (Tech Products)
- Key light cycles through Hot Pink → Electric Cyan → Neon Green
- Render 3 versions, composite or animate

### Neon Glow
- Add emission shader to product edges
- Bloom/glow in compositor
- Colored light spill on surface

### Color Splash
- Monochrome product (white/gray)
- One vibrant accent element (Hot Pink button, Cyan logo)
- High contrast focus

---

## Brand Examples

- **JBL** (colorful speaker line)
- **Beats by Dre** (bold headphone colors)
- **Nike** (vibrant sneaker drops)
- **Glossier** (playful beauty branding)
- **Supreme** (bold streetwear visuals)
- **Monster Energy** (neon green branding)

---

## AI Prompt Integration

```
"...vibrant pop aesthetic, hot pink and electric cyan color scheme, glossy plastic finish, bright studio lighting, pure white background, high energy, playful and bold, Gen-Z product photography, Instagram-ready, colorful and saturated..."
```

**Keywords:**
- "Vibrant pop"
- "Bold colors"
- "High saturation"
- "Neon" or "electric"
- "Energetic"
- "White background"

---

## Seasonal Variations

### Summer
- Sunshine Yellow + Electric Cyan + Vivid Orange
- Beach, pool, festival vibes

### Spring
- Hot Pink + Neon Green + White
- Fresh, blooming, renewal energy

### Retro 80s/90s
- Deep Purple + Hot Pink + Electric Cyan
- Vaporwave, nostalgia, Memphis design

### Nightlife
- Deep Purple + Hot Pink + Neon Green
- Rave, club, party products

---

## Hex Color Quick Reference

| Color | Hex | RGB |
|-------|-----|-----|
| Hot Pink | #FF006E | 255, 0, 110 |
| Electric Cyan | #00F5FF | 0, 245, 255 |
| Sunshine Yellow | #FFD60A | 255, 214, 10 |
| Vivid Orange | #FF5A00 | 255, 90, 0 |
| Neon Green | #39FF14 | 57, 255, 20 |
| Deep Purple | #8338EC | 131, 56, 236 |
| Pure White | #FFFFFF | 255, 255, 255 |
| Cool Gray | #E8E8E8 | 232, 232, 232 |

---

**Pro Tip:** This palette is LOUD. Perfect for products targeting 16-30 year olds, social media campaigns, limited edition drops, and anything that needs to stop the scroll. Not appropriate for luxury, medical, or professional services. Use it when your goal is maximum attention and shareability. These colors photograph incredibly well for Instagram, TikTok, and video content.
