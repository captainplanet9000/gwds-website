#!/usr/bin/env python3
"""
3D Product Render - Batch Prompt Generator
Combines products × styles × color palettes to generate 100+ unique prompts
"""

import itertools
import os
from pathlib import Path

# Product categories
PRODUCTS = [
    "smartphone",
    "laptop",
    "wireless headphones",
    "running sneakers",
    "luxury perfume bottle",
    "automatic watch",
    "aviator sunglasses",
    "mechanical keyboard",
    "portable speaker",
    "mirrorless camera",
]

# Scene styles
STYLES = [
    {
        "name": "floating platform",
        "desc": "floating above a geometric platform with clean gradient background",
        "ar": "1:1",
    },
    {
        "name": "dramatic shadow",
        "desc": "on pure white background with long dramatic shadow extending across frame",
        "ar": "1:1",
    },
    {
        "name": "neon cyberpunk",
        "desc": "with neon lighting, cyan and magenta glow, dark background with volumetric fog",
        "ar": "9:16",
    },
    {
        "name": "natural lifestyle",
        "desc": "on wooden surface with botanical elements, soft window light, organic aesthetic",
        "ar": "4:5",
    },
    {
        "name": "minimalist studio",
        "desc": "clean studio setup, soft lighting, seamless white background, professional product photography",
        "ar": "16:9",
    },
]

# Color palettes
PALETTES = [
    {
        "name": "tech-minimal",
        "colors": "space gray and silver with electric blue accents",
        "mood": "clean, modern, professional",
    },
    {
        "name": "luxury-dark",
        "colors": "charcoal black with brushed gold accents, warm lighting",
        "mood": "sophisticated, premium, editorial",
    },
    {
        "name": "vibrant-pop",
        "colors": "hot pink and electric cyan on white background",
        "mood": "energetic, playful, bold",
    },
    {
        "name": "earth-organic",
        "colors": "terracotta and sage green with warm sand tones",
        "mood": "natural, sustainable, wholesome",
    },
    {
        "name": "neon-future",
        "colors": "electric magenta and cyber cyan on deep black",
        "mood": "cyberpunk, futuristic, high-tech",
    },
]

# Rendering styles
RENDER_QUALITIES = [
    "octane render quality",
    "cinema 4D quality",
    "hyperrealistic",
    "photorealistic product photography",
    "commercial quality render",
]


def generate_prompt(product, style, palette, quality):
    """Generate a single AI image prompt"""
    prompt = f"Isometric 3D render of a {product} {style['desc']}. "
    prompt += f"Color scheme: {palette['colors']}. {palette['mood']} aesthetic. "
    prompt += f"Studio lighting, {quality}, 8K resolution, pristine and commercial."
    
    return {
        "prompt": prompt,
        "product": product,
        "style": style["name"],
        "palette": palette["name"],
        "aspect_ratio": style["ar"],
    }


def generate_all_combinations(limit=None):
    """Generate all possible combinations"""
    prompts = []
    
    for product, style, palette in itertools.product(PRODUCTS, STYLES, PALETTES):
        quality = RENDER_QUALITIES[len(prompts) % len(RENDER_QUALITIES)]
        prompts.append(generate_prompt(product, style, palette, quality))
    
    if limit:
        return prompts[:limit]
    return prompts


def save_prompts_to_file(prompts, output_file="generated_prompts.txt"):
    """Save prompts to a text file"""
    with open(output_file, "w", encoding="utf-8") as f:
        f.write("# Generated Product Render Prompts\n")
        f.write(f"# Total: {len(prompts)} prompts\n")
        f.write("# Format: [Product | Style | Palette | AR] Prompt\n\n")
        
        for i, p in enumerate(prompts, 1):
            f.write(f"## Prompt {i}\n")
            f.write(f"**Product:** {p['product']}\n")
            f.write(f"**Style:** {p['style']}\n")
            f.write(f"**Palette:** {p['palette']}\n")
            f.write(f"**Aspect Ratio:** {p['aspect_ratio']}\n\n")
            f.write(f"{p['prompt']}\n\n")
            f.write("---\n\n")
    
    print(f"✅ Saved {len(prompts)} prompts to {output_file}")


def save_prompts_csv(prompts, output_file="generated_prompts.csv"):
    """Save prompts to CSV for spreadsheet import"""
    import csv
    
    with open(output_file, "w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(
            f, fieldnames=["prompt", "product", "style", "palette", "aspect_ratio"]
        )
        writer.writeheader()
        writer.writerows(prompts)
    
    print(f"✅ Saved {len(prompts)} prompts to {output_file}")


def interactive_mode():
    """Interactive CLI for selective generation"""
    print("\n" + "="*70)
    print("  3D PRODUCT RENDER - BATCH PROMPT GENERATOR")
    print("="*70 + "\n")
    
    # Select products
    print("Available products:")
    for i, p in enumerate(PRODUCTS, 1):
        print(f"  {i}. {p}")
    print("\nEnter product numbers (comma-separated, or 'all'):")
    product_input = input("> ").strip()
    
    if product_input.lower() == "all":
        selected_products = PRODUCTS
    else:
        indices = [int(x.strip())-1 for x in product_input.split(",")]
        selected_products = [PRODUCTS[i] for i in indices]
    
    # Select styles
    print("\nAvailable styles:")
    for i, s in enumerate(STYLES, 1):
        print(f"  {i}. {s['name']}")
    print("\nEnter style numbers (comma-separated, or 'all'):")
    style_input = input("> ").strip()
    
    if style_input.lower() == "all":
        selected_styles = STYLES
    else:
        indices = [int(x.strip())-1 for x in style_input.split(",")]
        selected_styles = [STYLES[i] for i in indices]
    
    # Select palettes
    print("\nAvailable palettes:")
    for i, pal in enumerate(PALETTES, 1):
        print(f"  {i}. {pal['name']}")
    print("\nEnter palette numbers (comma-separated, or 'all'):")
    palette_input = input("> ").strip()
    
    if palette_input.lower() == "all":
        selected_palettes = PALETTES
    else:
        indices = [int(x.strip())-1 for x in palette_input.split(",")]
        selected_palettes = [PALETTES[i] for i in indices]
    
    # Generate combinations
    prompts = []
    for product, style, palette in itertools.product(
        selected_products, selected_styles, selected_palettes
    ):
        quality = RENDER_QUALITIES[len(prompts) % len(RENDER_QUALITIES)]
        prompts.append(generate_prompt(product, style, palette, quality))
    
    print(f"\n✨ Generated {len(prompts)} unique prompts!")
    
    # Save options
    print("\nSave format:")
    print("  1. Text file (.txt)")
    print("  2. CSV spreadsheet (.csv)")
    print("  3. Both")
    format_choice = input("> ").strip()
    
    if format_choice in ["1", "3"]:
        save_prompts_to_file(prompts)
    if format_choice in ["2", "3"]:
        save_prompts_csv(prompts)
    
    print("\n✅ Done! Check your output files.")
    print(f"📊 Total prompts generated: {len(prompts)}\n")


def main():
    """Main entry point"""
    import sys
    
    if len(sys.argv) > 1 and sys.argv[1] == "--auto":
        # Auto mode: generate all combinations
        print("🤖 Auto mode: Generating ALL combinations...")
        prompts = generate_all_combinations()
        save_prompts_to_file(prompts)
        save_prompts_csv(prompts)
        print(f"\n✅ Generated {len(prompts)} total prompts!")
    else:
        # Interactive mode
        interactive_mode()


if __name__ == "__main__":
    main()
