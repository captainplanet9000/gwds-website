# Blender Scene Template: Floating Platform Isometric

**Use Case:** Social media posts, modern product cards, trendy e-commerce imagery

## Scene Setup

### Camera
- **Type:** Orthographic (true isometric, no perspective distortion)
- **Orthographic Scale:** 10 (adjust based on product size)
- **Rotation:** 
  - X: 60° (classic isometric angle)
  - Y: 0°
  - Z: 45°
- **Position:** Elevated above scene, looking down at isometric angle
- **Alternative:** Perspective camera at 85mm, but loses true isometric feel

### Lighting Rig

**HDRI Environment (Primary)**
- Use studio HDRI (studio_small_08.exr or similar)
- Strength: 1.0
- Rotation Z: Adjust to control highlight placement
- Purpose: Provides realistic ambient lighting and reflections

**Sun Lamp (Accent)**
- Type: Sun (parallel rays, perfect for isometric)
- Position: Upper front-left
- Strength: 2.5
- Angle: 30° from vertical
- Color: Warm white (4500K)
- Purpose: Creates crisp shadows and defines form

**Area Light (Fill - Optional)**
- Type: Area (1m x 1m)
- Position: Lower camera-right
- Strength: 50W
- Purpose: Lifts shadows slightly, prevents black crush

### Platform Design

**Geometric Platform:**
- Shape: Cube, cylinder, hexagonal prism, or custom
- Scale: 150-200% of product width
- Material: Matte solid color OR glossy for reflections
- Position: Below product (product hovers 10-20cm above)

**Material Options:**
1. **Matte Concrete:**
   - Roughness: 0.9
   - Color: Light gray (#CCCCCC)
   - Displacement: Subtle noise for texture

2. **Glossy Acrylic:**
   - Roughness: 0.05
   - Color: White or colored
   - Shows product reflection

3. **Metallic:**
   - Metallic: 1.0
   - Roughness: 0.2
   - Color: Gold, silver, copper

### Background

**Gradient Backdrop:**
- Create large plane behind scene
- Material: Emission shader with Gradient Texture
  - Top color: Light (white, pale blue, etc.)
  - Bottom color: Slightly darker or complementary
- No shadows (disable in object properties)

**Alternative: Infinite Void:**
- No background object
- Use World shader with gradient
- Creates floating-in-space feel

### Product Positioning

**Hover Effect:**
- Product centered above platform
- Gap: 10-20cm (visible but not extreme)
- Shadow projection on platform (shadow catcher or plane)

**Shadow Options:**
1. **Soft Contact Shadow:**
   - Thin plane below product
   - Shadow catcher material (captures shadow only)
   - Blur in post if too sharp

2. **Fake Blob Shadow:**
   - Circle mesh with gradient transparency
   - Emission shader (dark center, transparent edges)
   - No lighting required, always consistent

## Render Settings

**Cycles Engine:**
- Samples: 256 (test), 1024 (final)
- Max Bounces: 8
- Denoising: Enabled (OptiX or OpenImageDenoise)

**Output:**
- Resolution: 2000x2000px (square) or 2000x2500 (4:5)
- Color Management: Filmic, Medium Contrast
- Format: PNG (with transparency) or JPG (white background)

## Material Guidelines

**Product Materials:**
Use realistic PBR materials (see Hero Product Shot template)

**Platform Material (Matte Example):**
```
Principled BSDF:
  Base Color: RGB(0.8, 0.8, 0.8)
  Metallic: 0.0
  Roughness: 0.9
  
Add Noise Texture → Bump for subtle surface texture
```

**Background Material (Gradient Example):**
```
Emission Shader:
  Strength: 0.5
  Color: Gradient Texture (Generated coordinates)
    - Color Ramp: White (top) to Light Gray (bottom)
```

## Variations

### Platform Shapes
- **Hexagon:** Trendy, modern, tech products
- **Circle/Cylinder:** Classic, safe, most products
- **Cube:** Architectural, bold, statement pieces
- **Irregular Stone:** Organic, natural, artisanal products
- **Thin Floating Shelf:** Minimalist, thin products

### Lighting Moods
- **Bright & Clean:** High HDRI strength, white platform
- **Moody & Dramatic:** Dim HDRI, dark platform, strong sun
- **Colorful & Fun:** Colored platform, gradient background
- **Neon Accent:** Add colored area lights under platform

## Post-Processing

**Compositor (Blender):**
1. Denoise node
2. Glare node (streaks or fog glow, subtle)
3. Color balance (tweak temperature)
4. Mix node: Add slight vignette

**Photoshop/External:**
- Add subtle drop shadow if needed
- Color grade for brand consistency
- Sharpen (High Pass filter, 1-2px radius, overlay blend)

## AI Prompt Equivalent

If recreating this look with AI generation:

```
"Isometric 3D render of [PRODUCT] floating above a [SHAPE] [MATERIAL] platform. Clean gradient background from [COLOR] to [COLOR]. Soft studio lighting with gentle shadows. Product photography style, commercial quality, octane render. --ar 1:1"
```

---

**Pro Tip:** This setup is perfect for Instagram posts and product catalogs. The isometric view shows depth while maintaining clean, modern aesthetics. Batch render multiple products with same camera/lighting for consistent brand look.
