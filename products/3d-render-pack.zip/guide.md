# Best Practices for AI-Generated Product Photography

**Comprehensive guide to creating professional product renders with AI tools**

---

## Table of Contents

1. [Getting Started](#getting-started)
2. [Tool Selection](#tool-selection)
3. [Prompt Engineering](#prompt-engineering)
4. [Midjourney Specific](#midjourney-specific)
5. [DALL-E 3 Specific](#dall-e-3-specific)
6. [Flux Specific](#flux-specific)
7. [Post-Processing](#post-processing)
8. [Batch Workflows](#batch-workflows)
9. [Common Mistakes](#common-mistakes)
10. [Advanced Techniques](#advanced-techniques)

---

## Getting Started

### What You Need
- AI image generation tool account (Midjourney, DALL-E, Flux, etc.)
- Basic image editing software (Photoshop, GIMP, Photopea)
- Clear idea of your product and target aesthetic

### First Steps
1. Choose 3-5 prompts from the pack that match your product category
2. Test each prompt with your product name substituted in
3. Generate 4 variations per prompt (total 12-20 images)
4. Curate the top 5 best results
5. Refine those 5 with adjusted prompts or upscaling

### Workflow Overview
```
Prompt Selection → Test Generation → Curate → Refine → Post-Process → Export
```

---

## Tool Selection

### Midjourney v6/v6.1
**Best for:**
- Photorealistic product renders
- Isometric 3D aesthetics
- High-quality finishes and materials
- Consistent style across batches

**Pros:**
- Excellent at understanding product photography language
- Reliable isometric renders
- Strong material simulation (metal, glass, plastic)
- Community gallery for inspiration

**Cons:**
- Requires Discord
- No free tier
- Less control over exact composition

**Pricing:** $10-60/month

### DALL-E 3
**Best for:**
- Exact prompt following
- Specific color requests
- Simpler compositions
- Tight deadline work (fast generation)

**Pros:**
- Very literal prompt interpretation
- Good at text/labels on products (sometimes)
- Fast generation (30-60 seconds)
- Integrated with ChatGPT Plus

**Cons:**
- Can look "AI-ish" (less photorealistic)
- Weaker at complex lighting
- Struggles with isometric precision

**Pricing:** $20/month (ChatGPT Plus)

### Flux Pro/Dev
**Best for:**
- Photorealism
- Complex scenes
- Mixed media (product + environment)
- Budget-conscious high quality

**Pros:**
- Strong photorealism
- Good at lighting nuance
- Flexible prompt structure
- Open-source version available (Dev)

**Cons:**
- Less community knowledge
- Can overfit on generic stock photo aesthetics
- Isometric hits more miss than Midjourney

**Pricing:** $5-30/month (via replicate.com or fal.ai)

### Recommendation
- **E-commerce primary images:** Midjourney v6.1
- **Fast iterations/concepts:** DALL-E 3
- **Budget + quality:** Flux Pro
- **Ultimate quality:** Midjourney v6.1 + Photoshop polish

---

## Prompt Engineering

### Anatomy of a Great Product Prompt

```
[Composition Type] + [Product Description] + [Scene Setup] + 
[Materials/Finish] + [Lighting] + [Background] + [Style Tags] + [Quality Tags]
```

### Example Breakdown

**Prompt:**
```
Isometric 3D render of a sleek wireless headphones, floating above a hexagonal platform. Matte black earcups with rose gold metal headband, glossy finish. Soft studio lighting from upper left, gentle shadows. Clean gradient background from white to pale gray. Product photography style, octane render quality, 8K, pristine.
```

**Components:**
- Composition: "Isometric 3D render"
- Product: "sleek wireless headphones"
- Scene: "floating above a hexagonal platform"
- Materials: "matte black earcups with rose gold metal headband, glossy finish"
- Lighting: "soft studio lighting from upper left, gentle shadows"
- Background: "clean gradient background from white to pale gray"
- Style: "product photography style"
- Quality: "octane render quality, 8K, pristine"

### Keywords That Work

**For Realism:**
- "photorealistic product photography"
- "professional commercial quality"
- "studio lighting"
- "octane render" / "cinema 4D quality"

**For Composition:**
- "isometric 3D render"
- "floating above platform"
- "dramatic single-source lighting"
- "centered composition"

**For Materials:**
- "brushed aluminum"
- "matte black finish"
- "translucent plastic"
- "polished chrome"
- "soft-touch rubber"

**For Lighting:**
- "soft diffused lighting"
- "high-contrast rim light"
- "warm tungsten glow"
- "cold neon accent"

---

## Midjourney Specific

### Essential Parameters

**Aspect Ratio:**
```
--ar 1:1    (Square - Instagram, general use)
--ar 4:5    (Vertical - Instagram feed, e-commerce)
--ar 16:9   (Horizontal - website banners)
--ar 9:16   (Vertical - Stories, mobile)
```

**Version:**
```
--v 6.1     (Latest, best quality)
--v 6       (Stable, slightly different aesthetic)
```

**Style:**
```
--style raw         (Less opinionated, more literal)
--style raw --s 250 (Balanced stylization)
```

**Quality:**
```
--q 2     (Double render time, slight quality boost for finals)
```

### Prompting Tips

1. **Be Specific About Materials:**
   - Don't: "metal"
   - Do: "brushed stainless steel with matte clearcoat"

2. **Describe Lighting Explicitly:**
   - Don't: "good lighting"
   - Do: "soft overhead studio lighting, key light from camera left at 45 degrees"

3. **Use Photography Terms:**
   - "product photography"
   - "commercial quality"
   - "editorial style"
   - "studio shot"

4. **Reference Real Brands (Carefully):**
   - "Apple product photography aesthetic" (style, not brand)
   - "Aesop perfume bottle mood" (mood, not exact copy)

### Workflow

1. Initial prompt with `--v 6.1 --ar 1:1`
2. Generate 4 variations
3. Upscale best 2 (U1, U2, etc.)
4. Use "Vary (Subtle)" or "Vary (Strong)" for refinement
5. Repeat until satisfied

### Saving Seeds for Consistency

When you find a perfect result:
1. React with ✉️ emoji
2. MJ will DM you the job details
3. Note the seed number
4. Add `--seed [number]` to future prompts for similar style

---

## DALL-E 3 Specific

### Prompting Style

DALL-E 3 is very literal — be descriptive and precise.

**Good Prompt Structure:**
```
Create a professional product photograph of a [product]. The [product] should be [description]. It is positioned [placement]. The background is [background]. Lighting setup: [lighting]. The overall style is [style]. Photorealistic, high quality, commercial photography.
```

### Tips

1. **Use Full Sentences:**
   - DALL-E responds better to natural language than keyword lists

2. **Specify What You DON'T Want:**
   - "No text on the product, no logos, no branding"

3. **Request Revisions:**
   - Generate once, then tell ChatGPT: "Make the lighting warmer" or "Change background to white"

4. **Leverage ChatGPT for Iteration:**
   - "Create 5 variations of this prompt with different color schemes"

### Limitations

- Can't perfectly match specific brand aesthetics
- Sometimes adds unwanted text/details
- Less consistent with isometric angles
- May need more iterations to get materials right

---

## Flux Specific

### Best Practices

1. **Use Natural Descriptive Language:**
   - Flux handles conversational prompts well
   - "A beautiful product shot of..."

2. **Emphasize Photorealism:**
   - Add "photorealistic, DSLR camera, studio lighting" explicitly

3. **Specify Camera Settings (If Desired):**
   - "Shot on Canon EOS R5, 85mm f/1.8, soft natural light"

4. **Use Negative Prompts (If Tool Supports):**
   - Negative: "blur, grain, low quality, cartoon, unrealistic, text, watermark"

### Platform Recommendations

- **Replicate.com:** Good for API access, pay-per-use
- **Fal.ai:** Fast, reliable, affordable
- **Together.ai:** Batch processing friendly

---

## Post-Processing

### Essential Edits (Every Image)

1. **Background Cleanup:**
   - Remove any AI artifacts, odd shadows
   - Ensure background is pure white (255,255,255) if intended
   - Use magic wand tool + delete, or mask + refine edge

2. **Color Correction:**
   - Levels: Ensure blacks are true black, whites are true white
   - Curves: Gentle S-curve for contrast
   - Saturation: +5 to +10% boost (AI often undersaturates)

3. **Sharpening:**
   - Unsharp Mask: Amount 80-120%, Radius 1.0px, Threshold 0
   - Or High Pass Filter: 1-2px radius, set layer to Overlay at 50-80%

4. **Crop & Align:**
   - Ensure product is level (horizon, verticals straight)
   - Crop to final aspect ratio
   - Rule of thirds or centered (depending on use)

### Advanced Edits (For Hero Images)

1. **Dodge & Burn:**
   - Lighten highlights on key product features
   - Darken shadows for depth
   - Use soft brush at 10-20% opacity

2. **Selective Color Grading:**
   - Adjust specific colors (e.g., make reds warmer, blues cooler)
   - Match brand color guidelines exactly

3. **Add Depth:**
   - Subtle vignette (darken edges 5-10%)
   - Gradient overlays for mood
   - Multiply layer with gradient for atmospheric depth

4. **Detail Enhancement:**
   - Duplicate layer, apply slight Gaussian blur
   - Set blend mode to Overlay at 20-30% (gives micro-detail pop)

### Tools

**Photoshop:** Industry standard, most powerful
**GIMP:** Free alternative, full-featured
**Photopea:** Browser-based, Photoshop-like, FREE
**Canva Pro:** Simple edits, background removal, good for non-designers

---

## Batch Workflows

### Generating 100+ Product Images

**Strategy:**

1. **Use Batch Scripts (Included in Pack):**
   - `batch-generator.py` → Generates all combinations
   - Run: `python batch-generator.py --auto`
   - Output: CSV with 100+ prompts

2. **Copy-Paste Method:**
   - Load CSV into Google Sheets
   - Filter by product category or style
   - Copy prompts column
   - Paste into AI tool (1 at a time or via API)

3. **API Approach (Advanced):**
   - Midjourney API (via unofficial wrappers)
   - DALL-E API (official OpenAI)
   - Flux API (Replicate, Fal.ai)
   - Script loops through prompts, auto-generates

4. **Curate in Batches:**
   - Generate 20 images
   - Quick-review: keep/delete
   - Upscale keepers
   - Repeat

### Tools for Batch Processing

- **Airtable:** Organize prompts, track status
- **Notion:** Database of generated images with tags
- **Eagle App:** Visual library management
- **Adobe Bridge:** Batch metadata, ratings

---

## Common Mistakes

### ❌ Mistake 1: Vague Prompts

**Bad:**
```
product photography of headphones
```

**Good:**
```
Isometric 3D render of premium wireless headphones, matte black with rose gold accents, floating above hexagonal platform, soft studio lighting, white background, commercial quality, 8K
```

**Why:** AI needs details to make decisions. Vague = generic stock photo look.

---

### ❌ Mistake 2: Too Many Concepts in One Prompt

**Bad:**
```
headphones floating and also on a table with flowers and neon lights and sunset
```

**Good:**
```
Pick ONE: floating platform OR natural lifestyle with flowers
```

**Why:** AI struggles with complex multi-scene prompts. Keep it focused.

---

### ❌ Mistake 3: Forgetting Negative Space

**Bad:**
```
Headphones fill entire frame, tight crop
```

**Good:**
```
Headphones centered with 30% padding on all sides, clean breathing room
```

**Why:** Products need space. Tight crops look claustrophobic, won't work for marketing.

---

### ❌ Mistake 4: Ignoring Aspect Ratio

**Bad:**
```
Generate 1:1 image, then stretch to 16:9 for website banner
```

**Good:**
```
Generate at final aspect ratio (16:9 for banner)
```

**Why:** Stretching distorts proportions. Always generate at target AR.

---

### ❌ Mistake 5: Accepting First Result

**Bad:**
```
Use first generated image without iteration
```

**Good:**
```
Generate 4 variations, upscale best 2, refine, repeat
```

**Why:** AI generation has randomness. First try is rarely the best.

---

### ❌ Mistake 6: Over-Reliance on AI (No Post-Processing)

**Bad:**
```
Export directly from AI tool, use raw image
```

**Good:**
```
Color correct, sharpen, clean background, adjust levels
```

**Why:** Raw AI images have artifacts, color issues, minor imperfections. 5 minutes in Photoshop = professional quality.

---

## Advanced Techniques

### Technique 1: Img2Img Refinement

**What:** Start with AI generation, then use that as reference for another generation

**Workflow:**
1. Generate product render (text-to-image)
2. Download result
3. Use as input image for img2img
4. Prompt: "Enhance lighting and materials, keep composition"
5. Result: Refined version with better details

**Tools:**
- Midjourney: `/blend` command
- DALL-E: Upload as reference
- Flux: img2img mode

---

### Technique 2: Style Transfer

**What:** Take photographic style from one image, apply to your product

**Workflow:**
1. Find reference product photo you love (e.g., Apple product page)
2. Use as style reference in AI tool
3. Generate your product in that style

**Midjourney:**
```
[your prompt] --sref [URL of reference image] --sw 100
```

---

### Technique 3: Composite Renders

**What:** Generate product and background separately, composite in Photoshop

**Workflow:**
1. Generate product on white background (easy to mask)
2. Generate just the background scene you want
3. Mask product from first image
4. Place on second image background
5. Match lighting with dodge/burn

**Why:** More control than trying to generate both perfectly in one shot

---

### Technique 4: Prompt Chaining

**What:** Use AI to write better prompts

**Workflow:**
1. Give ChatGPT your basic idea
2. Ask: "Write 5 Midjourney prompts for product photography of [item], emphasizing [style]"
3. Use generated prompts
4. Iterate on best results

---

### Technique 5: Seed + Variation Matrix

**What:** Generate systematic variations from one successful seed

**Workflow:**
1. Find perfect generation, note seed number
2. Generate grid of variations:
   - Same seed + different products
   - Same seed + different color palettes
   - Same seed + different lighting descriptions
3. Creates cohesive product line aesthetic

---

## Quality Checklist

Before finalizing any product render, verify:

**Technical:**
- [ ] Resolution: Minimum 2000px on long edge
- [ ] No visible AI artifacts or glitches
- [ ] Sharp focus on product (not blurry)
- [ ] Colors accurate to brand guidelines
- [ ] Lighting looks natural and intentional
- [ ] Shadows fall correctly (physics make sense)

**Composition:**
- [ ] Product is primary focus
- [ ] Adequate negative space
- [ ] Background doesn't distract
- [ ] Horizon/verticals are level
- [ ] Framing matches intended use (social, web, print)

**Brand Alignment:**
- [ ] Style matches brand aesthetic
- [ ] Colors match brand palette
- [ ] Mood aligns with target audience
- [ ] Looks premium (or playful, or natural, etc. as intended)

**Usability:**
- [ ] Works on white background (if needed)
- [ ] Works on dark background (if needed)
- [ ] Readable as thumbnail
- [ ] Text overlay space available (if for ads)

---

## File Management

### Naming Convention

```
[category]_[product]_[style]_[palette]_[version].png
```

Example:
```
headphones_wireless_floating-platform_tech-minimal_v03.png
```

### Folder Structure

```
/product-renders/
  /raw/               (straight from AI tool)
  /processed/         (after post-processing)
  /finals/            (approved, ready to use)
  /rejected/          (didn't make the cut, but saved)
  /prompts/           (text files with prompts used)
```

---

## Legal & Ethical

**Copyright:**
- AI-generated images are generally your IP (check tool's ToS)
- Midjourney: You own images (with paid plan)
- DALL-E: You own images
- Flux: Depends on platform ToS

**Best Practices:**
- Don't copy real products verbatim (create inspired by, not clones)
- Don't use brand names/logos you don't own
- Disclose AI-generated if selling as product (some platforms require it)

**Use Cases:**
- ✅ Mockups for your own products
- ✅ Placeholder images for design work
- ✅ Concept visualization for clients
- ✅ Social media content for your brand
- ❌ Claiming as "real photography" when it's not
- ❌ Using competitor's exact products for your marketing

---

## Next Steps

1. **Start Simple:** Choose 3 prompts, test with your product
2. **Iterate:** Generate variations, refine prompts
3. **Build Library:** Create 20-30 hero images for your catalog
4. **Automate:** Use batch scripts for large-scale generation
5. **Polish:** Spend time on post-processing for top 10 images
6. **Deploy:** Use in website, social media, ads, packaging

**Remember:** AI is a tool, not a replacement for creative direction. The best results come from combining AI generation with human curation and refinement.

---

## Support & Community

- **Midjourney Discord:** Active community, prompt sharing
- **Reddit r/midjourney:** Tips and inspiration
- **Twitter #AIart:** Cutting-edge techniques
- **This Pack:** Reach out to support@gammawaves.studio with questions

**Happy rendering! 🎨📸**
