# 3D Product Renders Pack

**Professional prompts and tools for AI-generated product photography**

Create stunning isometric 3D product renders without Blender skills. This pack includes 20 battle-tested prompts, scene templates, color palettes, and batch generation scripts for Midjourney, DALL-E 3, and Flux.

## What's Inside

- **20 Product Render Prompts** — Ready-to-use prompts for phones, laptops, headphones, sneakers, watches, and more
- **5 Blender Scene Templates** — Lighting/camera setups described in detail (recreate or use as AI prompt reference)
- **5 Color Palette Guides** — Curated schemes from tech-minimal to luxury-dark
- **2 Python Batch Scripts** — Generate 100+ prompt variations automatically
- **Best Practices Guide** — Pro tips for AI product photography

## How to Use

### Quick Start (Copy-Paste)
1. Open `prompts/` folder
2. Copy any .txt prompt file
3. Paste into Midjourney, DALL-E, or Flux
4. Adjust product name or colors if needed
5. Generate!

### Advanced (Batch Generation)
1. Install Python 3.8+
2. Run `python scripts/batch-generator.py`
3. Select products, styles, and color palettes
4. Script outputs 50-200 unique prompts
5. Batch generate in your AI tool of choice

### Midjourney Specific
All prompts include recommended parameters:
- `--ar 1:1` for Instagram/square
- `--ar 16:9` for website headers
- `--ar 9:16` for mobile/stories
- `--v 6.1` (latest model)
- `--style raw` for photorealistic renders

## Prompt Structure

Each prompt includes:
- **Product Description** — Item being rendered
- **Scene Setup** — Platform, background, composition
- **Lighting** — Key, fill, rim, and accent lights
- **Style Notes** — Material finish, reflections, shadows
- **Recommended Settings** — Model version, aspect ratio, style flags

## Tool Compatibility

- **Midjourney v6/v6.1** ✅ Optimized (best results)
- **DALL-E 3** ✅ Works well (adjust for more descriptive style)
- **Flux Pro/Dev** ✅ Strong isometric renders
- **Stable Diffusion XL** ⚠️ Requires prompt tweaking (use embeddings)
- **Leonardo.ai** ✅ Good with Alchemy upscale
- **Ideogram** ✅ Solid for clean product shots

## License

**Commercial Use:** ✅ Allowed — sell generated images freely  
**Attribution:** Not required  
**Resale of prompts:** ❌ Not permitted  
**Generated images:** 100% yours to use in any project  

## Use Cases

- E-commerce product mockups
- Marketing/social media assets
- Pitch decks and presentations
- Web design placeholder imagery
- Print-on-demand designs
- Portfolio filler content

## Pro Tips

- **Consistency:** Use same seed number + palette for product line cohesion
- **Variations:** Run each prompt 4x, pick the best, upscale
- **Editing:** Export high-res, edit in Photoshop (remove bg, add text, etc.)
- **Batch Workflow:** Use scripts to generate 100 images, curate top 20
- **Upscaling:** Use Topaz Gigapixel or AI upscalers for print quality (300dpi+)

## What's NOT Included

- Actual 3D model files (prompts generate images only)
- Blender .blend files (templates are descriptions, not files)
- Stock photos (everything is AI-generated from scratch)
- Video tutorials (text guides only)

## Support

Questions? Need help adapting prompts for your niche?  
Email: support@gammawaves.studio

---

**3D Product Renders Pack v1.0**  
© 2026 Gamma Waves Design Studio  
Made with 🐾 by GWDS
