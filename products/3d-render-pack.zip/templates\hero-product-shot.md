# Blender Scene Template: Hero Product Shot

**Use Case:** Main product page image, hero banner, e-commerce primary photo

## Scene Setup

### Camera
- **Type:** Orthographic (for true isometric) or Perspective with long focal length
- **Focal Length:** 85mm equivalent (low distortion)
- **Position:** Front-left at 30° horizontal, 20° vertical elevation
- **Framing:** Product fills 60-70% of frame, breathing room on all sides
- **Depth of Field:** F/5.6 equivalent (most of product sharp, slight bg blur)

### Lighting Rig

**Key Light (Main)**
- Position: Upper left, 45° from camera axis
- Type: Area light (2m x 2m softbox simulation)
- Intensity: 100W
- Color Temperature: 5500K (neutral daylight)
- Purpose: Creates primary highlights and defines form

**Fill Light (Shadow Softener)**
- Position: Camera right, at camera height
- Type: Area light (3m x 2m, very soft)
- Intensity: 30W (30% of key)
- Color Temperature: 6000K (slightly cooler)
- Purpose: Prevents shadows from going black, shows detail

**Rim Light (Edge Definition)**
- Position: Behind product, opposite key light
- Type: Spot light with slight softness
- Intensity: 60W
- Color Temperature: 5000K
- Purpose: Separates product from background with bright edge

**Background Light (Optional)**
- Position: Behind product, pointing at backdrop
- Type: Area light or spot
- Intensity: 40W
- Purpose: Creates gradient on background, depth

### Environment

**Background:**
- Infinite white plane (no horizon line) OR
- HDRi environment (studio_small_08.exr recommended)
- Gradient ramp shader (white to light gray)

**Ground Plane:**
- Glossy white surface (Roughness: 0.1) OR
- Matte platform (cube/cylinder primitive)
- Receives shadows for grounding

**Render Settings:**
- Engine: Cycles (for photorealism)
- Samples: 512 minimum (1024 for finals)
- Denoising: Intel Open Image Denoise enabled
- Color Management: Filmic, Medium High Contrast

## Material Guidelines

### Product Materials
Use Principled BSDF with these starting points:

**Metal (Brushed Aluminum):**
- Metallic: 1.0
- Roughness: 0.3-0.5
- Anisotropic: 0.3 (for brushed direction)
- Texture: Noise texture for micro-scratches

**Plastic (Matte):**
- Metallic: 0.0
- Roughness: 0.6-0.8
- Subsurface: 0.05 (subtle depth)
- Color: Product color in Base Color

**Glass (Screen, Lens):**
- Transmission: 1.0
- Roughness: 0.05 (slight blur)
- IOR: 1.517 (typical glass)
- Screen content: Emission shader mix (subtle glow)

**Rubber/Silicone:**
- Roughness: 0.7-0.9 (very matte)
- Subsurface: 0.1 (soft translucency)
- Bump map for texture

### Background Material
- Simple diffuse white OR
- Gradient texture node (white to gray)
- Roughness: 1.0 (completely matte, no reflections)

## Post-Processing

**Compositor Nodes (Blender):**
1. Glare node (subtle bloom on highlights, threshold 1.0)
2. Color correction (slight S-curve for contrast)
3. Slight vignette (darken edges 5-10%)

**External (Photoshop/GIMP):**
- Levels adjustment (crush blacks slightly)
- Saturation +5 to +10%
- Sharpen (Unsharp Mask: Amount 80%, Radius 1px)
- Export as sRGB JPEG (quality 95%) or PNG

## Common Adjustments

**Product too bright?** Lower key light intensity or increase fill  
**Background too gray?** Add background light or increase environment strength  
**Edges too harsh?** Increase rim light softness or lower intensity  
**Not enough pop?** Increase key-to-fill ratio (make fill dimmer)  
**Looks flat?** Rotate product slightly, add rim light  

## File Organization

```
hero-product-shot.blend
├── Camera
├── Lights
│   ├── Key_Light
│   ├── Fill_Light
│   ├── Rim_Light
│   └── BG_Light (optional)
├── Product (import your model here)
├── Ground_Plane
└── Background
```

**Instructions:**
1. Append this template into new project
2. Import/link your product .obj or .fbx
3. Scale and position product at world origin
4. Assign materials using reference above
5. Render test (256 samples)
6. Adjust lighting as needed
7. Final render (1024 samples)

---

**Pro Tip:** Save this as a startup template. Every new product render starts from the same professional lighting setup, ensuring consistency across your catalog.
