# Tech Minimal Color Palette

**Brand Vibe:** Clean, modern, professional, Apple/Tesla aesthetic

---

## Core Colors

### Primary
- **Space Gray:** `#2C2C2E` | RGB(44, 44, 46)
  - Use for: Product bodies, primary elements
  - Works with: Metal, matte plastic, anodized aluminum

- **Pure White:** `#FFFFFF` | RGB(255, 255, 255)
  - Use for: Backgrounds, accents, secondary products
  - Works with: Clean surfaces, modern plastics

### Accent
- **Silver:** `#C7C7CC` | RGB(199, 199, 204)
  - Use for: Metal details, bezels, trim
  - Works with: Brushed metal, polished steel

- **Cool Gray:** `#8E8E93` | RGB(142, 142, 147)
  - Use for: Shadows, inactive elements, text (in UI mockups)
  - Works with: Matte finishes, stone

### Highlight (Use Sparingly)
- **Electric Blue:** `#007AFF` | RGB(0, 122, 255)
  - Use for: LED indicators, screen glows, CTAs
  - Works with: Glass, translucent plastic, lights

---

## Product Applications

### Smartphones
- Body: Space Gray or Pure White
- Frame: Silver trim
- Screen: Black with Electric Blue UI elements
- Buttons: Matching body color

### Laptops
- Chassis: Space Gray (premium) or Silver (classic)
- Keyboard: Black keys on Space Gray body
- Screen: White/light interface
- Logo: Silver emboss or Electric Blue backlight

### Accessories (Earbuds, Watches, etc.)
- Primary: White or Space Gray
- Accents: Silver metal components
- Indicators: Electric Blue LEDs

---

## Background Recommendations

- **Seamless White:** Most versatile, lets product shine
- **Light Gray Gradient:** White (#FFFFFF) to Cool Gray (#F2F2F7)
- **Dark Mode:** Pure black (#000000) with Space Gray products
- **Concrete Texture:** Subtle gray (#E5E5EA) with texture overlay

---

## Lighting Setup

**Color Temperature:**
- Key Light: 5500K (neutral daylight)
- Fill: 6000K (slightly cool, tech feel)
- Rim: 5000K (neutral to warm)

**Mood:**
- Even, controlled, studio quality
- Minimal shadows (tech products need clarity)
- Subtle highlights on metal edges

---

## Typography Pairing

**Fonts:**
- San Francisco (Apple system font)
- Inter
- Helvetica Neue
- Roboto

**Usage:**
- Product names: Light weight, 48-72pt
- Specs: Regular weight, 12-14pt
- Headlines: Medium weight, all caps, letter-spacing +0.05em

---

## Complementary Materials

### Surfaces
- **Brushed aluminum** (Space Gray or Silver)
- **Matte frosted glass** (White or translucent)
- **Polished steel** (Silver accents)
- **Soft-touch rubber** (Space Gray for grips)

### Textures
- Avoid: Glossy plastic (looks cheap)
- Prefer: Matte, brushed, sandblasted finishes
- Glass: Anti-reflective coating simulation

---

## DO's and DON'Ts

✅ **DO:**
- Keep color count to 2-3 max per product
- Use white backgrounds for e-commerce
- Add subtle blue glow for screens/LEDs
- Maintain high contrast for readability
- Use shadows sparingly (soft, minimal)

❌ **DON'T:**
- Mix warm and cool grays in same product
- Use saturated colors (except blue accent)
- Over-texture products (keep clean)
- Add gradients to solid surfaces
- Use yellow or orange (warm tones break aesthetic)

---

## Variations

### Light Mode (Default)
- Background: White (#FFFFFF)
- Product: Space Gray or Silver
- Accents: Electric Blue

### Dark Mode
- Background: Black (#000000) or Deep Gray (#1C1C1E)
- Product: Silver or White
- Accents: Electric Blue (brighter, #0A84FF)

### Monochrome Premium
- All grays: Pure White → Cool Gray → Space Gray → Black
- No color accents (ultra-minimal)
- Sophisticated, editorial feel

---

## Brand Examples

- **Apple** (iPhone, MacBook, AirPods)
- **Tesla** (product design, not cars)
- **Microsoft Surface** (hardware line)
- **Google Pixel** (marketing imagery)
- **Nothing** (tech brand with minimal aesthetic)

---

## AI Prompt Integration

When using these colors in AI prompts:

```
"...sleek space gray aluminum body with brushed metal finish, pure white background, minimal studio lighting, electric blue LED indicator, tech-minimal aesthetic, Apple product photography style..."
```

**Keywords:**
- "Tech-minimal"
- "Apple aesthetic"
- "Neutral tones"
- "Brushed metal"
- "Clean and modern"

---

## Hex Color Quick Reference

| Color | Hex | RGB |
|-------|-----|-----|
| Space Gray | #2C2C2E | 44, 44, 46 |
| Pure White | #FFFFFF | 255, 255, 255 |
| Silver | #C7C7CC | 199, 199, 204 |
| Cool Gray | #8E8E93 | 142, 142, 147 |
| Electric Blue | #007AFF | 0, 122, 255 |
| Black | #000000 | 0, 0, 0 |

---

**Pro Tip:** This palette is timeless. It won't date your renders in 5 years. Perfect for tech products, professional services, B2B marketing, and anything that needs to communicate quality and reliability. When in doubt, go monochrome and add one blue accent.
