# Blender Scene Template: Natural Lifestyle

**Use Case:** Wellness brands, organic products, lifestyle blogs, approachable commercial photography

## Scene Setup

### Camera
- **Type:** Perspective
- **Focal Length:** 50-85mm (natural portrait lens feel)
- **Position:** Eye-level or slightly above, intimate angle
- **Framing:** Product in thirds, context elements visible (not isolated)
- **Depth of Field:** Shallow to medium (F/2.8-F/4), soft background bokeh

### Soft Natural Lighting

**Window Light Simulation (Key):**
- Type: Area light (4m x 3m, rectangular like a window)
- Position: Camera left, 60° angle, slightly above product
- Strength: 40W (soft, diffused daylight)
- Color Temperature: 5800K (overcast daylight) to 4500K (warm afternoon)
- Purpose: Simulates north-facing window or shaded outdoor light

**Bounce Card Fill (Subtle):**
- Type: Area light (large, 3m x 3m)
- Position: Camera right, opposite window light
- Strength: 10W (very gentle)
- Color: Warm white 4000K
- Purpose: Mimics light bouncing off walls/floors, lifts shadows naturally

**No Harsh Lights** — Everything is soft and diffused

### Environment Setup

**Background Options:**

1. **Out-of-Focus Greenery:**
   - Add 3D plants (low-poly, will be blurred anyway)
   - Position 1-2 meters behind product
   - Shader: Mix of green tones, slight translucency
   - Blur via camera depth of field

2. **Wooden Surface:**
   - Ground plane with realistic wood PBR texture
   - Rough planks or smooth table finish
   - Warm brown/honey tones

3. **White/Cream Seamless:**
   - Simple infinite backdrop
   - Slight warm tint (cream, not pure white)
   - Minimal but clean

**Props & Context:**

**Natural Elements:**
- Plant leaves (eucalyptus, monstera, ferns)
- Flowers (fresh, not wilted)
- Wooden slices (tree rings visible)
- Stones, pebbles
- Linen fabric, cotton cloth
- Water droplets (optional freshness)

**Arrangement:**
- Scatter props casually (not perfectly arranged)
- Some elements in foreground (out of focus, frame product)
- Some in background (depth, context)
- Avoid clutter — 2-4 props maximum

### Product Positioning

**Placement:**
- Not centered — rule of thirds
- Slightly tilted or angled (human touch, not sterile)
- Interacting with props (resting on leaf, beside stones)
- Shadows fall naturally on surface

**Scale:**
- Product is hero but not isolated
- Context supports product story (botanicals for skincare, food for kitchen products, etc.)

## Render Settings

**Cycles Engine:**
- Samples: 512 (1024 if lots of translucency/subsurface)
- Max Bounces: 8 (soft light bounces create warmth)
- Caustics: Disabled (too sharp for natural look)
- Denoising: Enabled (gentle, preserve detail)

**Output:**
- Resolution: 2000x2500px (4:5 Instagram) or 2000x2000 (1:1)
- Color Management: Filmic, Medium-Low Contrast (soft, not punchy)
- Format: PNG or JPG (high quality, 95%)

## Material Guidelines

**Product Materials:**
- Slightly increase roughness (no mirror finishes)
- Add subsurface scattering to relevant materials (wax, translucent plastics)
- Matte labels with slight bump texture

**Natural Prop Materials:**

**Wood:**
```
Principled BSDF:
  Base Color: Wood texture (warm tones)
  Roughness: 0.6-0.8
  Subsurface: 0.05 (organic depth)
  Bump: Procedural wood grain
```

**Leaves:**
```
Principled BSDF:
  Base Color: Green (varied shades)
  Roughness: 0.4
  Subsurface: 0.2 (light passes through)
  Translucency: Connect to Subsurface Color
  Alpha: Leaf texture with alpha channel
```

**Linen Cloth:**
```
Principled BSDF:
  Base Color: Cream/beige
  Roughness: 0.8 (very matte)
  Sheen: 0.3 (fabric-like reflection)
  Bump: Fabric weave texture
```

**Water Droplets (Advanced):**
- Glass BSDF with high IOR (1.33)
- Small sphere primitives scattered on surfaces
- Transmission: 1.0, Roughness: 0.0

## Color Palette

**Warm Natural:**
- Greens: #7A9B76, #A8C5A0 (muted, not neon)
- Browns: #8B7355, #D4A574 (wood, earth)
- Creams: #F5F1E8, #E8DCC4 (backgrounds)
- Product: Can be any color, but earth tones blend best

**Avoid:**
- Pure white (too clinical)
- Bright neon colors (unless product requires it)
- Stark black (too harsh)

## Lighting Variations

### Morning Light (Cool & Fresh)
- Key Light: 6000K (cool daylight)
- Bounce: White (neutral)
- Mood: Energizing, clean, spa-like

### Afternoon Warmth (Current)
- Key Light: 4500K (warm sunlight)
- Bounce: Warm white
- Mood: Cozy, inviting, organic

### Golden Hour (Editorial)
- Key Light: 3500K (sunset)
- Bounce: Orange-tinted
- Mood: Luxury natural, high-end wellness

## Composition Tips

**Rule of Thirds:**
- Product at intersection points (not dead center)
- Leaves/props in foreground at opposite third
- Background elements provide depth

**Depth Layers:**
1. Foreground: Blurred leaf or edge of fabric (frames shot)
2. Mid-ground: Product in focus
3. Background: Soft bokeh of plants/texture

**Leading Lines:**
- Branch extending from corner toward product
- Table edge diagonal across frame
- Fabric fold directing eye

## Post-Processing

**Minimal Touch-Ups:**
1. **White Balance:** Shift slightly warm (200-400K)
2. **Saturation:** -5 to -10% (muted, not oversaturated)
3. **Contrast:** Gentle S-curve (soft blacks, not crushed)
4. **Sharpening:** Very light (Amount 40%, Radius 1px)
5. **Vignette:** Subtle darken edges (5-10%)

**Optional Organic Feel:**
- Film grain overlay (2-3% opacity)
- Slight color shift (green in shadows, warm in highlights)
- Diffusion glow (soft light halo around bright areas)

## AI Prompt Equivalent

```
"Natural lifestyle product photography of [PRODUCT] on wooden surface with fresh eucalyptus leaves and soft morning light. Window light from left, gentle shadows, botanical styling, organic aesthetic. Out-of-focus greenery background, depth of field. Warm and inviting, wellness brand style. --ar 4:5 --style raw"
```

## Use Cases

- Skincare/beauty (natural/organic brands)
- Food products (artisanal, farm-to-table)
- Wellness products (supplements, aromatherapy)
- Sustainable/eco brands
- Handmade crafts, artisanal goods
- Lifestyle blog content
- Instagram feed aesthetic (cohesive natural branding)

## Brand Examples (This Aesthetic)

- Aesop (skincare)
- Herbivore Botanicals
- Goop
- Kinfolk magazine style
- Anthropologie product shots

## Common Mistakes

❌ **Too cluttered** — Stick to 2-4 props max  
❌ **Props too sharp** — Blur with DoF or manually in post  
❌ **Harsh shadows** — Soft light only, strong fill  
❌ **Fake plastic plants** — Use realistic 3D models or real photos as textures  
❌ **Oversaturation** — Keep colors muted and natural  

✅ **Soft, diffused light always**  
✅ **Real texture and imperfection** (wood grain, leaf veins)  
✅ **Warm color temperature** (inviting, not clinical)  
✅ **Shallow depth of field** (professional camera feel)  

---

**Pro Tip:** This style sells trust and authenticity. Perfect for brands that emphasize natural ingredients, sustainability, or artisanal craft. Shoot multiple angles with same lighting setup for consistent social media grid. Pair with earthy color palettes in branding for maximum cohesion.
