# Blender Scene Template: Dramatic Shadow Minimal

**Use Case:** Editorial layouts, minimalist branding, architectural product photography

## Scene Setup

### Camera
- **Type:** Perspective
- **Focal Length:** 50mm (natural perspective)
- **Position:** Overhead at 30-45° angle, looking slightly down
- **Framing:** Product in upper third, shadow extends into lower two-thirds
- **Depth of Field:** Deep (F/8-F/11), everything sharp

### Single-Source Lighting

**Key Light (Only Light):**
- Type: Sun lamp (parallel rays, sharp shadows)
- Position: Upper right, 60-70° from vertical
- Strength: 5.0 (strong, simulates direct sunlight through window)
- Color Temperature: 5500K (neutral daylight)
- Shadow: Sharp and defined (no softness)
- Purpose: Creates long, dramatic shadow as the primary visual element

**No Fill Light** — This is critical to the aesthetic. Shadows should go nearly black.

**No Rim Light** — Product edges are defined by shadow, not highlights.

### Environment

**Background:**
- Completely white infinite plane OR
- Large white wall behind product (no texture, pure white)
- Material: Emission shader at strength 0.5 (contributes to ambient only)

**Ground Plane:**
- Pure white diffuse material
- Roughness: 1.0 (completely matte)
- No glossy reflections (shadow is the only dark element)

**Alternative (Inverted):**
- Black background + white/light product

### Product Positioning

**Placement:**
- Product positioned in upper right or upper left quadrant
- Shadow extends diagonally across frame toward opposite lower corner
- Shadow length: 2-3x the product dimension
- Composition: 70-80% negative space (white), 20-30% product + shadow

## Render Settings

**Eevee Engine (Faster, Sufficient):**
- Ambient Occlusion: Enabled
- Shadows: High quality
- Anti-Aliasing: 16x

**Cycles (Higher Quality):**
- Samples: 128 (shadows are sharp, less noise)
- Max Bounces: 4 (minimal indirect lighting needed)
- Denoising: Optional (mostly clean)

**Output:**
- Resolution: 3000x3000px (square for flexibility)
- Color Management: Filmic, High Contrast OR Standard sRGB
- Format: PNG (preserve pure white) or JPG

## Material Guidelines

**Product Material:**
- Use realistic PBR materials
- Slightly increase roughness (avoid mirror-like reflections)
- Keep colors saturated but not neon
- Product should be mid-tone or dark to contrast white background

**Background/Ground:**
```
Emission Shader (Background Plane):
  Color: Pure White RGB(1, 1, 1)
  Strength: 0.5
  
Diffuse BSDF (Ground):
  Color: Pure White
  Roughness: 1.0
```

## Composition Rules

### Shadow Direction
- **Upper right to lower left:** Classic, natural (sun from window)
- **Upper left to lower right:** Also natural, choose based on product shape
- **Straight down:** Harsh midday sun, very minimal
- **Long horizontal:** Early morning/late afternoon feel

### Negative Space
- Allow shadow to breathe — don't crop it tight
- 60-80% of frame should be empty white
- Product is intentionally small in frame (creates luxury, importance)

### Product Orientation
- Show the most recognizable angle
- Avoid perfect front-on (boring)
- 30° rotation reveals depth and form
- Consider how shadow interacts with product shape

## Variations

### Colored Shadows
- Add **subtle** colored gel to sun light (pale blue, soft purple)
- Shadow becomes tinted instead of gray
- Very trendy, editorial feel

### Multiple Shadows (Advanced)
- Add second sun lamp at different angle
- Creates overlapping shadows (window blinds effect)
- Keep second light at 30-50% strength of primary

### Textured Background
- Replace white with subtle paper texture
- Very high-key (bright), just hint of grain
- Adds warmth and tactility

### Gradient Background (Soft Version)
- Instead of pure white, use white-to-light-gray gradient
- Reduces stark contrast slightly
- More approachable for some brands

## Post-Processing

**Minimal (Preferred):**
- Levels adjustment: Ensure whites are pure white (255, 255, 255)
- Slight sharpening (Unsharp Mask, amount 50%)
- Export at high quality

**Optional Enhancements:**
- Increase shadow contrast (darker blacks in shadow area)
- Slight color tint (warm or cool, 5-10%)
- Add subtle film grain for analog feel

## AI Prompt Equivalent

```
"Minimalist product photography of [PRODUCT] on pure white background, dramatic long shadow extending across frame. Single directional sunlight from upper right, high contrast, architectural aesthetic. Product small in frame, 70% negative space. Clean and editorial. --ar 1:1 --style raw"
```

## Use Cases

- **Editorial Magazines:** The New York Times, Monocle aesthetic
- **Luxury Brands:** High-end minimalism (Byredo, Aesop vibes)
- **Architecture Firms:** Products as objects, form-focused
- **Art Galleries:** Museum-quality product presentation
- **Portfolio Hero Images:** Stand-out visual with design intent

## Common Mistakes

❌ **Shadow too short** — Should be 2-3x product length  
❌ **Fill light added** — Breaks the minimalist tension  
❌ **Background too gray** — Must be bright white or inverted to black  
❌ **Product centered** — Loses dynamic composition  
❌ **Shadow too soft** — Should be crisp with defined edge  

✅ **Keep it simple** — One light, pure backgrounds, bold composition  

---

**Pro Tip:** This style works best with products that have interesting silhouettes. The shadow becomes a graphic element as important as the product itself. Print this large (24x24 inches minimum) for gallery-quality presentation.
