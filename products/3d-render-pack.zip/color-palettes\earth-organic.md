# Earth Organic Color Palette

**Brand Vibe:** Natural, sustainable, wholesome, eco-conscious, artisanal

---

## Core Colors

### Earth Tones
- **Terracotta:** `#D4735E` | RGB(212, 115, 94)
  - Use for: Clay pottery, warm accents, earthy products
  - Works with: Ceramics, natural plastics

- **Sage Green:** `#87A96B` | RGB(135, 169, 107)
  - Use for: Plant-based products, wellness, eco-friendly
  - Works with: Matte finishes, organic materials

- **Warm Sand:** `#E8D6B6` | RGB(232, 214, 182)
  - Use for: Backgrounds, neutrals, natural bases
  - Works with: Paper, cotton, unbleached materials

### Natural Accents
- **Forest Green:** `#4A5D39` | RGB(74, 93, 57)
  - Use for: Deep greens, botanical themes, outdoor
  - Works with: Recycled materials, wood

- **Clay Brown:** `#8B5A3C` | RGB(139, 90, 60)
  - Use for: Leather, wood, rich earth
  - Works with: Natural wood, leather goods

- **Stone Gray:** `#9FA8A3` | RGB(159, 168, 163)
  - Use for: Concrete, stone, minimal modern organic
  - Works with: Stone, concrete, paper

### Soft Neutrals
- **Cream:** `#F5F1E8` | RGB(245, 241, 232)
  - Use for: Backgrounds, soft contrast
  - Works with: Textiles, paper, natural bases

- **Charcoal:** `#3B3A36` | RGB(59, 58, 54)
  - Use for: Text, deep shadows, grounding
  - Works with: Depth, contrast against light tones

---

## Product Applications

### Skincare/Beauty (Natural/Organic)
- Packaging: Terracotta ceramic jar or Warm Sand cardboard
- Cap: Forest Green or Clay Brown wood
- Label: Cream with Charcoal typography
- Background: Sage Green botanicals or Warm Sand seamless

### Food Products (Artisanal/Farm-to-Table)
- Primary: Warm Sand packaging (kraft paper aesthetic)
- Accent: Terracotta or Sage Green labels
- Text: Forest Green or Charcoal
- Props: Real botanicals, wooden surfaces

### Wellness/Supplements
- Bottle: Forest Green glass or Stone Gray ceramic
- Cap: Clay Brown wood or metal
- Label: Cream with Sage Green accents
- Background: Out-of-focus greenery or wood texture

### Home Goods (Sustainable/Handmade)
- Product: Terracotta clay, Sage Green textiles
- Details: Clay Brown leather, Forest Green stitching
- Base: Stone Gray concrete or wooden surface
- Background: Cream or botanical setting

---

## Background Recommendations

- **Soft Focus Greenery:** Blurred leaves, forest, plants
- **Natural Wood:** Light oak, walnut, reclaimed timber
- **Linen/Cotton Fabric:** Cream or Warm Sand textured cloth
- **Stone/Concrete:** Stone Gray textured surface
- **Kraft Paper:** Warm Sand background with slight texture

---

## Lighting Setup

**Color Temperature:**
- Key Light: 4500K (warm afternoon sunlight)
- Fill: 5000K (neutral warm)
- Backlighting: 4000K (golden hour glow)

**Mood:**
- Soft, natural, diffused (window light)
- Gentle shadows (no harsh contrast)
- Warm overall feel (inviting, cozy)
- Organic, unpretentious

---

## Material Finishes

### Natural Materials
- **Unglazed Ceramic:** Terracotta with visible texture
- **Wood:** Clay Brown, visible grain, matte oil finish
- **Stone:** Stone Gray, rough texture, natural splits
- **Paper/Cardboard:** Warm Sand, recycled texture
- **Cotton/Linen:** Cream, visible weave, matte

### Textures
- **Clay:** Rough, porous, handmade feel
- **Wood Grain:** Linear, natural, imperfect
- **Woven Fabric:** Visible threads, irregular weave
- **Paper Pulp:** Fibrous, recycled look
- **Leather:** Clay Brown, vegetable-tanned, natural patina

---

## Typography Pairing

**Fonts:**
- Freight Text (warm, readable serif)
- Mrs Eaves (elegant organic serif)
- Avenir (clean modern sans for contrast)
- Philosopher (rounded, approachable)

**Usage:**
- Product names: Serif, Terracotta or Forest Green
- Descriptions: Sans-serif, Charcoal, smaller weight
- Organic/Natural claims: Script or hand-lettered feel

---

## Botanical Elements

**Props to Include:**
- Eucalyptus branches (Sage Green)
- Dried lavender (muted purple accent)
- Fresh rosemary or thyme (Forest Green)
- Cotton stems (Cream puffs)
- Wooden spoons/utensils (Clay Brown)
- River stones (Stone Gray, smooth)
- Twine/jute string (natural tan)

---

## Color Combinations

### Warm Earthy
- Terracotta + Clay Brown + Cream
- Use: Ceramics, pottery, handmade goods

### Fresh Natural
- Sage Green + Warm Sand + Cream
- Use: Wellness, fresh food, eco-products

### Modern Organic
- Stone Gray + Forest Green + Cream
- Use: Contemporary sustainable brands, minimalist eco

### Classic Earth
- Clay Brown + Forest Green + Warm Sand
- Use: Traditional organic, farm-to-table, artisanal

---

## DO's and DON'Ts

✅ **DO:**
- Use real botanical props (or realistic 3D models)
- Add imperfections (texture, grain, irregularity)
- Keep lighting soft and natural
- Layer natural materials (wood + fabric + plants)
- Embrace muted, desaturated tones

❌ **DON'T:**
- Use neon or electric colors (breaks organic feel)
- Over-process images (too sharp, too perfect)
- Use pure white backgrounds (too clinical)
- Add synthetic materials (plastic, chrome)
- Use cool blue tones (too cold for earth palette)

---

## Seasonal Variations

### Spring
- Lighter: Cream + Sage Green + soft yellow-green
- Fresh growth, renewal, botanical focus

### Summer
- Brighter: Warm Sand + Terracotta + Forest Green
- Sun-dried, warm, abundant

### Autumn (Current Vibe)
- Deeper: Clay Brown + Terracotta + Forest Green
- Harvest, grounding, cozy

### Winter
- Muted: Stone Gray + Charcoal + Cream
- Minimal, restful, quiet earth

---

## Brand Examples

- **Herbivore Botanicals** (natural skincare)
- **Patagonia** (earth tones in branding)
- **Burt's Bees** (natural beauty products)
- **Thrive Market** (organic foods e-commerce)
- **The Honest Company** (eco-friendly goods)
- **Package Free** (zero-waste products)

---

## AI Prompt Integration

```
"...earth-toned organic aesthetic, terracotta and sage green color palette, natural wood surface, soft botanical styling, warm afternoon sunlight, handmade artisanal feel, eco-conscious product photography, sustainable materials, matte natural finishes..."
```

**Keywords:**
- "Earth tones"
- "Organic aesthetic"
- "Natural materials"
- "Botanical"
- "Artisanal"
- "Sustainable"
- "Warm natural lighting"

---

## Material Sourcing (Real Products)

**Where This Palette Works Best:**
- Skincare/beauty (natural/organic segment)
- Food products (artisanal, farm-to-table)
- Home goods (sustainable, handmade)
- Wellness products (supplements, aromatherapy)
- Baby products (organic, gentle)
- Stationery (recycled, eco-friendly)

**Price Point:**
- Mid-range to premium ($20-$100)
- Emphasizes quality, craftsmanship, sustainability over mass production

---

## Photography Style

**Composition:**
- Asymmetrical, natural arrangements
- Negative space with purpose
- Layered depth (foreground botanicals, mid-product, soft background)

**Styling:**
- Casual, unstaged look (even though it's deliberate)
- Props appear "just placed" not arranged
- Sunlight "happened" to hit perfectly (but it's controlled)

---

## Hex Color Quick Reference

| Color | Hex | RGB |
|-------|-----|-----|
| Terracotta | #D4735E | 212, 115, 94 |
| Sage Green | #87A96B | 135, 169, 107 |
| Warm Sand | #E8D6B6 | 232, 214, 182 |
| Forest Green | #4A5D39 | 74, 93, 57 |
| Clay Brown | #8B5A3C | 139, 90, 60 |
| Stone Gray | #9FA8A3 | 159, 168, 163 |
| Cream | #F5F1E8 | 245, 241, 232 |
| Charcoal | #3B3A36 | 59, 58, 54 |

---

**Pro Tip:** This palette builds trust. Consumers associate earth tones with authenticity, transparency, and care. Perfect for brands that emphasize natural ingredients, sustainable practices, or artisanal craft. When photographing products with this palette, embrace imperfection — a crooked label, visible texture, natural shadows. "Too perfect" reads as fake. Real organic brands have character.
