# Neon Future Color Palette

**Brand Vibe:** Cyberpunk, futuristic, high-tech, nightlife, vaporwave

---

## Core Colors

### Primary Neons
- **Electric Magenta:** `#FF10F0` | RGB(255, 16, 240)
  - Use for: Accent lighting, UI glows, bold statements
  - Works with: Glossy surfaces, RGB setups, neon signs

- **Cyber Cyan:** `#00FFFF` | RGB(0, 255, 255)
  - Use for: Cool tech vibes, digital interfaces, ice/future
  - Works with: Metal, glass, translucent plastics

- **Acid Green:** `#CCFF00` | RGB(204, 255, 0)
  - Use for: Energy, toxicity, sci-fi biological themes
  - Works with: Glowing elements, hazard aesthetics

### Secondary Accents
- **Deep Purple:** `#6600CC` | RGB(102, 0, 204)
  - Use for: Shadows, depth, mystical tech
  - Works with: Gradients from magenta

- **Hot Orange:** `#FF3300` | RGB(255, 51, 0)
  - Use for: Warmth in cold palette, warnings, energy
  - Works with: Neon signs, LED indicators

- **Ice Blue:** `#66B3FF` | RGB(102, 179, 255)
  - Use for: Holographic effects, cooling, tech ice
  - Works with: Transparent elements, holograms

### Neutral Base
- **Deep Black:** `#0A0A0A` | RGB(10, 10, 10)
  - Use for: Backgrounds, voids, space
  - Critical: Neons need darkness to glow

- **Charcoal:** `#1A1A1A` | RGB(26, 26, 26)
  - Use for: Product bodies, surfaces
  - Works with: Matte finishes, absorbs neon reflections

---

## Product Applications

### Gaming Peripherals
- Body: Charcoal or Deep Black matte
- Backlighting: Electric Magenta + Cyber Cyan RGB cycling
- Accents: Acid Green trim or Deep Purple underglow
- Background: Pure black with neon grid

### Smartphones/Tech (Futuristic)
- Body: Glossy black or dark chrome
- Screen UI: Cyber Cyan and Ice Blue elements
- Edge lighting: Electric Magenta rim glow
- Background: Dark with colored fog

### Headphones (Cyberpunk Style)
- Earcups: Charcoal with glossy finish
- LED strips: Electric Magenta and Cyber Cyan
- Cables: Neon-colored braided (Hot Orange or Acid Green)
- Background: Black with neon reflections

### Energy Drinks/Party Products
- Can: Deep Black base
- Graphics: Electric Magenta + Cyber Cyan + Acid Green
- Glow effects: Emission shaders on logo/text
- Background: Neon cityscape or abstract void

---

## Background Recommendations

- **Pure Black Void:** Let neons float in darkness
- **Cyberpunk City:** Blurred neon signs, rainy streets (Blade Runner)
- **Tech Grid:** Glowing gridlines receding to vanishing point (Tron)
- **Colored Fog:** Volumetric haze (Deep Purple or Cyber Cyan)
- **Digital Glitch:** Abstract pixel/data corruption patterns

---

## Lighting Setup

**Colored Key Lights:**
- **Left:** Cyber Cyan area light (80W, 45° angle)
- **Right:** Electric Magenta area light (100W, rim position)
- **Optional:** Acid Green or Hot Orange accent from below

**No White Light** — All illumination is colored

**Atmosphere:**
- Volumetric fog (subtle, colored)
- Light beams visible in haze
- Reflections on glossy surfaces critical

**Color Temperature:**
- Not applicable (no neutral light)
- Use RGB values directly for neon feel

---

## Material Finishes

### Metals
- **Chrome:** Mirror-polished, reflects neon colors
- **Brushed Dark Metal:** Charcoal, subtle anisotropic highlights
- **Holographic:** Iridescent shader, rainbow reflections

### Plastics
- **Glossy Black:** High reflection, wet-look finish (Roughness 0.05)
- **Translucent Neon:** Cyan or magenta plastic with subsurface glow
- **Matte Black:** Absorbs light, makes neon elements pop (Roughness 0.9)

### Glass
- **Smoked Glass:** Dark tint, shows neon reflections
- **Holographic:** Rainbow refraction, futuristic
- **Neon Tube:** Emission shader, cylindrical glass tubes

### Special FX
- **Emission Shaders:** On logos, UI elements, LEDs
- **Glow/Bloom:** Heavy in compositor for neon spill
- **Chromatic Aberration:** RGB split on edges (glitchy, digital)

---

## Typography Pairing

**Fonts:**
- Orbitron (geometric, sci-fi)
- Exo 2 (futuristic sans)
- Audiowide (tech, wide letterforms)
- Share Tech Mono (monospace, code aesthetic)

**Effects:**
- Neon glow (outer glow, Electric Magenta or Cyber Cyan)
- Glitch effect (RGB split, displacement)
- Scan lines (horizontal lines overlay)
- Holographic shimmer (animated rainbow gradient)

**Usage:**
- Headlines: Bold, all caps, neon glow
- UI text: Monospace, small, Cyber Cyan or Acid Green
- Warnings: Hot Orange with glitch effect

---

## Color Combinations

### Classic Cyberpunk
- Electric Magenta + Cyber Cyan + Deep Black
- Use: Tech products, gaming, nightlife
- Vibe: Blade Runner, Cyberpunk 2077

### Toxic Future
- Acid Green + Deep Purple + Deep Black
- Use: Energy drinks, hazard themes, bio-tech
- Vibe: Radioactive, dystopian

### Vaporwave
- Electric Magenta + Ice Blue + Deep Purple
- Use: Aesthetic art, retro-futurism, music
- Vibe: 80s/90s nostalgia meets future

### Synthwave
- Hot Orange + Cyber Cyan + Deep Purple
- Use: Retro gaming, music visuals, sunset themes
- Vibe: Outrun, retrowave, neon sunsets

---

## DO's and DON'Ts

✅ **DO:**
- Embrace pure black backgrounds (essential)
- Use glossy/reflective materials to catch neon light
- Add volumetric fog for atmosphere
- Maximize bloom/glow in post-processing
- Use 2-3 neon colors max per image
- Create colored reflections on surfaces

❌ **DON'T:**
- Use more than 3-4 neon colors at once (chaos)
- Add warm neutral lighting (kills the vibe)
- Use matte materials exclusively (need reflections)
- Forget atmospheric effects (fog, haze, light beams)
- Over-brighten blacks (they should stay dark)

---

## Visual Effects

### Glow/Bloom (Essential)
- Compositor glare node: Fog Glow or Streaks
- Threshold: 0.8-1.0 (only bright neons glow)
- Size: 7-9 (strong bloom)

### Chromatic Aberration
- RGB channels split on edges
- Red shifts outward on one side, blue on other
- Subtle (1-2px) or extreme (5-10px) for glitch

### Scan Lines
- Horizontal lines overlay (10-20% opacity)
- Black lines on neon areas (CRT monitor effect)

### Glitch/Displacement
- Random pixel shifts
- RGB channel separation
- Digital corruption patterns

---

## Brand Examples

- **Razer** (gaming peripherals with RGB)
- **Cyberpunk 2077** (game aesthetic)
- **Tron Legacy** (film visual design)
- **Monster Energy** (acid green branding)
- **Blade Runner 2049** (film color palette)
- **Spotify** (neon/dark UI marketing)

---

## AI Prompt Integration

```
"...cyberpunk neon aesthetic, electric magenta and cyber cyan lighting, deep black background with volumetric fog, glossy futuristic product, high contrast, Blade Runner style, neon glow effects, holographic accents, dark tech photography, 8K octane render..."
```

**Keywords:**
- "Cyberpunk"
- "Neon"
- "Electric magenta" or "cyber cyan"
- "Volumetric fog"
- "Blade Runner aesthetic"
- "Glowing"
- "Futuristic"
- "Dark background"

---

## Scene Variations

### Rainy Cyberpunk Street
- Wet reflective ground (mirrors neon lights)
- Vertical neon signs blurred in background
- Steam/fog rising from grates

### Tron Grid
- Infinite black void
- Glowing gridlines (Cyber Cyan) receding to horizon
- Geometric platform beneath product

### Hacker Terminal
- Product surrounded by floating holographic UI
- Code/data streams (Acid Green text)
- Dark room, only screen glow

### Nightclub/Rave
- Strobing colored lights
- Silhouettes of crowd (out of focus)
- Product center-stage with multiple colored spotlights

---

## Hex Color Quick Reference

| Color | Hex | RGB |
|-------|-----|-----|
| Electric Magenta | #FF10F0 | 255, 16, 240 |
| Cyber Cyan | #00FFFF | 0, 255, 255 |
| Acid Green | #CCFF00 | 204, 255, 0 |
| Deep Purple | #6600CC | 102, 0, 204 |
| Hot Orange | #FF3300 | 255, 51, 0 |
| Ice Blue | #66B3FF | 102, 179, 255 |
| Deep Black | #0A0A0A | 10, 10, 10 |
| Charcoal | #1A1A1A | 26, 26, 26 |

---

**Pro Tip:** This palette is MAXIMUM IMPACT. Perfect for products targeting gamers, tech enthusiasts, nightlife, electronic music fans, and anyone who wants to stand out with aggressive futurism. Not suitable for professional services, wellness, or family products. Use when your brand identity is "disruptive," "edgy," or "cutting-edge." Pair with synthwave music or glitch sound design for video content. Export in video format for Instagram Reels/TikTok with animated RGB glow effects for viral potential.
