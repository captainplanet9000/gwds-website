'use client';

import { useEffect, useState } from 'react';
import Link from 'next/link';
import { supabase } from '@/lib/supabase-browser';

export default function Settings() {
  const [user, setUser] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [portalLoading, setPortalLoading] = useState(false);
  const [profile, setProfile] = useState<any>(null);

  useEffect(() => {
    supabase.auth.getUser().then(({ data }) => {
      setUser(data.user);
      if (data.user) {
        fetch('/api/usage').then(r => r.json()).then(d => { setProfile(d); setLoading(false); }).catch(() => setLoading(false));
      } else { setLoading(false); }
    });
  }, []);

  const openPortal = async () => {
    setPortalLoading(true);
    try {
      const res = await fetch('/api/billing/portal', { method: 'POST' });
      const data = await res.json();
      if (data.url) window.location.href = data.url;
      else alert(data.error || 'Failed to open billing portal');
    } catch { alert('Failed to open billing portal'); }
    setPortalLoading(false);
  };

  const handleUpgrade = async (priceId: string) => {
    try {
      const res = await fetch('/api/billing/checkout', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ priceId }),
      });
      const data = await res.json();
      if (data.url) window.location.href = data.url;
      else alert(data.error || 'Failed to create checkout');
    } catch { alert('Failed to create checkout'); }
  };

  if (loading) return <div style={{ padding: 48, color: 'var(--text-muted)' }}>Loading...</div>;

  return (
    <div style={{ minHeight: '100vh' }}>
      <nav style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '12px 32px', borderBottom: '1px solid var(--border)', background: 'var(--bg-surface)' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 24 }}>
          <Link href="/" style={{ display: 'flex', alignItems: 'center', gap: 8, fontWeight: 700, fontSize: '1rem', color: 'var(--text-primary)', textDecoration: 'none' }}>
            <span style={{ width: 28, height: 28, background: 'var(--accent)', borderRadius: 6, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: '0.8rem' }}>⚡</span>
            AI SaaS
          </Link>
          <div style={{ display: 'flex', gap: 4 }}>
            <Link href="/dashboard" style={{ padding: '6px 12px', borderRadius: 6, fontSize: '0.85rem', color: 'var(--text-secondary)', textDecoration: 'none' }}>📊 Overview</Link>
            <Link href="/dashboard/playground" style={{ padding: '6px 12px', borderRadius: 6, fontSize: '0.85rem', color: 'var(--text-secondary)', textDecoration: 'none' }}>🧪 Playground</Link>
            <Link href="/dashboard/settings" style={{ padding: '6px 12px', borderRadius: 6, fontSize: '0.85rem', color: 'var(--accent)', background: 'var(--accent-subtle)', textDecoration: 'none' }}>⚙️ Settings</Link>
          </div>
        </div>
      </nav>

      <div style={{ padding: 32, maxWidth: 700, margin: '0 auto' }}>
        <h1 style={{ fontSize: '1.4rem', fontWeight: 700, marginBottom: 32, letterSpacing: '-0.02em' }}>⚙️ Settings</h1>

        {/* Profile */}
        <section style={{ padding: 24, background: 'var(--bg-surface)', border: '1px solid var(--border)', borderRadius: 12, marginBottom: 24 }}>
          <h2 style={{ fontSize: '1rem', fontWeight: 600, marginBottom: 16 }}>Profile</h2>
          <div style={{ display: 'grid', gap: 12, fontSize: '0.9rem' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between' }}>
              <span style={{ color: 'var(--text-secondary)' }}>Email</span>
              <span>{user?.email}</span>
            </div>
            <div style={{ display: 'flex', justifyContent: 'space-between' }}>
              <span style={{ color: 'var(--text-secondary)' }}>Name</span>
              <span>{user?.user_metadata?.full_name || '—'}</span>
            </div>
            <div style={{ display: 'flex', justifyContent: 'space-between' }}>
              <span style={{ color: 'var(--text-secondary)' }}>Member since</span>
              <span>{user?.created_at ? new Date(user.created_at).toLocaleDateString() : '—'}</span>
            </div>
          </div>
        </section>

        {/* Billing */}
        <section style={{ padding: 24, background: 'var(--bg-surface)', border: '1px solid var(--border)', borderRadius: 12, marginBottom: 24 }}>
          <h2 style={{ fontSize: '1rem', fontWeight: 600, marginBottom: 16 }}>Billing & Plan</h2>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 16 }}>
            <div>
              <span style={{ display: 'inline-flex', padding: '4px 12px', borderRadius: 100, fontSize: '0.82rem', fontWeight: 600, textTransform: 'uppercase', background: 'var(--accent-subtle)', color: 'var(--accent)' }}>
                {profile?.plan || 'free'}
              </span>
              <span style={{ marginLeft: 12, color: 'var(--text-secondary)', fontSize: '0.88rem' }}>
                {profile?.apiCallsThisMonth || 0} / {profile?.monthlyLimit || 100} API calls this month
              </span>
            </div>
          </div>

          {profile?.plan === 'free' && (
            <div style={{ display: 'flex', gap: 12 }}>
              <button onClick={() => handleUpgrade(process.env.NEXT_PUBLIC_STRIPE_PRO_PRICE_ID || 'price_pro')} style={{ padding: '10px 20px', background: 'var(--accent)', color: 'white', border: 'none', borderRadius: 8, fontSize: '0.88rem', fontWeight: 600, cursor: 'pointer' }}>
                Upgrade to Pro — $29/mo
              </button>
              <button onClick={() => handleUpgrade(process.env.NEXT_PUBLIC_STRIPE_ENTERPRISE_PRICE_ID || 'price_enterprise')} style={{ padding: '10px 20px', background: 'var(--bg-elevated)', color: 'var(--text-primary)', border: '1px solid var(--border)', borderRadius: 8, fontSize: '0.88rem', fontWeight: 500, cursor: 'pointer' }}>
                Enterprise — $99/mo
              </button>
            </div>
          )}

          {profile?.plan !== 'free' && (
            <button onClick={openPortal} disabled={portalLoading} style={{ padding: '10px 20px', background: 'var(--bg-elevated)', color: 'var(--text-primary)', border: '1px solid var(--border)', borderRadius: 8, fontSize: '0.88rem', fontWeight: 500, cursor: 'pointer' }}>
              {portalLoading ? 'Loading...' : 'Manage Billing →'}
            </button>
          )}
        </section>

        {/* API Keys */}
        <section style={{ padding: 24, background: 'var(--bg-surface)', border: '1px solid var(--border)', borderRadius: 12 }}>
          <h2 style={{ fontSize: '1rem', fontWeight: 600, marginBottom: 16 }}>API Keys</h2>
          <p style={{ color: 'var(--text-secondary)', fontSize: '0.88rem', marginBottom: 16 }}>
            Use API keys to call the AI endpoint programmatically from your own applications.
          </p>
          <div style={{ padding: 16, background: 'var(--bg-elevated)', borderRadius: 8, fontFamily: 'monospace', fontSize: '0.82rem', color: 'var(--text-muted)', marginBottom: 12 }}>
            POST /api/ai/chat<br />
            Authorization: Bearer your-api-key<br />
            {'{'}  "messages": [{'{'}"role": "user", "content": "Hello"{'}'} ] {'}'}
          </div>
          <p style={{ color: 'var(--text-muted)', fontSize: '0.82rem' }}>
            API key management coming soon. For now, the API uses session authentication.
          </p>
        </section>
      </div>
    </div>
  );
}
