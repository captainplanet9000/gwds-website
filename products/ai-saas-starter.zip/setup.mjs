#!/usr/bin/env node

import { createInterface } from 'readline';
import { writeFileSync, existsSync, readFileSync } from 'fs';

const rl = createInterface({ input: process.stdin, output: process.stdout });
const ask = (q) => new Promise((res) => rl.question(q, res));

console.log('\n⚡ AI SaaS Starter Kit — Setup Wizard\n');
console.log('This wizard creates your .env.local file.\n');

async function main() {
  if (existsSync('.env.local')) {
    const overwrite = await ask('.env.local already exists. Overwrite? (y/N): ');
    if (overwrite.toLowerCase() !== 'y') {
      console.log('Setup cancelled.');
      rl.close();
      return;
    }
  }

  console.log('─── Supabase ───\n');
  console.log('Create a project at https://supabase.com/dashboard\n');
  const supabaseUrl = await ask('Supabase URL: ');
  const supabaseAnon = await ask('Supabase Anon Key: ');
  const supabaseService = await ask('Supabase Service Role Key: ');

  console.log('\n─── Stripe ───\n');
  console.log('Create an account at https://stripe.com\n');
  const stripeSecret = await ask('Stripe Secret Key (sk_test_...): ');
  const stripePublishable = await ask('Stripe Publishable Key (pk_test_...): ');
  const stripeWebhook = await ask('Stripe Webhook Secret (whsec_...): ');
  const stripePro = await ask('Stripe Pro Price ID (price_...): ');
  const stripeEnterprise = await ask('Stripe Enterprise Price ID (price_...): ');

  console.log('\n─── OpenRouter ───\n');
  console.log('Get an API key at https://openrouter.ai/keys\n');
  const openrouterKey = await ask('OpenRouter API Key: ');

  console.log('\n─── App ───\n');
  const appUrl = await ask('App URL (default: http://localhost:3000): ') || 'http://localhost:3000';
  const appName = await ask('App Name (default: AI SaaS): ') || 'AI SaaS';

  let env = `# AI SaaS Starter Kit\n\n`;
  env += `# Supabase\n`;
  env += `NEXT_PUBLIC_SUPABASE_URL=${supabaseUrl}\n`;
  env += `NEXT_PUBLIC_SUPABASE_ANON_KEY=${supabaseAnon}\n`;
  env += `SUPABASE_SERVICE_ROLE_KEY=${supabaseService}\n\n`;
  env += `# Stripe\n`;
  env += `STRIPE_SECRET_KEY=${stripeSecret}\n`;
  env += `STRIPE_WEBHOOK_SECRET=${stripeWebhook}\n`;
  env += `NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY=${stripePublishable}\n`;
  env += `STRIPE_PRO_PRICE_ID=${stripePro}\n`;
  env += `STRIPE_ENTERPRISE_PRICE_ID=${stripeEnterprise}\n\n`;
  env += `# OpenRouter\n`;
  env += `OPENROUTER_API_KEY=${openrouterKey}\n\n`;
  env += `# App\n`;
  env += `NEXT_PUBLIC_APP_URL=${appUrl}\n`;
  env += `NEXT_PUBLIC_APP_NAME=${appName}\n`;

  writeFileSync('.env.local', env);

  console.log('\n✅ .env.local created!');
  console.log('\nNext steps:');
  console.log('  1. Run setup.sql in your Supabase SQL editor');
  console.log('  2. npm install');
  console.log('  3. npm run dev');
  console.log(`\nOpen ${appUrl} in your browser.\n`);

  rl.close();
}

main().catch((e) => { console.error(e); rl.close(); });
