/**
 * Token bucket rate limiter — in-memory, per-process.
 * For production with multiple instances, use Redis instead.
 */

interface Bucket {
  tokens: number;
  lastRefill: number;
}

const buckets = new Map<string, Bucket>();

interface RateLimitConfig {
  /** Max tokens in the bucket */
  maxTokens: number;
  /** Tokens added per second */
  refillRate: number;
}

const PLAN_LIMITS: Record<string, RateLimitConfig> = {
  free: { maxTokens: 5, refillRate: 0.1 },        // 5 requests burst, ~6/min
  pro: { maxTokens: 30, refillRate: 1 },            // 30 burst, ~60/min
  enterprise: { maxTokens: 100, refillRate: 5 },    // 100 burst, ~300/min
};

export interface RateLimitResult {
  allowed: boolean;
  remaining: number;
  resetMs: number;
}

export function checkRateLimit(userId: string, plan: string = 'free'): RateLimitResult {
  const config = PLAN_LIMITS[plan] || PLAN_LIMITS.free;
  const now = Date.now();
  let bucket = buckets.get(userId);

  if (!bucket) {
    bucket = { tokens: config.maxTokens, lastRefill: now };
    buckets.set(userId, bucket);
  }

  // Refill tokens
  const elapsed = (now - bucket.lastRefill) / 1000;
  bucket.tokens = Math.min(config.maxTokens, bucket.tokens + elapsed * config.refillRate);
  bucket.lastRefill = now;

  if (bucket.tokens >= 1) {
    bucket.tokens -= 1;
    return {
      allowed: true,
      remaining: Math.floor(bucket.tokens),
      resetMs: Math.ceil((1 - (bucket.tokens % 1)) / config.refillRate * 1000),
    };
  }

  const resetMs = Math.ceil((1 - bucket.tokens) / config.refillRate * 1000);
  return { allowed: false, remaining: 0, resetMs };
}

/** Clean up old buckets periodically (call from a cron or interval) */
export function cleanupBuckets(maxAgeMs: number = 3600000): void {
  const now = Date.now();
  for (const [key, bucket] of buckets) {
    if (now - bucket.lastRefill > maxAgeMs) {
      buckets.delete(key);
    }
  }
}
