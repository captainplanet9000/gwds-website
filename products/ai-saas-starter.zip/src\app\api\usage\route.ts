import { NextResponse } from 'next/server';
import { createServerClient } from '@supabase/ssr';
import { cookies } from 'next/headers';
import { getUsageStats } from '@/lib/ai';
import { getUserProfile, getPlanLimit } from '@/lib/auth';

export const dynamic = 'force-dynamic';

export async function GET() {
  try {
    const cookieStore = await cookies();
    const supabase = createServerClient(
      process.env.NEXT_PUBLIC_SUPABASE_URL!,
      process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!,
      {
        cookies: {
          getAll() { return cookieStore.getAll(); },
          setAll(cookiesToSet) {
            cookiesToSet.forEach(({ name, value, options }) => {
              cookieStore.set(name, value, options);
            });
          },
        },
      }
    );

    const { data: { user } } = await supabase.auth.getUser();
    if (!user) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });

    const [profile, stats] = await Promise.all([
      getUserProfile(user.id),
      getUsageStats(user.id, 30),
    ]);

    if (!profile) return NextResponse.json({ error: 'User not found' }, { status: 404 });

    return NextResponse.json({
      plan: profile.plan,
      apiCallsThisMonth: profile.api_calls_this_month,
      monthlyLimit: getPlanLimit(profile.plan),
      ...stats,
    });
  } catch (error) {
    return NextResponse.json({ error: 'Failed to get usage stats' }, { status: 500 });
  }
}
