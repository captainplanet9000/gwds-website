'use client';

import { useState } from 'react';
import Link from 'next/link';

const MODELS = [
  { id: 'openai/gpt-4o-mini', name: 'GPT-4o Mini', desc: 'Fast & cheap' },
  { id: 'openai/gpt-4o', name: 'GPT-4o', desc: 'Best quality' },
  { id: 'anthropic/claude-3.5-sonnet', name: 'Claude 3.5 Sonnet', desc: 'Great reasoning' },
  { id: 'google/gemini-2.0-flash-001', name: 'Gemini 2.0 Flash', desc: 'Google speed' },
  { id: 'meta-llama/llama-3.1-70b-instruct', name: 'Llama 3.1 70B', desc: 'Open source' },
];

export default function Playground() {
  const [prompt, setPrompt] = useState('');
  const [model, setModel] = useState(MODELS[0].id);
  const [response, setResponse] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [stats, setStats] = useState<{ tokens: number; latency: number; remaining: number } | null>(null);

  const send = async () => {
    if (!prompt.trim()) return;
    setLoading(true);
    setError('');
    setResponse('');
    setStats(null);

    const startTime = Date.now();
    try {
      const res = await fetch('/api/ai/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          messages: [{ role: 'user', content: prompt }],
          model,
        }),
      });

      const data = await res.json();
      if (!res.ok) { setError(data.error || 'Request failed'); setLoading(false); return; }

      setResponse(data.content);
      setStats({
        tokens: data.usage?.total_tokens || 0,
        latency: Date.now() - startTime,
        remaining: data.remaining ?? 0,
      });
    } catch (e) {
      setError('Network error');
    }
    setLoading(false);
  };

  return (
    <div style={{ minHeight: '100vh' }}>
      {/* Nav */}
      <nav style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '12px 32px', borderBottom: '1px solid var(--border)', background: 'var(--bg-surface)' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 24 }}>
          <Link href="/" style={{ display: 'flex', alignItems: 'center', gap: 8, fontWeight: 700, fontSize: '1rem', color: 'var(--text-primary)', textDecoration: 'none' }}>
            <span style={{ width: 28, height: 28, background: 'var(--accent)', borderRadius: 6, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: '0.8rem' }}>⚡</span>
            AI SaaS
          </Link>
          <div style={{ display: 'flex', gap: 4 }}>
            <Link href="/dashboard" style={{ padding: '6px 12px', borderRadius: 6, fontSize: '0.85rem', color: 'var(--text-secondary)', textDecoration: 'none' }}>📊 Overview</Link>
            <Link href="/dashboard/playground" style={{ padding: '6px 12px', borderRadius: 6, fontSize: '0.85rem', color: 'var(--accent)', background: 'var(--accent-subtle)', textDecoration: 'none' }}>🧪 Playground</Link>
            <Link href="/dashboard/settings" style={{ padding: '6px 12px', borderRadius: 6, fontSize: '0.85rem', color: 'var(--text-secondary)', textDecoration: 'none' }}>⚙️ Settings</Link>
          </div>
        </div>
      </nav>

      <div style={{ padding: 32, maxWidth: 900, margin: '0 auto' }}>
        <h1 style={{ fontSize: '1.4rem', fontWeight: 700, marginBottom: 24, letterSpacing: '-0.02em' }}>🧪 API Playground</h1>

        {/* Model selector */}
        <div style={{ marginBottom: 20 }}>
          <label style={{ display: 'block', fontSize: '0.82rem', fontWeight: 500, color: 'var(--text-secondary)', marginBottom: 8 }}>Model</label>
          <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap' }}>
            {MODELS.map(m => (
              <button key={m.id} onClick={() => setModel(m.id)} style={{
                padding: '8px 14px', borderRadius: 8, fontSize: '0.82rem', cursor: 'pointer',
                background: model === m.id ? 'var(--accent-subtle)' : 'var(--bg-surface)',
                color: model === m.id ? 'var(--accent)' : 'var(--text-secondary)',
                border: `1px solid ${model === m.id ? 'var(--accent)' : 'var(--border)'}`,
              }}>
                <strong>{m.name}</strong>
                <span style={{ marginLeft: 6, fontSize: '0.75rem', opacity: 0.7 }}>{m.desc}</span>
              </button>
            ))}
          </div>
        </div>

        {/* Prompt */}
        <div style={{ marginBottom: 20 }}>
          <label style={{ display: 'block', fontSize: '0.82rem', fontWeight: 500, color: 'var(--text-secondary)', marginBottom: 8 }}>Prompt</label>
          <textarea value={prompt} onChange={e => setPrompt(e.target.value)} rows={5}
            placeholder="Ask the AI anything..."
            style={{ width: '100%', padding: 14, background: 'var(--bg-surface)', border: '1px solid var(--border)', borderRadius: 10, color: 'var(--text-primary)', fontSize: '0.9rem', resize: 'vertical', outline: 'none', fontFamily: 'inherit' }}
            onKeyDown={e => { if (e.key === 'Enter' && (e.metaKey || e.ctrlKey)) send(); }}
          />
          <div style={{ display: 'flex', justifyContent: 'space-between', marginTop: 8 }}>
            <span style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>⌘+Enter to send</span>
            <button onClick={send} disabled={loading || !prompt.trim()} style={{
              padding: '10px 24px', background: 'var(--accent)', color: 'white', border: 'none',
              borderRadius: 8, fontSize: '0.9rem', fontWeight: 600, cursor: 'pointer', opacity: loading ? 0.7 : 1,
            }}>
              {loading ? 'Generating...' : 'Send →'}
            </button>
          </div>
        </div>

        {/* Error */}
        {error && <div style={{ padding: '12px 16px', background: 'rgba(239,68,68,0.1)', border: '1px solid rgba(239,68,68,0.2)', borderRadius: 10, color: 'var(--rose)', fontSize: '0.88rem', marginBottom: 20 }}>{error}</div>}

        {/* Response */}
        {response && (
          <div style={{ marginBottom: 20 }}>
            <label style={{ display: 'block', fontSize: '0.82rem', fontWeight: 500, color: 'var(--text-secondary)', marginBottom: 8 }}>Response</label>
            <div style={{ padding: 16, background: 'var(--bg-surface)', border: '1px solid var(--border)', borderRadius: 10, fontSize: '0.9rem', lineHeight: 1.7, whiteSpace: 'pre-wrap' }}>
              {response}
            </div>
          </div>
        )}

        {/* Stats */}
        {stats && (
          <div style={{ display: 'flex', gap: 24, fontSize: '0.82rem', color: 'var(--text-muted)' }}>
            <span>🔤 {stats.tokens} tokens</span>
            <span>⚡ {stats.latency}ms</span>
            <span>📊 {stats.remaining} calls remaining</span>
          </div>
        )}
      </div>
    </div>
  );
}
