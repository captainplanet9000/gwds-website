# ⚡ AI SaaS Starter Kit

A production-ready SaaS boilerplate with authentication, Stripe billing, AI integration, rate limiting, and usage tracking. Built with Next.js 15, React 19, Supabase, and Stripe.

![Dark Theme](https://img.shields.io/badge/theme-dark-1a1a2e) ![Next.js 15](https://img.shields.io/badge/Next.js-15-black) ![React 19](https://img.shields.io/badge/React-19-61dafb) ![Supabase](https://img.shields.io/badge/Supabase-3ecf8e) ![Stripe](https://img.shields.io/badge/Stripe-635bff)

## What's Included

### 🔐 Authentication
- Email/password sign up & sign in
- Magic link authentication
- Password reset flow
- Middleware protecting dashboard routes
- Auth callback handler with profile creation

### 💳 Stripe Billing
- Three-tier pricing (Free / Pro $29/mo / Enterprise $99/mo)
- Stripe Checkout integration
- Customer Portal for self-serve billing management
- Webhook handler for subscription lifecycle events
- Plan enforcement on API endpoints

### 🤖 AI Integration
- OpenRouter integration (access to 200+ models)
- GPT-4o, Claude, Gemini, Llama — all available
- Token counting and usage tracking
- Model selection per request

### ⚡ Rate Limiting
- Token bucket algorithm
- Per-plan burst limits and refill rates
- Graceful 429 responses with Retry-After headers

### 📊 Usage Analytics
- API call tracking with token counts and latency
- Monthly usage limits per plan
- Per-day breakdown
- Recent activity feed

### 🧪 API Playground
- Interactive prompt testing
- Model selector
- Real-time response with usage stats

## Quick Start

```bash
# 1. Install dependencies
npm install

# 2. Run the setup wizard
node setup.mjs

# 3. Set up database tables
# Copy setup.sql contents into your Supabase SQL editor and run it

# 4. Start development server
npm run dev
```

Open [http://localhost:3000](http://localhost:3000).

## Project Structure

```
ai-saas-starter/
├── src/
│   ├── app/
│   │   ├── page.tsx                    # Landing page with pricing
│   │   ├── layout.tsx                  # Root layout
│   │   ├── globals.css                 # Global styles + Tailwind
│   │   ├── (auth)/
│   │   │   ├── signin/page.tsx         # Sign in page
│   │   │   ├── signup/page.tsx         # Sign up page
│   │   │   └── forgot-password/page.tsx
│   │   ├── dashboard/
│   │   │   ├── page.tsx                # Dashboard overview
│   │   │   ├── playground/page.tsx     # AI playground
│   │   │   └── settings/page.tsx       # Profile, billing, API keys
│   │   └── api/
│   │       ├── auth/callback/route.ts  # Supabase auth callback
│   │       ├── ai/chat/route.ts        # AI endpoint (rate limited)
│   │       ├── billing/
│   │       │   ├── checkout/route.ts   # Create Stripe checkout
│   │       │   ├── portal/route.ts     # Stripe customer portal
│   │       │   └── webhook/route.ts    # Stripe webhook handler
│   │       └── usage/route.ts          # Usage statistics
│   ├── lib/
│   │   ├── auth.ts                     # User profile & API limits
│   │   ├── stripe.ts                   # Stripe integration
│   │   ├── ai.ts                       # OpenRouter AI calls
│   │   ├── rate-limit.ts              # Token bucket rate limiter
│   │   ├── supabase-server.ts         # Server-side Supabase clients
│   │   └── supabase-browser.ts        # Client-side Supabase client
│   └── middleware.ts                   # Auth middleware
├── setup.sql                           # Supabase database schema
├── setup.mjs                           # Interactive setup wizard
├── .env.example                        # Environment variable template
└── package.json
```

## Environment Variables

| Variable | Required | Description |
|----------|----------|-------------|
| `NEXT_PUBLIC_SUPABASE_URL` | ✅ | Supabase project URL |
| `NEXT_PUBLIC_SUPABASE_ANON_KEY` | ✅ | Supabase anonymous key |
| `SUPABASE_SERVICE_ROLE_KEY` | ✅ | Supabase service role key |
| `STRIPE_SECRET_KEY` | ✅ | Stripe secret key |
| `STRIPE_WEBHOOK_SECRET` | ✅ | Stripe webhook signing secret |
| `NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY` | ✅ | Stripe publishable key |
| `STRIPE_PRO_PRICE_ID` | ✅ | Stripe price ID for Pro plan |
| `STRIPE_ENTERPRISE_PRICE_ID` | ✅ | Stripe price ID for Enterprise plan |
| `OPENROUTER_API_KEY` | ✅ | OpenRouter API key |
| `NEXT_PUBLIC_APP_URL` | ✅ | Your app's URL |
| `NEXT_PUBLIC_APP_NAME` | — | Display name for your app |

## Setting Up Stripe

1. Create products in Stripe Dashboard → Products
2. Create a Pro price ($29/mo) and Enterprise price ($99/mo)
3. Copy the price IDs to your `.env.local`
4. Set up a webhook endpoint: `https://yourdomain.com/api/billing/webhook`
5. Subscribe to events: `checkout.session.completed`, `customer.subscription.updated`, `customer.subscription.deleted`, `invoice.payment_failed`

## API Usage

```bash
# Call the AI endpoint (requires authentication)
curl -X POST http://localhost:3000/api/ai/chat \
  -H "Content-Type: application/json" \
  -H "Cookie: <session-cookie>" \
  -d '{
    "messages": [{"role": "user", "content": "Hello!"}],
    "model": "openai/gpt-4o-mini"
  }'
```

## Plan Limits

| Feature | Free | Pro | Enterprise |
|---------|------|-----|------------|
| API calls/month | 100 | 10,000 | 100,000 |
| Rate limit (burst) | 5 | 30 | 100 |
| Rate limit (sustained) | 6/min | 60/min | 300/min |
| Models | GPT-4o-mini | All | All + fine-tuned |
| Support | Community | Priority | Dedicated |

## Tech Stack

- **Next.js 15** — App Router, Server Components, Middleware
- **React 19** — Latest React
- **Tailwind CSS 4** — Utility-first styling
- **Supabase** — Auth, Database, Row Level Security
- **Stripe** — Subscriptions, Checkout, Customer Portal
- **OpenRouter** — Multi-model AI gateway
- **TypeScript** — Full type safety

## License

Commercial single-developer license. See [LICENSE.md](./LICENSE.md).
