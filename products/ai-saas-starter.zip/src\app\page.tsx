import Link from 'next/link';

const PLANS = [
  { name: 'Free', price: '$0', period: '/month', features: ['100 API calls/month', '1 API key', 'GPT-4o-mini access', 'Community support'], cta: 'Get Started', href: '/signup', highlight: false },
  { name: 'Pro', price: '$29', period: '/month', features: ['10,000 API calls/month', '5 API keys', 'All models access', 'Priority support', 'Usage analytics', 'Webhook notifications'], cta: 'Start Pro Trial', href: '/signup?plan=pro', highlight: true },
  { name: 'Enterprise', price: '$99', period: '/month', features: ['100,000 API calls/month', 'Unlimited API keys', 'All models + fine-tuned', 'Dedicated support', 'Advanced analytics', 'SSO / SAML', 'SLA guarantee'], cta: 'Contact Sales', href: '/signup?plan=enterprise', highlight: false },
];

export default function LandingPage() {
  return (
    <div style={{ minHeight: '100vh' }}>
      {/* Nav */}
      <nav style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '16px 48px', borderBottom: '1px solid var(--border)', background: 'rgba(9,9,11,0.8)', backdropFilter: 'blur(16px)', position: 'sticky', top: 0, zIndex: 100 }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 10, fontWeight: 700, fontSize: '1.1rem' }}>
          <span style={{ width: 32, height: 32, background: 'var(--accent)', borderRadius: 8, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: '0.9rem' }}>⚡</span>
          AI SaaS
        </div>
        <div style={{ display: 'flex', gap: 24, alignItems: 'center' }}>
          <a href="#features" style={{ color: 'var(--text-secondary)', textDecoration: 'none', fontSize: '0.9rem' }}>Features</a>
          <a href="#pricing" style={{ color: 'var(--text-secondary)', textDecoration: 'none', fontSize: '0.9rem' }}>Pricing</a>
          <Link href="/signin" style={{ color: 'var(--text-secondary)', textDecoration: 'none', fontSize: '0.9rem' }}>Sign In</Link>
          <Link href="/signup" style={{ padding: '8px 20px', background: 'var(--accent)', color: 'white', borderRadius: 8, textDecoration: 'none', fontSize: '0.88rem', fontWeight: 600 }}>Get Started</Link>
        </div>
      </nav>

      {/* Hero */}
      <section style={{ textAlign: 'center', padding: '120px 24px 80px', maxWidth: 800, margin: '0 auto' }}>
        <div style={{ display: 'inline-block', padding: '4px 16px', background: 'var(--accent-subtle)', border: '1px solid rgba(99,102,241,0.2)', borderRadius: 100, fontSize: '0.8rem', color: 'var(--accent-hover)', marginBottom: 24, fontWeight: 500 }}>
          Production-ready AI SaaS boilerplate
        </div>
        <h1 style={{ fontSize: '3.5rem', fontWeight: 800, lineHeight: 1.1, letterSpacing: '-0.03em', marginBottom: 20 }}>
          Ship your AI product<br />
          <span style={{ background: 'linear-gradient(135deg, var(--accent), #a78bfa)', WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent' }}>in days, not months</span>
        </h1>
        <p style={{ fontSize: '1.15rem', color: 'var(--text-secondary)', lineHeight: 1.6, maxWidth: 600, margin: '0 auto 40px' }}>
          Auth, billing, rate limiting, usage tracking, and an AI playground — all wired up and ready. Just add your API keys and deploy.
        </p>
        <div style={{ display: 'flex', gap: 16, justifyContent: 'center' }}>
          <Link href="/signup" style={{ padding: '14px 32px', background: 'var(--accent)', color: 'white', borderRadius: 10, textDecoration: 'none', fontSize: '1rem', fontWeight: 600 }}>Start Building →</Link>
          <Link href="/dashboard/playground" style={{ padding: '14px 32px', background: 'var(--bg-surface)', color: 'var(--text-primary)', border: '1px solid var(--border)', borderRadius: 10, textDecoration: 'none', fontSize: '1rem', fontWeight: 500 }}>Try Playground</Link>
        </div>
      </section>

      {/* Features */}
      <section id="features" style={{ padding: '80px 48px', maxWidth: 1100, margin: '0 auto' }}>
        <h2 style={{ textAlign: 'center', fontSize: '2rem', fontWeight: 700, marginBottom: 48, letterSpacing: '-0.02em' }}>Everything you need to ship</h2>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 24 }}>
          {[
            { icon: '🔐', title: 'Authentication', desc: 'Supabase Auth with email/password, magic links, and OAuth. Middleware protects dashboard routes.' },
            { icon: '💳', title: 'Stripe Billing', desc: 'Subscription management with checkout, customer portal, webhook handling, and plan enforcement.' },
            { icon: '🤖', title: 'AI Integration', desc: 'OpenRouter for 200+ models. Usage tracking, token counting, and model selection per request.' },
            { icon: '⚡', title: 'Rate Limiting', desc: 'Token bucket rate limiter with per-plan limits. Burst allowances and graceful 429 responses.' },
            { icon: '📊', title: 'Usage Analytics', desc: 'Track API calls, tokens used, and latency. Per-day breakdown with monthly billing limits.' },
            { icon: '🔑', title: 'API Keys', desc: 'Generate and manage API keys for programmatic access. Revoke, rotate, and monitor usage.' },
          ].map(f => (
            <div key={f.title} style={{ padding: 28, background: 'var(--bg-surface)', border: '1px solid var(--border)', borderRadius: 16 }}>
              <div style={{ fontSize: '1.8rem', marginBottom: 12 }}>{f.icon}</div>
              <h3 style={{ fontSize: '1.05rem', fontWeight: 600, marginBottom: 8 }}>{f.title}</h3>
              <p style={{ fontSize: '0.88rem', color: 'var(--text-secondary)', lineHeight: 1.5 }}>{f.desc}</p>
            </div>
          ))}
        </div>
      </section>

      {/* Pricing */}
      <section id="pricing" style={{ padding: '80px 48px', maxWidth: 1100, margin: '0 auto' }}>
        <h2 style={{ textAlign: 'center', fontSize: '2rem', fontWeight: 700, marginBottom: 12, letterSpacing: '-0.02em' }}>Simple, transparent pricing</h2>
        <p style={{ textAlign: 'center', color: 'var(--text-secondary)', marginBottom: 48, fontSize: '1rem' }}>Start free. Upgrade when you need more.</p>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 24, alignItems: 'start' }}>
          {PLANS.map(plan => (
            <div key={plan.name} style={{
              padding: 32, background: 'var(--bg-surface)', border: plan.highlight ? '2px solid var(--accent)' : '1px solid var(--border)',
              borderRadius: 16, position: 'relative',
            }}>
              {plan.highlight && (
                <div style={{ position: 'absolute', top: -12, left: '50%', transform: 'translateX(-50%)', padding: '4px 16px', background: 'var(--accent)', borderRadius: 100, fontSize: '0.72rem', fontWeight: 600, color: 'white', textTransform: 'uppercase', letterSpacing: '0.05em' }}>Most Popular</div>
              )}
              <h3 style={{ fontSize: '1.2rem', fontWeight: 700, marginBottom: 8 }}>{plan.name}</h3>
              <div style={{ marginBottom: 24 }}>
                <span style={{ fontSize: '2.5rem', fontWeight: 800, letterSpacing: '-0.03em' }}>{plan.price}</span>
                <span style={{ color: 'var(--text-muted)', fontSize: '0.9rem' }}>{plan.period}</span>
              </div>
              <ul style={{ listStyle: 'none', marginBottom: 32 }}>
                {plan.features.map(f => (
                  <li key={f} style={{ display: 'flex', alignItems: 'center', gap: 8, padding: '6px 0', fontSize: '0.88rem', color: 'var(--text-secondary)' }}>
                    <span style={{ color: 'var(--green)', fontSize: '0.9rem' }}>✓</span> {f}
                  </li>
                ))}
              </ul>
              <Link href={plan.href} style={{
                display: 'block', textAlign: 'center', padding: '12px 24px',
                background: plan.highlight ? 'var(--accent)' : 'var(--bg-elevated)',
                color: plan.highlight ? 'white' : 'var(--text-primary)',
                border: plan.highlight ? 'none' : '1px solid var(--border)',
                borderRadius: 10, textDecoration: 'none', fontWeight: 600, fontSize: '0.9rem',
              }}>{plan.cta}</Link>
            </div>
          ))}
        </div>
      </section>

      {/* Footer */}
      <footer style={{ padding: '40px 48px', borderTop: '1px solid var(--border)', textAlign: 'center', color: 'var(--text-muted)', fontSize: '0.82rem' }}>
        Built with Next.js, Supabase, Stripe, and OpenRouter. Ship your AI SaaS today.
      </footer>
    </div>
  );
}
