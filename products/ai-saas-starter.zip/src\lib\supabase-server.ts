import { createClient } from '@supabase/supabase-js';

const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL!;
const supabaseServiceKey = process.env.SUPABASE_SERVICE_ROLE_KEY!;
const supabaseAnonKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!;

/** Server-side admin client (service role — bypasses RLS) */
export function createAdminClient() {
  return createClient(supabaseUrl, supabaseServiceKey);
}

/** Server-side public client (respects RLS) */
export function createServerClient() {
  return createClient(supabaseUrl, supabaseAnonKey);
}
