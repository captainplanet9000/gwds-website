import { createAdminClient } from './supabase-server';

export interface AiRequest {
  messages: { role: 'system' | 'user' | 'assistant'; content: string }[];
  model?: string;
  max_tokens?: number;
  temperature?: number;
}

export interface AiResponse {
  content: string;
  model: string;
  usage: { prompt_tokens: number; completion_tokens: number; total_tokens: number };
}

const DEFAULT_MODEL = 'openai/gpt-4o-mini';

/** Call OpenRouter API for AI completions */
export async function callAi(request: AiRequest): Promise<AiResponse> {
  const apiKey = process.env.OPENROUTER_API_KEY;
  if (!apiKey) throw new Error('OPENROUTER_API_KEY not configured');

  const model = request.model || DEFAULT_MODEL;

  const response = await fetch('https://openrouter.ai/api/v1/chat/completions', {
    method: 'POST',
    headers: {
      'Authorization': `Bearer ${apiKey}`,
      'Content-Type': 'application/json',
      'HTTP-Referer': process.env.NEXT_PUBLIC_APP_URL || 'http://localhost:3000',
      'X-Title': process.env.NEXT_PUBLIC_APP_NAME || 'AI SaaS',
    },
    body: JSON.stringify({
      model,
      messages: request.messages,
      max_tokens: request.max_tokens || 2048,
      temperature: request.temperature ?? 0.7,
    }),
  });

  if (!response.ok) {
    const error = await response.text();
    throw new Error(`OpenRouter API error: ${response.status} ${error}`);
  }

  const data = await response.json();
  const choice = data.choices?.[0];
  if (!choice) throw new Error('No response from AI model');

  return {
    content: choice.message.content,
    model: data.model || model,
    usage: data.usage || { prompt_tokens: 0, completion_tokens: 0, total_tokens: 0 },
  };
}

/** Log API usage to the database */
export async function logUsage(
  userId: string,
  model: string,
  promptTokens: number,
  completionTokens: number,
  durationMs: number,
): Promise<void> {
  const supabase = createAdminClient();
  await supabase.from('usage_logs').insert({
    user_id: userId,
    model,
    prompt_tokens: promptTokens,
    completion_tokens: completionTokens,
    total_tokens: promptTokens + completionTokens,
    duration_ms: durationMs,
  });
}

/** Get usage statistics for a user */
export async function getUsageStats(userId: string, days: number = 30) {
  const supabase = createAdminClient();
  const since = new Date(Date.now() - days * 86400000).toISOString();

  const { data: logs } = await supabase
    .from('usage_logs')
    .select('*')
    .eq('user_id', userId)
    .gte('created_at', since)
    .order('created_at', { ascending: false });

  const entries = logs || [];
  const totalCalls = entries.length;
  const totalTokens = entries.reduce((s, l) => s + (l.total_tokens || 0), 0);
  const avgLatency = entries.length > 0 ? Math.round(entries.reduce((s, l) => s + (l.duration_ms || 0), 0) / entries.length) : 0;

  // Group by day
  const byDay: Record<string, { calls: number; tokens: number }> = {};
  entries.forEach(l => {
    const day = l.created_at.split('T')[0];
    if (!byDay[day]) byDay[day] = { calls: 0, tokens: 0 };
    byDay[day].calls++;
    byDay[day].tokens += l.total_tokens || 0;
  });

  return { totalCalls, totalTokens, avgLatency, byDay, recentLogs: entries.slice(0, 20) };
}
