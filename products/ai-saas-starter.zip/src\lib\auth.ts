import { createAdminClient } from './supabase-server';

export interface UserProfile {
  id: string;
  email: string;
  full_name: string | null;
  avatar_url: string | null;
  plan: 'free' | 'pro' | 'enterprise';
  stripe_customer_id: string | null;
  stripe_subscription_id: string | null;
  api_calls_this_month: number;
  created_at: string;
}

/** Get user profile by Supabase auth user ID */
export async function getUserProfile(userId: string): Promise<UserProfile | null> {
  const supabase = createAdminClient();
  const { data, error } = await supabase
    .from('users')
    .select('*')
    .eq('id', userId)
    .single();

  if (error || !data) return null;
  return data as UserProfile;
}

/** Create or update user profile after auth */
export async function upsertUserProfile(userId: string, email: string, fullName?: string): Promise<UserProfile> {
  const supabase = createAdminClient();
  const { data, error } = await supabase
    .from('users')
    .upsert({
      id: userId,
      email,
      full_name: fullName || null,
      plan: 'free',
      api_calls_this_month: 0,
    }, { onConflict: 'id' })
    .select()
    .single();

  if (error) throw new Error(`Failed to upsert user: ${error.message}`);
  return data as UserProfile;
}

/** Get the API call limit for a plan */
export function getPlanLimit(plan: string): number {
  switch (plan) {
    case 'enterprise': return 100000;
    case 'pro': return 10000;
    default: return 100; // free
  }
}

/** Check if user has remaining API calls */
export async function checkApiLimit(userId: string): Promise<{ allowed: boolean; remaining: number; limit: number }> {
  const profile = await getUserProfile(userId);
  if (!profile) return { allowed: false, remaining: 0, limit: 0 };

  const limit = getPlanLimit(profile.plan);
  const remaining = limit - profile.api_calls_this_month;
  return { allowed: remaining > 0, remaining: Math.max(0, remaining), limit };
}

/** Increment API call count */
export async function incrementApiCalls(userId: string): Promise<void> {
  const supabase = createAdminClient();
  await supabase.rpc('increment_api_calls', { user_id: userId });
}
