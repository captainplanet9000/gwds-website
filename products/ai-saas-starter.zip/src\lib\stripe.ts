import Stripe from 'stripe';
import { createAdminClient } from './supabase-server';

export const stripe = new Stripe(process.env.STRIPE_SECRET_KEY!, {
  apiVersion: '2024-12-18.acacia',
});

/** Create a Stripe checkout session for a subscription */
export async function createCheckoutSession(
  userId: string,
  email: string,
  priceId: string,
  returnUrl: string,
): Promise<string> {
  const supabase = createAdminClient();

  // Get or create Stripe customer
  let { data: user } = await supabase.from('users').select('stripe_customer_id').eq('id', userId).single();

  let customerId = user?.stripe_customer_id;
  if (!customerId) {
    const customer = await stripe.customers.create({ email, metadata: { supabase_user_id: userId } });
    customerId = customer.id;
    await supabase.from('users').update({ stripe_customer_id: customerId }).eq('id', userId);
  }

  const session = await stripe.checkout.sessions.create({
    customer: customerId,
    mode: 'subscription',
    line_items: [{ price: priceId, quantity: 1 }],
    success_url: `${returnUrl}/dashboard?checkout=success`,
    cancel_url: `${returnUrl}/dashboard?checkout=cancelled`,
    metadata: { supabase_user_id: userId },
  });

  return session.url!;
}

/** Create a Stripe customer portal session */
export async function createPortalSession(customerId: string, returnUrl: string): Promise<string> {
  const session = await stripe.billingPortal.sessions.create({
    customer: customerId,
    return_url: `${returnUrl}/dashboard/settings`,
  });
  return session.url;
}

/** Handle Stripe webhook events */
export async function handleWebhookEvent(event: Stripe.Event): Promise<void> {
  const supabase = createAdminClient();

  switch (event.type) {
    case 'checkout.session.completed': {
      const session = event.data.object as Stripe.Checkout.Session;
      const userId = session.metadata?.supabase_user_id;
      if (!userId) break;

      const subscription = await stripe.subscriptions.retrieve(session.subscription as string);
      const priceId = subscription.items.data[0]?.price.id;

      let plan: 'free' | 'pro' | 'enterprise' = 'free';
      if (priceId === process.env.STRIPE_PRO_PRICE_ID) plan = 'pro';
      else if (priceId === process.env.STRIPE_ENTERPRISE_PRICE_ID) plan = 'enterprise';

      await supabase.from('users').update({
        plan,
        stripe_subscription_id: subscription.id,
        stripe_customer_id: session.customer as string,
      }).eq('id', userId);

      await supabase.from('subscriptions').upsert({
        user_id: userId,
        stripe_subscription_id: subscription.id,
        stripe_price_id: priceId,
        plan,
        status: subscription.status,
        current_period_start: new Date(subscription.current_period_start * 1000).toISOString(),
        current_period_end: new Date(subscription.current_period_end * 1000).toISOString(),
      }, { onConflict: 'user_id' });
      break;
    }

    case 'customer.subscription.updated':
    case 'customer.subscription.deleted': {
      const subscription = event.data.object as Stripe.Subscription;
      const { data: users } = await supabase
        .from('users')
        .select('id')
        .eq('stripe_subscription_id', subscription.id);

      if (users && users.length > 0) {
        const userId = users[0].id;
        const isActive = subscription.status === 'active' || subscription.status === 'trialing';
        const priceId = subscription.items.data[0]?.price.id;

        let plan: 'free' | 'pro' | 'enterprise' = 'free';
        if (isActive) {
          if (priceId === process.env.STRIPE_PRO_PRICE_ID) plan = 'pro';
          else if (priceId === process.env.STRIPE_ENTERPRISE_PRICE_ID) plan = 'enterprise';
        }

        await supabase.from('users').update({ plan }).eq('id', userId);
        await supabase.from('subscriptions').upsert({
          user_id: userId,
          stripe_subscription_id: subscription.id,
          stripe_price_id: priceId,
          plan,
          status: subscription.status,
          current_period_start: new Date(subscription.current_period_start * 1000).toISOString(),
          current_period_end: new Date(subscription.current_period_end * 1000).toISOString(),
        }, { onConflict: 'user_id' });
      }
      break;
    }

    case 'invoice.payment_failed': {
      const invoice = event.data.object as Stripe.Invoice;
      const customerId = invoice.customer as string;
      const { data: users } = await supabase
        .from('users')
        .select('id')
        .eq('stripe_customer_id', customerId);
      if (users && users.length > 0) {
        await supabase.from('users').update({ plan: 'free' }).eq('id', users[0].id);
      }
      break;
    }
  }
}
