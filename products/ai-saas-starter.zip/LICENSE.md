# Commercial License — Single Developer

Copyright (c) 2024 Gamma Waves Design Studio

## Grant

You are granted a non-exclusive, non-transferable license to use this software
for **one (1) developer** across unlimited personal and commercial projects.

## Permitted

- Use in unlimited personal projects
- Use in unlimited client projects
- Modify the source code for your own use
- Deploy to production

## Not Permitted

- Redistribute or resell the source code
- Share your license with other developers
- Use in open-source projects
- Create competing template products from this source

## Team License

For teams of 2+ developers, contact support for a team license.

## No Warranty

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND.
