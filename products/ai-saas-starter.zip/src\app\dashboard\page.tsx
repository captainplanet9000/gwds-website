'use client';

import { useEffect, useState } from 'react';
import Link from 'next/link';
import { supabase } from '@/lib/supabase-browser';

interface UsageData {
  plan: string;
  apiCallsThisMonth: number;
  monthlyLimit: number;
  totalCalls: number;
  totalTokens: number;
  avgLatency: number;
  byDay: Record<string, { calls: number; tokens: number }>;
  recentLogs: any[];
}

export default function Dashboard() {
  const [user, setUser] = useState<any>(null);
  const [usage, setUsage] = useState<UsageData | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    supabase.auth.getUser().then(({ data }) => {
      setUser(data.user);
      if (data.user) {
        fetch('/api/usage').then(r => r.json()).then(d => { setUsage(d); setLoading(false); }).catch(() => setLoading(false));
      } else {
        setLoading(false);
      }
    });
  }, []);

  const handleSignOut = async () => {
    await supabase.auth.signOut();
    window.location.href = '/';
  };

  if (loading) return <div style={{ padding: 48, color: 'var(--text-muted)' }}>Loading...</div>;

  const usagePercent = usage ? Math.min(100, (usage.apiCallsThisMonth / usage.monthlyLimit) * 100) : 0;
  const planColors: Record<string, string> = { free: '#71717a', pro: '#6366f1', enterprise: '#8b5cf6' };

  return (
    <div style={{ minHeight: '100vh' }}>
      {/* Dashboard Nav */}
      <nav style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '12px 32px', borderBottom: '1px solid var(--border)', background: 'var(--bg-surface)' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 24 }}>
          <Link href="/" style={{ display: 'flex', alignItems: 'center', gap: 8, fontWeight: 700, fontSize: '1rem', color: 'var(--text-primary)', textDecoration: 'none' }}>
            <span style={{ width: 28, height: 28, background: 'var(--accent)', borderRadius: 6, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: '0.8rem' }}>⚡</span>
            AI SaaS
          </Link>
          <div style={{ display: 'flex', gap: 4 }}>
            {[
              { href: '/dashboard', label: 'Overview', icon: '📊' },
              { href: '/dashboard/playground', label: 'Playground', icon: '🧪' },
              { href: '/dashboard/settings', label: 'Settings', icon: '⚙️' },
            ].map(link => (
              <Link key={link.href} href={link.href} style={{ padding: '6px 12px', borderRadius: 6, fontSize: '0.85rem', color: 'var(--text-secondary)', textDecoration: 'none' }}>
                {link.icon} {link.label}
              </Link>
            ))}
          </div>
        </div>
        <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
          <span style={{ display: 'inline-flex', padding: '2px 10px', borderRadius: 100, fontSize: '0.72rem', fontWeight: 600, textTransform: 'uppercase', background: 'var(--accent-subtle)', color: 'var(--accent)' }}>{usage?.plan || 'free'}</span>
          <span style={{ fontSize: '0.85rem', color: 'var(--text-secondary)' }}>{user?.email}</span>
          <button onClick={handleSignOut} style={{ padding: '6px 12px', background: 'var(--bg-elevated)', border: '1px solid var(--border)', borderRadius: 6, color: 'var(--text-secondary)', fontSize: '0.82rem', cursor: 'pointer' }}>Sign Out</button>
        </div>
      </nav>

      {/* Dashboard Content */}
      <div style={{ padding: '32px', maxWidth: 1000, margin: '0 auto' }}>
        <h1 style={{ fontSize: '1.6rem', fontWeight: 700, marginBottom: 32, letterSpacing: '-0.02em' }}>Dashboard</h1>

        {/* Stats Grid */}
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 16, marginBottom: 32 }}>
          {[
            { label: 'API Calls', value: usage?.apiCallsThisMonth || 0, sub: `/ ${usage?.monthlyLimit || 0} limit` },
            { label: 'Total Tokens', value: usage?.totalTokens ? `${(usage.totalTokens / 1000).toFixed(1)}k` : '0', sub: 'last 30 days' },
            { label: 'Avg Latency', value: `${usage?.avgLatency || 0}ms`, sub: 'per request' },
            { label: 'Plan', value: (usage?.plan || 'free').charAt(0).toUpperCase() + (usage?.plan || 'free').slice(1), sub: usage?.plan === 'free' ? 'Upgrade →' : 'Active' },
          ].map(s => (
            <div key={s.label} style={{ padding: 20, background: 'var(--bg-surface)', border: '1px solid var(--border)', borderRadius: 12 }}>
              <div style={{ fontSize: '0.72rem', fontWeight: 500, color: 'var(--text-muted)', textTransform: 'uppercase', letterSpacing: '0.04em', marginBottom: 6 }}>{s.label}</div>
              <div style={{ fontSize: '1.5rem', fontWeight: 700, marginBottom: 4 }}>{s.value}</div>
              <div style={{ fontSize: '0.78rem', color: 'var(--text-muted)' }}>{s.sub}</div>
            </div>
          ))}
        </div>

        {/* Usage Bar */}
        <div style={{ padding: 20, background: 'var(--bg-surface)', border: '1px solid var(--border)', borderRadius: 12, marginBottom: 32 }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 8 }}>
            <span style={{ fontSize: '0.85rem', fontWeight: 600 }}>Monthly Usage</span>
            <span style={{ fontSize: '0.82rem', color: 'var(--text-secondary)' }}>{usage?.apiCallsThisMonth || 0} / {usage?.monthlyLimit || 0}</span>
          </div>
          <div style={{ height: 8, background: 'var(--bg-elevated)', borderRadius: 4, overflow: 'hidden' }}>
            <div style={{ height: '100%', width: `${usagePercent}%`, background: usagePercent > 90 ? 'var(--rose)' : usagePercent > 70 ? 'var(--amber)' : 'var(--accent)', borderRadius: 4, transition: 'width 0.3s' }} />
          </div>
        </div>

        {/* Recent Activity */}
        <div style={{ padding: 20, background: 'var(--bg-surface)', border: '1px solid var(--border)', borderRadius: 12 }}>
          <h2 style={{ fontSize: '1rem', fontWeight: 600, marginBottom: 16 }}>Recent API Calls</h2>
          {!usage?.recentLogs?.length ? (
            <p style={{ color: 'var(--text-muted)', fontSize: '0.88rem', textAlign: 'center', padding: 24 }}>
              No API calls yet. <Link href="/dashboard/playground" style={{ color: 'var(--accent)' }}>Try the playground →</Link>
            </p>
          ) : (
            <div style={{ display: 'flex', flexDirection: 'column', gap: 4 }}>
              {usage.recentLogs.slice(0, 10).map((log: any, i: number) => (
                <div key={i} style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '8px 12px', borderRadius: 6, fontSize: '0.85rem' }}>
                  <div style={{ display: 'flex', gap: 12, alignItems: 'center' }}>
                    <span style={{ fontFamily: 'monospace', fontSize: '0.78rem', color: 'var(--accent)' }}>{log.model}</span>
                    <span style={{ color: 'var(--text-muted)' }}>{log.total_tokens} tokens</span>
                  </div>
                  <div style={{ display: 'flex', gap: 12, alignItems: 'center', color: 'var(--text-muted)', fontSize: '0.78rem' }}>
                    <span>{log.duration_ms}ms</span>
                    <span>{new Date(log.created_at).toLocaleString()}</span>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
