import { NextResponse } from 'next/server';
import { createServerClient } from '@supabase/ssr';
import { cookies } from 'next/headers';
import { checkApiLimit, incrementApiCalls, getUserProfile } from '@/lib/auth';
import { callAi, logUsage } from '@/lib/ai';
import { checkRateLimit } from '@/lib/rate-limit';

export const dynamic = 'force-dynamic';

export async function POST(request: Request) {
  try {
    // Authenticate user
    const cookieStore = await cookies();
    const supabase = createServerClient(
      process.env.NEXT_PUBLIC_SUPABASE_URL!,
      process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!,
      {
        cookies: {
          getAll() { return cookieStore.getAll(); },
          setAll(cookiesToSet) {
            cookiesToSet.forEach(({ name, value, options }) => {
              cookieStore.set(name, value, options);
            });
          },
        },
      }
    );

    const { data: { user } } = await supabase.auth.getUser();
    if (!user) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    // Get user profile and check limits
    const profile = await getUserProfile(user.id);
    if (!profile) {
      return NextResponse.json({ error: 'User profile not found' }, { status: 404 });
    }

    // Rate limit check
    const rateResult = checkRateLimit(user.id, profile.plan);
    if (!rateResult.allowed) {
      return NextResponse.json(
        { error: 'Rate limited', retryAfterMs: rateResult.resetMs },
        { status: 429, headers: { 'Retry-After': String(Math.ceil(rateResult.resetMs / 1000)) } }
      );
    }

    // Monthly API limit check
    const limitResult = await checkApiLimit(user.id);
    if (!limitResult.allowed) {
      return NextResponse.json(
        { error: 'Monthly API limit reached', limit: limitResult.limit, used: limitResult.limit - limitResult.remaining },
        { status: 429 }
      );
    }

    // Parse request
    const body = await request.json();
    const { messages, model, max_tokens, temperature } = body;

    if (!messages || !Array.isArray(messages) || messages.length === 0) {
      return NextResponse.json({ error: 'messages array is required' }, { status: 400 });
    }

    // Call AI
    const startTime = Date.now();
    const result = await callAi({ messages, model, max_tokens, temperature });
    const durationMs = Date.now() - startTime;

    // Log usage and increment counter
    await Promise.all([
      logUsage(user.id, result.model, result.usage.prompt_tokens, result.usage.completion_tokens, durationMs),
      incrementApiCalls(user.id),
    ]);

    return NextResponse.json({
      content: result.content,
      model: result.model,
      usage: result.usage,
      remaining: limitResult.remaining - 1,
    });
  } catch (error) {
    console.error('AI chat error:', error);
    return NextResponse.json(
      { error: error instanceof Error ? error.message : 'Internal server error' },
      { status: 500 }
    );
  }
}
