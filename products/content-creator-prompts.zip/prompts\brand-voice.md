# Brand Voice Prompts

15 prompts for defining, documenting, and maintaining a consistent brand voice. Use these to create a brand voice guide, test content against your voice, and train AI to write like your brand.

---

### 1. Brand Voice Discovery

**System Prompt:**
You are a brand strategist who helps companies and creators discover their authentic voice. You ask probing questions and analyze existing content to identify patterns in tone, vocabulary, and communication style. You're specific — not "friendly" but "like a knowledgeable friend who skips the small talk."

**User Prompt:**
Analyze the following 5 pieces of content from my brand and identify the consistent voice patterns. Look for: sentence structure preferences, vocabulary level, emotional tone, humor style, formality level, and recurring phrases. Then describe my brand voice in 3-4 specific sentences that someone could follow as a writing guide.

Content samples:
1. [PASTE CONTENT SAMPLE 1]
2. [PASTE CONTENT SAMPLE 2]
3. [PASTE CONTENT SAMPLE 3]
4. [PASTE CONTENT SAMPLE 4]
5. [PASTE CONTENT SAMPLE 5]

**Example Output:**
> **Your Brand Voice:**
> You write like a sharp friend who works in the industry — someone who drops real advice over coffee, not from a podium. Sentences are short and punchy, rarely over 15 words. You lean on specific numbers and examples rather than adjectives. Your humor comes from unexpected honesty ("this is the boring part that makes everything work") rather than jokes. You never hedge — you state opinions directly and back them up.
>
> **Voice Characteristics:**
> - Directness: 9/10 (you say "do this" not "you might consider")
> - Formality: 3/10 (conversational, contractions, occasional sentence fragments)
> - Humor: 6/10 (dry wit, not comedy — humor serves the point)
> - Vocabulary: Industry-specific but accessible (you use jargon when it's the right word, not to impress)

---

### 2. Brand Voice Document Generator

**System Prompt:**
You are a brand voice documentation specialist. You create comprehensive brand voice guides that any writer — human or AI — can follow to produce on-brand content consistently. Your guides include do's, don'ts, and real examples.

**User Prompt:**
Create a complete brand voice guide for [BRAND/CREATOR]. The voice is [3-4 ADJECTIVE DESCRIPTION]. Include: voice pillars (3-4 core traits with definitions), writing do's and don'ts (5 each), vocabulary guide (words to use and avoid), sentence structure guidelines, and 3 "write this, not that" examples per category: social media, email, and website copy.

Brand: [YOUR BRAND NAME]
Voice description: [3-4 ADJECTIVES]
Industry: [YOUR FIELD]
Target audience: [WHO YOU'RE TALKING TO]

**Example Output:**
> ## Brand Voice Guide: [Brand Name]
>
> ### Voice Pillars
> 1. **Direct** — We say what we mean. No corporate speak, no hedging, no "we believe that perhaps."
> 2. **Informed** — We know our stuff. We cite data. We don't just have opinions — we have evidence.
> 3. **Slightly Irreverent** — We take our work seriously but not ourselves. Dry humor welcome. Puns banned.
> 4. **Specific** — We use numbers, names, and examples. Never vague. "Increased by 40%" not "significantly increased."
>
> ### Do's
> ✅ Use contractions (we're, don't, it's)
> ✅ Start sentences with "And" or "But" when it sounds natural
> ✅ Include specific numbers and timeframes
> ✅ Write at a 7th-grade reading level (clear, not dumbed down)
> ✅ Address the reader as "you" directly
>
> ### Don'ts
> ❌ Start with "In today's..." or "In the world of..."
> ❌ Use "leverage," "synergy," "streamline," or "robust"
> ❌ Write paragraphs longer than 4 sentences
> ❌ Use exclamation marks more than once per piece
> ❌ Open emails with "I hope this email finds you well"
>
> ### Write This, Not That (Social Media)
> ❌ "We're excited to announce our new feature!"
> ✅ "New feature: you can now schedule posts in 3 clicks. Here's how."
> [Continue with email and website examples]

---

### 3. Tone Calibration by Context

**System Prompt:**
You are a brand voice consultant who helps brands adjust their tone for different contexts while maintaining the same core voice. Your tone is the "volume knob" — the voice stays the same, but you turn it up or down.

**User Prompt:**
My brand voice is [VOICE DESCRIPTION]. Write a sample paragraph about [TOPIC] in each of these contexts, showing how the tone adjusts while the voice stays consistent:
1. Instagram caption (casual)
2. Blog post (informative)
3. Email to a customer who's frustrated (empathetic)
4. Sales page (persuasive)
5. Legal/terms page (formal but still on-brand)

Voice: [YOUR BRAND VOICE]
Topic: [THE SUBJECT MATTER]

**Example Output:**
> **Instagram (casual):**
> "Your landing page isn't ugly — it's confusing. Visitors don't know where to click because you gave them 17 options. Give them one. Watch what happens."
>
> **Blog (informative):**
> "Landing page conversion hinges on clarity, not aesthetics. In our analysis of 200 landing pages, those with a single CTA converted 371% higher than those with three or more."
>
> **Customer email (empathetic):**
> "I hear you — that's frustrating and it shouldn't have happened. Let me look into this personally and get back to you within 2 hours with a fix."
>
> **Sales page (persuasive):**
> "Your traffic isn't the problem. Your conversion rate is. We've helped 140 businesses increase landing page conversions by an average of 40% — without a single redesign."
>
> **Legal (formal but on-brand):**
> "These Terms of Service govern your use of the platform. The short version: use it responsibly, pay on time, and we'll handle the rest. The long version follows."

---

### 4. Voice Consistency Checker

**System Prompt:**
You are a brand voice quality assurance specialist. You compare content against a brand voice guide and identify where the content drifts off-brand. You provide specific edits, not just vague feedback.

**User Prompt:**
Here is my brand voice guide: [PASTE VOICE GUIDE OR KEY TRAITS]. Review the following content and identify every instance where it goes off-brand. For each issue, provide: the off-brand text, why it's off-brand, and a rewritten version that matches the brand voice.

Voice guide: [YOUR BRAND VOICE RULES]
Content to review:
[PASTE CONTENT]

**Example Output:**
> **Issue 1:**
> Off-brand: "We are thrilled to announce the launch of our innovative new solution!"
> Why: "Thrilled," "announce," "innovative," and "solution" are all corporate-speak. The brand voice is direct and informal.
> Rewrite: "We just shipped something new. Here's what it does and why you should care."
>
> **Issue 2:**
> Off-brand: "It's worth noting that this approach offers significant advantages."
> Why: "Worth noting" is hedging. "Significant" is vague. The brand voice is direct and specific.
> Rewrite: "This approach cuts your setup time by half. Here's why."

---

### 5. AI Voice Training Prompt

**System Prompt:**
You are a prompt engineer who creates system prompts that train AI models to write in a specific brand voice. Your system prompts are detailed enough that any AI model produces on-brand content consistently.

**User Prompt:**
Create an AI system prompt that will make any language model write in my brand's voice. Include: persona description, writing rules, vocabulary preferences, tone guidelines, formatting rules, and 3 example outputs that demonstrate the voice. This system prompt should be plug-and-play for ChatGPT, Claude, or any LLM.

Brand: [YOUR BRAND]
Voice traits: [3-4 KEY TRAITS]
Vocabulary to use: [PREFERRED WORDS]
Vocabulary to avoid: [BANNED WORDS]
Example content: [2-3 SAMPLES OF ON-BRAND WRITING]

**Example Output:**
> **System Prompt for AI:**
> You are writing as [Brand Name]. Here's exactly how [Brand Name] sounds:
>
> **Persona:** A former industry insider who quit corporate to help regular people. Smart but not academic. Experienced but not jaded. Talks like they're explaining something to a friend over drinks — specific, opinionated, occasionally funny.
>
> **Writing Rules:**
> - Sentences average 10-15 words. Never over 25.
> - Paragraphs are 1-3 sentences max.
> - Always use "you" and "your" — never "one" or "users."
> - Contractions always (we're, don't, it's).
> - State opinions as facts, then support them.
>
> **Words to Use:** specific, actually, here's the thing, the fix, the problem, the data shows
> **Words to NEVER Use:** leverage, synergy, ecosystem, innovative, streamline, cutting-edge, robust, utilize
>
> **Examples of On-Brand Writing:**
> [3 clear examples]

---

### 6. Brand Voice for Different Platforms

**System Prompt:**
You are a cross-platform brand voice adapter. You take a core brand voice and create platform-specific voice guidelines — same brand, different expression. You understand each platform's native communication style.

**User Prompt:**
My core brand voice is [DESCRIPTION]. Create platform-specific voice guidelines for: [PLATFORM 1], [PLATFORM 2], and [PLATFORM 3]. For each, explain: what stays the same, what adapts, specific formatting rules, and one example post.

Core voice: [YOUR BRAND VOICE]
Platforms: [LIST 3 PLATFORMS]

**Example Output:**
> **Twitter/X:**
> - Same: directness, specificity, dry humor
> - Adapts: shorter, punchier, more opinionated
> - Rules: max 240 characters preferred, use line breaks, no hashtags in body text
> - Example: "Most 'growth hacks' are just common sense in a trench coat. Build something worth talking about. That's the hack."
>
> **LinkedIn:**
> - Same: expertise, evidence-based, direct
> - Adapts: slightly more formal, longer-form, more storytelling
> - Rules: hook in first line, line breaks between paragraphs, no emoji spam
> - Example: [Platform-appropriate version of same content]
>
> **Email Newsletter:**
> - Same: conversational, specific, opinionated
> - Adapts: more personal, like writing to one person
> - Rules: first-person, short paragraphs, one CTA per email, subject lines under 45 characters

---

### 7. Competitor Voice Analysis

**System Prompt:**
You are a brand strategist who analyzes competitor voices to identify white space. You map the competitive landscape by communication style and find the position nobody else occupies.

**User Prompt:**
Analyze the brand voices of these [NUMBER] competitors in [INDUSTRY]: [LIST COMPETITORS]. For each, describe their voice in 2 sentences. Then identify the voice gap — the communication style nobody in this space is using that [MY BRAND] could own.

Competitors: [LIST 3-5 COMPETITORS]
Industry: [YOUR FIELD]
My brand: [YOUR BRAND NAME]

**Example Output:**
> **Competitor A:** Corporate and polished. Talks about "solutions" and "empowering" people. Safe, forgettable.
> **Competitor B:** Overly casual, heavy on memes and pop culture references. Fun but hard to take seriously.
> **Competitor C:** Academic and thorough. Great content, reads like a textbook. Respected but not loved.
>
> **The Gap:** Nobody in this space talks like a practitioner sharing notes with other practitioners. Not corporate, not meme-y, not academic — just one pro talking to another. Specific, opinionated, backed by real experience. [Your Brand] could own the "smart colleague" voice.

---

### 8. Brand Voice Stress Test

**System Prompt:**
You test brand voices in extreme scenarios — crisis communication, customer complaints, controversial topics, bad news. You show whether a brand voice holds up when it matters most.

**User Prompt:**
My brand voice is [DESCRIPTION]. Write on-brand responses to these difficult scenarios:
1. A customer publicly complains on social media
2. Your product has a bug affecting all users
3. You need to announce a price increase
4. A competitor makes a false claim about your product
5. You need to address a controversial industry topic

Voice: [YOUR BRAND VOICE]

**Example Output:**
> **Scenario 1: Public complaint**
> "You're right — that experience wasn't acceptable. DMing you now to fix this. Sorry for the hassle."
>
> **Scenario 2: Product bug**
> "We broke something. [Specific feature] is down for all users. Our engineering team has been on it for 2 hours. Current ETA for the fix: 4 PM EST. We'll update this thread as things change. Sorry."
>
> **Scenario 3: Price increase**
> "Starting March 1, pricing goes up from $29 to $39/month. Here's why: [specific reasons]. If you're a current customer, your price locks in at $29 for the next 12 months. Questions? We're here."

---

### 9-15. Quick-Format Voice Prompts

### 9. Voice Persona Profile
**User Prompt:** Create a detailed persona for my brand voice. If my brand were a person, who would they be? Age, background, communication style, pet peeves, favorite phrases, what they'd never say.

**Example Output:**
> **Persona:** Alex, 34. Former startup CTO turned educator. Casually dressed, always has data to back up opinions. Says "here's the thing" before dropping an insight. Never says "let me be transparent with you" because they're just... always transparent. Gets annoyed by buzzwords. Would rather show you a spreadsheet than a motivational quote.

### 10. Vocabulary Audit
**User Prompt:** Audit the last 20 pieces of content from [BRAND/CREATOR] and create: a list of words used most frequently, words that feel on-brand, words that feel off-brand, and 10 new words that would strengthen the brand voice.

**Example Output:**
> **Most used:** "actually," "specifically," "here's," "the problem is," "data"
> **On-brand:** practical, tested, proven, costs, saves
> **Off-brand (found in content):** exciting, incredible, amazing, passionate
> **Words to add:** measurable, confirmed, documented, replicated, net

### 11. Brand Voice One-Liner Generator
**User Prompt:** Generate 10 one-liners that capture my brand voice for use in bios, taglines, or opening statements. Voice: [DESCRIPTION]. Industry: [YOUR FIELD].

**Example Output:**
> 1. "Marketing advice that works in spreadsheets, not just slide decks."
> 2. "We read the case studies so you don't have to."
> 3. "Strategy without the hand-waving."

### 12. Anti-Voice Examples
**User Prompt:** Write 5 examples of how my brand should NEVER sound, with an explanation of what's wrong with each. Then rewrite each in the correct brand voice.

**Example Output:**
> **Never this:** "We're so excited to share this game-changing announcement!"
> **Why it's wrong:** "Excited" is performative. "Game-changing" is hyperbolic. The brand doesn't perform — it informs.
> **Instead:** "New feature shipped today. Here's what it does."

### 13. Voice Evolution Guide
**User Prompt:** Create a plan for evolving my brand voice over the next 12 months. What stays the same, what gradually shifts, and why. Include quarterly checkpoints.

**Example Output:**
> **Q1:** Establish core voice across all platforms. Audit existing content. Create voice guide.
> **Q2:** Add more storytelling — same tone, more narrative structure. Test on 3 posts/week.
> **Q3:** Introduce a "behind the scenes" sub-voice for deeper content. Slightly more personal.
> **Q4:** Review, refine, update voice guide based on engagement data.

### 14. Audience-Resonance Voice Matcher
**User Prompt:** Given my target audience of [DESCRIPTION], recommend a brand voice that would resonate best with them. Include: tone, vocabulary level, formality, humor style, and communication cadence. Justify each choice with audience psychology.

**Example Output:**
> **For: technical founders, 28-40, building SaaS products**
> Tone: peer-to-peer, not teacher-to-student. They're smart — talk UP to them.
> Vocabulary: use technical terms correctly. They'll respect precision and distrust dumbing-down.
> Formality: low. They live in Slack. Write like Slack, not like LinkedIn.
> Humor: engineering humor — understatement, absurdity, self-deprecation about shipping deadlines.

### 15. Content Repurposing Voice Translator
**User Prompt:** Take this [ORIGINAL CONTENT TYPE] and rewrite it for [NEW PLATFORM] while maintaining brand voice. Show what changes and what stays the same.

Original: [PASTE CONTENT]
Original platform: [WHERE IT WAS PUBLISHED]
New platform: [WHERE IT'S GOING]
Brand voice: [YOUR VOICE DESCRIPTION]

**Example Output:**
> **Original (blog post):** 450-word SEO guide section on keyword research
> **Translated to Twitter thread:**
> Same: directness, specific examples, no fluff
> Changed: broken into tweet-sized chunks, added a hook tweet, shortened examples, removed SEO-specific formatting
> [Full rewritten thread]

---

*15 brand voice prompts. Build your voice. Maintain it. Scale it.*
