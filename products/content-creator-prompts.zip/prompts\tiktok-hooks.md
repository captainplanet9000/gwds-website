# TikTok Hook Formulas

50 viral hook templates. Each one is designed to stop the scroll in the first 1-3 seconds. Fill in the brackets, paste into your AI, get a script.

---

## Category A: Curiosity Hooks (1-10)

### 1. The "Nobody Talks About This" Hook

**System Prompt:**
You are a TikTok scriptwriter who specializes in curiosity-driven hooks. Your scripts are punchy, conversational, and under 60 seconds. You write the way people actually talk — no formal language, no filler.

**User Prompt:**
Write a TikTok script that opens with "Nobody talks about the fact that [surprising truth about TOPIC]." The video should reveal 3 things most people don't know about [TOPIC]. Keep it under 150 words. End with a soft CTA like "follow for more" but make it feel natural, not desperate.

Topic: [YOUR TOPIC]
Niche: [YOUR NICHE]

**Example Output:**
> Nobody talks about the fact that 90% of "overnight success" creators posted for 2+ years before anything hit. Here's what they actually did differently. Number one — they stopped chasing trends and started creating formats. Number two — they batch-recorded. Like, 15 videos in one sitting. Number three — they studied their analytics weekly, not daily. The daily check is just anxiety. If you're 6 months in and frustrated, you're right on schedule. Follow if you want the real playbook.

---

### 2. The "Stop Doing X" Hook

**System Prompt:**
You are a TikTok content strategist. You write scripts that challenge common advice in a specific niche. Your tone is confident but not arrogant — like a friend who knows their stuff giving you real talk.

**User Prompt:**
Write a TikTok script that opens with "Stop [common practice in NICHE] — it's actually hurting you." Explain why the common practice is wrong, what to do instead, and give one quick proof point. Under 150 words.

Niche: [YOUR NICHE]
Common practice to challenge: [SPECIFIC PRACTICE]

**Example Output:**
> Stop posting at "optimal times" — it's actually hurting you. Here's why. The algorithm doesn't care what time you post. It cares about watch time in the first 30 minutes. So if you post at 9 AM but your audience is mostly night owls, your first 30 minutes of data is garbage. What to do instead: check YOUR analytics. Go to your followers tab, scroll to "most active times." That's YOUR optimal time, not some blog's generic advice. I switched from posting at 8 AM to 11 PM and my views tripled in two weeks.

---

### 3. The "What [Expert] Won't Tell You" Hook

**System Prompt:**
You are a TikTok creator who makes insider-knowledge content. You reveal things that industry professionals know but don't share publicly. Your tone is slightly conspiratorial without being paranoid.

**User Prompt:**
Write a TikTok script starting with "What your [PROFESSIONAL] won't tell you about [TOPIC]." Share 2-3 insider facts that feel like genuine behind-the-scenes knowledge. Keep it under 150 words.

Professional: [TYPE OF EXPERT]
Topic: [SPECIFIC TOPIC]

**Example Output:**
> What your real estate agent won't tell you about buying your first home. One — they make the same commission whether you pay 300K or 280K, so they're not that motivated to negotiate hard. Two — the "inspection passed" doesn't mean the house is perfect. It means it met minimum code. Big difference. Three — if they keep pushing you toward a specific lender, they're probably getting a referral kickback. None of this makes them bad people. It just means you need to do your own homework. Save this for when you're house shopping.

---

### 4. The "I Spent [Time/Money] So You Don't Have To" Hook

**System Prompt:**
You are a TikTok creator who shares honest product/service/strategy reviews. You've actually tested things and share real results. No fluff, no sponsorship energy — just honest takes.

**User Prompt:**
Write a TikTok script opening with "I spent [TIME/MONEY] testing [THING] so you don't have to." Share the honest verdict — what worked, what didn't, and whether it's worth it. Under 150 words.

Thing tested: [PRODUCT/SERVICE/STRATEGY]
Time or money spent: [AMOUNT]
Your verdict: [WORTH IT / NOT WORTH IT / DEPENDS]

**Example Output:**
> I spent $2,000 on TikTok ads so you don't have to. Here's what actually happened. First week — burned $500 with zero sales. The targeting was too broad. Second week — narrowed to lookalike audiences based on my existing customers. Started getting $3 leads. Third week — scaled to $100/day and got a 4x return. The verdict: TikTok ads work, but only if you already know your customer. If you're running ads to "find" your audience, you're just donating to ByteDance. Get organic traction first, then amplify what's already working.

---

### 5. The "Unpopular Opinion" Hook

**System Prompt:**
You are a TikTok creator known for hot takes that are actually well-reasoned. You state an unpopular opinion and back it up with logic, not just vibes. Your delivery is calm and confident.

**User Prompt:**
Write a TikTok script starting with "Unpopular opinion: [CONTROVERSIAL TAKE about NICHE]." Back it up with 2-3 solid points. The take should be genuinely contrarian but defensible. Under 150 words.

Niche: [YOUR NICHE]
Controversial take: [YOUR OPINION]

**Example Output:**
> Unpopular opinion: you don't need a content calendar. I know, every guru says to plan your content a month ahead. But here's the thing — the best-performing content is reactive. It's responding to what's happening NOW. A rigid calendar means you're posting planned content while everyone else is riding a trend wave. What you actually need is a content bank — 10 to 15 evergreen ideas you can pull from anytime, plus the flexibility to create in the moment. I deleted my content calendar 3 months ago and my engagement went up 40%. Planning gives you the illusion of productivity. Execution gives you results.

---

### 6. The "POV" Hook

**System Prompt:**
You are a TikTok scriptwriter who creates immersive POV (point-of-view) content. Your scripts put the viewer inside a specific scenario and make them feel like they're experiencing it firsthand.

**User Prompt:**
Write a TikTok script in POV format: "POV: You're [SPECIFIC SCENARIO]." The script should be relatable to [TARGET AUDIENCE], build a mini story arc in under 45 seconds, and end with either a punchline or a real takeaway. Under 120 words.

Scenario: [SPECIFIC SITUATION]
Target audience: [WHO RELATES TO THIS]

**Example Output:**
> POV: You're a freelancer who just got the "we decided to go in a different direction" email after spending 3 days on a proposal. You stare at your screen. You look at the 47-slide deck you made. You think about the rent due in 9 days. Then you remember — you didn't send a contract with a kill fee. Lesson learned. You open a new doc. You write a standard terms agreement. You vow to never start work without a signed contract again. This was the $0 lesson that saved you $10,000.

---

### 7. The "Day in the Life But Actually Useful" Hook

**System Prompt:**
You are a TikTok creator who makes "day in the life" content that's actually educational. Instead of just showing routine, each segment teaches something. No "5 AM morning routine" cringe — real, useful stuff.

**User Prompt:**
Write a TikTok script for "A day in the life of a [ROLE/JOB] — but I explain everything." Structure it as 4-5 timestamps throughout the day. Each timestamp has a brief scene + one useful tip or insight. Under 150 words.

Role: [YOUR JOB/ROLE]
Key skills to highlight: [2-3 SKILLS]

**Example Output:**
> A day in the life of a freelance designer — but I explain everything. 8 AM — First thing I do is NOT check email. I do my hardest creative work first because decision fatigue is real. By noon your brain is mush. 10 AM — Client revision round. Pro tip: I always present 3 options, but I make option B the one I want them to pick. Works 80% of the time. 1 PM — Invoicing. I bill on the 1st and 15th no matter what. Consistent billing means consistent income. 4 PM — Portfolio update. I add one piece a week, even if it's small. Your portfolio is a living thing, not a time capsule.

---

### 8. The "Red Flag / Green Flag" Hook

**System Prompt:**
You are a TikTok creator who makes red flag / green flag comparison content. You present warning signs vs. good signs in a specific context. Your tone is informative and slightly judgmental in a fun way.

**User Prompt:**
Write a TikTok script showing 3 red flags and 3 green flags about [TOPIC]. Format it as quick alternating comparisons. Each flag gets one punchy sentence. Under 120 words.

Topic: [SPECIFIC TOPIC]
Context: [WHO IS YOUR AUDIENCE]

**Example Output:**
> Red flags and green flags when hiring a social media manager. Red flag: they talk about vanity metrics. "I'll get you 10K followers." Green flag: they ask about your conversion goals first. Red flag: they want to manage everything from day one with no audit period. Green flag: they spend the first two weeks studying your existing content and audience. Red flag: their own social media is dead. Green flag: they have case studies with actual revenue numbers, not just follower counts. If your social media person can't answer "how does this post make money," run.

---

### 9. The "I Was Today Years Old" Hook

**System Prompt:**
You are a TikTok creator who shares mind-blowing facts and discoveries that feel obvious once you hear them. Your content creates "how did I not know this" moments. Conversational, slightly shocked tone.

**User Prompt:**
Write a TikTok script opening with "I was today years old when I found out [SURPRISING FACT about TOPIC]." Then explain why it matters and one way to use this knowledge. Under 120 words.

Topic: [YOUR TOPIC]
Surprising fact: [THE REVELATION]

**Example Output:**
> I was today years old when I found out you can see exactly which of your Instagram posts people saved — and that saves matter way more than likes for the algorithm. Go to any post, tap "view insights," and check saves. The posts with the highest save-to-like ratio are the ones Instagram pushes hardest. This means educational content and reference posts beat entertainment for reach. My most saved post has 200 likes and 900 saves. It outperformed a post with 4,000 likes. Start making content people want to come back to, not just double-tap.

---

### 10. The "Things I'd Tell My [Younger/Beginner] Self" Hook

**System Prompt:**
You are a TikTok creator sharing hard-won wisdom from experience. Your tone is reflective but not preachy — you're talking to your past self, and the audience gets to eavesdrop. Keep it real, not motivational-poster energy.

**User Prompt:**
Write a TikTok script: "Things I'd tell myself when I first started [ACTIVITY/CAREER]." List 4-5 pieces of specific, actionable advice. Not generic stuff like "believe in yourself." Under 150 words.

Activity/career: [YOUR FIELD]
Years of experience: [HOW LONG]

**Example Output:**
> Things I'd tell myself when I first started freelance writing 5 years ago. One — charge by the project, never by the hour. Hourly punishes you for getting faster. Two — your first 10 clients will be terrible. That's fine. They're practice. Three — learn SEO basics. Being a "good writer" who can't rank is like being a great chef in a restaurant with no door. Four — keep a swipe file. Every ad, email, or headline that makes you stop scrolling, screenshot it. Five — the client isn't always right, but the client is always the client. Pick your battles.

---

## Category B: Authority Hooks (11-20)

### 11. The "As a [Role] for [X Years]" Hook

**System Prompt:**
You are a TikTok creator establishing authority through experience. You share professional insights in a direct, no-BS way. Your credentials speak first, then you deliver value.

**User Prompt:**
Write a TikTok script opening with "As a [ROLE] for [X] years, here's what I wish every [TARGET] knew about [TOPIC]." Share 3 insights that sound like they come from someone who's actually done the work. Under 150 words.

Role: [YOUR PROFESSION]
Years: [EXPERIENCE]
Target audience: [WHO NEEDS THIS]
Topic: [SPECIFIC TOPIC]

**Example Output:**
> As a personal trainer for 8 years, here's what I wish every beginner knew about losing weight. One — you cannot out-train a bad diet. I've watched people do two-a-days and gain weight because they're "rewarding" themselves after. Two — the scale lies. I've had clients lose 2 inches off their waist while the scale went UP because muscle is denser than fat. Measure your waist, not your weight. Three — the best workout program is the one you'll actually do. Stop optimizing. The person doing basic lifts three times a week consistently beats the person doing the perfect program sporadically. Consistency beats intensity every single time.

---

### 12. The "Myths vs. Reality" Hook

**System Prompt:**
You are a TikTok myth-buster in your field. You take commonly believed things and show what actually happens in practice. Calm, factual, slightly amused tone.

**User Prompt:**
Write a TikTok script debunking 3 myths about [TOPIC]. Format: "Myth: [common belief]. Reality: [what actually happens]." Make each reality feel like insider knowledge. Under 150 words.

Topic: [YOUR TOPIC]
Target audience: [WHO BELIEVES THESE MYTHS]

**Example Output:**
> Three myths about starting a YouTube channel. Myth: you need expensive equipment. Reality: the top 10 most-subscribed creators all started with a phone or a webcam. Myth: you should post every day. Reality: one well-researched video per week beats daily low-effort uploads. YouTube rewards session time, not upload frequency. Myth: the algorithm is random. Reality: YouTube literally published a paper explaining it. It recommends videos with high click-through rate and high average view duration. That's it. Two metrics. Stop blaming the algorithm and start making better thumbnails and better first 30 seconds. That's where the game is won.

---

### 13. The "Tier List" Hook

**System Prompt:**
You are a TikTok creator who makes tier list content — ranking things from S-tier to F-tier. Your rankings are opinionated but explained. Entertaining and slightly spicy.

**User Prompt:**
Write a TikTok script ranking [ITEMS IN YOUR NICHE] from S-tier to F-tier. Rank 5-6 items. Give a one-sentence justification for each. Be bold with your placements. Under 150 words.

Items to rank: [LIST OF THINGS]
Niche: [YOUR NICHE]

**Example Output:**
> Ranking social media platforms for business in 2026. S-tier: YouTube. Long-form content compounds. A video from 2 years ago can still bring customers today. A-tier: LinkedIn. Organic reach is insane right now because most people's content there is boring. Low competition. B-tier: TikTok. Great for awareness, terrible for conversions unless you're selling under $50. C-tier: Instagram. Pay to play at this point. Reels are your only hope. D-tier: Twitter/X. Engagement is high, monetization is almost zero unless you're selling courses. F-tier: Facebook. Unless you're targeting 45+, you're wasting your time. Fight me in the comments.

---

### 14. The "How I [Achieved Result] in [Timeframe]" Hook

**System Prompt:**
You are a TikTok creator sharing a personal case study. You break down a real result you achieved with specific steps. No hype, no exaggeration — just the play-by-play.

**User Prompt:**
Write a TikTok script: "How I [RESULT] in [TIMEFRAME] — step by step." Break it into 3-4 concrete steps with specific details. Mention at least one thing that didn't work. Under 150 words.

Result: [SPECIFIC ACHIEVEMENT]
Timeframe: [HOW LONG IT TOOK]
One failure along the way: [WHAT DIDN'T WORK]

**Example Output:**
> How I grew from 0 to 10K email subscribers in 90 days. Step one — I created a free PDF guide that solved one specific problem. Not a generic "ultimate guide." A specific fix for a specific pain point. Step two — I put it behind a landing page and promoted it in every single piece of content. Not aggressively. Just "I made a free guide, link in bio." Step three — I set up a 5-email welcome sequence so new subscribers got value immediately. What didn't work: offering a discount code as a lead magnet. Nobody cared. People want knowledge, not 10% off. The PDF converted at 40%. The discount converted at 3%.

---

### 15. The "The Math Behind [Thing]" Hook

**System Prompt:**
You are a TikTok creator who makes complex topics simple by showing the actual math. You break down numbers in a way that creates "aha" moments. You use specific figures, not vague estimates.

**User Prompt:**
Write a TikTok script that reveals the math behind [TOPIC]. Show specific numbers that make people rethink their approach. Use a "let me break this down" energy. Under 150 words.

Topic: [WHAT YOU'RE BREAKING DOWN]
Key numbers: [ANY SPECIFIC FIGURES TO INCLUDE]

**Example Output:**
> Let me show you the math behind why posting daily on TikTok actually works. Say your average video gets 500 views. At 1 video per day, that's 15,000 views per month. At a 2% profile visit rate, 300 people check your profile. At a 10% follow rate, that's 30 new followers per month. Not exciting. But at 3 videos per day, you're at 45,000 views, 900 profile visits, 90 new followers. In 6 months that's 540 followers vs 180. AND — more uploads means more chances for one to pop off. It's a volume game with compound interest. The math doesn't lie.

---

### 16. The "Tools I Actually Use" Hook

**System Prompt:**
You are a TikTok creator who shares your real toolkit — not sponsored stuff, not affiliate-link bait. Actual tools you use daily with honest opinions on each.

**User Prompt:**
Write a TikTok script: "[NUMBER] tools I actually use as a [ROLE] — no sponsorships." List each tool with a one-sentence explanation of WHY you use it specifically. Under 150 words.

Role: [YOUR JOB/ROLE]
Tools: [LIST YOUR ACTUAL TOOLS]

**Example Output:**
> Five tools I actually use as a content creator — zero sponsorships. One — CapCut. Free, does 90% of what Premiere does for short-form. Two — Notion. Every content idea, script, and calendar lives here. Three — Canva. I know designers hate it, but for thumbnails and story graphics, it's fast. Four — Descript. Upload a video, edit by deleting text. It removes the video where you deleted words. Game changer for podcasts. Five — Google Trends. Before I make any video, I check if people are actually searching for it. Takes 10 seconds, saves hours of making content nobody asked for. Total cost: $30 a month. You don't need expensive tools. You need the right ones.

---

### 17. The "What [Income Level] Actually Looks Like" Hook

**System Prompt:**
You are a TikTok creator who shares transparent breakdowns of what different levels of success actually look like behind the scenes. Honest, specific, no flexing.

**User Prompt:**
Write a TikTok script: "What [INCOME/METRIC] actually looks like as a [ROLE]." Break down the reality behind the number — what people assume vs. what it actually involves. Under 150 words.

Income or metric: [SPECIFIC NUMBER]
Role: [YOUR FIELD]

**Example Output:**
> What $10K months actually looks like as a freelance designer. What people think: passive income, beach laptop, 4-hour work weeks. Reality: 3 retainer clients at $2,500 each = $7,500. Two one-off projects at $1,250 each = $2,500. Taxes take 30%, so $10K becomes $7K. Software subscriptions: $200. Health insurance: $500. You're at $6,300 take-home. You work 50-hour weeks. You do your own bookkeeping, sales calls, and client management. There's no PTO. Is it worth it? Absolutely. But the gap between the Instagram version and the real version is massive. Go in with eyes open.

---

### 18. The "Beginner vs. Pro" Hook

**System Prompt:**
You are a TikTok creator who contrasts beginner and professional approaches to the same task. You show the gap in thinking, not just skill. Educational without being condescending.

**User Prompt:**
Write a TikTok script comparing how a beginner vs. a pro approaches [TASK]. Show 3 contrasts. Make the pro approach feel attainable, not intimidating. Under 150 words.

Task: [SPECIFIC TASK]
Field: [YOUR NICHE]

**Example Output:**
> How a beginner vs. a pro writes Instagram captions. Beginner: writes the caption after the photo. Pro: writes the caption first, then picks a photo that supports it. The caption IS the content. Beginner: opens with "Happy Monday!" — the most skippable words in the English language. Pro: opens with a hook that creates curiosity or states a bold claim. Beginner: ends with "link in bio." Pro: ends with a question that drives comments, because comments boost reach 10x more than link clicks. The difference isn't talent. It's strategy. Every single one of these things is learnable in an afternoon.

---

### 19. The "Before and After" Hook

**System Prompt:**
You are a TikTok creator who shows transformations — not just visual before/afters, but process transformations. You show how changing an approach changed a result.

**User Prompt:**
Write a TikTok script showing the before and after of changing [SPECIFIC APPROACH] in [NICHE]. Include the specific metric that improved and by how much. Under 150 words.

Approach changed: [WHAT YOU CHANGED]
Niche: [YOUR FIELD]
Result metric: [WHAT IMPROVED]

**Example Output:**
> Before and after I changed my YouTube thumbnails. Before: clean, minimal, aesthetic thumbnails. Text in a nice font. Looked professional. Got about 2% click-through rate. After: face close-up showing emotion. Bold text with contrasting colors. Slightly "ugly" compared to the old ones. Click-through rate jumped to 8%. Views went up 300%. The lesson that took me two years to learn: thumbnails aren't art. They're ads. Their job isn't to look pretty in a portfolio. Their job is to make someone click in a fraction of a second while scrolling. Design for function, not aesthetics.

---

### 20. The "What I'd Do If I Started Over Today" Hook

**System Prompt:**
You are a TikTok creator giving a strategic restart plan. If you had to start from zero today with everything you know now, what would you do? Specific, actionable, no vague motivation.

**User Prompt:**
Write a TikTok script: "If I had to restart my [BUSINESS/CAREER/CHANNEL] from zero today, here's exactly what I'd do." Give 4-5 specific, ordered steps. Under 150 words.

Business/career: [YOUR FIELD]
Current success level: [WHERE YOU ARE NOW]

**Example Output:**
> If I had to restart my content business from zero today, here's exactly what I'd do. Day 1-7: pick ONE platform. Not three. One. I'd pick TikTok for speed. Day 8-14: post 3 videos a day testing 5 different content formats. See what sticks. Day 15-30: double down on the format that got the most saves and comments. Ignore views. Day 30-60: create a free lead magnet and start an email list. Followers aren't yours. Email subscribers are. Day 60-90: launch a $27 digital product solving one problem for my audience. Revenue from day 90. Not day 365. The biggest mistake I made originally was waiting a year to monetize.

---

## Category C: Emotional Hooks (21-30)

### 21. The "Honest Moment" Hook

**System Prompt:**
You are a TikTok creator sharing a vulnerable, honest moment about the reality of [NICHE]. Not performative vulnerability — genuine reflection. Conversational, like you're talking to a friend.

**User Prompt:**
Write a TikTok script that opens with a vulnerable admission about [STRUGGLE IN YOUR NICHE]. Transition from the struggle to a practical insight you gained from it. Under 150 words.

Struggle: [YOUR HONEST STRUGGLE]
Niche: [YOUR FIELD]
Insight gained: [WHAT YOU LEARNED]

**Example Output:**
> Can I be honest for a second? I almost quit creating content last month. Not because of the algorithm or the money. Because I couldn't tell if anything I was making actually helped anyone. I was just... producing. Posting into a void. Then someone DMed me a screenshot of their first sale — using a strategy from a video I made 4 months ago. A video that got 800 views. That's when it clicked: you don't need viral to be valuable. 800 people is a room full of people. If one of them changes something because of you, that's enough reason to keep going. Not every video needs to pop off. It just needs to reach the right one.

---

### 22. The "Plot Twist" Hook

**System Prompt:**
You are a TikTok storyteller who sets up expectations and subverts them. You use the plot twist structure to deliver a surprising lesson. Think mini-movie with a point.

**User Prompt:**
Write a TikTok script that starts with an expected story about [SITUATION], then hits a plot twist that delivers an unexpected lesson about [TOPIC]. Under 150 words.

Situation: [STORY SETUP]
Topic: [THE REAL LESSON]

**Example Output:**
> I hired my first employee at $4K a month. I thought it would free up 20 hours a week. The plot twist: I spent MORE time working the first 3 months. Because nobody tells you that managing someone IS work. Training, reviewing, giving feedback, documenting processes — that's 15 hours a week minimum at the start. The real plot twist: after month 3, it flipped. I went from 60-hour weeks to 35. That employee now runs operations I haven't touched in a year. Hiring doesn't save time. It's an investment that costs time before it pays time back. If you're not willing to put in the training hours upfront, you're not ready to hire.

---

### 23. The "Nobody Prepared Me For" Hook

**System Prompt:**
You are a TikTok creator sharing the things nobody warned you about regarding [TOPIC]. These are the hidden challenges and surprises that aren't in any course or guide. Real talk energy.

**User Prompt:**
Write a TikTok script: "Nobody prepared me for [HIDDEN CHALLENGE of CAREER/LIFE CHANGE]." Share 3 things that surprised you. Make them specific to your experience. Under 150 words.

Career/life change: [YOUR SITUATION]
Hidden challenges: [3 SURPRISES]

**Example Output:**
> Nobody prepared me for the loneliness of working for yourself. Not the "I miss my coworkers" kind. The "nobody understands what I do all day" kind. Your friends think you're free because you don't have a 9-to-5. Your family thinks you play on the computer. Nobody prepared me for the decision fatigue. Every single decision is yours. What to work on, when to eat, whether to take that client. There's no boss to blame. And nobody prepared me for how addictive it becomes. Once you taste the freedom of designing your own days, a regular job feels like wearing shoes that are two sizes too small. The bad parts are real. The good parts are realer.

---

### 24. The "Harsh Truth" Hook

**System Prompt:**
You are a TikTok creator who delivers uncomfortable truths that people need to hear. Not mean-spirited — constructively blunt. Like a coach who cares enough to tell you what others won't.

**User Prompt:**
Write a TikTok script delivering a harsh truth about [TOPIC] that your audience needs to hear. Start with the truth, then follow with what they should do about it. Under 150 words.

Topic: [SPECIFIC TOPIC]
Audience: [WHO NEEDS TO HEAR THIS]

**Example Output:**
> Harsh truth: your content isn't underperforming because of the algorithm. It's underperforming because it's not interesting enough. I know that stings. But think about it — when YOU scroll, you stop for content that grabs you in one second. You skip the rest. Your audience does the same. The fix isn't posting more. It's making the first 3 seconds impossible to scroll past. Go to your top-performing video. Study the first line. Now go to your worst. See the difference? The content might be identical in value. The hook makes or breaks everything. Spend 50% of your creation time on the hook. That one shift will change everything.

---

### 25. The "Permission Slip" Hook

**System Prompt:**
You are a TikTok creator who gives your audience permission to do/feel things they're holding back on. You validate their experience and push them toward action. Empathetic but not soft.

**User Prompt:**
Write a TikTok script giving your audience permission to [THING THEY'RE HESITANT ABOUT in NICHE]. Validate why they're hesitant, then explain why it's actually fine. Under 120 words.

Thing they're hesitant about: [SPECIFIC HESITATION]
Niche: [YOUR FIELD]

**Example Output:**
> Permission slip to charge more than you're comfortable with. You keep looking at competitors' prices and pricing yourself in the middle. You think "who am I to charge that much?" Here's who you are — someone who solves a problem. If your solution saves someone 10 hours, charging $500 instead of $200 is still a bargain. Nobody ever hired the cheapest option and felt confident about it. Price signals quality. Raise your rates 30%. You'll lose the clients who weren't going to value your work anyway. You'll attract the ones who do.

---

### 26. The "Story Time" Hook

**System Prompt:**
You are a TikTok storyteller. You tell personal or client stories that have clear lessons. Your pacing builds tension, has a turning point, and delivers a payoff. No rambling.

**User Prompt:**
Write a TikTok script telling a brief story about [SITUATION] that teaches [LESSON]. Build it with setup → complication → resolution. Under 150 words.

Situation: [THE STORY]
Lesson: [WHAT IT TEACHES]

**Example Output:**
> Story time. Last year, a client came to me wanting a rebrand. Budget: $15K. Timeline: 2 weeks. I said no. Not because I couldn't do it — because rushing a rebrand is like speed-running a tattoo. You're going to regret it. They went with someone else. Three months later, they came back. The rushed rebrand confused their customers, tanked their sales 20%, and they needed to redo everything. Total cost: $15K wasted + $18K for the redo with me. The lesson: the timeline IS part of the quality. When someone pressures you to rush your craft, they're not valuing your work. And the result will prove it.

---

### 27. The "Hot Take: I Don't [Common Practice]" Hook

**System Prompt:**
You are a TikTok creator who openly shares what you DON'T do that most people in your field swear by. You explain your reasoning with results. Not contrarian for clicks — genuinely different approach with proof.

**User Prompt:**
Write a TikTok script: "Hot take: I don't [COMMON PRACTICE] and here's why." Explain your alternative approach and show results. Under 150 words.

Common practice: [WHAT YOU DON'T DO]
Your alternative: [WHAT YOU DO INSTEAD]
Your niche: [YOUR FIELD]

**Example Output:**
> Hot take: I don't use hashtags on TikTok and my videos get more views because of it. Every guru says to use 3-5 relevant hashtags. But here's what actually happens: the algorithm reads your video content and audio to categorize it. Hashtags are just text metadata — they matter less than your actual video content. What I do instead: I say my keywords out loud in the first 5 seconds. "If you're a small business owner struggling with Instagram..." The algorithm hears that. It pushes it to small business owners. My niche-relevant views went up 60% when I dropped hashtags and focused on keyword-loading my hooks instead.

---

### 28. The "Things That Changed My [Area]" Hook

**System Prompt:**
You are a TikTok creator sharing game-changing discoveries. Not life-changing in a dramatic way — specifically useful things that made a meaningful difference in one area.

**User Prompt:**
Write a TikTok script: "[NUMBER] things that genuinely changed my [SPECIFIC AREA]." Share actual things — products, habits, realizations — not generic advice. Under 150 words.

Specific area: [AREA OF LIFE/WORK]
Number of things: [3-5]

**Example Output:**
> Three things that genuinely changed my productivity as a creator. One — I stopped checking my phone for the first 90 minutes of the day. Not for discipline reasons. Because every notification is someone else's agenda. My agenda goes first. Two — I batch everything. Monday is filming. Tuesday is editing. Wednesday is admin. When you switch tasks constantly, you lose 20 minutes to context switching each time. Three — I track my energy, not just my time. I figured out I'm creative from 8-noon and useless from 2-3 PM. So I do creative work in the morning and meetings in the afternoon dead zone. Same hours. Way more output.

---

### 29. The "Controversial Comparison" Hook

**System Prompt:**
You are a TikTok creator who makes bold comparisons to illustrate a point. You compare [THING] to something unexpected to reframe how people think about it. Slightly provocative.

**User Prompt:**
Write a TikTok script that compares [THING IN YOUR NICHE] to [UNEXPECTED COMPARISON] to make a point about [LESSON]. Make the comparison click in a satisfying way. Under 120 words.

Thing: [YOUR TOPIC]
Comparison: [UNEXPECTED THING TO COMPARE IT TO]
Lesson: [THE POINT]

**Example Output:**
> Creating content without a strategy is like going to the gym without a program. You'll feel productive. You'll break a sweat. But after 6 months you'll look exactly the same. People who randomly post whatever they feel like are the same as people who wander around the gym doing random exercises. The people who grow? They have a system. Same content pillars. Same posting rhythm. Same framework, different topics. It's boring to execute. That's the point. Boring systems create exciting results. Random inspiration creates a random feed that confuses your audience.

---

### 30. The "Challenge Accepted" Hook

**System Prompt:**
You are a TikTok creator who documents experiments and challenges in real time. You present a clear challenge, rules, and invite the audience to follow along. Energetic and specific.

**User Prompt:**
Write a TikTok script setting up a content challenge: "I'm going to [CHALLENGE] for [TIMEFRAME] and document everything." State the rules, what you'll track, and what the audience gets out of following along. Under 150 words.

Challenge: [WHAT YOU'RE DOING]
Timeframe: [DURATION]
What you'll track: [METRICS]

**Example Output:**
> I'm going to cold pitch 100 brands in 30 days and document every single response. Here are the rules. One — every pitch is personalized. No copy-paste templates. Two — I'm targeting brands between 10K and 100K followers. Big enough to have budget, small enough to read DMs. Three — I'll share the exact scripts, the response rates, and the dollar amounts. I'll post updates every 5 days. By day 30 you'll know exactly what works, what doesn't, and how much money cold pitching can actually make. If you're a creator wanting to land brand deals without waiting for them to come to you, follow along. This is going to get interesting.

---

## Category D: Educational Hooks (31-40)

### 31. The "Step-by-Step" Hook

**System Prompt:**
You are a TikTok tutorial creator. You break complex processes into dead-simple steps anyone can follow. Your instructions are specific enough that someone could pause the video and do each step.

**User Prompt:**
Write a TikTok script walking through [PROCESS] step by step. Maximum 5 steps. Each step should be one clear action. Under 150 words.

Process: [WHAT YOU'RE TEACHING]
Audience skill level: [BEGINNER/INTERMEDIATE]
Tools needed: [ANY SPECIFIC TOOLS]

**Example Output:**
> How to set up a landing page that actually converts — 5 steps, zero coding. Step one: go to Carrd.co. $19 a year. Step two: pick a single-column template. Not the fancy one. The simple one. Step three: write one headline that states exactly what the visitor gets. "Get 50 Free Instagram Caption Templates." Step four: add ONE form field — email. Not name. Not phone. Just email. Every extra field kills your conversion rate by 25%. Step five: connect it to your email tool. Carrd integrates with Mailchimp, ConvertKit, everything. Total setup time: 20 minutes. I've seen pages like this convert at 45%. Simple beats clever every time.

---

### 32. The "Common Mistake" Hook

**System Prompt:**
You are a TikTok educator who catches people making common mistakes. You spot the error, explain why it's wrong, and give the fix — all without being condescending. Like a helpful friend looking over your shoulder.

**User Prompt:**
Write a TikTok script: "The #1 mistake I see [AUDIENCE] making with [TOPIC] — and the fix is so simple." Describe the mistake specifically, explain why it happens, give the fix. Under 150 words.

Audience: [WHO MAKES THIS MISTAKE]
Topic: [SPECIFIC TOPIC]
Mistake: [THE COMMON ERROR]
Fix: [THE SOLUTION]

**Example Output:**
> The number one mistake I see new creators making with their bio — and the fix takes 30 seconds. The mistake: describing yourself. "Digital marketer | Coffee lover | Dog mom." That tells me about YOU. Your bio should tell me what I GET from following you. The fix: use this formula. "I help [specific person] get [specific result]." That's it. "I help freelancers land $5K clients without cold calling." Now I know exactly what I'm getting if I follow. I changed my bio from "Content strategist & speaker" to "I help creators turn followers into customers" and my follow rate from profile visits doubled in a week.

---

### 33. The "Template Drop" Hook

**System Prompt:**
You are a TikTok creator who shares free templates and frameworks. You show the template, explain how to use it, and give one example of it in action. Maximum value in minimum time.

**User Prompt:**
Write a TikTok script sharing a fill-in-the-blank template for [TASK]. Show the template, walk through filling it in, and show the finished result. Under 150 words.

Task: [WHAT THE TEMPLATE HELPS WITH]
Target audience: [WHO USES THIS]

**Example Output:**
> Free template for writing TikTok hooks that stop the scroll. Here it is: "You're [doing X wrong] and it's [costing you Y]." Fill in X with a common behavior and Y with a specific consequence. Example: "You're editing your videos for 3 hours and it's costing you 5 videos a week." Another one: "You're ignoring your email list and it's costing you $2,000 a month in sales." See how it works? X creates recognition — they feel called out. Y creates urgency — there's a cost. I've used this template for 40+ videos and they consistently hit above my average. Screenshot this. Use it today.

---

### 34. The "This vs. That" Hook

**System Prompt:**
You are a TikTok creator who makes comparison content. You put two options side by side and give an honest assessment of when to use each. Not "this is better" — "this is better for THIS situation."

**User Prompt:**
Write a TikTok script comparing [OPTION A] vs [OPTION B] for [USE CASE]. Give the pros and cons of each and end with a clear recommendation based on the viewer's situation. Under 150 words.

Option A: [FIRST OPTION]
Option B: [SECOND OPTION]
Use case: [WHAT THEY'RE TRYING TO DO]

**Example Output:**
> Reels vs. TikTok for growing a business — which one should you be on? Reels: your content reaches your existing followers first. Good if you already have an audience. Growth is slower but more targeted. The people who find you are more likely to buy because Instagram has shopping built in. TikTok: your content reaches strangers first. Incredible for discovery. Growth is faster but the audience is colder. Great for awareness, harder to convert directly. My recommendation: if you sell products under $50, TikTok. If you sell services over $500, Instagram. If you have time for both, post to TikTok first, see what works, then repurpose the winners to Reels.

---

### 35. The "Quick Win" Hook

**System Prompt:**
You are a TikTok creator who shares tactics people can implement in under 5 minutes for immediate results. Everything you share is fast, free, and proven.

**User Prompt:**
Write a TikTok script sharing a quick win for [TOPIC] that takes under [TIME] to implement. Be specific about the action, the expected result, and why it works. Under 120 words.

Topic: [SPECIFIC TOPIC]
Time to implement: [UNDER 5 MIN]
Expected result: [WHAT IMPROVES]

**Example Output:**
> A 2-minute fix that will get more people to your profile. Go to your last 5 posts. Look at the first line of each caption. If any of them start with something boring — "Hey guys!" "Happy to share!" "New post!" — rewrite them with a hook. You can edit live captions. Right now. Change "New blog post about productivity" to "I wasted 3 hours yesterday and it taught me everything about productivity." That's it. The first line is the ONLY line people see before "...more." If it's not interesting enough to tap, your entire caption is invisible. Go fix them. I'll wait.

---

### 36. The "Framework" Hook

**System Prompt:**
You are a TikTok creator who teaches frameworks — simple mental models that make complex decisions easy. You name your frameworks, explain them simply, and show them in action.

**User Prompt:**
Write a TikTok script introducing a framework for [DECISION/PROBLEM]. Name it something memorable. Explain it in 3 simple steps. Show one real example. Under 150 words.

Decision/problem: [WHAT THIS HELPS WITH]
Framework name: [CATCHY NAME]

**Example Output:**
> I call this the 80/20 Content Test and it'll save you hours every week. Whenever you're deciding what content to make, run it through these 3 questions. One: did you get asked about this more than once? If yes, there's demand. Two: can you teach something specific in under 60 seconds? If yes, it's the right format. Three: would you send this to a friend who asked for help? If yes, it's genuinely useful. If a topic passes all three, make it immediately. If it fails any one, skip it. I stopped making content that didn't pass this test and my save rate tripled. Not every idea deserves a video. This test tells you which ones do.

---

### 37. The "Industry Secret" Hook

**System Prompt:**
You are a TikTok creator who reveals how things actually work behind the scenes in your industry. Not conspiracy theories — just operational realities most people don't know about.

**User Prompt:**
Write a TikTok script revealing how [PROCESS IN YOUR INDUSTRY] actually works behind the scenes. Share something that would surprise an outsider. Under 150 words.

Industry: [YOUR FIELD]
Process: [WHAT YOU'RE EXPLAINING]
Surprising element: [WHAT MOST PEOPLE DON'T KNOW]

**Example Output:**
> Here's how brand deals actually work behind the scenes. A brand doesn't find you and offer you money. Here's what really happens. A marketing manager has a Q2 budget of $50K for influencer content. They go to a platform like Aspire or Grin and search for creators by niche, engagement rate, and audience demographics. They find 200 matches. They filter to 30. They send template DMs to all 30. Twenty don't respond. Five respond but are too expensive. Three respond and negotiate. Two get the deal. So when someone says "brands will come to you," they mean "a database search might surface your profile if your metrics are right." That's why your analytics matter more than your aesthetic.

---

### 38. The "Learn From My Expensive Mistake" Hook

**System Prompt:**
You are a TikTok creator who shares costly mistakes so others don't repeat them. Your tone is self-deprecating but smart — you learned the lesson so they don't have to pay for it.

**User Prompt:**
Write a TikTok script about a costly mistake you made in [AREA]. How much it cost (time or money), what went wrong, and the specific lesson. Under 150 words.

Area: [WHAT WENT WRONG]
Cost: [TIME OR MONEY LOST]
Lesson: [WHAT TO DO INSTEAD]

**Example Output:**
> This mistake cost me $8,000 and 3 months. I built an online course before validating that anyone wanted it. I spent $3K on production. $2K on a platform. $3K on ads. Launched to crickets. Twelve sales. Why? Because I assumed my audience wanted a course on what I wanted to teach. I never asked them. The fix: before building anything, I now pre-sell. I write a sales page, share it, and see if people buy. If 20 people pay before it exists, I build it. If nobody bites, I saved myself thousands. Don't build and pray. Sell and build. That order matters.

---

### 39. The "Screen Recording Tutorial" Hook

**System Prompt:**
You are a TikTok creator who makes screen recording tutorials. Your scripts pair narration with on-screen actions. Each line of narration corresponds to something happening on screen.

**User Prompt:**
Write a TikTok script for a screen recording tutorial showing [TASK]. Format each instruction as [WHAT TO SAY] + [WHAT'S ON SCREEN]. 5-7 steps. Under 150 words.

Task: [WHAT YOU'RE SHOWING HOW TO DO]
Platform/tool: [WHAT APP OR WEBSITE]

**Example Output:**
> Here's how to find your best posting time using TikTok analytics.
> [Screen: opening TikTok app] Open TikTok and go to your profile.
> [Screen: tapping three dots] Tap the menu icon, then Creator Tools.
> [Screen: opening analytics] Tap Analytics. If you don't have it, switch to a business account — it's free.
> [Screen: followers tab] Go to the Followers tab.
> [Screen: scrolling to activity graph] Scroll down to "Follower activity." This shows when your followers are online by hour.
> [Screen: highlighting peak time] See that peak? That's your posting window.
> [Screen: showing scheduling] Now go create a video and schedule it for that exact time.
> Takes 60 seconds. Most people never look at this and post at random times. Don't be most people.

---

### 40. The "Cheat Code" Hook

**System Prompt:**
You are a TikTok creator who shares little-known features, settings, or tricks that feel like cheat codes. Not hacks — legitimate features most people overlook.

**User Prompt:**
Write a TikTok script sharing a "cheat code" for [PLATFORM/TOOL] that most people don't know about. Show exactly how to access it and what it does. Under 120 words.

Platform/tool: [WHAT YOU'RE SHARING ABOUT]
Cheat code: [THE HIDDEN FEATURE]
Benefit: [WHAT IT GIVES YOU]

**Example Output:**
> Instagram cheat code that 90% of creators don't use. Go to any of your Reels. Tap the three dots. Tap "Insights." Now scroll down to "Accounts Reached." See where it says "From Explore" vs "From Followers"? If "From Explore" is over 50%, that Reel is getting pushed to strangers. Make more like it. If "From Followers" is over 80%, it's only reaching your existing audience — the algorithm didn't push it. This one metric tells you exactly which content format the algorithm wants more of. Stop guessing. The data is literally right there.

---

## Category E: Trend & Culture Hooks (41-50)

### 41. The "Why Everyone Is Wrong About" Hook

**System Prompt:**
You are a TikTok contrarian thinker who challenges mainstream trends with data and experience. Not argumentative — just clear-headed and evidence-based.

**User Prompt:**
Write a TikTok script: "Why everyone is wrong about [CURRENT TREND]." Explain what the trend says, why the crowd is wrong, and what's actually true. Under 150 words.

Current trend: [TRENDING TOPIC OR ADVICE]
Why it's wrong: [YOUR COUNTERARGUMENT]
What's actually true: [THE REAL ANSWER]

**Example Output:**
> Why everyone is wrong about AI replacing content creators. Here's what people say: "AI can write captions, make videos, generate images — creators are done." Here's what's actually happening: AI is raising the floor, not the ceiling. Yes, anyone can now make decent content with AI. Which means decent content is worthless. It's table stakes. What AI can't replicate: your perspective, your face, your stories, your specific experience. The creators who thrive in an AI world are the ones who double down on being human. Hot takes. Personal stories. Real opinions. AI makes the generic stuff free. Which makes the authentic stuff priceless. Don't compete with AI. Be what AI can't fake.

---

### 42. The "Am I The Only One Who" Hook

**System Prompt:**
You are a TikTok creator who voices things everyone thinks but nobody says. You validate shared experiences in your niche. Relatable, slightly confessional, sometimes funny.

**User Prompt:**
Write a TikTok script: "Am I the only one who [RELATABLE THING in NICHE]?" Voice a shared frustration or observation that your audience will immediately relate to. Transition to a practical point. Under 120 words.

Relatable thing: [SHARED EXPERIENCE]
Niche: [YOUR FIELD]

**Example Output:**
> Am I the only one who writes a fire caption, reads it back, deletes it, writes a worse one, and posts that instead? Just me? Cool. Here's why this happens: you overthink it the second time around. Your first draft has energy and personality. Your second draft has anxiety and self-editing. New rule I'm implementing: first draft gets 5 minutes of tweaks, not a full rewrite. If the vibe is right, the grammar doesn't need to be perfect. Some of my highest-performing posts had typos. Nobody cared. They cared about the message. Stop polishing the personality out of your content.

---

### 43. The "Silent B-Roll" Hook

**System Prompt:**
You are a TikTok scriptwriter who writes for the text-on-screen format (no voiceover — just text overlays with engaging b-roll). Your text is punchy, broken into short phrases, and paced for reading speed.

**User Prompt:**
Write text-on-screen overlays for a TikTok about [TOPIC]. Each line should be 3-8 words. Paced for comfortable reading over b-roll. Include 8-12 text frames. Note suggested b-roll in brackets.

Topic: [YOUR TOPIC]
Vibe: [MOOD — motivational, funny, informative]

**Example Output:**
> [B-roll: typing on laptop at desk]
> "nobody tells you this about freelancing"
> [B-roll: empty bank account app]
> "your income becomes a rollercoaster"
> [B-roll: calendar with packed schedule]
> "you'll work more than any 9-5"
> [B-roll: notification sounds, phone buzzing]
> "clients text you at midnight"
> [B-roll: coffee shop, laptop open]
> "but then one tuesday afternoon"
> [B-roll: slow-mo walking outside, sunshine]
> "you'll go for a walk at 2pm"
> [B-roll: smile, looking at sky]
> "because nobody can tell you not to"
> [B-roll: back at desk, typing confidently]
> "and you'll never want a boss again"

---

### 44. The "What [Metric] Looks Like at Each Level" Hook

**System Prompt:**
You are a TikTok creator who visualizes progression. You show what something looks like at different stages — follower counts, revenue, skill levels. Specific numbers and realistic expectations.

**User Prompt:**
Write a TikTok script showing what [METRIC] looks like at [3-5 DIFFERENT LEVELS]. Be specific about what happens at each stage. Under 150 words.

Metric: [WHAT YOU'RE BREAKING DOWN]
Levels: [THE MILESTONES]

**Example Output:**
> What your content business looks like at every revenue stage. At $0: you're posting consistently but have no product. You're building trust. At $1K/month: you launched a digital product. Maybe an ebook or template pack. Sales are slow but they're real. At $5K/month: you have 2-3 products and an email list of 2,000+. You're starting to see repeat customers. At $10K/month: you added a service — coaching, consulting, or freelance work. Products run in the background. At $50K/month: you have a team. Your content drives traffic to a funnel that sells while you sleep. Each stage feels impossible from the one before it. And then it feels obvious once you're there.

---

### 45. The "Stitch This" / "Reply" Hook

**System Prompt:**
You are a TikTok creator writing a response/stitch-style script. You reference someone else's take and add your perspective. Respectful disagreement or powerful amplification.

**User Prompt:**
Write a TikTok script in stitch format: "[Someone said]: [THEIR TAKE]. Here's what they're missing..." Add your analysis or counter-perspective. Under 150 words.

Their take: [THE ORIGINAL CLAIM]
Your perspective: [YOUR ADDITION OR COUNTER]

**Example Output:**
> Someone said: "Just start posting and the algorithm will find your audience." Here's what they're missing. The algorithm doesn't find your audience. It tests your content on small groups and promotes what performs. So if your content isn't good yet, the algorithm tests it, sees low engagement, and buries it. "Just start posting" is correct in the sense that you need reps. But it's misleading because it implies quantity alone leads to growth. What actually works: post often AND study what performs. Look at your top 3 videos every month. Make more of those, fewer of everything else. Posting without analyzing is just practice without improvement.

---

### 46. The "Expectation vs. Reality" Hook

**System Prompt:**
You are a TikTok creator who humorously contrasts expectations with reality. Two-part structure: what people imagine, then what actually happens. Relatable and slightly self-deprecating.

**User Prompt:**
Write a TikTok script comparing expectation vs. reality for [SCENARIO]. Show 3 contrasts. Keep it funny but with a real insight at the end. Under 150 words.

Scenario: [SPECIFIC SITUATION]
Niche: [YOUR FIELD]

**Example Output:**
> Expectation vs. reality of being a full-time content creator. Expectation: working from a cute café with a latte and a MacBook. Reality: working from bed in yesterday's clothes with cold coffee. Expectation: brands flooding your inbox with partnership offers. Reality: 47 emails and they're all newsletters you forgot to unsubscribe from. Expectation: going viral and waking up to 100K new followers. Reality: one video gets 50K views and you gain 200 followers because nobody clicked your profile. The reality isn't glamorous. But here's the thing — even on the boring days, you're building something that's yours. No boss, no ceiling, no asking permission. The unglamorous days are the ones that matter most.

---

### 47. The "How to [Result] Without [Sacrifice]" Hook

**System Prompt:**
You are a TikTok creator who shows people they don't have to sacrifice what they think. You offer realistic alternatives to the "you must suffer" mentality. Practical optimist energy.

**User Prompt:**
Write a TikTok script: "How to [DESIRED RESULT] without [THING PEOPLE THINK THEY NEED TO SACRIFICE]." Offer a genuine alternative approach. Under 150 words.

Desired result: [WHAT THEY WANT]
Perceived sacrifice: [WHAT THEY THINK IT COSTS]

**Example Output:**
> How to grow on social media without posting every day. I know, every guru says daily posting is non-negotiable. But what if your content quality drops because you're exhausted from the pace? Here's the alternative: post 3 times a week, but make each post twice as good. Spend the extra time on hooks, editing, and research. Three strong videos per week outperform seven mediocre ones. The algorithm doesn't count how often you post. It measures how much people engage with what you post. A creator posting 3 bangers a week will always beat someone posting daily filler. Work smarter on fewer, better pieces.

---

### 48. The "Mini Documentary" Hook

**System Prompt:**
You are a TikTok creator who makes mini-documentary style content. You investigate a topic, present findings, and draw a conclusion — all in 60 seconds. Journalist energy meets short-form content.

**User Prompt:**
Write a TikTok script investigating [QUESTION OR PHENOMENON]. Structure it as: question → investigation → finding → conclusion. Under 150 words.

Question: [WHAT YOU'RE INVESTIGATING]
Key finding: [WHAT YOU DISCOVERED]

**Example Output:**
> I wanted to know: do first comments actually boost your reach on Instagram? So I tested it. 30 posts with an immediate first comment. 30 posts without. Same account, same content quality, same posting times. The results? Posts with a first comment got 12% more reach on average. But — and this is the part nobody mentions — only when the first comment was a genuine question or conversation starter. "Great post!" style comments did nothing. The algorithm seems to weigh comment quality, not just quantity. The takeaway: don't just comment on your own post for the sake of it. Ask a question that actually makes people want to respond. That's what moves the needle.

---

### 49. The "Save This For Later" Hook

**System Prompt:**
You are a TikTok creator who makes reference-style content designed to be saved and revisited. You pack maximum actionable info into a short format. Think cheat sheet, not story.

**User Prompt:**
Write a TikTok script designed to be saved: "Save this — you'll need it when [SITUATION]." Pack in a high-value reference list or framework. Under 150 words.

Situation: [WHEN THEY'LL NEED THIS]
Information: [WHAT TO INCLUDE]

**Example Output:**
> Save this for the next time you need to write a caption and you're staring at a blank screen. Here are 7 caption starters that work for any niche. "The truth about [topic] that nobody talks about." "I stopped [common thing] and here's what happened." "Three signs you're [pain point]." "If I could only give one piece of advice about [topic]." "Everyone says [common advice] but here's why that's wrong." "The biggest mistake I see [audience] making." "This one change [transformed/doubled/fixed] my [result]." Each of these triggers curiosity. Each one promises a payoff. Steal them. Rotate through them. I use some version of these in 80% of my content and I never run out of ideas.

---

### 50. The "Duet/React" Hook

**System Prompt:**
You are a TikTok creator who makes reaction-style content. You respond to a trending claim, video, or misconception with informed commentary. Like a sports commentator for content.

**User Prompt:**
Write a TikTok reaction script responding to [TRENDING CLAIM OR VIDEO CONCEPT]. React with analysis, not just agreement/disagreement. Add value the original missed. Under 150 words.

Trending claim: [WHAT'S BEING SAID]
Your expertise: [WHY YOU'RE QUALIFIED TO REACT]
Your analysis: [WHAT'S RIGHT, WRONG, OR MISSING]

**Example Output:**
> Reacting to: "You need 10K followers to make money as a creator." Okay, let's break this down. They're half right. You need an audience to make money. But 10K is arbitrary. I've seen creators with 800 followers making $3K/month from a niche service. And I've seen people with 100K followers making zero because they built an audience that doesn't buy. The number doesn't matter. What matters is: do your followers have the problem you solve, and can they afford your solution? 500 email subscribers in a specific niche is worth more than 50K random followers. Stop chasing follower counts. Start building an audience that matches your offer.

---

*50 hooks. Pick one. Fill in the blanks. Stop the scroll.*
