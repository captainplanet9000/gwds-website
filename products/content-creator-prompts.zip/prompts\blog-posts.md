# Blog Post Outlines & Writing Prompts

30 blog post frameworks with system prompts, user prompts, and example outputs. Covers SEO-driven content, thought leadership, tutorials, and list posts.

---

## SEO-Driven Posts (1-10)

### 1. The "Ultimate Guide" Post

**System Prompt:**
You are a blog content strategist who writes comprehensive guides that rank on Google. You structure posts with clear H2s and H3s, include relevant keywords naturally, and make every section independently valuable. You write in a conversational but authoritative tone.

**User Prompt:**
Write a blog post outline for "The Ultimate Guide to [TOPIC]." Include: title (with target keyword), meta description (155 chars), 8-10 H2 sections, 2-3 H3s under each H2, and a brief description of what each section covers. Target keyword: [KEYWORD].

Topic: [YOUR TOPIC]
Target keyword: [PRIMARY KEYWORD]
Target audience: [WHO READS THIS]
Word count target: [2000-5000]

**Example Output:**
> **Title:** The Ultimate Guide to Email Marketing for Small Businesses (2026)
> **Meta:** Learn email marketing from scratch. Covers list building, automation, copywriting, and revenue strategies for small businesses.
>
> **H2: What Is Email Marketing (And Why It Still Works)**
> - H3: Email vs. Social Media: The ROI Comparison
> - H3: Email Marketing Stats That Matter in 2026
> [Establish credibility, show data proving email isn't dead]
>
> **H2: Building Your Email List from Zero**
> - H3: Lead Magnet Ideas That Actually Convert
> - H3: Opt-in Form Placement Strategy
> - H3: Growing Your List Without Paid Ads
> [Tactical list-building strategies]
>
> **H2: Choosing an Email Platform**
> - H3: Free Options (Mailchimp, Beehiiv, MailerLite)
> - H3: Paid Options (ConvertKit, ActiveCampaign)
> [Comparison table with features and pricing]
>
> [Continue for 6-8 more H2 sections covering writing, automation, analytics, monetization...]

---

### 2. The "How To" Tutorial Post

**System Prompt:**
You are a technical blog writer who creates step-by-step tutorials. Every step includes what to do, why to do it, and a screenshot/example description. You anticipate common mistakes and address them proactively.

**User Prompt:**
Write a blog post outline for "How to [TASK] in [TIMEFRAME]: Step-by-Step." Include: title, meta description, prerequisite section, numbered steps (8-12), common mistakes section, FAQ section, and conclusion with next steps.

Task: [WHAT THEY'LL LEARN]
Timeframe: [HOW LONG IT TAKES]
Skill level: [BEGINNER/INTERMEDIATE]

**Example Output:**
> **Title:** How to Set Up Google Analytics 4 in 15 Minutes: Step-by-Step Guide
> **Meta:** Set up GA4 on your website today. This step-by-step guide walks you through setup, event tracking, and your first custom report.
>
> **Prerequisites:** Google account, website with admin access, 15 minutes
>
> **Step 1:** Create a GA4 Property [what to click, where to go]
> **Step 2:** Install the Tracking Code [3 methods: manual, GTM, plugin]
> **Step 3:** Verify Data Is Flowing [how to check real-time reports]
> **Step 4:** Set Up Key Events [which events to track for different business types]
> [Continue for 8-12 steps]
>
> **Common Mistakes:** Duplicate tracking codes, not filtering internal traffic, ignoring event setup
> **FAQ:** 5 common questions with concise answers
> **Next Steps:** Link to advanced GA4 tutorial

---

### 3. The "Best [Things] for [Goal]" Listicle

**System Prompt:**
You are a blog writer who creates list posts that actually help people decide. Not just descriptions — pros, cons, pricing, and a clear "best for" verdict per item. No filler items to pad the list.

**User Prompt:**
Write a blog post outline for "The [NUMBER] Best [THINGS] for [GOAL] in [YEAR]." Include: title, meta description, a "How We Tested/Evaluated" section, each item with pros/cons/pricing/verdict, and a comparison table summary.

Things: [WHAT YOU'RE LISTING]
Goal: [WHO THESE ARE FOR]
Number: [HOW MANY]

**Example Output:**
> **Title:** The 9 Best Project Management Tools for Freelancers in 2026
> **Meta:** Tested 20+ project management tools. These 9 are the best for freelancers — covers free options, pricing, and which is best for your workflow.
>
> **Evaluation Criteria:** Ease of use, price, client collaboration features, mobile app quality
>
> **#1 Notion** — Best Overall
> Pros: infinitely customizable, free tier is generous
> Cons: learning curve, can feel overwhelming
> Price: Free / $10/mo
> Best for: freelancers who want everything in one tool
>
> [Continue for all 9]
>
> **Comparison Table:** All 9 tools with ratings on each criterion
> **Our Pick:** Notion for solo freelancers, Asana for freelancers with teams

---

### 4. The "[Topic] vs [Topic]" Comparison Post

**System Prompt:**
You write comparison blog posts that help readers make informed decisions. You define clear comparison criteria, present both options fairly, and give situational recommendations.

**User Prompt:**
Write a blog outline for "[OPTION A] vs [OPTION B]: Which Is Better for [USE CASE]?" Include: title, meta, quick answer box, 5-6 comparison criteria with sections for each, pricing comparison, and final verdict.

Option A: [FIRST OPTION]
Option B: [SECOND OPTION]
Use case: [READER'S GOAL]

**Example Output:**
> **Title:** WordPress vs Webflow: Which Is Better for Small Business Websites?
> **Meta:** WordPress vs Webflow — we compare pricing, ease of use, SEO, customization, and scalability for small business sites.
>
> **Quick Answer:** WordPress for content-heavy sites and full control. Webflow for design-first sites without coding.
>
> **Criterion 1: Ease of Use** [detailed comparison]
> **Criterion 2: Design Flexibility** [detailed comparison]
> **Criterion 3: SEO Capabilities** [detailed comparison]
> **Criterion 4: Pricing** [total cost analysis]
> **Criterion 5: Scalability** [what happens as you grow]
>
> **Verdict:** Choose WordPress if [criteria]. Choose Webflow if [criteria].

---

### 5. The "Mistakes to Avoid" Post

**System Prompt:**
You write "mistakes" posts that rank for "[topic] mistakes" keywords. Each mistake is a specific, common error — not generic warnings. You include the fix alongside each mistake.

**User Prompt:**
Write a blog outline for "[NUMBER] [TOPIC] Mistakes That Are Costing You [CONSEQUENCE]." Include: title, meta, each mistake as an H2 with: what the mistake is, why people make it, real example, and the fix.

Topic: [YOUR TOPIC]
Number of mistakes: [HOW MANY]
Consequence: [WHAT THEY'RE LOSING]

**Example Output:**
> **Title:** 11 Email Marketing Mistakes That Are Killing Your Open Rates
> **Meta:** Struggling with email open rates? You're probably making these 11 common mistakes. Here's what they are and how to fix each one.
>
> **Mistake 1: Sending Without Segmenting**
> - What it is: blasting the same email to your entire list
> - Why people do it: it's faster
> - Impact: unsegmented emails get 14% lower open rates
> - Fix: create 3-5 segments based on behavior or interest
>
> [Continue for all 11 mistakes with the same structure]

---

### 6. The "Beginner's Guide" Post

**System Prompt:**
You write beginner guides that assume zero prior knowledge. You define every term, explain every concept, and build understanding sequentially. No jargon without explanation.

**User Prompt:**
Write a blog outline for "[TOPIC] for Beginners: Everything You Need to Know." Include: title, meta, "What is [Topic]" section, key terms glossary, step-by-step getting started section, common questions, and recommended resources.

Topic: [YOUR TOPIC]
Target reader: [COMPLETE BEGINNER IN WHAT CONTEXT]

**Example Output:**
> **Title:** SEO for Beginners: Everything You Need to Know to Start Ranking
> **Meta:** New to SEO? This beginner's guide covers keywords, on-page optimization, backlinks, and tools — everything you need to start ranking on Google.
>
> **What Is SEO?** [plain-English explanation]
> **Key Terms:** keywords, SERP, backlinks, domain authority, meta description [definitions]
> **Getting Started (Step by Step):**
> - Step 1: Install Google Search Console
> - Step 2: Do your first keyword research
> - Step 3: Optimize one existing page
> [Continue for 8-10 steps]
> **Common Questions:** 8-10 FAQ with concise answers
> **Recommended Tools:** Free and paid options with links

---

### 7. The "Case Study" Post

**System Prompt:**
You write case study blog posts that tell a story with data. You structure them as: situation → action → result → lessons. Every claim is backed by a specific number.

**User Prompt:**
Write a blog outline for "How [SUBJECT] Achieved [RESULT]: A Case Study." Include: title, meta, background section, the challenge, the strategy (detailed), results with data, key takeaways, and how the reader can apply this.

Subject: [WHO/WHAT THE CASE STUDY IS ABOUT]
Result: [WHAT THEY ACHIEVED]
Strategy: [WHAT THEY DID]

**Example Output:**
> **Title:** How a Solo Creator Built a $20K/Month Newsletter in 9 Months: Case Study
> **Meta:** Detailed case study of how one creator grew from 0 to 15K subscribers and $20K/month in newsletter revenue. Full strategy breakdown.
>
> **Background:** Who they are, what they were doing before
> **The Challenge:** No audience, no email list, competitive niche
> **The Strategy:**
> - Phase 1: Twitter growth for discovery (months 1-3)
> - Phase 2: Free newsletter launch (month 3)
> - Phase 3: Paid tier introduction (month 6)
> - Phase 4: Sponsorship outreach (month 8)
> **Results:** 15K subscribers, 42% open rate, $20K/month breakdown
> **Key Takeaways:** 5 lessons any creator can apply
> **Reader Action Items:** 3 things to do this week

---

### 8. The "Year in Review" Post

**System Prompt:**
You write transparent year-in-review posts. Revenue numbers, what worked, what failed, and plans for next year. Readers love these because they're rare honest looks behind the curtain.

**User Prompt:**
Write a blog outline for "[YEAR] Year in Review: What Worked, What Didn't, and What's Next." Include: title, meta, goals recap, revenue breakdown, top wins, biggest failures, key lessons, and next year's goals.

Year: [WHICH YEAR]
Business type: [WHAT YOU DO]

**Example Output:**
> **Title:** 2025 Year in Review: $127K Revenue, 3 Big Wins, and 2 Expensive Mistakes
> **Meta:** Full transparent review of 2025 — revenue breakdown, what strategies worked, what failed, and what I'm changing for 2026.
>
> **Goals I Set:** [list with ✅/❌ status]
> **Revenue Breakdown:** Pie chart of income sources with exact numbers
> **Top 3 Wins:** Each with context and what made it work
> **Top 2 Failures:** Each with cost (time/money) and what you learned
> **Key Lessons:** 5 distilled insights
> **2026 Goals:** Specific, measurable targets

---

### 9. The "Resource Roundup" Post

**System Prompt:**
You write resource roundup posts that become bookmarks. Every resource is vetted with a brief annotation explaining why it's worth someone's time.

**User Prompt:**
Write a blog outline for "[NUMBER] [RESOURCES] Every [PERSON] Should Know About." Include: title, meta, resources organized by category, each with name, link description, and one-sentence annotation.

Resources: [TYPE OF RESOURCES]
Person: [TARGET READER]

**Example Output:**
> **Title:** 47 Free Resources Every Freelance Writer Should Bookmark
> **Meta:** 47 free tools, templates, communities, and guides for freelance writers. Organized by category. All vetted and actively maintained.
>
> **Writing Tools (8 resources)**
> **Grammar & Editing (6 resources)**
> **Finding Clients (9 resources)**
> **Contracts & Legal (5 resources)**
> **Learning & Development (7 resources)**
> **Communities (6 resources)**
> **Templates (6 resources)**
>
> [Each with: name, URL placeholder, and why it's useful]

---

### 10. The "Data-Driven" Post

**System Prompt:**
You write blog posts that present original data or analysis. You state your methodology, present findings clearly, and draw actionable conclusions. Charts and tables are suggested throughout.

**User Prompt:**
Write a blog outline for "We Analyzed [NUMBER] [THINGS]: Here's What We Found About [TOPIC]." Include: title, meta, methodology section, 5-7 key findings, each with data and implication, and conclusion.

Things analyzed: [WHAT YOU STUDIED]
Topic: [WHAT YOU DISCOVERED]
Key findings: [MAIN RESULTS]

**Example Output:**
> **Title:** We Analyzed 1,000 Viral LinkedIn Posts: Here's What They Have in Common
> **Meta:** Analysis of 1,000 LinkedIn posts with 10K+ likes. We found patterns in format, length, topic, and posting time.
>
> **Methodology:** How we collected data, time period, criteria for "viral"
> **Finding 1:** Posts with a personal story in the first line got 3x more engagement [data table]
> **Finding 2:** Optimal length was 150-200 words — not long-form [chart]
> **Finding 3:** Posts published Tuesday-Thursday 8-10 AM EST outperformed [chart]
> [Continue for 5-7 findings]
> **Conclusion:** Actionable summary of what to do based on findings

---

## Thought Leadership Posts (11-20)

### 11. The "Contrarian" Post

**System Prompt:**
You write opinion posts that challenge industry consensus. You state the popular belief, your counter-position, and support it with reasoning and evidence. Respectful disagreement, not rage-bait.

**User Prompt:**
Write a blog outline for "Why [POPULAR ADVICE] Is Wrong (And What to Do Instead)." Include: title, meta, the popular advice explained, why people believe it, your counter-argument with evidence, what to do instead, and when the popular advice IS right.

Popular advice: [WHAT EVERYONE SAYS]
Your counter: [WHY IT'S WRONG]

**Example Output:**
> **Title:** Why "Niche Down" Is Bad Advice for Most Creators
> **Meta:** Everyone says to niche down. Here's why that advice is killing small creators — and what actually works for growth.
>
> **The Advice Everyone Gives:** Explanation of "niche down" orthodoxy
> **Why People Believe It:** It works for businesses, so creators assume it works for them
> **The Problem:** Data showing broad personal brands outgrowing niche accounts
> **What to Do Instead:** The "niche of one" approach — your personality as the niche
> **When Niching Down IS Right:** Faceless accounts, B2B content, info products

---

### 12. The "Lessons From" Post

**System Prompt:**
You write analytical posts that extract business/career lessons from unexpected sources — books, sports, historical events, personal experiences.

**User Prompt:**
Write a blog outline for "[NUMBER] Lessons I Learned from [UNEXPECTED SOURCE] That Changed My [AREA]." Include: title, meta, brief context about the source, each lesson with the original insight and your application.

Source: [WHERE THE LESSONS COME FROM]
Area: [WHAT THEY CHANGED]

**Example Output:**
> **Title:** 7 Lessons I Learned from Running Marathons That Made Me a Better Entrepreneur
> **Meta:** What training for marathons taught me about business. Seven transferable lessons about pacing, pain, and playing the long game.
>
> **Lesson 1: The Wall Is Mental** — Mile 20 analogy → business year 2
> **Lesson 2: Pacing Beats Speed** — Starting slow → sustainable growth
> **Lesson 3: Nutrition Is Infrastructure** — Fueling the body → investing in systems
> [Continue for 7 lessons]

---

### 13. The "State of [Industry]" Post

**System Prompt:**
You write industry analysis posts that position you as a thought leader. You assess current trends, identify shifts, and make predictions. Data-backed where possible.

**User Prompt:**
Write a blog outline for "The State of [INDUSTRY] in [YEAR]: What's Changed, What's Next." Include: title, meta, 3 things that changed this year, 3 trends to watch, 2 predictions, and what it means for the reader.

Industry: [YOUR FIELD]
Year: [WHICH YEAR]

**Example Output:**
> **Title:** The State of Content Marketing in 2026: What's Changed and What's Next
> **Meta:** Analysis of major content marketing shifts in 2026 — AI impact, platform changes, and emerging strategies.
>
> **What Changed This Year:**
> - AI-generated content became table stakes
> - Short-form video overtook blog traffic for B2C
> - Email list size became the key metric for brand valuation
>
> **Trends to Watch:**
> - Community-led content strategies
> - AI-assisted personalization at scale
> - Creator-brand partnerships replacing traditional advertising
>
> **Predictions:** 2 specific, time-bound predictions
> **What This Means for You:** Actionable recommendations based on the analysis

---

### 14. The "Playbook" Post

**System Prompt:**
You write comprehensive playbook posts — complete strategies someone could implement end-to-end. More detailed than a how-to, more actionable than a think piece.

**User Prompt:**
Write a blog outline for "The [TOPIC] Playbook: A Complete Strategy for [GOAL]." Include: title, meta, overview, phase-by-phase strategy (3-4 phases), tools needed, timeline, budget, and expected results.

Topic: [STRATEGY AREA]
Goal: [WHAT THEY'LL ACHIEVE]

**Example Output:**
> **Title:** The Cold Email Playbook: How to Land Clients Without a Network
> **Meta:** Complete cold email strategy for freelancers and agencies. Covers research, templates, follow-ups, and scaling — with exact scripts.
>
> **Phase 1: Research & List Building** (Week 1)
> **Phase 2: Crafting the Outreach** (Week 2) [includes 3 email templates]
> **Phase 3: Follow-Up Sequence** (Weeks 3-4) [includes timing and templates]
> **Phase 4: Scaling & Optimizing** (Month 2+) [includes metrics to track]
> **Tools:** List of free/paid tools for each phase
> **Timeline:** Realistic expectations per month
> **Expected Results:** Based on industry averages

---

### 15-20. Additional Blog Frameworks

### 15. The "Behind the Numbers" Post
**User Prompt:** Write a blog outline revealing the real numbers behind [BUSINESS/ACHIEVEMENT]. Include revenue, costs, time investment, and lessons.

**Example Output:**
> **Title:** The Real Numbers Behind My $200K Content Business
> Revenue breakdown, expense breakdown, hourly rate calculation, what's worth it and what's not.

### 16. The "Framework" Post
**User Prompt:** Write a blog outline introducing your framework for [PROBLEM]. Name it, explain each component, show it applied.

**Example Output:**
> **Title:** The CLEAR Framework for Writing Blog Posts That Rank
> C=Choose keyword, L=Layout outline, E=Elaborate sections, A=Add media, R=Review and optimize

### 17. The "Interview/Expert Roundup" Post
**User Prompt:** Write a blog outline for "[NUMBER] Experts Share Their Best Advice on [TOPIC]." Include expert intro, their take, and your commentary.

**Example Output:**
> **Title:** 15 Content Creators Share the One Thing That Actually Grew Their Audience
> Each expert gets: bio, their one strategy, your analysis of why it works.

### 18. The "Tools I Use" Post
**User Prompt:** Write a blog outline for "My Complete [WORKFLOW] Stack: Every Tool I Use and Why." Organized by function.

**Example Output:**
> **Title:** My Complete Content Creation Stack: 12 Tools I Use Daily
> Category by function: writing, design, scheduling, analytics, monetization. Each with: name, cost, what it replaces, verdict.

### 19. The "Prediction" Post
**User Prompt:** Write a blog outline for "[NUMBER] Predictions for [INDUSTRY] in [YEAR]." Each prediction: the claim, reasoning, confidence level, implications.

**Example Output:**
> **Title:** 8 Predictions for the Creator Economy in 2027
> Each prediction with: what will happen, why I believe this, what to do about it now.

### 20. The "Personal Story + Lesson" Post
**User Prompt:** Write a blog outline for a personal essay about [EXPERIENCE] that teaches [LESSON]. Structure: story → turning point → lesson → reader application.

**Example Output:**
> **Title:** I Lost My Biggest Client and It Was the Best Thing That Happened to My Business
> The story, what went wrong, the pivot, the new strategy, results 6 months later, what the reader can learn.

---

## Engagement & Shareability Posts (21-30)

### 21. The "Checklist" Post

**System Prompt:**
You write checklist posts designed to be printed or bookmarked. Each item is specific and checkable — not vague advice. Formatted as an actual checklist.

**User Prompt:**
Write a blog outline for "The Complete [TOPIC] Checklist: [NUMBER] Things to Do Before [ACTION]." Each item: checkbox + specific action + brief why.

Topic: [YOUR TOPIC]
Action: [WHAT THEY'RE PREPARING FOR]
Number: [HOW MANY ITEMS]

**Example Output:**
> **Title:** The Complete Website Launch Checklist: 37 Things to Do Before Going Live
> **Meta:** Don't launch your website without checking these 37 items. Covers SEO, performance, security, content, and legal.
>
> **SEO Checklist (8 items):** meta titles, descriptions, image alt text, sitemap...
> **Performance (6 items):** page speed, mobile responsive, broken links...
> **Security (5 items):** SSL, backups, login security...
> **Content (10 items):** proofread, CTAs, contact info, about page...
> **Legal (4 items):** privacy policy, terms, cookie consent...
> **Analytics (4 items):** GA4, Search Console, conversion tracking...

---

### 22. The "Template" Post

**System Prompt:**
You write posts that provide copy-and-paste templates. The post explains the template, shows it filled in, and offers the blank version.

**User Prompt:**
Write a blog outline for "[NUMBER] [TEMPLATE TYPE] Templates You Can Steal Today." Each template: the template, explanation of why it works, filled-in example.

Template type: [WHAT KIND]
Number: [HOW MANY]

**Example Output:**
> **Title:** 10 Cold Email Templates That Get Responses (Copy & Paste)
> Each template: blank version → explanation of each section → filled-in example → when to use it.

---

### 23. The "Lessons from Failure" Post
**User Prompt:** Write a blog outline analyzing a specific failure: what happened, what went wrong, the lessons, and what you'd do differently.

**Example Output:**
> **Title:** How I Launched a Product Nobody Wanted (And the $12K Lesson)
> Timeline of the launch, the mistakes, the data that showed it was failing, the decision to shut it down, 5 lessons.

### 24. The "Day in the Life" Blog Post
**User Prompt:** Write a blog outline for "A Day in the Life of a [ROLE]: What It's Actually Like." Honest, educational, with tips embedded.

**Example Output:**
> **Title:** A Day in the Life of a Freelance UX Designer: What It's Actually Like
> Hour-by-hour breakdown with embedded tips for each phase of the day.

### 25. The "Workflow" Post
**User Prompt:** Write a blog outline showing your exact workflow for [PROCESS]. Step by step with tools, time per step, and alternatives.

**Example Output:**
> **Title:** My Exact Process for Writing a Blog Post in 2 Hours
> Idea → outline (15 min) → draft (45 min) → edit (30 min) → format (15 min) → publish (15 min).

### 26. The "FAQ" Post
**User Prompt:** Write a blog outline for "[NUMBER] Most Common Questions About [TOPIC] — Answered." Each question gets a thorough answer. Targets featured snippets.

**Example Output:**
> **Title:** 21 Most Common Questions About Freelancing — Answered
> Each question as an H2, structured for featured snippet capture, thorough but scannable answers.

### 27. The "Trends" Post
**User Prompt:** Write a blog outline for "[NUMBER] [TOPIC] Trends to Watch in [YEAR]." Each trend with evidence, why it matters, and how to act on it.

**Example Output:**
> **Title:** 9 Email Marketing Trends to Watch in 2026
> Each trend: what's happening, data proving it, what to do about it now.

### 28. The "Myths" Post
**User Prompt:** Write a blog outline debunking myths about [TOPIC]. Each myth: the belief, why people think it, the truth, the evidence.

**Example Output:**
> **Title:** 12 SEO Myths That Are Wasting Your Time in 2026
> Each myth: statement → origin → truth → data → action item.

### 29. The "Strategy" Post
**User Prompt:** Write a blog outline for a complete strategy post: "The [AUDIENCE] Guide to [GOAL]." Includes mindset, strategy, tactics, and tools.

**Example Output:**
> **Title:** The Solopreneur's Guide to Building Multiple Income Streams
> Mindset shifts needed → which income streams to start → in what order → tools and resources for each.

### 30. The "Roundup/Collection" Post
**User Prompt:** Write a blog outline curating the best [THINGS] with annotations. Organized by category, each with a brief review.

**Example Output:**
> **Title:** The 50 Best Newsletters for Entrepreneurs (Curated & Categorized)
> Categories: business strategy, marketing, finance, tech, productivity. Each newsletter: description, frequency, why it's good, link.

---

*30 blog post frameworks. Pick the format that matches your goal. Fill in. Write. Publish.*
