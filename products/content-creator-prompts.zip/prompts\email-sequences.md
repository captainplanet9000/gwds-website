# Email Marketing Sequences

20 complete email sequence frameworks. Each includes the sequence structure, individual email prompts with system/user format, and example outputs. Covers welcome, launch, re-engagement, and abandoned cart flows.

---

## Welcome Sequences (1-5)

### 1. The 5-Email Value-First Welcome Sequence

**System Prompt:**
You are an email copywriter who writes welcome sequences that build trust before selling. Each email delivers genuine value while subtly positioning a paid offer. Tone: conversational, direct, like a smart friend emailing you. No corporate speak. No "hope this email finds you well."

**User Prompt:**
Write a 5-email welcome sequence for a [NICHE] newsletter/brand. The subscriber signed up for [LEAD MAGNET]. The sequence should deliver value for 4 emails, then soft-pitch [PRODUCT] in email 5. Include subject lines, send timing, and full email body for each.

Niche: [YOUR NICHE]
Lead magnet: [WHAT THEY DOWNLOADED]
Product to pitch: [YOUR OFFER]
Brand voice: [CASUAL/PROFESSIONAL/BOLD]

**Example Output:**

**Email 1 — Sent Immediately**
> **Subject:** Here's your [lead magnet] + one thing to do first
>
> Hey [Name],
>
> Your [Content Creator Cheat Sheet] is attached. Download it, save it, whatever — it's yours.
>
> But before you dive in, do this one thing: pick ONE strategy from page 2 and try it on your next post. Don't try all 12. Just one.
>
> The people who get results from this aren't the ones who read it cover to cover. They're the ones who implement one thing immediately.
>
> I'll send you something useful in 2 days — a framework I use every single week that never made it into the cheat sheet.
>
> Talk soon,
> [Name]

**Email 2 — Day 3**
> **Subject:** The framework I use every Monday morning
>
> Quick story. A year ago, I sat down every Monday with zero plan for the week's content. By Friday, I'd posted maybe 2 out of 5 planned posts. The rest? "I'll do it tomorrow."
>
> Then I built a framework I now call the Content Sprint. Every Monday, I spend 90 minutes and plan + draft the entire week.
>
> Here's how it works:
> - 20 min: review last week's analytics (what performed, what didn't)
> - 30 min: outline 5 posts based on what worked
> - 40 min: draft all 5 (rough is fine — you edit later)
>
> That's it. 90 minutes buys you a week of content.
>
> Try it next Monday. Reply and tell me how it goes — I read every response.

**Email 3 — Day 5**
> **Subject:** The mistake that cost me 6 months of growth
>
> I spent my first 6 months creating content I thought was good. It wasn't bad. It just didn't connect.
>
> The problem: I was writing for everyone. When you write for everyone, you resonate with no one.
>
> The fix was embarrassingly simple. I wrote down one specific person — their age, their problem, their daily frustration — and started writing directly to them.
>
> My engagement tripled in 3 weeks.
>
> Here's my one-person avatar template:
> - Name: [made up]
> - Age: [specific]
> - Biggest frustration with [your niche]: [exact words they'd use]
> - What they've tried that didn't work: [specifics]
>
> Fill that out. Tape it next to your screen. Write to that person.

**Email 4 — Day 7**
> **Subject:** 3 things I'd do differently if I started over today
>
> If I had to restart my content business from scratch, I'd change three things:
>
> 1. I'd start an email list on day 1, not day 300. Social media followers aren't yours. Email subscribers are.
>
> 2. I'd spend 80% of my time on distribution, not creation. A great post nobody sees is worthless. A decent post with smart distribution beats it every time.
>
> 3. I'd charge for something by month 2. Not month 12. Revenue validates faster than likes.
>
> I'm telling you this because it took me 2 years to learn these lessons. Hopefully this email saves you some of that time.
>
> Tomorrow, I'm sharing something I've been working on. It's directly related to lesson #3.

**Email 5 — Day 8**
> **Subject:** Built this for people like you
>
> Over the last 4 emails, I've shared my best content frameworks, my biggest mistakes, and what I'd do differently.
>
> But frameworks only get you so far. What I actually needed when I was starting out was a complete library of proven prompts I could plug into and start creating immediately.
>
> So I built one.
>
> The Content Creator Mega Pack: 300+ ready-to-use prompts for TikTok, YouTube, Instagram, Twitter, email, and more.
>
> Not theory. Not a course. Just the exact frameworks formatted as AI prompts — paste them in, fill in the blanks, get content.
>
> It's $29 — less than a month of the streaming service you forgot to cancel.
>
> [LINK]
>
> If it's not for you, no worries. You'll keep getting these emails either way. I'm not going to start pitching you every Tuesday.
>
> But if you've been thinking "I wish someone would just give me the templates" — this is that.

---

### 2. The "Quick Win" Welcome Sequence

**System Prompt:**
You are an email copywriter who delivers a quick win in every email. Each email solves one small problem completely. By the end of the sequence, the subscriber has seen enough results to trust you with their money.

**User Prompt:**
Write a 4-email welcome sequence where each email delivers one actionable quick win for [AUDIENCE]. Email 4 transitions to a pitch. Include subject lines and full body copy.

Audience: [WHO YOUR SUBSCRIBERS ARE]
Quick wins: [4 SMALL PROBLEMS TO SOLVE]
Product: [WHAT YOU'RE EVENTUALLY SELLING]

**Example Output:**

**Email 1 — Immediate**
> **Subject:** Quick win #1: fix this in 30 seconds
>
> Welcome. No long intro — let's get you a result right now.
>
> Quick win: go to your Instagram bio and replace whatever you have with this formula:
>
> "I help [specific person] get [specific result]"
>
> That's it. Not your job title. Not your hobbies. What the FOLLOWER gets from following you.
>
> Do it now. Takes 30 seconds. Your profile conversion rate will thank you.
>
> Tomorrow: quick win #2 (this one's about captions).

**Email 2 — Day 2**
> **Subject:** Quick win #2: the first-line trick
> [Caption opening line framework — specific, immediately usable]

**Email 3 — Day 4**
> **Subject:** Quick win #3: the 5-minute content recycling trick
> [How to turn one post into 3 pieces of content in 5 minutes]

**Email 4 — Day 6**
> **Subject:** Quick wins are great. A system is better.
> [Transition: these quick wins helped, but they're isolated tactics. A system connects everything. Here's the product that IS the system.]

---

### 3. The Story-Driven Welcome Sequence

**System Prompt:**
You write welcome sequences that unfold like a story across multiple emails. Each email advances the narrative while teaching something. The reader gets hooked on the story and the lessons simultaneously.

**User Prompt:**
Write a 5-email story-driven welcome sequence for [BRAND/CREATOR]. Tell the origin story of [YOUR JOURNEY] across 5 emails. Each email: one chapter of the story + one embedded lesson. End with a pitch.

Journey: [YOUR STORY ARC]
Lessons: [5 KEY TAKEAWAYS]
Product: [YOUR OFFER]

**Example Output:**
> **Email 1:** "How it started" — the problem you faced, the frustration, why you started down this path. Lesson: everyone starts from a place of not knowing.
> **Email 2:** "The first attempt" — what you tried, why it failed, the cost. Lesson: the first approach is always wrong — iterate.
> **Email 3:** "The turning point" — what changed, who helped, the breakthrough moment. Lesson: the specific insight that changed everything.
> **Email 4:** "Building the system" — how you turned the breakthrough into a repeatable process. Lesson: the framework.
> **Email 5:** "What it looks like now" — the results, the proof, and the offer to help others do the same.

---

### 4. The Authority-Building Welcome Sequence

**System Prompt:**
You write welcome sequences that establish expertise. Each email showcases your knowledge through teaching, case studies, and specific results. By email 5, the reader sees you as the authority in your space.

**User Prompt:**
Write a 5-email authority-building sequence for [EXPERT/BRAND]. Each email demonstrates expertise in a different way: Email 1: one powerful insight. Email 2: myth-busting. Email 3: case study. Email 4: industry prediction. Email 5: your system + pitch.

Expert/brand: [YOUR IDENTITY]
Expertise area: [YOUR FIELD]
Product: [YOUR OFFER]

**Example Output:**
> **Email 1 — Subject:** "The one metric that matters more than followers"
> [Powerful insight: email subscriber count is the real measure of a creator business, not social followers. Data showing why.]
>
> **Email 2 — Subject:** "Stop doing this (it's costing you money)"
> [Myth: posting at "optimal times" matters. Truth: content quality and hook strength matter 10x more. Evidence.]
>
> **Email 3 — Subject:** "How Sarah went from 200 to 10K subscribers in 90 days"
> [Case study with specific steps, tools, and results.]
>
> **Email 4 — Subject:** "What happens to creators in 2027 (my prediction)"
> [Industry prediction showing you think ahead — AI, platforms, monetization shifts.]
>
> **Email 5 — Subject:** "My system for all of this"
> [Connect the dots between emails 1-4. This is the system. Here's how to get it.]

---

### 5. The Segmentation Welcome Sequence

**System Prompt:**
You write welcome sequences that segment subscribers based on their responses. Email 1 asks what they need most. Subsequent emails are tailored to their answer. This increases relevance and conversion.

**User Prompt:**
Write a 4-email welcome sequence that segments subscribers into [2-3 GROUPS]. Email 1 asks them to self-identify by clicking a link. Emails 2-4 are tailored to each group. Include the segmentation mechanism.

Groups: [YOUR SEGMENTS]
How to segment: [CLICK-BASED, REPLY-BASED, OR QUIZ]

**Example Output:**
> **Email 1 — Subject:** "Quick question before we start"
> "I want to send you the most relevant stuff. Which describes you best?
> → I'm just getting started [LINK]
> → I'm growing but stuck [LINK]
> → I'm ready to monetize [LINK]"
>
> **If "just starting":** Email 2 = foundational strategy, Email 3 = first steps, Email 4 = starter product pitch
> **If "growing but stuck":** Email 2 = growth frameworks, Email 3 = case study, Email 4 = growth product pitch
> **If "ready to monetize":** Email 2 = revenue models, Email 3 = pricing strategy, Email 4 = premium product pitch

---

## Launch Sequences (6-10)

### 6. The 7-Day Product Launch Sequence

**System Prompt:**
You are a launch email copywriter. You build anticipation, create urgency, and drive conversions through a structured email sequence. No fake urgency — real deadlines, real bonuses, real scarcity.

**User Prompt:**
Write a 7-email launch sequence for [PRODUCT] at [PRICE]. Include: pre-launch (2 emails), launch day (1 email), mid-launch (2 emails), last chance (2 emails). Cart closes on day 7.

Product: [YOUR PRODUCT]
Price: [AMOUNT]
Key benefits: [3 MAIN BENEFITS]
Bonuses: [ANY BONUSES]
Cart close date: [DEADLINE]

**Example Output:**

**Day -3: Pre-launch Email 1**
> **Subject:** Something's coming on [DATE]
> Tease the product without revealing details. Share the problem it solves. Build curiosity.

**Day -1: Pre-launch Email 2**
> **Subject:** Tomorrow at [TIME]
> Reveal what the product is. Share a behind-the-scenes look at the creation process. FAQs.

**Day 1: Launch Email**
> **Subject:** It's live — [PRODUCT NAME]
> Full pitch. Benefits, what's included, who it's for, price, bonuses, testimonials. Clear CTA.

**Day 3: Social Proof Email**
> **Subject:** "[Testimonial quote]"
> Share 3-5 early buyer reactions. Show real results if available.

**Day 5: FAQ/Objection Email**
> **Subject:** "Is this right for me?"
> Address top 5 objections and questions. Remove friction.

**Day 6: Last Day Warning**
> **Subject:** 24 hours left
> Recap the offer. Remind of bonuses. Create urgency.

**Day 7: Final Email**
> **Subject:** Closing at midnight
> Short, direct. Last chance. Clear deadline. Strong CTA.

---

### 7. The "Behind the Scenes" Launch Sequence

**System Prompt:**
You write launch sequences that bring the audience into the creation process. Each email shares a piece of the journey — what you built, why, and who helped. By launch day, they feel invested in the product's success.

**User Prompt:**
Write a 5-email launch sequence that documents the creation of [PRODUCT]. Each email reveals a new aspect: the problem, the research, the build, the testing, and the launch.

Product: [WHAT YOU'RE LAUNCHING]

**Example Output:**
> **Email 1 — Subject:** "The problem that drove me crazy"
> **Email 2 — Subject:** "I interviewed 50 people to understand this"
> **Email 3 — Subject:** "Building in public: here's what I've made so far"
> **Email 4 — Subject:** "I tested it on 20 people. Here's what they said"
> **Email 5 — Subject:** "It's done. And you get first access."

---

### 8. The Waitlist Launch Sequence

**System Prompt:**
You write sequences for waitlist-based launches. Build exclusivity and anticipation. Waitlist members get early access, better pricing, or exclusive bonuses.

**User Prompt:**
Write a 4-email waitlist launch sequence. Email 1: join the waitlist. Email 2: you're in + tease. Email 3: early access opens. Email 4: public launch (waitlist gets bonus).

Product: [YOUR PRODUCT]
Waitlist bonus: [EXCLUSIVE OFFER]

**Example Output:**
> **Email 1:** "Something's coming — get on the list" [build curiosity, limited info]
> **Email 2:** "You're on the list — here's what to expect" [tease features, timeline]
> **Email 3:** "Early access is live — 48 hours before everyone else" [exclusive access + bonus]
> **Email 4:** "It's public now — but your bonus expires tonight" [urgency for waitlist exclusives]

---

### 9. The Mini-Launch (3 Emails)

**System Prompt:**
You write compact launch sequences for smaller products or quick promotions. Three emails: announce, explain, close. No fluff, no 7-day buildup.

**User Prompt:**
Write a 3-email launch sequence for [PRODUCT] at [PRICE]. Email 1: announce + pitch. Email 2: social proof + FAQ. Email 3: last chance. Total sequence: 5 days.

Product: [YOUR PRODUCT]
Price: [AMOUNT]

**Example Output:**
> **Email 1 (Day 1) — Subject:** "Made something for you — $[PRICE]"
> Direct pitch. What it is, what's included, who it's for, price. No games.
>
> **Email 2 (Day 3) — Subject:** "Quick answers about [PRODUCT]"
> 5 FAQs + 3 testimonials/early results. Remove remaining objections.
>
> **Email 3 (Day 5) — Subject:** "Last day for [PRODUCT]"
> 12-sentence email. Recap offer. Deadline. CTA. Done.

---

### 10. The Evergreen Launch Funnel

**System Prompt:**
You write evergreen email sequences that simulate a live launch. The subscriber enters the sequence whenever they sign up, and it feels like a time-limited launch just for them. Deadlines are real (using deadline funnel or similar tools).

**User Prompt:**
Write a 6-email evergreen launch sequence for [PRODUCT]. The "launch" starts when someone joins the email list. Include a personalized deadline 7 days after signup.

Product: [YOUR PRODUCT]
Price: [AMOUNT]
Deadline mechanism: [TOOL OR APPROACH]

**Example Output:**
> **Email 1 (Day 1):** Value + subtle tease of product
> **Email 2 (Day 2):** Deep value + mention of upcoming opportunity
> **Email 3 (Day 4):** Case study + product introduction (your personal deadline is [DATE])
> **Email 4 (Day 5):** Full pitch + FAQ + bonuses
> **Email 5 (Day 6):** Social proof + objection handling
> **Email 6 (Day 7):** "Your access expires tonight" — final CTA

---

## Re-engagement Sequences (11-15)

### 11. The "We Miss You" Re-engagement Sequence

**System Prompt:**
You write re-engagement sequences for subscribers who haven't opened an email in 30-90 days. Your tone is honest, not guilt-trippy. You give them a genuine reason to re-engage or a clean way to leave.

**User Prompt:**
Write a 3-email re-engagement sequence for inactive subscribers. Email 1: check-in. Email 2: best content roundup. Email 3: stay or unsubscribe (with incentive to stay).

Niche: [YOUR NICHE]
Inactive period: [HOW LONG]
Incentive: [WHAT YOU OFFER TO STAY]

**Example Output:**

**Email 1 — Subject:** "Still interested?"
> Hey [Name], I noticed you haven't opened an email from me in a while. No guilt — inboxes are battlefields. But I want to make sure I'm sending you stuff you actually want. If you're still interested in [NICHE] content, just click this link and you're all set: [STAY LINK]. If not, no hard feelings. I'll clean up my list in a week.

**Email 2 — Subject:** "In case you missed these"
> In case you dipped out during a busy week, here are the 3 best things I sent this month: [Link 1 — description], [Link 2 — description], [Link 3 — description]. If any of these sound interesting, click and you're back in. If not, I'll stop emailing.

**Email 3 — Subject:** "Last email (unless you want to stay)"
> This is the last email I'll send unless you click below. No tricks — just want to keep my list full of people who want to be here. Click to stay → [LINK]. As a thank-you for staying: [free resource/discount/exclusive content]. If I don't hear from you, I'll remove you from the list. Clean inboxes for everyone.

---

### 12. The "What Changed" Re-engagement

**System Prompt:**
You write re-engagement emails that acknowledge the subscriber's time away and offer something genuinely new or improved as a reason to come back.

**User Prompt:**
Write a 2-email re-engagement sequence focused on what's NEW since they last engaged. Show them what they're missing.

**Example Output:**
> **Email 1 — Subject:** "A lot has changed"
> [Share 3 specific improvements, new content, or new products since they last engaged]
>
> **Email 2 — Subject:** "Here's a free [thing] to welcome you back"
> [Offer a new lead magnet or exclusive content as a re-engagement incentive]

---

### 13. The "Feedback" Re-engagement

**System Prompt:**
You write re-engagement emails that ask for feedback. Turning inactive subscribers into participants re-activates them and gives you data.

**User Prompt:**
Write a 2-email re-engagement sequence that asks for feedback. Email 1: quick survey. Email 2: results of the survey + action you're taking.

**Example Output:**
> **Email 1 — Subject:** "Quick favor? (takes 30 seconds)"
> I'm improving what I send you. One question: what do you want more of? [Option A] [Option B] [Option C] [Just click — no form to fill]
>
> **Email 2 — Subject:** "You spoke, I listened"
> [Share survey results. Announce changes based on feedback. This shows you're responsive and worth staying subscribed to.]

---

### 14. The "Breakup" Re-engagement

**System Prompt:**
You write bold breakup-style re-engagement emails. Slightly dramatic subject lines that stand out in a crowded inbox. The contrast gets attention.

**User Prompt:**
Write a single breakup-style re-engagement email that gets attention. Bold, slightly dramatic, but genuine. Include a clear CTA to stay or leave.

**Example Output:**
> **Subject:** "Should I stop emailing you?"
>
> I'll keep this short. You haven't opened an email from me in [X weeks/months]. I get it — you're busy, your inbox is a disaster, or maybe what I'm sending isn't relevant anymore.
>
> I don't want to be that person who keeps texting after you've clearly moved on.
>
> So here's the deal:
> → Click here if you want to keep getting emails from me [STAY LINK]
> → Do nothing and I'll remove you in 7 days
>
> No hard feelings either way. I'd rather have 1,000 subscribers who want to hear from me than 10,000 who don't.

---

### 15. The Win-Back with Offer

**System Prompt:**
You write win-back emails for subscribers who haven't purchased. Not re-engagement for opens — specifically for people who engage but haven't converted. Includes a special offer.

**User Prompt:**
Write a 3-email win-back sequence for subscribers who've been opening emails but never purchased [PRODUCT]. Include a limited offer in email 2.

Product: [YOUR PRODUCT]
Special offer: [DISCOUNT/BONUS]
Deadline: [EXPIRY]

**Example Output:**
> **Email 1:** "You've been reading — but haven't jumped in yet" [Acknowledge, address likely objections, share a new testimonial]
> **Email 2:** "I almost never do this — [OFFER]" [Special discount or bonus, legitimate deadline]
> **Email 3:** "[OFFER] expires tonight" [Short, direct, clear deadline]

---

## Abandoned Cart Sequences (16-20)

### 16. The Standard Abandoned Cart Sequence

**System Prompt:**
You are an e-commerce email copywriter specializing in cart recovery. Your emails are helpful, not pushy. You remind without nagging. Each email addresses a different reason for abandonment.

**User Prompt:**
Write a 3-email abandoned cart sequence for [PRODUCT] at [PRICE]. Email 1 (1 hour later): reminder. Email 2 (24 hours): address objections. Email 3 (48 hours): urgency/incentive.

Product: [WHAT THEY LEFT IN CART]
Price: [AMOUNT]
Common objections: [WHY PEOPLE HESITATE]

**Example Output:**

**Email 1 (1 hour after abandonment)**
> **Subject:** You left something behind
>
> Hey [Name], looks like you didn't finish checking out. No pressure — just wanted to make sure nothing went wrong on our end.
>
> Your cart: [PRODUCT NAME] — $[PRICE]
>
> [COMPLETE YOUR ORDER BUTTON]
>
> If you had a question, just reply to this email. I answer every one.

**Email 2 (24 hours)**
> **Subject:** Quick answers about [PRODUCT]
>
> I know buying decisions take time. Here are the 3 questions I get most:
>
> **"Is this right for me?"** It's built for [specific person]. If that's you, yes.
> **"What if it's not what I expected?"** Full refund within 30 days. No questions.
> **"Is there a payment plan?"** [Yes/No — specifics]
>
> Still interested? Your cart is saved: [LINK]

**Email 3 (48 hours)**
> **Subject:** Last reminder — your cart expires soon
>
> Your saved cart for [PRODUCT] will expire in 24 hours.
>
> Quick recap of what you're getting: [2-3 bullet points of key benefits]
>
> [COMPLETE YOUR ORDER BUTTON]
>
> After this, I won't email about it again. Just wanted to make sure you didn't forget.

---

### 17. The "Social Proof" Abandoned Cart

**System Prompt:**
You write cart recovery emails heavy on social proof. Instead of pushy sales tactics, you let other buyers make the case.

**User Prompt:**
Write a 3-email abandoned cart sequence where each email features different social proof: Email 1: customer review. Email 2: case study result. Email 3: number of buyers + deadline.

Product: [YOUR PRODUCT]
Reviews: [2-3 CUSTOMER QUOTES]
Results: [A SPECIFIC OUTCOME]

**Example Output:**
> **Email 1 — Subject:** "Here's what [Customer] said about [PRODUCT]"
> [Feature one detailed customer review with their specific result]
>
> **Email 2 — Subject:** "[Customer] got [specific result] in [timeframe]"
> [Mini case study — their situation before, what they did, the result]
>
> **Email 3 — Subject:** "[NUMBER] people bought this week — your cart's still open"
> [Social proof through volume + cart expiry deadline]

---

### 18. The "Discount Ladder" Abandoned Cart

**System Prompt:**
You write tiered discount cart recovery sequences. The discount increases with each email. This recovers different segments — some buy without a discount, some need a small push, some need a bigger one.

**User Prompt:**
Write a 3-email abandoned cart sequence with escalating incentives. Email 1: no discount. Email 2: small discount. Email 3: bigger discount with deadline.

Product: [YOUR PRODUCT]
Price: [AMOUNT]
Discount tiers: [5%, 10%, 15% etc.]

**Example Output:**
> **Email 1 (1hr) — Subject:** "Forgot something?"
> [Simple reminder, no discount. This catches people who just got distracted.]
>
> **Email 2 (24hr) — Subject:** "A little something to help you decide"
> [5-10% discount code. "I don't do this often, but..." Genuine limited-time code.]
>
> **Email 3 (48hr) — Subject:** "Final offer: [BIGGER DISCOUNT]% off — expires tonight"
> [15-20% discount. Clear deadline. This is the last email. Make it count.]

---

### 19. The "What Went Wrong?" Abandoned Cart

**System Prompt:**
You write cart recovery emails that ask the customer what happened. This is both a recovery tactic and feedback-gathering. Sometimes the answer reveals a site bug, confusing checkout, or missing info.

**User Prompt:**
Write a 2-email abandoned cart sequence focused on feedback. Email 1: ask what happened. Email 2: respond to common answers with solutions.

Product: [YOUR PRODUCT]

**Example Output:**
> **Email 1 — Subject:** "Was something wrong?"
>
> Hey [Name], I noticed you started checkout for [PRODUCT] but didn't finish. Was it:
>
> → Technical issue? [Reply "TECH" and we'll help]
> → Had a question? [Reply "QUESTION" and I'll answer]
> → Changed your mind? [That's okay — reply "PASS" and I won't email about this again]
> → Just got distracted? [Here's your cart link to finish up: LINK]

> **Email 2 — Subject:** "In case it was one of these"
> [Address top 3 abandonment reasons: price concern → value justification, trust concern → guarantee/reviews, timing concern → reminder that offer may not last]

---

### 20. The "Review Cart" Abandoned Cart (High-Ticket)

**System Prompt:**
You write abandoned cart emails for high-ticket items ($100+). These require more trust-building and objection handling. The sequence is longer and includes an option to talk to a human.

**User Prompt:**
Write a 4-email abandoned cart sequence for a high-ticket product ($[PRICE]). Includes a personal video/call option. Each email builds more trust and removes a different objection.

Product: [YOUR PRODUCT]
Price: [HIGH PRICE]
Guarantee: [YOUR GUARANTEE]

**Example Output:**
> **Email 1 (1hr) — Subject:** "Your cart is saved"
> [Simple reminder. Include what's in the cart, price, and image. Non-pushy.]
>
> **Email 2 (24hr) — Subject:** "Is $[PRICE] the concern?"
> [Break down the value: ROI calculation, what you save/earn vs. the price, payment plan option]
>
> **Email 3 (48hr) — Subject:** "Want to talk about it?"
> [Offer a 15-min call or quick chat to answer questions. For high-ticket, human contact converts.]
>
> **Email 4 (72hr) — Subject:** "Last note about [PRODUCT]"
> [Final email: recap benefits, full guarantee details, strongest testimonial, clear CTA. Then stop.]

---

*20 email sequences. Pick the one that matches your funnel stage. Customize. Send. Convert.*
