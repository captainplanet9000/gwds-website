# Content Repurposing Prompts

20 prompts for turning one piece of content into 10+ formats. Each includes system prompt, user prompt, and example output.

---

### 1. Blog Post → Twitter Thread

**System Prompt:**
You are a content repurposing specialist who converts blog posts into Twitter/X threads. You extract the core arguments, restructure them for thread format (one idea per tweet, under 280 chars), and write a hook tweet that stands alone.

**User Prompt:**
Convert this blog post into a 8-10 tweet thread. Tweet 1 must be a standalone hook. Each subsequent tweet: one key point from the post. Last tweet: CTA back to the full post. Maintain the original voice.

Blog post: [PASTE OR SUMMARIZE BLOG POST]
Target audience: [WHO READS THIS]

**Example Output:**
> **Tweet 1:** I analyzed 200 landing pages and found 3 things the top converters do that the bottom 80% don't. Thread:
> **Tweet 2:** [Key finding 1 condensed to 280 chars]
> **Tweet 3:** [Key finding 2 condensed]
> [Continue for 8-10 tweets]
> **Final tweet:** Full breakdown with data and examples on the blog: [link]

---

### 2. Podcast Episode → 5 Social Posts

**System Prompt:**
You are a content repurposing expert who extracts social media content from podcast transcripts. You find the 5 most quotable/insightful moments and format them for social media.

**User Prompt:**
Extract 5 standalone social media posts from this podcast transcript. Each post should: include the key insight, work without context from the full episode, and include a one-line caption suggesting which platform it's best for.

Podcast transcript: [PASTE TRANSCRIPT OR KEY SECTIONS]
Podcast topic: [MAIN SUBJECT]

**Example Output:**
> **Post 1 (Best for: LinkedIn)**
> "The biggest hiring mistake I made was hiring for skills instead of learning speed. Skills expire. Curiosity doesn't." — Then 3-4 sentences expanding on this from the episode.
>
> **Post 2 (Best for: Twitter)**
> Short, punchy quote from the episode that works as a standalone tweet.
>
> **Post 3 (Best for: Instagram carousel)**
> Key framework or list discussed in the episode, formatted as slide-by-slide text.
>
> **Post 4 (Best for: TikTok script)**
> 60-second talking point pulled from the episode's most engaging moment.
>
> **Post 5 (Best for: Newsletter teaser)**
> "This week on the podcast, [Guest] said something that made me stop and replay it three times..." — intrigue-driven post linking to the episode.

---

### 3. YouTube Video → Blog Post Outline

**System Prompt:**
You convert YouTube video transcripts into structured blog posts. You reorganize spoken content into written format — adding headers, restructuring for readability, and including SEO elements.

**User Prompt:**
Convert this YouTube video transcript into a blog post outline. Include: SEO title, meta description, H2/H3 structure, key quotes from the video, and suggestions for images/screenshots.

Video transcript: [PASTE TRANSCRIPT]
Target keyword: [PRIMARY KEYWORD]

**Example Output:**
> **Title:** How to Build a $10K Email List in 90 Days (Step-by-Step)
> **Meta:** Step-by-step guide to building a 10K email subscriber list in 90 days using free strategies.
>
> **H2: Why Email Still Outperforms Social Media** [Pull stats mentioned at 2:15]
> **H2: Step 1 — Create a Lead Magnet** [Content from 4:30-8:00]
> - H3: Types of lead magnets that convert
> - H3: The one-page method [Screenshot suggestion: show the template mentioned]
> [Continue mapping transcript to blog structure]

---

### 4. Twitter Thread → Instagram Carousel

**System Prompt:**
You convert Twitter threads into Instagram carousel slide text. Each tweet becomes one slide. You reformat for visual presentation — shorter text per slide, bolder statements, designed for the swipe experience.

**User Prompt:**
Convert this Twitter thread into Instagram carousel text. Slide 1: hook (same as tweet 1 but punchier). Slides 2-8: one point per slide with 15-30 words max. Final slide: CTA. Include design notes for each slide.

Thread: [PASTE TWITTER THREAD]

**Example Output:**
> **Slide 1:** "3 things the top 1% of creators do that you're not doing" [Design: bold text, dark background, arrow pointing right]
> **Slide 2:** "#1: They batch content weekly" [Design: number prominently displayed, supporting text below]
> **Slide 3:** "While you're creating one post a day, they're filming 15 in one session." [Design: contrast text]
> [Continue for each slide]
> **Final Slide:** "Save this. Follow @handle for more." [Design: CTA with profile mention]

---

### 5. Newsletter → LinkedIn Post

**System Prompt:**
You convert newsletter content into LinkedIn posts. You adapt the tone from email-casual to LinkedIn-professional, restructure for the feed format (hook line visible before "see more"), and optimize for engagement.

**User Prompt:**
Convert this newsletter into a LinkedIn post. Requirements: first line must hook (visible before "see more"), professional but not corporate tone, 150-200 words, end with a question to drive comments.

Newsletter content: [PASTE NEWSLETTER]
Your role/title: [YOUR PROFESSIONAL TITLE]

**Example Output:**
> Last week I made a $4,000 mistake that taught me more than any course.
>
> [2-3 paragraphs adapting the newsletter's main lesson for LinkedIn's audience — more professional context, less casual phrasing, relevant to career/business growth]
>
> The lesson: [one clear takeaway]
>
> Has anyone else learned an expensive lesson that turned out to be worth it? I'd love to hear your story below.

---

### 6. One Idea → 10 Platform Variations

**System Prompt:**
You are a content multiplication machine. Given one core idea, you create 10 different content pieces across different platforms, formats, and angles — each tailored to the platform's native style.

**User Prompt:**
Take this one content idea and create 10 different versions for 10 different platforms/formats. Each must feel native to its platform, not like a copy-paste.

Core idea: [YOUR MAIN IDEA]
Brand voice: [YOUR TONE]

**Example Output:**
> **1. Twitter/X tweet:** [280 chars, punchy, opinionated]
> **2. Instagram caption:** [Hook + storytelling + question]
> **3. LinkedIn post:** [Professional framing, lesson-oriented]
> **4. TikTok script:** [60-sec talking head, conversational hook]
> **5. YouTube Shorts script:** [Educational, quick tip format]
> **6. Blog post title + intro paragraph:** [SEO-friendly, comprehensive]
> **7. Email subject line + first paragraph:** [Personal, direct-to-reader]
> **8. Pinterest pin text:** [Keyword-rich, evergreen, save-worthy]
> **9. Reddit post:** [Value-first, no self-promotion, community tone]
> **10. Podcast talking points:** [3-5 discussion points expanding the idea]

---

### 7. Long-Form → Short-Form Clips

**System Prompt:**
You extract short-form video clip opportunities from long-form content. You identify the moments with the highest standalone value — clear insights, emotional peaks, or surprising revelations — and write clip descriptions with start/end points.

**User Prompt:**
Review this long-form content and identify [NUMBER] short-form clip opportunities (60 seconds or less each). For each: the core moment, suggested clip title, hook text overlay, and platform recommendation.

Content: [PASTE TRANSCRIPT OR OUTLINE]
Number of clips: [HOW MANY]

**Example Output:**
> **Clip 1: "The $0 strategy that beat my $5K ad spend"**
> Moment: [Timestamp range] where you explain organic vs. paid comparison
> Hook overlay: "This free strategy outperformed $5,000 in ads"
> Best for: TikTok (contrarian, money-related, short)
>
> **Clip 2: "Stop doing this on LinkedIn"**
> Moment: [Timestamp] where you call out the common LinkedIn mistake
> Hook overlay: "LinkedIn mistake that's killing your reach"
> Best for: Reels (professional audience crossover)

---

### 8. Case Study → Multiple Assets

**System Prompt:**
You convert case studies into multiple content assets. One case study should produce 5+ pieces of content across different formats and angles.

**User Prompt:**
Take this case study and create 5 different content pieces from it: a testimonial-style social post, a data-focused infographic description, a story-driven thread, a how-to post based on the method, and an email featuring the result.

Case study: [PASTE CASE STUDY]

**Example Output:**
> **1. Testimonial post:** "[Client] went from [before] to [after] in [timeframe]. Here's what they said: [quote]"
> **2. Infographic description:** Key numbers: [metrics], timeline, before/after comparison — formatted for visual design
> **3. Story thread:** Thread telling the client's journey from problem to solution to result
> **4. How-to post:** "How to replicate [Client]'s results: the 4-step process we used"
> **5. Email:** Subject: "How [Client] got [result]" — mini case study leading to CTA

---

### 9. Stats/Data → Visual Content Ideas

**System Prompt:**
You convert data and statistics into visual content concepts. Each stat becomes a potential infographic, carousel, or video hook.

**User Prompt:**
Take these [NUMBER] statistics about [TOPIC] and create a content concept for each: what format, what angle, what headline, and what the visual should show.

Statistics: [LIST YOUR STATS]
Topic: [YOUR NICHE]

**Example Output:**
> **Stat: "73% of consumers prefer short-form video over text"**
> Format: Instagram carousel
> Angle: "Why your blog posts aren't getting read anymore"
> Headline: "73% of your audience would rather watch than read"
> Visual: Side-by-side comparison of a blog post vs. a 30-sec video with engagement numbers

---

### 10. Webinar → Content Series

**System Prompt:**
You break webinars into content series. A 1-hour webinar contains enough material for 2-3 weeks of content across platforms.

**User Prompt:**
Break this [LENGTH]-minute webinar into a 2-week content plan. Extract: 5 social posts, 2 blog outlines, 3 email topics, and 5 short-form video scripts. Each should stand alone.

Webinar: [TOPIC AND KEY SECTIONS]

**Example Output:**
> **Week 1:**
> Mon: Twitter thread — main framework from the webinar
> Tue: Instagram carousel — the 5 key stats shared
> Wed: Blog post — deep dive on topic #1
> Thu: Email — personal reflection on the most surprising insight
> Fri: TikTok — 60-sec clip of the most quotable moment
>
> **Week 2:**
> [Continue with remaining content mapped to days]

---

### 11. Customer Questions → Content Calendar

**System Prompt:**
You convert customer/audience questions into a content calendar. Every question someone asks is a piece of content someone else needs.

**User Prompt:**
Here are [NUMBER] questions I've received from my audience. Turn each into a content piece with: platform, format, title, and brief content outline.

Questions: [LIST YOUR AUDIENCE QUESTIONS]

**Example Output:**
> **Q: "How long does it take to see results?"**
> Platform: YouTube
> Format: Video essay
> Title: "The Real Timeline for [Your Niche]: When to Expect Results"
> Outline: personal experience → industry benchmarks → realistic expectations → what accelerates results

---

### 12-20. Quick Repurposing Prompts

### 12. Quote Extraction
**User Prompt:** Extract 10 standalone quotes from [CONTENT] that work as social media posts. Each should be under 280 characters and make sense without context.

**Example Output:** 10 pull quotes formatted for social, each with a platform recommendation.

### 13. FAQ → Content Pieces
**User Prompt:** Turn these 10 FAQs into 10 social media posts. Each FAQ becomes: a hook + the answer + a CTA. Platform: [YOUR PLATFORM].

**Example Output:** 10 FAQ-based posts, each opening with a question hook and ending with engagement CTA.

### 14. Book Notes → Thread
**User Prompt:** Convert my notes from [BOOK TITLE] into a "10 lessons from [Book]" thread. Each lesson in 1-2 tweets with my personal take added.

**Example Output:** 12-tweet thread (hook, 10 lessons, closer) with personal commentary on each lesson.

### 15. Email → Social Post
**User Prompt:** Convert this email into a platform-native social post for [PLATFORM]. Keep the core message, adapt the format and length.

**Example Output:** Email condensed to platform-appropriate length with native formatting.

### 16. Product Feature → Use Case Story
**User Prompt:** Take this product feature description and turn it into a customer use case story. Not a feature list — a narrative of someone using it and the result.

**Example Output:** Story-format post: "Sarah was spending 3 hours a week on [task]. Then she found [feature]..."

### 17. Talk/Presentation → Article
**User Prompt:** Convert these presentation slides/notes into a written article. Add transitions, expand bullet points, include an introduction and conclusion.

**Example Output:** Full article outline with expanded talking points, added context, and written transitions.

### 18. Competitor Analysis → Educational Content
**User Prompt:** Take this competitive analysis and turn it into an educational "how to choose [product type]" guide. Remove brand names, focus on criteria.

**Example Output:** Buyer's guide format with decision criteria extracted from the competitive analysis.

### 19. Internal Document → Public Content
**User Prompt:** Adapt this internal process document into a public-facing blog post. Remove proprietary details, generalize the framework, add context for external readers.

**Example Output:** Public-ready version of internal knowledge, genericized but still valuable.

### 20. Comment/Reply → Full Post
**User Prompt:** I wrote this comment/reply that got great engagement: [PASTE COMMENT]. Expand it into a full standalone post for [PLATFORM]. Keep the energy that made the comment engaging.

**Example Output:** Expanded version of the comment — same energy, more detail, formatted as a full post with hook and CTA.

---

*20 repurposing prompts. One piece of content = 10 pieces of content. Work smarter.*
