# AI Video Generation Prompts

25 prompts for AI video tools like Runway, Pika, Sora, Kling, and similar platforms. Each prompt includes the system context, the generation prompt, and expected output description. Organized by use case.

---

## Cinematic & Storytelling (1-8)

### 1. Epic Landscape Reveal

**System Prompt:**
You are an AI video prompt engineer who writes detailed generation prompts for text-to-video models. You specify camera movement, lighting, mood, timing, and visual details. Your prompts produce cinematic results.

**User Prompt:**
Write an AI video generation prompt for a cinematic landscape reveal. The camera should [MOVEMENT TYPE] to reveal [LANDSCAPE]. Include time of day, weather, and mood details. 4-second clip.

Landscape: [SPECIFIC LOCATION/SCENERY]
Camera movement: [DRONE RISE / PAN / TRACKING]
Mood: [EPIC / SERENE / MYSTERIOUS]

**Example Output:**
> **Video Prompt:**
> Slow drone rise revealing vast mountain range at golden hour. Camera starts behind pine tree silhouettes, rises smoothly to reveal snow-capped peaks stretching to the horizon. Warm orange sunlight casting long shadows across alpine meadows. Thin clouds threading between peaks. Cinematic, anamorphic lens flare. 24fps, 4 seconds.
>
> **Expected Result:** A smooth upward drone movement transitioning from ground-level forest to a sweeping mountain vista. Golden light, film-grade color.

---

### 2. Character Walking Shot

**System Prompt:**
You are an AI video prompt engineer specializing in human subjects. You describe characters with consistent features, clothing, and movement. Avoid ambiguity in descriptions.

**User Prompt:**
Write an AI video prompt for a character walking through [ENVIRONMENT]. Describe the character, their movement, the environment, and the camera following them. 4-second clip.

Character: [DESCRIPTION]
Environment: [WHERE THEY'RE WALKING]
Camera: [FOLLOWING / TRACKING / STATIONARY]

**Example Output:**
> **Video Prompt:**
> Medium tracking shot following a woman in a long dark coat walking through a neon-lit Tokyo alley at night. Camera follows from behind at waist height. Rain-slicked pavement reflecting pink and blue neon signs. Steam rising from street vents. She walks with purpose, not looking back. Shallow depth of field. Cinematic color grade, teal and orange tones. 4 seconds.
>
> **Expected Result:** Smooth tracking shot with consistent character movement, moody urban atmosphere, reflective surfaces.

---

### 3. Time-Lapse Transformation

**System Prompt:**
You are an AI video prompt engineer who creates time-lapse style prompts. You describe the start state, end state, and the transformation between them.

**User Prompt:**
Write an AI video prompt for a time-lapse showing [START STATE] transforming into [END STATE]. Include environmental context and pacing notes. 4-second clip.

Start state: [BEGINNING CONDITION]
End state: [FINAL CONDITION]
Context: [WHERE THIS HAPPENS]

**Example Output:**
> **Video Prompt:**
> Time-lapse of an abandoned urban lot transforming into a thriving community garden. Camera fixed at eye level. Day-to-night-to-day cycles as weeds clear, soil is tilled, seedlings emerge, grow, and bloom into colorful flowers and vegetable plants. People appear and disappear like ghosts tending the garden. Clouds race across the sky. 4 seconds compressed from months. Warm, hopeful color palette.
>
> **Expected Result:** Fixed-camera time-lapse with visible transformation, day/night cycles, and plant growth progression.

---

### 4. Product Reveal Shot

**System Prompt:**
You are an AI video prompt engineer for commercial/product content. You create sleek, professional product reveal animations with studio-quality lighting and movement.

**User Prompt:**
Write an AI video prompt for a product reveal of [PRODUCT]. Include surface material, lighting style, camera rotation, and background. 4-second clip.

Product: [SPECIFIC PRODUCT]
Material/finish: [MATTE/GLOSSY/METALLIC]
Lighting: [STUDIO/DRAMATIC/NATURAL]

**Example Output:**
> **Video Prompt:**
> Slow 180-degree orbit around a matte black wireless speaker on a polished concrete surface. Single overhead softbox creates clean highlights on the cylindrical body. Background: minimalist, dark grey gradient. Camera moves from front to side profile. Product rotates slightly on a turntable. No text. Product photography lighting style. Clean, premium, Apple-commercial aesthetic. 4 seconds.
>
> **Expected Result:** Smooth orbiting product shot with consistent lighting, professional commercial feel.

---

### 5. Emotional Close-Up

**System Prompt:**
You are an AI video prompt engineer who captures human emotion in close-up shots. You describe facial expressions, micro-movements, and emotional context with precision.

**User Prompt:**
Write an AI video prompt for an emotional close-up of a person experiencing [EMOTION]. Include lighting, background focus, and subtle movements. 3-second clip.

Emotion: [SPECIFIC FEELING]
Character: [BRIEF DESCRIPTION]
Lighting: [NATURAL/DRAMATIC/SOFT]

**Example Output:**
> **Video Prompt:**
> Extreme close-up of a young man's face as he reads something on a phone screen. His expression shifts from neutral to a slow, genuine smile — eyes crinkling first, then mouth curving. Soft natural window light from the left side. Background completely blurred. A single tear forms at the corner of his eye. Camera holds steady with slight handheld breathing. Warm, intimate color grade. 3 seconds.
>
> **Expected Result:** Steady close-up with subtle, believable emotional shift. Natural lighting, shallow depth of field.

---

### 6. Chase/Action Sequence

**System Prompt:**
You are an AI video prompt engineer for action content. You describe dynamic movement, camera motion, and pacing for high-energy clips.

**User Prompt:**
Write an AI video prompt for an action sequence: [ACTION DESCRIPTION]. Include camera movement speed, character movement, and environment dynamics. 4-second clip.

Action: [WHAT'S HAPPENING]
Environment: [WHERE]
Camera style: [HANDHELD/STEADICAM/DRONE]

**Example Output:**
> **Video Prompt:**
> Low-angle tracking shot following a parkour runner leaping across rooftops at sunset. Camera follows from slightly below, capturing the runner's silhouette against the orange sky. Gravel sprays as they land on each roof. Wind whips their jacket. Urban skyline visible in the background. Dynamic, handheld energy with smooth stabilization. Action movie color grade. 4 seconds.
>
> **Expected Result:** Dynamic tracking shot with human movement across rooftops, silhouette lighting, action movie aesthetic.

---

### 7. Atmospheric Establishing Shot

**System Prompt:**
You write establishing shots for AI video — the kind that open a film. You set mood, place, and time in a single clip.

**User Prompt:**
Write an AI video prompt for an establishing shot of [LOCATION] that conveys [MOOD]. Include weather, lighting, and one dynamic element (smoke, birds, water, etc.). 4 seconds.

Location: [WHERE]
Mood: [FEELING]
Dynamic element: [MOVEMENT IN THE SCENE]

**Example Output:**
> **Video Prompt:**
> Wide establishing shot of an abandoned industrial warehouse at dusk. Blue-grey overcast sky. Broken windows. Weeds growing through cracked concrete. A single flickering fluorescent light inside casts pale green light through one window. A murder of crows lifts off the roof in slow motion, scattering into the darkening sky. Static camera. Film grain. Atmospheric, eerie mood. 4 seconds.
>
> **Expected Result:** Moody static wide shot with one dynamic element (birds), strong atmosphere, dusk lighting.

---

### 8. Flashback/Memory Shot

**System Prompt:**
You write AI video prompts that evoke memory or flashback sequences. You use visual cues like overexposure, soft focus, and warm tones to signal "this is a memory."

**User Prompt:**
Write an AI video prompt for a flashback/memory sequence of [SCENE]. Include the visual treatment that makes it feel like a memory. 4 seconds.

Scene: [WHAT'S HAPPENING IN THE MEMORY]
Era: [WHEN IT'S SET]

**Example Output:**
> **Video Prompt:**
> Overexposed, dreamy footage of children running through a wheat field in summer. Camera at low angle, slightly out of focus. Super 8mm film quality — grain, light leaks, saturated warm tones. Children are faceless silhouettes laughing. Golden hour light. Slow motion. The footage gently sways as if the camera is in someone's hand who is also walking. Nostalgic, bittersweet mood. 4 seconds.
>
> **Expected Result:** Dreamy, overexposed memory-style footage with film grain, warm tones, and slow motion.

---

## Social Media & Marketing (9-16)

### 9. Logo Animation

**System Prompt:**
You write AI video prompts for logo reveals and brand animations. Clean, professional, suitable for intros and outros.

**User Prompt:**
Write an AI video prompt for a logo animation. The logo [DESCRIPTION] should materialize from [EFFECT]. Background: [COLOR/STYLE]. 3 seconds.

Logo description: [WHAT THE LOGO LOOKS LIKE]
Effect: [HOW IT APPEARS]
Background: [SETTING]

**Example Output:**
> **Video Prompt:**
> Dark background. Golden particles swirl in from the edges of frame, converging at center. Particles form into a geometric wolf head logo. As the logo solidifies, the particles settle and emit a brief warm pulse of light. Logo holds steady for 1 second. Minimal, premium aesthetic. Black background with subtle gradient. 3 seconds.
>
> **Expected Result:** Particle-to-logo formation animation, premium feel, clean finish.

---

### 10. Social Media Hook Video

**System Prompt:**
You write AI video prompts designed to stop the scroll in social feeds. High visual impact in the first 0.5 seconds. Bold colors, unexpected movement, or striking imagery.

**User Prompt:**
Write an AI video prompt for a scroll-stopping social media clip about [TOPIC]. Must grab attention within the first frame. Include text overlay suggestion. 3 seconds.

Topic: [YOUR CONTENT TOPIC]
Platform: [TIKTOK/REELS/SHORTS]
Vibe: [ENERGETIC/DRAMATIC/QUIRKY]

**Example Output:**
> **Video Prompt:**
> Extreme close-up of an eye opening suddenly. Iris reflects a stock market chart going vertical. Camera rapidly pulls back to reveal a person sitting at a trading desk surrounded by multiple monitors showing green candles. Dramatic zoom-out effect. Dark room, screens casting blue light on their face. Fast, punchy movement. 3 seconds.
>
> **Text Overlay Suggestion:** "This pattern printed AGAIN" (bold white text, center frame, frame 1)
>
> **Expected Result:** Fast, dramatic eye-to-reveal sequence designed for maximum first-frame impact.

---

### 11. Testimonial Background Video

**System Prompt:**
You write AI video prompts for background loops behind testimonial text or quotes. Subtle movement, professional, non-distracting.

**User Prompt:**
Write an AI video prompt for a looping background behind a customer testimonial. Subtle movement, [BRAND COLORS], and professional atmosphere. 4-second loop.

Brand colors: [YOUR COLORS]
Industry: [YOUR FIELD]
Mood: [PROFESSIONAL/WARM/MODERN]

**Example Output:**
> **Video Prompt:**
> Soft-focus abstract background with slowly moving navy blue and gold gradient. Gentle bokeh light particles drift upward. Subtle organic movement — like light through water. Clean, professional, non-distracting. Designed to loop seamlessly. Space in center for text overlay. 4-second loop.
>
> **Expected Result:** Seamless looping abstract background suitable for text overlay, brand-colored, professional.

---

### 12. Before/After Transition

**System Prompt:**
You write AI video prompts for before/after comparison clips. The transition between states should be smooth and satisfying.

**User Prompt:**
Write an AI video prompt showing a before/after transformation of [SUBJECT]. Include the transition effect between states. 4 seconds.

Subject: [WHAT TRANSFORMS]
Before state: [STARTING CONDITION]
After state: [ENDING CONDITION]

**Example Output:**
> **Video Prompt:**
> Split screen effect: left side shows a cluttered, disorganized desk with papers, coffee cups, tangled cables. A clean white wipe sweeps from left to right, revealing the same desk completely organized — minimal setup, clean cable management, single plant, MacBook centered. Camera static. Clean lighting on both sides. Satisfying, ASMR-like transition. 4 seconds.
>
> **Expected Result:** Clean split-screen wipe transition from messy to organized desk.

---

### 13. App/Product Demo Loop

**System Prompt:**
You write AI video prompts for product demo animations. Focus on hands interacting with devices, screen content, and clean presentation.

**User Prompt:**
Write an AI video prompt showing hands interacting with [DEVICE/PRODUCT] in a lifestyle setting. Include specific interactions. 4 seconds.

Device: [WHAT THEY'RE USING]
Interaction: [WHAT THEY'RE DOING]
Setting: [WHERE]

**Example Output:**
> **Video Prompt:**
> Close-up of hands holding a smartphone at a coffee shop table. Thumb scrolls through a clean, minimal app interface. Screen shows data dashboard with charts updating in real-time. Shallow depth of field — latte and pastry blurred in background. Natural morning light from window. Camera angle: slightly above, looking down at phone. Clean, modern, aspirational. 4 seconds.
>
> **Expected Result:** Lifestyle product usage shot with realistic hand interaction and shallow depth of field.

---

### 14. Countdown/Hype Video

**System Prompt:**
You write AI video prompts for countdown and hype content — product launches, events, announcements. High energy, dynamic visuals.

**User Prompt:**
Write an AI video prompt for a hype/countdown video for [EVENT/LAUNCH]. Include dynamic movement, bold visuals, and space for text. 4 seconds.

Event: [WHAT YOU'RE HYPING]
Energy level: [HIGH/MEDIUM]
Visual style: [NEON/MINIMAL/CINEMATIC]

**Example Output:**
> **Video Prompt:**
> Dynamic sequence of rapid cuts: neon numbers (3, 2, 1) appearing and shattering. Each number is 3D chrome floating in a dark void. As each shatters, particles fly toward camera. After "1" shatters, a bright flash reveals empty space for logo/text. Neon purple and electric blue palette. High energy, bass-drop timing. 4 seconds.
>
> **Expected Result:** Fast-paced 3D countdown with chrome numbers shattering, neon color scheme.

---

### 15. Nature B-Roll

**System Prompt:**
You write AI video prompts for nature b-roll — footage used as background or cutaway in longer videos. Peaceful, high quality, specific.

**User Prompt:**
Write an AI video prompt for nature b-roll of [NATURAL SCENE]. Include specific details that make it feel photorealistic. 4 seconds.

Scene: [SPECIFIC NATURE SCENE]
Season: [TIME OF YEAR]
Camera: [STATIC/SLOW PAN/AERIAL]

**Example Output:**
> **Video Prompt:**
> Slow-motion close-up of rain droplets hitting the surface of a still forest pond. Each droplet creates perfect concentric ripples. Camera is inches above the water surface. Lush green ferns and moss visible in soft focus behind the pond. Overcast light, rich green tones. Sound of gentle rainfall. Macro lens feel. 4 seconds at 120fps slow motion.
>
> **Expected Result:** Macro-style slow-motion water droplets on a forest pond, rich green tones, meditative feel.

---

### 16. Urban Lifestyle Shot

**System Prompt:**
You write AI video prompts for urban lifestyle content — the kind of footage used in brand videos, travel content, or city-focused social media.

**User Prompt:**
Write an AI video prompt for an urban lifestyle shot in [CITY/SETTING]. Include human element, city details, and mood. 4 seconds.

City/setting: [WHERE]
Human element: [WHAT THE PERSON IS DOING]
Time of day: [WHEN]

**Example Output:**
> **Video Prompt:**
> Medium shot of a woman sitting at an outdoor café in Paris, typing on a laptop. She pauses, sips espresso, and looks up at passing pedestrians with a slight smile. Background: classic Parisian streetscape with balconied buildings, trees, pedestrians walking by. Morning light. Warm European color grade — slightly desaturated, golden tones. Shallow depth of field on the woman, street life blurred behind. 4 seconds.
>
> **Expected Result:** European lifestyle shot with shallow DOF, warm tones, and natural human moment.

---

## Abstract & Artistic (17-25)

### 17. Liquid Metal Morphing

**System Prompt:**
You write AI video prompts for abstract visual effects. Liquid, morphing, and particle effects that work as backgrounds, transitions, or standalone art.

**User Prompt:**
Write an AI video prompt for a liquid metal morphing effect that transforms from [SHAPE A] to [SHAPE B]. Include material properties and lighting. 4 seconds.

Shape A: [STARTING FORM]
Shape B: [ENDING FORM]
Material: [CHROME/GOLD/MERCURY]

**Example Output:**
> **Video Prompt:**
> Liquid chrome sphere floating in a dark void slowly morphs into a human face profile. The metal surface reflects studio ring lights as it stretches and reshapes. Smooth, organic transformation — no hard edges. Mercury-like surface tension visible at the edges. Dramatic side lighting creating strong contrast between reflective highlights and deep shadows. Black background. 4 seconds.
>
> **Expected Result:** Chrome liquid morphing from sphere to face, high-quality reflections, dramatic lighting.

---

### 18. Ink Drop in Water

**System Prompt:**
You write AI video prompts for fluid dynamics effects. Ink, smoke, and liquid interactions in slow motion.

**User Prompt:**
Write an AI video prompt for ink/paint dropping into water with [COLOR SCHEME]. Include camera angle and fluid behavior. 4 seconds.

Colors: [YOUR COLOR PALETTE]
Behavior: [SLOW BLOOM / RAPID DISPERSAL / CONTROLLED STREAMS]
Camera: [TOP-DOWN / SIDE VIEW / MACRO]

**Example Output:**
> **Video Prompt:**
> Top-down macro view of deep indigo ink dropping into perfectly still water. The ink blooms outward in fractal tendrils, mixing with a second drop of liquid gold. The two colors dance and interweave — never fully mixing, creating organic marble-like patterns. Crystal clear water. White background beneath the water surface. Extreme slow motion. 4 seconds.
>
> **Expected Result:** Top-down ink bloom in water with two contrasting colors, fractal patterns, slow motion.

---

### 19. Particle System Animation

**System Prompt:**
You write AI video prompts for particle-based abstract animations. Stars, dust, fireflies, embers — controlled particle behavior.

**User Prompt:**
Write an AI video prompt for a particle animation where [PARTICLE TYPE] forms [SHAPE/PATTERN]. Include movement behavior and color. 4 seconds.

Particles: [TYPE — stars/embers/dust/fireflies]
Shape: [WHAT THEY FORM]
Color scheme: [YOUR PALETTE]

**Example Output:**
> **Video Prompt:**
> Thousands of tiny warm golden firefly-like particles swirling in a dark forest clearing. The particles slowly converge into the shape of a tree, holding the form for 1 second, then dissolving back into random flight. Camera slowly pushes in. Bokeh background of real forest trees. Warm amber glow from particles. Magical, enchanted atmosphere. 4 seconds.
>
> **Expected Result:** Particle convergence into tree shape, firefly aesthetic, warm glow, forest setting.

---

### 20. Abstract Texture Loop

**System Prompt:**
You write AI video prompts for seamlessly looping abstract textures. These serve as backgrounds, wallpapers, or design elements.

**User Prompt:**
Write an AI video prompt for a seamless looping abstract texture. Material: [TEXTURE TYPE]. Movement: [DIRECTION/BEHAVIOR]. Colors: [PALETTE]. 4-second loop.

Texture: [MARBLE/FABRIC/ORGANIC/GEOMETRIC]
Movement: [FLOWING/PULSING/ROTATING]
Colors: [YOUR COLORS]

**Example Output:**
> **Video Prompt:**
> Seamlessly looping macro view of flowing liquid marble. Deep black base with veins of molten copper and white gold flowing slowly from right to left. The veins pulse gently as if alive. Surface has a high-gloss wet appearance. Camera stationary, looking straight down. Designed for perfect loop — end frame matches start frame. 4-second loop.
>
> **Expected Result:** Seamless looping marble texture, dark with metallic veins, macro perspective.

---

### 21. Double Exposure Effect

**System Prompt:**
You write AI video prompts for double exposure effects — two overlapping images or video layers creating artistic composites.

**User Prompt:**
Write an AI video prompt for a double exposure combining [SUBJECT A] with [SUBJECT B]. Include blend mode and movement. 4 seconds.

Subject A: [PRIMARY SUBJECT]
Subject B: [OVERLAY SUBJECT]
Blend: [HOW THEY COMBINE]

**Example Output:**
> **Video Prompt:**
> Double exposure: silhouette of a person's head and shoulders filled with a time-lapse of a city at night. The city lights and traffic flow within the silhouette boundary. Outside the silhouette: solid dark background. The person slowly turns their head. City lights shift and move with the rotation. Cinematic, contemplative mood. 4 seconds.
>
> **Expected Result:** Person silhouette filled with city timelapse, rotation movement, artistic composite.

---

### 22. Geometric Pattern Animation

**System Prompt:**
You write AI video prompts for geometric and mathematical patterns. Clean lines, satisfying movement, design-oriented.

**User Prompt:**
Write an AI video prompt for a geometric pattern that [BEHAVIOR]. Style: [MINIMAL/ORNATE/SACRED GEOMETRY]. Colors: [PALETTE]. 4 seconds.

Behavior: [GROWS/ROTATES/TESSELLATES/FRACTALS]
Style: [YOUR AESTHETIC]
Colors: [YOUR COLORS]

**Example Output:**
> **Video Prompt:**
> Sacred geometry pattern growing from a central point. Starts as a single golden circle on black background. Lines extend outward forming the Flower of Life pattern — each new circle appearing in sequence. Lines are thin, precise, gold on black. The pattern rotates slowly as it builds. Minimal, meditative, mathematical. Clean vector-like rendering. 4 seconds.
>
> **Expected Result:** Growing sacred geometry pattern, gold on black, sequential build animation.

---

### 23. Miniature/Tilt-Shift Effect

**System Prompt:**
You write AI video prompts that create tilt-shift miniature effects — making real-world scenes look like tiny models.

**User Prompt:**
Write an AI video prompt for a tilt-shift miniature view of [SCENE]. Include the blur zones and any speed manipulation. 4 seconds.

Scene: [WHAT TO MAKE LOOK MINIATURE]
Angle: [HIGH ANGLE / OVERHEAD]

**Example Output:**
> **Video Prompt:**
> High-angle overhead shot of a busy city intersection with tilt-shift effect applied. Cars and buses move in slightly sped-up motion, looking like toys. Heavy blur at top and bottom of frame, sharp focus in the center strip. Pedestrians look like tiny figurines. Bright, slightly oversaturated colors enhancing the model-like appearance. 4 seconds at 2x speed.
>
> **Expected Result:** Tilt-shift miniature city intersection, toy-like appearance, sped-up movement.

---

### 24. Surreal Environment

**System Prompt:**
You write AI video prompts for surreal, impossible environments. Dreamlike spaces that couldn't exist in reality but feel photorealistic.

**User Prompt:**
Write an AI video prompt for a surreal environment where [IMPOSSIBLE ELEMENT]. Maintain photorealistic rendering. 4 seconds.

Impossible element: [WHAT MAKES IT SURREAL]
Mood: [DREAMLIKE/UNSETTLING/WHIMSICAL]
Camera: [MOVEMENT TYPE]

**Example Output:**
> **Video Prompt:**
> A long hallway with doors on both sides, but the hallway curves upward like the inside of a cylinder — doors visible on the ceiling and walls. A person walks forward normally while the hallway architecture bends around them. Warm afternoon sunlight streams through windows at impossible angles. Photorealistic rendering. Inception-like gravity distortion. Camera follows the person. Dreamlike, slightly unsettling. 4 seconds.
>
> **Expected Result:** Curved hallway defying gravity, photorealistic, Inception-style architecture.

---

### 25. Text Animation / Kinetic Typography

**System Prompt:**
You write AI video prompts for text and typography animations. Words that move, transform, or interact with the environment.

**User Prompt:**
Write an AI video prompt for kinetic typography showing the word "[WORD]" in [STYLE]. Include how the text appears, moves, and settles. 3 seconds.

Word: [YOUR TEXT]
Style: [3D/HANDWRITTEN/NEON/LIQUID]
Background: [SETTING]

**Example Output:**
> **Video Prompt:**
> The word "CREATE" appears one letter at a time, each letter a different material: C=chrome, R=wood, E=neon pink, A=stone, T=glass, E=liquid gold. Each letter drops from above and lands on a dark surface with material-appropriate physics — the chrome bounces, the glass shatters slightly at the edge, the liquid gold splashes. Once all letters land, they align and a pulse of light unifies them. 3 seconds.
>
> **Expected Result:** Multi-material kinetic text with physics-based landing, mixed media aesthetic.

---

*25 AI video prompts. Match the category to your content need. Generate. Edit. Publish.*
