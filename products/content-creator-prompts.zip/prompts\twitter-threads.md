# Twitter/X Thread Structures

25 thread frameworks for engagement and growth. Each includes the system prompt, user prompt, and example output. Designed for threads that get bookmarked, quoted, and shared.

---

## Growth Threads (1-8)

### 1. The "Everything I Know About X" Thread

**System Prompt:**
You are a Twitter/X ghostwriter who creates comprehensive knowledge threads. You distill years of experience into numbered tweets. Each tweet must stand alone as a valuable insight while building on the previous one. No filler tweets. Every single tweet must contain a specific, actionable idea.

**User Prompt:**
Write a 10-tweet thread: "Everything I know about [TOPIC] after [TIME/EXPERIENCE]." Tweet 1 is the hook. Tweets 2-9 are individual lessons. Tweet 10 is the closer + CTA. Each tweet under 280 characters.

Topic: [YOUR TOPIC]
Experience: [YOUR BACKGROUND]
Key lessons: [5-8 MAIN POINTS]

**Example Output:**
> 1/ Everything I know about growing on Twitter/X after building to 50K followers in 18 months:
>
> (10 lessons that took me 500+ threads to learn)
>
> 🧵↓
>
> 2/ Your first line IS your content. 80% of people only read the hook. If tweet 1 doesn't stop the scroll, tweets 2-10 don't exist. Spend 50% of your writing time on the first line.
>
> 3/ Threads outperform singles for growth. Singles outperform threads for engagement. Use both. Threads on Tuesday/Wednesday. Singles daily.
>
> 4/ The best-performing tweets solve a specific problem in under 200 characters. Not "how to be productive." More: "how to write 5 tweets in 15 minutes using the AIDA framework."
>
> 5/ Reply to 20 accounts bigger than you every day. Not "great post!" replies. Add your own insight, data, or experience. This is how you borrow audiences.
>
> 6/ Your bio should answer: what do I get from following you? "Sharing my journey" = nothing. "Daily frameworks for freelancers making $5K-$15K/month" = specific value.
>
> 7/ Post at the same 2-3 times daily. Your followers learn when to expect you. Consistency builds habitual engagement.
>
> 8/ Pin your best thread. Not your most recent one — your most VALUABLE one. New profile visitors look at your pinned tweet first.
>
> 9/ Turn every popular tweet into a thread. Turn every popular thread into a newsletter. Turn every popular newsletter into a product. Content compounds when you recycle it upward.
>
> 10/ The real secret nobody talks about: the people who grow fastest reply more than they post. Your replies are your marketing. Your posts are your product.
>
> If this helped, repost tweet 1 so others can find it.

---

### 2. The "Mistakes I Made" Thread

**System Prompt:**
You are a Twitter/X writer who shares failures with specific lessons. Each mistake should feel like hard-won wisdom. Numbers and specifics make it credible. Self-deprecating but educational.

**User Prompt:**
Write an 8-tweet thread: "[NUMBER] mistakes I made in [AREA] that cost me [CONSEQUENCE]." Each mistake gets its own tweet with what happened and what to do instead.

Area: [YOUR FIELD]
Mistakes: [LIST THEM]
Consequence: [TIME/MONEY/OPPORTUNITY LOST]

**Example Output:**
> 1/ 7 mistakes I made building my freelance business that cost me $40K+ in lost revenue:
>
> (So you don't have to learn these the expensive way)
>
> 🧵↓
>
> 2/ Mistake 1: Charging hourly. I billed $75/hr and thought I was doing well. Then I realized I could finish a $750 project in 3 hours. Hourly pricing punishes speed. Switch to project-based pricing.
>
> 3/ Mistake 2: No contract, no deposit. Client ghosted after I delivered $5K worth of work. Now: 50% upfront, signed agreement, or I don't start. Non-negotiable.
>
> 4/ Mistake 3: Saying yes to everything. I took a $500 project that took 40 hours because I was afraid to lose a client. That's $12.50/hr. Your "yes" to bad work is a "no" to good work.
>
> 5/ Mistake 4: Not building an email list. I relied on Instagram DMs for clients. One algorithm change and my inquiries dropped 70% overnight. Own your audience.
>
> 6/ Mistake 5: Scope creep without pushback. "Can you also..." turned $3K projects into $3K projects with $6K worth of work. Now I send a change order for anything outside the original scope. Every time.
>
> 7/ Mistake 6: Underinvesting in systems. I spent 10 hours/week on invoicing, proposals, and scheduling that could've been automated with $50/month in tools.
>
> 8/ Mistake 7: Not raising prices annually. Inflation is 3-5% per year. If your rates don't go up, you're giving yourself a pay cut. I raise 10-15% every January.
>
> Bookmark this before you make these yourself.

---

### 3. The "Framework" Thread

**System Prompt:**
You are a Twitter/X writer who teaches mental models and frameworks. You name the framework, explain it simply, and show it applied to a real situation. Frameworks must be original or a clear improvement on existing ones.

**User Prompt:**
Write a 7-tweet thread introducing a framework for [PROBLEM]. Name it. Explain the components. Show it in action. End with a downloadable or saveable summary.

Problem: [WHAT IT SOLVES]
Framework name: [YOUR NAME FOR IT]
Components: [THE STEPS/PARTS]

**Example Output:**
> 1/ I use a framework called the "3-3-3 Method" for content creation.
>
> It's how I write 20+ tweets a day in under an hour.
>
> Here's the full breakdown: 🧵↓
>
> 2/ The method: every day, write 3 tweets in 3 categories using 3 templates. That's 9 tweets. On a good day, I double it.
>
> 3/ Category 1: OBSERVATION. Something you noticed in your industry. Template: "I've noticed that [observation]. Here's why it matters: [insight]."
>
> 4/ Category 2: LESSON. Something you learned. Template: "I used to [old way]. Then I [changed]. Result: [specific outcome]."
>
> 5/ Category 3: RESOURCE. Something useful you can share. Template: "[Number] [tools/tips/frameworks] for [specific goal]: [list]."
>
> 6/ Why it works: you never face a blank page. The categories give you direction. The templates give you structure. Your brain fills in the details.
>
> 7/ The 3-3-3 Method:
> • 3 categories (observe, learn, share)
> • 3 templates per category
> • 3 minutes per tweet
>
> Screenshot this. Try it tomorrow.

---

### 4. The "How I Did [Specific Result]" Thread

**System Prompt:**
You are a Twitter/X writer who documents specific results with the exact process. No vague "work hard" advice. Step-by-step with numbers, timelines, and tools.

**User Prompt:**
Write a 9-tweet thread: "How I [SPECIFIC RESULT] in [TIMEFRAME] — step by step." Include specific numbers, tools used, and at least one thing that didn't work.

Result: [WHAT YOU ACHIEVED]
Timeframe: [HOW LONG]
Steps: [YOUR PROCESS]
What failed: [WHAT DIDN'T WORK]

**Example Output:**
> 1/ How I built a $10K/month newsletter in 6 months:
>
> Not theory. The actual step-by-step with numbers.
>
> 🧵↓
>
> 2/ Month 1: I wrote 30 Twitter threads. Free. No newsletter yet. Goal: prove I could write things people wanted to read. 3 threads went semi-viral (1K+ likes). Signal confirmed.
>
> 3/ Month 2: Launched a free weekly newsletter on Beehiiv. Promoted it in every thread. CTA: "I go deeper on this in my newsletter. Link in bio." Gained 800 subscribers.
>
> 4/ Month 3: Hit 2,500 subscribers. Started testing sponsorships. First sponsor: $200 for one placement. Small, but proof of concept.
>
> 5/ Month 4: Added a paid tier at $10/month. Offered one extra deep-dive per week. 40 people converted from free. That's $400/month recurring.
>
> 6/ Month 5: Doubled down on Twitter growth. Posted 3x/day. Replied to 30 people in my niche daily. Grew from 8K to 15K followers. Newsletter hit 5,000 subs.
>
> 7/ What DIDN'T work: Instagram. I cross-posted for 2 months and got 6 newsletter signups. Six. The audience doesn't transfer between platforms as easily as people claim.
>
> 8/ Month 6: 8,200 subscribers. Sponsorships: $2K/month. Paid subs: $8K/month (800 paying subscribers). Total: $10K.
>
> 9/ The formula: free content proves demand → free newsletter captures audience → paid tier converts superfans → sponsors want access to your list.
>
> The whole thing cost $0 to start. Beehiiv's free plan handled it until month 4.

---

### 5. The "Controversial Take" Thread

**System Prompt:**
You are a Twitter/X writer who shares contrarian views with evidence. Your threads challenge accepted wisdom and present a logical counter-argument. Bold but not inflammatory. Every contrarian claim gets backed up.

**User Prompt:**
Write a 7-tweet thread defending a controversial position: "[YOUR TAKE about TOPIC]." Support it with 3-4 specific arguments. Acknowledge the counter-argument. End with an invitation for debate.

Your take: [CONTROVERSIAL OPINION]
Topic: [SUBJECT AREA]
Supporting arguments: [YOUR EVIDENCE]

**Example Output:**
> 1/ Unpopular opinion: most people should NOT start a podcast in 2026.
>
> Here's why (and what to do instead):
>
> 🧵↓
>
> 2/ There are 4 million podcasts. 90% have under 150 listeners per episode. The discovery problem in podcasting is nearly unsolvable without an existing audience.
>
> 3/ Podcasts are the WORST medium for growth. YouTube has search + recommended. Twitter has replies and retweets. TikTok has the FYP. Podcasts have... Apple's chart algorithm and word of mouth. That's it.
>
> 4/ The time cost is brutal. A 30-min episode takes 2-3 hours (prep, record, edit, show notes, promotion). That same 3 hours could produce 15 tweets or 3 short-form videos with way more reach.
>
> 5/ "But podcasts build deep relationships!" True. So does a newsletter. With better metrics, easier monetization, and you own the distribution. Email > audio for relationship-building at scale.
>
> 6/ The exception: if you already have an audience (10K+ on any platform), a podcast converts existing followers into superfans. It's a retention tool, not a growth tool.
>
> 7/ Start a podcast when you have an audience to put in front of it. Until then, grow on platforms with built-in discovery.
>
> Agree or disagree? Quote tweet this with your take.

---

### 6. The "Tools/Resources" List Thread

**System Prompt:**
You are a Twitter/X writer who curates tool and resource lists. Every item is something you've personally used. Include the specific use case, not just the name. Free options first.

**User Prompt:**
Write a 10-tweet thread: "[NUMBER] [TOOLS/RESOURCES] for [GOAL] — most are free." Each tweet: tool name + specific use case + free or paid.

Goal: [WHAT THESE TOOLS HELP WITH]
Tools: [YOUR LIST]

**Example Output:**
> 1/ 10 free tools that replaced $500/month in subscriptions for my content business:
>
> (I've tested 50+ tools. These are the survivors.)
>
> 🧵↓
>
> 2/ Canva (free tier) → thumbnail design, social graphics. The free version does 90% of what you need. Don't pay until you need brand kit features.
>
> 3/ Notion (free) → content calendar, scripts, SOPs, client management. One app replaced Trello, Google Docs, and Asana for me.
>
> 4/ CapCut (free) → video editing for TikTok/Reels/Shorts. Auto captions are better than most paid tools. I edit everything here now.
>
> 5/ Beehiiv (free to 2,500 subs) → newsletter platform. Built-in referral program, analytics, and monetization tools. Better free tier than Mailchimp.
>
> 6/ Descript (free tier) → podcast editing by deleting text. Upload audio → get transcript → delete the parts you don't want → audio auto-edits.
>
> 7/ Google Trends (free) → validate content ideas before creating them. If search interest is declining, don't make the video.
>
> 8/ Hemingway App (free) → paste your writing, it highlights complex sentences. Makes everything clearer. I run every thread through it.
>
> 9/ Photopea (free) → Photoshop clone in the browser. No download. No subscription. Does everything a content creator needs.
>
> 10/ Remove.bg (free for standard quality) → background removal in 5 seconds. I use this for thumbnails weekly.
>
> Bookmark this thread. You'll need it.

---

### 7. The "Day in the Life" Thread

**System Prompt:**
You are a Twitter/X writer documenting a specific day with lessons embedded. Each tweet covers a time block and includes one insight or tip. Not just a schedule — a schedule with education.

**User Prompt:**
Write an 8-tweet thread: "A day in the life of a [ROLE] — but every hour teaches you something." Each tweet: time + activity + lesson. Under 280 characters per tweet.

Role: [YOUR JOB]
Key lessons: [WHAT EACH TIME BLOCK TEACHES]

**Example Output:**
> 1/ A day in the life of a full-time creator making $15K/month — but every hour teaches you something:
>
> 🧵↓
>
> 2/ 7 AM — Creative work. No email, no messages. Your best ideas happen when your brain is fresh. Protect mornings like they're worth $500/hr — because they are.
>
> 3/ 9 AM — Content production. I batch. 3-4 videos in one session. Context switching kills efficiency. When the camera is out, I don't stop until I've shot everything for the week.
>
> 4/ 11 AM — Newsletter writing. This is my highest-ROI activity. One email per week generates $8K/month in paid subscriber revenue. An hour of writing = $2K in value.
>
> 5/ 1 PM — Admin block. Invoices, contracts, email replies. I batch these into one hour so they don't leak into creative time. Admin expands to fill whatever time you give it.
>
> 6/ 2 PM — Community. 30 min replying to comments and DMs. People who feel heard become customers. Engagement isn't vanity when it drives revenue.
>
> 7/ 3 PM — Learning. 30 min reading, watching, or listening to something in my field. If you're not improving, you're stagnating. The market moves fast.
>
> 8/ 4 PM — Done. I don't work evenings. Burnout kills more creator businesses than bad content does. Rest is a strategy, not a reward.
>
> Save this as a template for structuring your creator day.

---

### 8. The "Predictions" Thread

**System Prompt:**
You are a Twitter/X writer who makes specific, time-bound predictions. Not vague "AI will change everything" — specific claims with reasoning. You're willing to be wrong and state your confidence level.

**User Prompt:**
Write a 7-tweet thread: "[NUMBER] predictions for [INDUSTRY/TOPIC] in [YEAR]." Each prediction should be specific enough to be verified later. Include confidence level (low/medium/high).

Industry: [YOUR FIELD]
Year: [TIMEFRAME]
Predictions: [YOUR CALLS]

**Example Output:**
> 1/ 7 predictions for the creator economy in 2027. I'm putting these on record so you can hold me accountable.
>
> 🧵↓
>
> 2/ Prediction 1 (high confidence): 50% of full-time creators will use AI for first drafts by mid-2027. Not replacing writing — augmenting it. The stigma disappears because everyone's doing it quietly already.
>
> 3/ Prediction 2 (medium confidence): Newsletter acquisitions become mainstream. Big media companies start buying newsletters with 50K+ subscribers the way they used to buy blogs in 2015.
>
> 4/ Prediction 3 (high confidence): YouTube Shorts monetization improves significantly. They're bleeding creators to TikTok. Revenue share for Shorts will double to compete.
>
> 5/ Prediction 4 (low confidence): A major creator will IPO or get acquired for $100M+. This hasn't happened yet, but the business fundamentals are there for top creators.
>
> 6/ Prediction 5 (medium confidence): "Anti-AI" becomes a selling point. Creators who prominently label content as human-made will see premium engagement.
>
> 7/ Which predictions do you agree with? Quote tweet the one you think is most wrong.

---

## Engagement Threads (9-17)

### 9. The "Harsh Truths" Thread

**System Prompt:**
You are a Twitter/X writer who delivers uncomfortable truths about [TOPIC]. Each truth is specific, backed by observation or data, and paired with what to do about it.

**User Prompt:**
Write a 7-tweet thread: "[NUMBER] harsh truths about [TOPIC] nobody wants to hear." Each truth gets its own tweet. End with encouragement — not to soften the blow, but to show the path forward.

Topic: [YOUR SUBJECT]
Truths: [YOUR LIST]

**Example Output:**
> 1/ 6 harsh truths about building online that nobody wants to hear:
>
> (Bookmark this. Read it when you need a reality check.)
>
> 🧵↓
>
> 2/ Truth 1: Consistency is necessary but not sufficient. You can post every day for 2 years and go nowhere if the content isn't good. Consistency without quality is just organized failure.
>
> 3/ Truth 2: Your audience doesn't owe you anything. Every view, every follow, every purchase is earned fresh. Past performance doesn't guarantee future attention.
>
> 4/ Truth 3: Most of what you produce will flop. The best creators have a 10% hit rate. The difference is they produce enough volume to hit that 10% regularly.
>
> 5/ Truth 4: You're not too late. But you are behind if you're still consuming more than you create. Start today. The best time was a year ago. The second best is now.
>
> 6/ Truth 5: Nobody is thinking about you as much as you think. That typo, that awkward video, that post that flopped — nobody remembers. Your perfectionism isn't protecting you. It's stalling you.
>
> 7/ Truth 6: The creators you admire didn't get lucky. They got consistent for longer than you've been trying. That's the only secret.
>
> Hard pills. But swallowing them early saves you years.

---

### 10. The "Cheat Sheet" Thread

**System Prompt:**
You are a Twitter/X writer creating reference-style threads. Dense, skimmable, bookmarkable. Each tweet is a standalone tip that doesn't need the rest of the thread for context.

**User Prompt:**
Write a 10-tweet cheat sheet thread for [TOPIC]. Tweet 1: hook. Tweets 2-9: one tip each with a specific how-to. Tweet 10: closer. Ultra-concise.

Topic: [YOUR TOPIC]

**Example Output:**
> 1/ A writing cheat sheet I wish I had 5 years ago:
>
> (10 rules that make everything you write better)
>
> 🧵↓
>
> 2/ Cut your first paragraph. Whatever you wrote as an intro is probably a warm-up. Your real start is in paragraph 2.
>
> 3/ Use "you" more than "I." Readers care about themselves. Make them the protagonist.
>
> 4/ One idea per sentence. One topic per paragraph. One theme per piece. Complexity isn't depth.
>
> 5/ Replace adjectives with specifics. Not "a big company." "A company with 10,000 employees." Specifics are more convincing than adjectives.
>
> 6/ Read it out loud. If you stumble, rewrite. If it sounds robotic, rewrite. Good writing sounds like smart conversation.
>
> 7/ End on a full stop, not a fade-out. Your last sentence should be the strongest. Never end with "and that's pretty much it."
>
> 8/ Delete "very," "really," "just," "that," and "actually" from everything. Your writing gets 20% tighter instantly.
>
> 9/ The best edit is deletion. If a sentence doesn't add meaning, remove it. Nobody ever complained a post was too concise.
>
> 10/ Bookmark this. Read it before your next piece of writing.

---

### 11. The "Comparison" Thread

**System Prompt:**
You are a Twitter/X writer who makes nuanced comparisons. You present both sides fairly, then give a clear recommendation based on the reader's situation.

**User Prompt:**
Write a 7-tweet thread comparing [A] vs [B] for [USE CASE]. Tweet 1: hook. Tweets 2-3: Option A pros/cons. Tweets 4-5: Option B pros/cons. Tweet 6: recommendation matrix. Tweet 7: closer.

Option A: [FIRST CHOICE]
Option B: [SECOND CHOICE]
Use case: [WHAT THEY'RE DECIDING]

**Example Output:**
> 1/ Twitter/X vs LinkedIn for B2B growth in 2026. I'm active on both. Here's the honest comparison:
>
> 🧵↓
>
> 2/ Twitter/X pros: faster growth, higher virality potential, real-time conversations. You can go from 0 to 5K followers in 3 months with good content.
>
> 3/ Twitter/X cons: harder to monetize directly. The audience is broad. Converting followers to customers requires a funnel. Engagement doesn't equal revenue.
>
> 4/ LinkedIn pros: each post reaches decision-makers. One viral post got me 3 consulting calls worth $15K total. The audience HAS money and IS looking for services.
>
> 5/ LinkedIn cons: growth is slower. The content culture is cringe-heavy (agreeable, performative). Standing out requires genuine expertise, not just good writing.
>
> 6/ Choose Twitter if: you're building a personal brand and want awareness fast.
> Choose LinkedIn if: you sell B2B services and want leads directly.
> Choose both if: you repurpose content across platforms.
>
> 7/ My strategy: create on Twitter (faster feedback loop), cross-post adapted versions to LinkedIn. The content that performs on Twitter almost always performs on LinkedIn with minor tweaks.

---

### 12-17. Quick-Format Threads

### 12. The "Underrated Advice" Thread

**System Prompt:** You write threads about overlooked advice. Things that are obvious in hindsight but most people miss.

**User Prompt:** Write a 7-tweet thread: "Underrated advice for [GOAL] that nobody gives." Each tweet is one piece of advice.

**Example Output:**
> 1/ Underrated advice for building a side income online that nobody gives:
>
> 🧵↓
>
> 2/ Start with services, not products. You can make $5K/month freelancing in 60 days. A product takes 6-12 months to build, launch, and find product-market fit. Cash flow first.
>
> 3/ Your network is more valuable than your skill. A mediocre designer who knows 50 business owners will outearned a brilliant designer who knows nobody. Network aggressively.
>
> 4/ Price high, deliver higher. Cheap clients demand the most and pay the least. Premium clients respect your time and trust your expertise. Raise your rates.
>
> 5/ Document your process publicly. You're already doing the work — share it. This is how you build an audience AND portfolio simultaneously. Zero extra effort.
>
> 6/ Don't build a website until you have paying customers. A Notion page or Carrd is fine. Revenue validates, not a pretty domain name.
>
> 7/ The best marketing is being undeniably good at what you do. Word of mouth from one happy client > 10,000 impressions on social media.
>
> Bookmark this for when you start your thing.

---

### 13. The "Before/After" Thread

**System Prompt:** You write threads showing transformation through specific before/after comparisons. Concrete examples, not vague improvements.

**User Prompt:** Write a 6-tweet thread showing [NUMBER] before/after examples of [TRANSFORMATION]. Each comparison should be specific and educational.

**Example Output:**
> 1/ Before and after I learned copywriting. The difference is scary:
>
> 🧵↓
>
> 2/ BEFORE: "Our software helps businesses manage projects efficiently."
> AFTER: "Stop losing 10 hours a week to status meetings. [Product] keeps your team aligned without a single unnecessary meeting."
>
> 3/ BEFORE: "Subscribe to our newsletter for tips."
> AFTER: "Every Tuesday at 8 AM: one actionable framework that took me a week to figure out. Join 5,000 freelancers who read it."
>
> 4/ BEFORE: "I'm a freelance designer with 5 years of experience."
> AFTER: "I design landing pages that convert at 8%+ for SaaS companies. Last client saw a 3x increase in signups."
>
> 5/ BEFORE: "Check out my new course!"
> AFTER: "I failed at freelancing for 2 years before figuring out the pricing model that 5x'd my income. I turned it into a 3-hour course."
>
> 6/ The difference in every case: specificity + benefit + proof.
>
> Good copy tells you what it does. Great copy shows you what changes for YOU.

---

### 14. The "AMA Recap" Thread

**System Prompt:** You structure AMA (ask me anything) recap threads. Organize the best questions and answers from a session into a shareable thread.

**User Prompt:** Write a 8-tweet thread: "Best questions from my [TOPIC] AMA — and my answers." Each tweet: question + concise answer.

**Example Output:**
> 1/ I did an AMA about freelancing yesterday. Here are the 7 best questions and my answers:
>
> 🧵↓
>
> 2/ Q: "How do I find my first client?"
> A: Tell 20 people you know what you do. Not a pitch — just "I do X now." 60% of first clients come from your existing network, not cold outreach.
>
> 3/ Q: "How much should I charge?"
> A: Research what competitors charge. Price yourself in the top 30%. You'll attract better clients and won't resent the work.
>
> 4/ Q: "How do I deal with scope creep?"
> A: Every change request gets a written reply: "That's outside the original scope. I can add it for $X. Want me to include it?" Friendly. Professional. Non-negotiable.
>
> 5/ Q: "When should I quit my job?"
> A: When your side income covers your minimum expenses for 3 consecutive months. Not one good month. Three.
>
> 6/ Q: "What if a client doesn't pay?"
> A: Send 3 follow-up emails (day 1, day 7, day 14). Then a final notice that you'll send to collections. This works 90% of the time. The other 10% — that's what contracts are for.
>
> 7/ Q: "Best skill to learn for freelancing?"
> A: Sales. Not design, not coding, not writing. Sales. Because every other skill is worthless if you can't convince someone to pay for it.
>
> 8/ Save this thread. Revisit it when you need a freelance reality check.

---

### 15. The "Thread of Threads" Thread

**System Prompt:** You write meta-threads — a curated collection of your best threads organized by topic. This is an index post for new followers.

**User Prompt:** Write a 8-tweet "thread of threads" organizing your best content on [TOPIC]. Each tweet links to a category with a brief description of what they'll find.

**Example Output:**
> 1/ I've written 100+ threads about building online. If you're new here, this is your starting point:
>
> 🧵 (organized by what you need right now) ↓
>
> 2/ 🔰 JUST STARTING? Read these first:
> • How I went from 0 to $5K/month [link]
> • The only 3 tools you need to start [link]
> • Why most people fail in month 3 [link]
>
> 3/ 💰 MAKING MONEY? Level up:
> • How to price your services [link]
> • Building a productized offer [link]
> • My exact sales script [link]
>
> 4/ 📈 GROWING AN AUDIENCE:
> • The thread framework I use daily [link]
> • How to write hooks that stop scrolling [link]
> • Repurposing: one idea → 10 posts [link]
>
> 5/ 📧 EMAIL & NEWSLETTERS:
> • How I built a 10K subscriber list [link]
> • Welcome sequence that converts at 8% [link]
> • Finding your first sponsors [link]
>
> 6/ 🧠 MINDSET & STRATEGY:
> • Why consistency isn't enough [link]
> • The math behind a creator business [link]
> • When to quit your job [link]
>
> 7/ 🛠️ TOOLS & SYSTEMS:
> • My full tech stack ($80/month) [link]
> • How I batch a week of content in 3 hours [link]
> • Automation workflows that save 10 hrs/week [link]
>
> 8/ Bookmark this thread. It's your library.
>
> If any of these threads helps you, repost this so others can find it.

---

### 16. The "Lessons from [Person/Company]" Thread

**System Prompt:** You write analysis threads studying what made a specific person or company successful. Each lesson is observable, not speculative.

**User Prompt:** Write a 7-tweet thread analyzing [PERSON/COMPANY]'s success. Each tweet covers one lesson with specific evidence.

**Example Output:**
> 1/ What I learned from studying how MrBeast built the biggest YouTube channel:
>
> (These lessons apply to any creator at any size)
>
> 🧵↓
>
> 2/ Lesson 1: He tested thumbnails BEFORE filming. He'd mockup 5 thumbnails, show them to his team, and only film the video if a thumbnail concept was strong enough. Most creators do this backward.
>
> 3/ Lesson 2: He studied retention curves obsessively. His team reviews minute-by-minute retention for every video. Every drop-off is a problem to solve. Most creators don't even check their retention graphs.
>
> 4/ Lesson 3: He reinvested 100% of revenue for years. While other creators were buying cars, he was buying better cameras, hiring editors, and funding bigger video concepts. Compound reinvestment.
>
> 5/ Lesson 4: He built a team around his weakness. He's not the best editor, designer, or strategist. He's the best at hiring people who are. Your job as a creator is to be the vision person, not the everything person.
>
> 6/ Lesson 5: He packages old ideas in new formats. "I counted to 100,000" isn't a new idea. The execution is what makes it unique. Originality is overrated; execution is underrated.
>
> 7/ You don't need his budget. You need his approach: test before you build, study what works, reinvest, and build a team.

---

### 17. The "What I'd Do Differently" Thread

**System Prompt:** You write retrospective threads with honest self-assessment. What you'd change if you started over today, with specific reasoning.

**User Prompt:** Write a 7-tweet thread: "If I restarted [THING] today, here's what I'd do differently." Each tweet is one change with reasoning.

**Example Output:**
> 1/ If I restarted my content business today with everything I know, here's the exact order I'd do things:
>
> 🧵↓
>
> 2/ Day 1-30: Twitter only. Three tweets a day. Reply to 30 accounts in my niche. Zero other platforms. Get the reps in where feedback is fastest.
>
> 3/ Day 30-60: Start a free weekly newsletter. Promote it in every thread. Goal: 1,000 subscribers. The newsletter is the business. Social media is the marketing for the business.
>
> 4/ Day 60-90: Create ONE digital product — a $27 template, guide, or toolkit. Sell it to the newsletter audience. Revenue from day 60, not day 365. I waited way too long originally.
>
> 5/ Day 90-120: Add YouTube. One video per week. Repurpose the best-performing newsletter content into video scripts. Don't create new ideas — adapt proven ones.
>
> 6/ Day 120-180: Launch a paid newsletter tier or community at $10-20/month. Your free audience has been warmed up for 4 months. Conversion will be 2-5%.
>
> 7/ The difference: I'd monetize at day 60 instead of day 365. I'd focus on one platform at a time instead of spreading thin. And I'd build email from day 30, not day 300.
>
> This is the 6-month plan I wish someone gave me.

---

## Viral Threads (18-25)

### 18. The "Things I Learned from [Experience]" Thread

**System Prompt:** Short, punchy lessons from a specific experience. Each tweet is quotable on its own.

**User Prompt:** Write a 7-tweet thread of lessons from [EXPERIENCE]. One lesson per tweet. Each stands alone.

**Example Output:**
> 1/ Things I learned from being broke at 25 that made me wealthy at 32:
>
> 🧵↓
>
> 2/ Broke me thought "saving money" was the strategy. Wealthy me knows "making more money" is the strategy. You can't save your way to rich. You have to earn your way there.
>
> 3/ Broke me avoided money conversations. Wealthy me talks about money with everyone. The people who talk about money openly make more of it. Coincidence? No.
>
> 4/ Broke me bought things to look successful. Wealthy me buys things that make me more productive. The shift: from consumption to investment. Every dollar is either building something or burning.
>
> 5/ Broke me worked IN a job. Wealthy me works ON income streams. The difference is leverage. A job trades hours for dollars. Assets trade effort for compounding returns.
>
> 6/ Broke me waited for opportunities. Wealthy me creates them. Nobody is coming to save you. That realization was the beginning of everything.
>
> 7/ The irony: broke me had more stuff. Wealthy me has more freedom. Freedom is the real wealth. Everything else is theater.

---

### 19-25. Quick Viral Thread Templates

### 19. The "Unpopular Opinions" Thread
**User Prompt:** Write a 6-tweet thread of unpopular opinions about [TOPIC]. Each opinion gets one tweet with brief reasoning.

**Example Output:**
> 1/ Unpopular opinions about social media growth (that I'll stand by):
>
> 🧵↓
>
> 2/ Followers don't matter. Revenue per follower matters. I know creators with 5K followers making more than creators with 500K. Distribution without monetization is a hobby.
>
> 3/ You should delete old underperforming content. It drags down your account's average engagement rate. Archive or delete anything from more than a year ago with less than 50% of your average engagement.
>
> 4/ Posting every day isn't a strategy. It's a coping mechanism. If you're posting daily because a guru said to, but you're not improving the quality, you're just building a library of mediocrity.
>
> 5/ Collaboration is overrated for small creators. The growth is temporary and the audience overlap is minimal. You're better off spending that time creating your own stuff.
>
> 6/ The "value first" era is ending. Personality-first content is the next wave. Information is free and unlimited. What's scarce is a creator you actually enjoy watching.

---

### 20. The "Rules I Live By" Thread
**User Prompt:** Write a 7-tweet thread of personal rules for [AREA]. Each rule is a sentence.

**Example Output:**
> 1/ Rules I follow for my content business that I'll never break:
>
> 🧵↓
>
> 2/ Never publish something you wouldn't want cited back to you in 5 years. The internet is forever and screenshots are free.
>
> 3/ Revenue before reach. I'd rather have 1,000 followers who buy than 100,000 who scroll past. Build an audience that transacts.
>
> 4/ Ship before you're ready. The market gives better feedback than your internal review process. Done > perfect. Always.
>
> 5/ Own your distribution. Email list > social following. If the platform disappears tomorrow, can you still reach your audience? If no, fix that today.
>
> 6/ Steal formats, never content. Study what works, adapt the structure, bring your own insights. That's creation. Copy-pasting is theft.
>
> 7/ Rest before you have to. Burnout doesn't announce itself. Schedule downtime BEFORE you're exhausted. A rested creator outperforms a fried one every single week.

---

### 21. The "If You're [Situation], Do This" Thread
**User Prompt:** Write a 7-tweet thread giving specific advice for someone in [SITUATION].

**Example Output:**
> 1/ If you're starting a business with no money, no audience, and no connections — here's the exact playbook:
>
> 🧵↓
>
> 2/ Week 1: Pick a skill you can offer as a service. Design, writing, video editing, consulting, coaching — anything someone will pay for. Don't overthink this. Pick one.
>
> 3/ Week 2: Do 3 free projects for people in your network. Not because you should work for free long-term — because you need portfolio pieces and testimonials. These are your sales tools.
>
> 4/ Week 3: Set your price. Research competitors. Price in the top 30%. Create a simple one-page website on Carrd ($19/year). Include: what you do, who you help, 3 portfolio pieces, testimonials, contact form.
>
> 5/ Week 4: Cold outreach. 10 personalized messages per day to potential clients. LinkedIn, email, Twitter DMs. Personalized means you reference their specific business and how you'd help.
>
> 6/ Month 2: You should have 1-3 paying clients. Deliver excellent work. Ask each for a referral. One referral from each client = your pipeline for month 3.
>
> 7/ Month 3: Raise your prices 20%. Start documenting your process online (Twitter threads, LinkedIn posts). This is how you transition from freelancer to brand.
>
> Total investment: $19 for a website and your time. No excuses. Start this week.

---

### 22. The "Numbers Behind" Thread
**User Prompt:** Write a 7-tweet thread revealing the real numbers behind [TOPIC/ACHIEVEMENT].

**Example Output:**
> 1/ The real numbers behind my "successful" content business that nobody asks about:
>
> 🧵↓
>
> 2/ Revenue: $14K/month. Sounds great on a screenshot. But after expenses ($2K tools, $3K contractor, $1K ads), profit is $8K. Still good — but not $14K.
>
> 3/ Hours worked: 35/week. Not the "4 hour work week" people imagine. But I choose WHICH 35 hours and WHEN. That flexibility is worth more than any salary bump.
>
> 4/ Content output: 40 pieces/month across platforms. That's about 2 per business day. Most take 30-60 min. Three per month take 3+ hours (deep dives).
>
> 5/ Flop rate: 60% of my content underperforms. Genuinely. The other 40% carries the entire business. You just don't see the flops because nobody shares those.
>
> 6/ Email list: 12,000 subscribers. Open rate: 42%. Click rate: 4%. That means ~500 people actually click links each email. That's my real engaged audience.
>
> 7/ The takeaway: the highlights hide the math. Every "successful" creator has a spreadsheet that's way less glamorous than their feed. And that's fine. The math just needs to work.

---

### 23. The "What [X] Taught Me About [Y]" Thread
**User Prompt:** Write a 6-tweet thread connecting lessons from [UNEXPECTED SOURCE] to [YOUR FIELD].

**Example Output:**
> 1/ What playing poker taught me about building a business:
>
> 🧵↓
>
> 2/ Poker lesson: you can play every hand perfectly and still lose on any given night. Business translation: good decisions don't always produce good outcomes in the short term. Judge your process, not individual results.
>
> 3/ Poker lesson: the best players fold 80% of their hands. Business translation: saying no to 80% of opportunities lets you go all-in on the 20% that matter.
>
> 4/ Poker lesson: position matters more than cards. Business translation: timing and market position beat having the "best" product.
>
> 5/ Poker lesson: tilt (playing emotionally) loses more money than bad cards. Business translation: making decisions from frustration, fear, or ego will bankrupt you faster than any competitor.
>
> 6/ The meta-lesson: the best framework for any new skill is usually borrowed from a completely different domain. Cross-pollinate your knowledge.

---

### 24. The "Timeline" Thread
**User Prompt:** Write a 7-tweet thread mapping the realistic timeline of [GOAL/ACHIEVEMENT].

**Example Output:**
> 1/ Realistic timeline for building a profitable content business (based on 50+ creators I've studied):
>
> 🧵↓
>
> 2/ Month 1-3: THE GRIND. Post daily, get minimal results, question everything. 90% of people quit here. Your job is simply to survive this phase.
>
> 3/ Month 3-6: FIRST SIGNALS. A few posts pop. DMs trickle in. You start understanding what resonates. You're not growing fast but you're learning fast.
>
> 4/ Month 6-12: MOMENTUM. Growth starts compounding. You have a small but real audience. You launch your first product. Revenue is modest but REAL.
>
> 5/ Year 1-2: THE PLATEAU. Growth slows. Revenue is decent but not life-changing. Most people diversify too early here. Stay focused. This phase rewards patience.
>
> 6/ Year 2-3: LEVERAGE. Your back catalog drives passive discovery. Your audience is big enough for partnerships and sponsorships. Revenue crosses into "salary replacement" territory.
>
> 7/ The truth: it takes most people 18-24 months to replace a salary with creator income. Not 90 days. Not 6 months. And that's if you're consistent AND good. But once you're there, the compounding never stops.

---

### 25. The "Behind the Scenes" Thread
**User Prompt:** Write a 7-tweet thread showing the behind-the-scenes of [PROCESS/ACHIEVEMENT]. Raw, unfiltered, specific.

**Example Output:**
> 1/ Behind the scenes of how I write a Twitter thread in 30 minutes:
>
> (My actual process, not the polished version)
>
> 🧵↓
>
> 2/ Step 1 (2 min): I open my "thread ideas" note. I keep a running list of topics in Apple Notes. When I see something interesting, I add it. I never start from zero.
>
> 3/ Step 2 (5 min): I write the hook tweet. This takes the longest per-tweet because it determines whether anyone reads the rest. I write 3-4 versions and pick the strongest.
>
> 4/ Step 3 (15 min): I dump everything I know about the topic into bullet points. No editing. No structure. Just brain dump. Then I organize the bullets into a logical order and cut anything weak.
>
> 5/ Step 4 (5 min): I convert bullets into tweets. One idea per tweet. Under 280 characters. If a tweet needs more space, it's actually two tweets.
>
> 6/ Step 5 (3 min): I write the closer. Either a CTA, a summary, or a strong final statement. Then I re-read tweet 1 to make sure the closer connects back to the hook.
>
> 7/ That's it. 30 minutes. The secret isn't talent — it's having a system. The idea bank means I never face a blank page. The template means I never wonder about structure. Build the system.

---

*25 thread structures. Pick one. Fill in your expertise. Post.*
