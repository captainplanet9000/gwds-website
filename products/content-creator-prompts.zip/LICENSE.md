# License — Content Creator Mega Pack

**© 2026 Gamma Waves Design Studio. All rights reserved.**

## What You Can Do

✅ Use these prompts for your own content creation (personal or business)
✅ Use the outputs generated from these prompts commercially
✅ Modify prompts to fit your workflow
✅ Use within a team at a single company/organization
✅ Store in your personal prompt library or tool

## What You Cannot Do

❌ Resell, redistribute, or share this pack (or any portion of it)
❌ Include these prompts in a competing product
❌ Upload to public repositories, forums, or shared drives
❌ Claim authorship of the prompt frameworks
❌ Use automated tools to mass-distribute the contents

## Team Use

One purchase = one team. If you're an agency with multiple clients who each want their own copy, each client needs a separate license.

## Liability

These prompts are tools. The output depends on your inputs and your AI model. We're not responsible for content generated using these prompts. You're responsible for reviewing and approving everything before publishing.

## Questions?

Contact: hello@gwds.co
