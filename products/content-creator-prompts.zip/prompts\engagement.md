# Engagement Boosting Prompts

25 prompts for creating content that drives comments, shares, saves, and conversation. Covers polls, questions, hot takes, interactive content, and community-building posts.

---

## Question & Poll Prompts (1-8)

### 1. The "This or That" Poll

**System Prompt:**
You are a social media engagement strategist. You create polls and question posts that are easy to answer, mildly divisive, and relevant to your audience's identity. The best engagement posts require almost zero effort to respond to but feel personally meaningful.

**User Prompt:**
Create a "This or That" poll for [NICHE] with [NUMBER] pairs. Each pair should: relate to a genuine preference/decision in the niche, be roughly 50/50 divisive, and spark follow-up discussion. Include the post caption and the poll options.

Niche: [YOUR NICHE]
Number of pairs: [5-8]
Platform: [INSTAGRAM STORIES / TWITTER / LINKEDIN]

**Example Output:**
> **Caption:** "Settle this once and for all. Reply with your picks — I'll share the results tomorrow."
>
> 1. Notion or Obsidian?
> 2. Morning creator or night owl creator?
> 3. Grow on one platform or be everywhere?
> 4. Charge hourly or project-based?
> 5. Post daily or 3x/week quality?
> 6. Niche down or go broad?
>
> **Why these work:** Each pair has genuine defenders on both sides. Nobody can scroll past without having an opinion.

---

### 2. The "Fill in the Blank" Post

**System Prompt:**
You create fill-in-the-blank engagement posts. The blank should be easy to complete but reveal something personal or opinionated. One-tap engagement.

**User Prompt:**
Create [NUMBER] fill-in-the-blank prompts for [NICHE]. Each blank should be completable in 1-5 words and reveal something about the commenter's experience or preference.

Niche: [YOUR NICHE]
Number: [5-10]

**Example Output:**
> 1. "The tool I couldn't run my business without is ________."
> 2. "My biggest content regret is ________."
> 3. "I'd be 10x more productive if I stopped ________."
> 4. "The best career advice I ever got was ________."
> 5. "If I could only use one social platform, it would be ________."
>
> **Caption:** "Fill in at least one. I'll go first: [YOUR ANSWER]."

---

### 3. The "Unpopular Opinion" Discussion Starter

**System Prompt:**
You write posts that invite unpopular opinions from the audience. You lead with your own hot take to set the tone, then open the floor. The take must be genuine enough to provoke thoughtful disagreement.

**User Prompt:**
Write an unpopular opinion post about [TOPIC] that will generate debate. Lead with your take, explain your reasoning in 2-3 sentences, then ask for others' unpopular opinions. Keep it respectful but bold.

Topic: [YOUR NICHE/TOPIC]
Your hot take: [YOUR ACTUAL OPINION]

**Example Output:**
> "Unpopular opinion: content calendars are a waste of time for solo creators.
>
> They give you the illusion of productivity without actual output. I've never met a creator who says 'my content calendar changed my life.' But I've met dozens who spent more time planning than creating.
>
> Just make the thing. What's YOUR unpopular opinion about content creation? Drop it below — no judgment zone."

---

### 4. The "Rate Your" Self-Assessment

**System Prompt:**
You create self-assessment engagement posts where the audience rates themselves on a scale. These work because people love self-evaluation and can't resist categorizing themselves.

**User Prompt:**
Create a "rate yourself" post for [AUDIENCE] on [TOPIC]. Include 5-7 criteria they rate 1-10 and a scoring guide (what their total means). Make it shareable.

Audience: [WHO YOU'RE TALKING TO]
Topic: [WHAT THEY'RE RATING]

**Example Output:**
> "Rate your content game (1-10 each):
>
> → Consistency: __ /10
> → Hook quality: __ /10
> → Visual design: __ /10
> → Engagement with audience: __ /10
> → Monetization strategy: __ /10
>
> 40-50: You're ahead of 95% of creators
> 30-39: Solid foundation — one area to improve
> 20-29: Pick your weakest score and focus there for 30 days
> Under 20: You're early. That's fine. Start with consistency.
>
> Drop your score below. No lying."

---

### 5. The "Would You Rather" Question

**System Prompt:**
You create "would you rather" questions for specific niches. Both options must be genuinely difficult to choose between — not an obvious answer. The best ones reveal values and priorities.

**User Prompt:**
Create [NUMBER] "would you rather" questions for [NICHE]. Each should present a genuine dilemma with no obvious correct answer. Both options should have clear pros and cons.

Niche: [YOUR NICHE]
Number: [5-8]

**Example Output:**
> 1. Would you rather have 100K followers who barely engage or 5K who buy everything you sell?
> 2. Would you rather go viral once a year or get steady 5K views on every post?
> 3. Would you rather have the perfect content strategy but no time to execute or unlimited time but no strategy?
> 4. Would you rather master one platform completely or be decent on five?
> 5. Would you rather create the content you love that grows slowly or content you're bored of that grows fast?

---

### 6. The Emoji Response Post

**System Prompt:**
You create posts where people respond with emojis only. Extremely low-friction engagement. The emojis must be distinct enough that the responses create interesting data.

**User Prompt:**
Create an emoji-response post about [TOPIC]. Assign specific emojis to specific answers. Make it fun and easy to participate.

Topic: [YOUR TOPIC]

**Example Output:**
> "How's your content creation going this week?
>
> 🔥 = crushing it, best week in months
> 😤 = the algorithm hates me specifically
> 🤷 = posted and prayed
> 😴 = haven't posted, don't @ me
> 📈 = slow but steady growth
>
> Drop your emoji. Be honest."

---

### 7. The "Caption This" Post

**System Prompt:**
You set up "caption this" engagement posts. You describe an image or scenario and ask the audience to provide the best caption. Comedy-driven, community-building.

**User Prompt:**
Write a "caption this" post for [SCENARIO/IMAGE DESCRIPTION]. The scenario should be relatable to [NICHE] and have obvious comedic potential. Include your own caption to set the tone.

Scenario: [DESCRIBE THE IMAGE/SITUATION]
Niche: [YOUR AUDIENCE]

**Example Output:**
> [Image: person staring at a blank screen with 47 open tabs]
>
> "Caption this. I'll start: 'The creative process.'
>
> Best caption gets featured in my story. Go."

---

### 8. The "Confession" Thread

**System Prompt:**
You create safe-space confession posts where the audience shares something they usually don't admit. Vulnerability breeds engagement. You lead by example.

**User Prompt:**
Write a confession-style engagement post for [NICHE]. Lead with your own confession that's relatable and slightly embarrassing. Invite others to share theirs. Keep it light, not heavy.

Niche: [YOUR FIELD]
Your confession: [SOMETHING RELATABLE]

**Example Output:**
> "Creator confession time. I'll go first:
>
> I've spent more money on courses about content creation than I've made from content creation.
>
> Your turn. What's your creator confession? No judgment — just solidarity. I guarantee someone else has the same one."

---

## Hot Takes & Debate (9-16)

### 9. The "Ranking" Post

**System Prompt:**
You create ranking posts that provoke disagreement. You rank things in your niche in an order that will make people argue in the comments. Some placements should be deliberately provocative.

**User Prompt:**
Create a ranking of [THINGS IN YOUR NICHE] from best to worst. Make at least 2 placements deliberately controversial. Frame it as "my ranking" to invite disagreement.

Things to rank: [LIST]
Niche: [YOUR FIELD]

**Example Output:**
> "My social media platform ranking for creators in 2026:
>
> 1. YouTube (not close)
> 2. Email (yes, email is a platform)
> 3. TikTok
> 4. LinkedIn (better than you think)
> 5. Twitter/X
> 6. Instagram (I said what I said)
> 7. Facebook
>
> Instagram stans, come at me. I have data."

---

### 10. The "Agree or Disagree" Post

**System Prompt:**
You write posts with bold statements that force a binary response. The statement should be defensible but not universally agreed upon.

**User Prompt:**
Write [NUMBER] "agree or disagree" statements about [TOPIC]. Each should be bold enough to split the audience roughly 60/40. Include one that you personally disagree with to show range.

Topic: [YOUR NICHE]
Number: [5-8]

**Example Output:**
> "Agree or disagree:
>
> 1. 'Consistency is more important than quality when starting out.'
> 2. 'You should never work for free, even for exposure.'
> 3. 'AI-generated content will be indistinguishable from human content by 2027.'
> 4. 'Having a niche is overrated for personal brands.'
> 5. 'Engagement rate matters more than follower count for brand deals.'
>
> Reply with A (agree) or D (disagree) for each. Then fight about it."

---

### 11. The "Hot Take Ladder" Post

**System Prompt:**
You write escalating hot take posts — starting mild and getting progressively spicier. The escalation itself becomes entertaining.

**User Prompt:**
Write a hot take ladder with 5 levels for [NICHE]. Level 1: mild. Level 5: career-threatening. Each should be your real opinion.

Niche: [YOUR FIELD]

**Example Output:**
> "My hot takes, ranked by how much trouble I'll get in:
>
> 🟢 Level 1: Posting at 'optimal times' barely matters if your content is good.
> 🟡 Level 2: Most online courses could be replaced by 3 blog posts and discipline.
> 🟠 Level 3: Follower count is the most overrated metric in content creation.
> 🔴 Level 4: 80% of 'LinkedIn influencers' have never built a real business.
> 💀 Level 5: If you can't explain what you do in one sentence, you don't have a business. You have a hobby with expenses.
>
> Which one made you the angriest? That's the one we should discuss."

---

### 12. The "Bingo Card" Post

**System Prompt:**
You create bingo card posts for specific audiences. Each square is a relatable experience. People tag themselves and share.

**User Prompt:**
Create a [NICHE] bingo card with 16 squares (4x4). Each square: a relatable experience specific to [AUDIENCE]. At least 4 should be slightly embarrassing. Include a caption.

Niche: [YOUR FIELD]
Audience: [WHO RELATES]

**Example Output:**
> **Caption:** "[Niche] Bingo — how many can you check off? I got 12/16. Tell me your score."
>
> | Bought a course, never finished it | Spent 2 hrs on a caption, got 5 likes | Changed your niche 3+ times | Have a "start tomorrow" list |
> | Compares yourself to someone with 100x your followers | Made a content calendar, abandoned it in a week | Googled "is my content good" | Went viral once, couldn't replicate it |
> | Screenshot motivational tweets instead of acting on them | Spent more on tools than you've earned | Refreshed analytics 10x in an hour | Said "just be authentic" then panicked about what to post |
> | Started a podcast, released 3 episodes | Told yourself "quality over quantity" to justify not posting | Drafted 20 posts, published 3 | Actually made money from content (rare square) |

---

### 13-16. Quick Engagement Prompts

### 13. The "If You Know, You Know" Post
**User Prompt:** Write an "IYKYK" post with [NUMBER] insider references that only people in [NICHE] would understand. The more niche-specific, the more it builds community.

**Example Output:**
> "If you know, you know:
> → The 'posted, 0 views after 10 min' panic refresh
> → Saving 47 trending audios you'll never use
> → The dopamine hit when a stranger saves your post
> → Explaining to your family that 'content creator' is a real job
> → The 2 AM 'I should just get a normal job' spiral followed by the 2 PM 'never mind I love this'
>
> How many hit? Tag someone who lives this."

---

### 14. The "Challenge" Post
**User Prompt:** Create a mini challenge for [AUDIENCE]: do [SPECIFIC THING] for [TIMEFRAME] and report back. Must be achievable in under 15 minutes.

**Example Output:**
> "7-day engagement challenge: reply to 10 comments on other creators' posts every day for 7 days. Not spam — genuine replies that add value. Watch what happens to YOUR engagement by day 7. Who's in? Reply 'IN' and I'll check on you next week."

---

### 15. The "Story Time" Request Post
**User Prompt:** Write a post asking your audience to share their story about [SPECIFIC EXPERIENCE]. Lead with your story. Make it feel safe and interesting.

**Example Output:**
> "What's your 'it almost didn't happen' story? Mine: I almost didn't publish the blog post that got me my biggest client. It sat in drafts for 3 weeks because I thought it wasn't good enough. That 'not good enough' post led to a $15K project. Your turn — what almost didn't happen?"

---

### 16. The "Roast Me" Post
**User Prompt:** Write a "roast my [THING]" post where you invite constructive criticism from your audience. Vulnerability + humor = engagement.

**Example Output:**
> "Roast my content strategy. Rules: be specific (not just 'it's bad'), be constructive (what would you change), and be funny if possible. I can take it. I'll implement the best suggestion and credit you. Go."

---

## Community Building (17-25)

### 17. The "Introduce Yourself" Post

**System Prompt:**
You create community introduction posts that make people actually want to participate. Not generic "tell me about yourself" — structured enough that responses are interesting.

**User Prompt:**
Write an "introduce yourself" post for [COMMUNITY/AUDIENCE]. Give a specific 3-4 field template people fill in. Lead with your own.

Community: [YOUR AUDIENCE]

**Example Output:**
> "New here? Or been here a while? Either way — introduce yourself.
>
> Template:
> → What you do:
> → How long you've been doing it:
> → Biggest win this year:
> → What you're working on right now:
>
> I'll go first:
> → Content strategist
> → 4 years
> → Hit 10K email subscribers
> → Building my first course
>
> Your turn. I reply to every one."

---

### 18. The "Help Thread" Post
**User Prompt:** Create a post that invites your audience to ask for help or share what they're stuck on. Position yourself as the facilitator, not the sole answerer.

**Example Output:**
> "Drop your biggest current challenge below. One sentence.
> The community (and I) will help. Last time we did this, 3 people solved problems they'd been stuck on for weeks.
>
> Rules: be specific. Not 'how do I grow?' More like 'how do I write hooks for B2B content?' Specific = solvable."

---

### 19. The "Celebrate Your Win" Post
**User Prompt:** Write a post that invites people to share recent wins — big or small. Normalize celebrating progress. Lead with your own small win, not a humble brag.

**Example Output:**
> "Win Wednesday. Drop your win from this week — big or small.
>
> Mine: I finally automated my email welcome sequence instead of manually sending them. Took 2 hours. Should've done it a year ago. But it's done.
>
> No win is too small. Did you post something? Send a pitch? Get out of bed and open your laptop? That counts."

---

### 20. The "Resource Share" Post
**User Prompt:** Create a post where you share one resource and ask your audience to share theirs. Crowdsourced value.

**Example Output:**
> "Share one tool, app, or resource that genuinely changed how you work. Not a vague recommendation — something specific you use regularly.
>
> I'll start: Hemingway App (free) — I paste every email and blog post through it. It catches every sentence that's too complex. Saved me from sounding like a robot more times than I can count.
>
> Your turn. One resource. Go."

---

### 21. The "Myth Busting" Discussion
**User Prompt:** Post a common myth in [NICHE] and invite your audience to share myths they've debunked. Creates discussion + shows expertise.

**Example Output:**
> "Myth: you need to post every day to grow.
> Reality: I tested this. 3x/week with better content outperformed daily posting by 40% in reach.
>
> What's a myth in YOUR field that you've personally debunked? Share the myth AND what's actually true."

---

### 22. The "Throwback" Post
**User Prompt:** Write a throwback post comparing where you were [TIME AGO] vs. now. Include specific, measurable differences. Invite others to share their growth.

**Example Output:**
> "1 year ago vs. today:
> → Followers: 800 → 12K
> → Email list: 0 → 3,200
> → Revenue from content: $0 → $4K/month
> → Confidence: 2/10 → 7/10
>
> The numbers don't matter as much as the trajectory. Where were you 1 year ago vs. now? Share your before/after."

---

### 23-25. Final Engagement Prompts

### 23. The "Tag Someone" Post
**User Prompt:** Write a post with a specific, positive reason to tag someone. Not generic "tag a friend" — a genuine reason.

**Example Output:**
> "Tag someone who's been quietly creating great content without enough recognition. No follow-for-follow energy — just genuinely shout out someone doing good work that deserves more eyes. I'll check out every single account tagged."

---

### 24. The "Prediction" Engagement Post
**User Prompt:** Share a prediction about [NICHE] and ask people if they agree. Include a clear timeline so it can be revisited.

**Example Output:**
> "Prediction: by December 2026, more money will be made through newsletters than through Instagram for solo creators. The math is already trending this way. Agree or disagree? Let's revisit this in 9 months."

---

### 25. The "AMA" Launch Post
**User Prompt:** Write an AMA announcement post for [TOPIC]. Include what you'll answer, when, and for how long. Create urgency.

**Example Output:**
> "AMA: Ask me anything about going full-time as a creator. I've been doing this for 3 years. I'll answer the uncomfortable questions too — income, failures, the parts people don't post about.
>
> Drop your questions below. I'll spend the next 2 hours answering every single one.
>
> Nothing is off limits. If I don't know, I'll say so."

---

*25 engagement prompts. Pick one. Post it. Watch the comments roll in.*
