# Content Creator Mega Pack

**300+ battle-tested prompts for every content platform.**

Stop staring at a blank screen. This pack gives you plug-and-play prompt frameworks for TikTok, YouTube, Instagram, Twitter/X, blogs, email, AI video, and more. Every prompt includes the exact system instruction + user prompt format so you can paste it straight into ChatGPT, Claude, or any LLM.

---

## What's Inside

| File | Prompts | What It Covers |
|------|---------|----------------|
| `prompts/tiktok-hooks.md` | 50 | Viral hook formulas, fill-in-the-blank templates |
| `prompts/youtube-scripts.md` | 30 | Script frameworks, intro hooks, story arcs, CTAs |
| `prompts/instagram-captions.md` | 40 | Caption templates by niche (fitness, tech, lifestyle, food) |
| `prompts/twitter-threads.md` | 25 | Thread structures for engagement and growth |
| `prompts/blog-posts.md` | 30 | Blog outlines, writing prompts, SEO frameworks |
| `prompts/email-sequences.md` | 20 | Welcome, launch, re-engagement, abandoned cart sequences |
| `prompts/ai-video-scripts.md` | 25 | Prompts for Runway, Pika, Sora-style AI video |
| `prompts/brand-voice.md` | 15 | Define and maintain a consistent brand voice |
| `prompts/repurposing.md` | 20 | Turn one piece of content into 10+ formats |
| `prompts/engagement.md` | 25 | Polls, questions, hot takes, engagement drivers |
| **Total** | **280+** | |

## Who This Is For

- Solo creators who need to post consistently without burnout
- Social media managers juggling multiple accounts
- Agencies that need scalable content production
- Anyone using AI tools for content but getting generic output

## How to Use

1. **Pick your platform** — Open the relevant file
2. **Find a prompt** — Browse by number or use the category headers
3. **Copy the System Prompt** — Paste it as your AI's system instruction
4. **Copy the User Prompt** — Fill in the bracketed fields with your specifics
5. **Generate** — Run it and tweak the output to match your voice

### Prompt Format

Every prompt follows this structure:

```
**System Prompt:**
You are a [role]. Your job is to [specific task]...

**User Prompt:**
[The actual instruction with [BRACKETED] fill-in fields]

**Example Output:**
[What good output looks like]
```

## Tips for Best Results

- **Be specific in the brackets.** "[your niche]" works, but "premium men's skincare for guys 25-35" works way better.
- **Chain prompts together.** Use a brand voice prompt first, then feed that into your content prompts.
- **Edit the output.** These prompts get you 80% there. Your voice and judgment bring it to 100%.
- **Save your best combos.** When a prompt + your inputs = fire content, save that exact combo.

## License

Personal and commercial use. See `LICENSE.md` for details.

---

*Built by Gamma Waves Design Studio — [gwds.co](https://gwds.co)*
