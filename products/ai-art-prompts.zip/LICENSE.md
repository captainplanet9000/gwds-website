# License — AI Art Direction Pack

**© 2026 Gamma Waves Design Studio. All rights reserved.**

## What You Can Do

✅ Use these prompts to generate images for personal or commercial projects
✅ Sell artwork/designs created using these prompts as your own
✅ Modify prompts to fit your creative needs
✅ Use within a team at a single company/organization

## What You Cannot Do

❌ Resell, redistribute, or share the prompt pack itself
❌ Include these prompts in a competing prompt product
❌ Upload to public repositories, forums, or shared drives
❌ Claim authorship of the prompt frameworks

## Generated Images

Images you generate using these prompts belong to you, subject to the terms of service of whichever AI platform you use (Midjourney, Stable Diffusion, DALL-E, etc.). Check each platform's commercial use policy.

## Questions?

Contact: hello@gwds.co
