# Midjourney Style Templates

40 Midjourney prompt templates organized by art style. Each includes the prompt, recommended parameters, and expected output description.

---

## Cyberpunk (1-5)

### 1. Cyberpunk Street Scene

**Prompt:**
`Neon-drenched cyberpunk street market in a vertical Asian megacity, holographic advertisements floating above food stalls, rain reflecting pink and cyan neon on wet asphalt, dense crowd of people with cybernetic augmentations, steam rising from street-level ramen shops, towering buildings disappearing into smog above, shot from street level looking up, Blade Runner meets Ghost in the Shell atmosphere --ar 9:16 --v 6 --style raw`

**Parameters:** 9:16 portrait, v6, style raw for photorealistic grit
**Expected Result:** Dense, atmospheric vertical city scene with strong neon color palette and rain-slicked surfaces.

---

### 2. Cyberpunk Portrait

**Prompt:**
`Close-up portrait of a woman with chrome jaw implant and glowing blue circuit tattoos under translucent skin, one eye replaced with a red optic scanner, short asymmetric silver hair, expression is calm and focused, dark background with faint holographic data streams, shot on vintage anamorphic lens with subtle lens flare, cinematic color grade teal and orange --ar 2:3 --v 6`

**Expected Result:** Detailed cyberpunk character portrait with visible augmentation tech and cinematic lighting.

---

### 3. Cyberpunk Vehicle

**Prompt:**
`Sleek autonomous hover taxi floating 3 feet above a rain-soaked cyberpunk highway at night, angular matte black body with glowing orange accent strips, transparent floor showing the road below, background of endless highway with light trails from other vehicles, dense fog diffusing neon city lights in the distance --ar 16:9 --v 6`

**Expected Result:** Futuristic vehicle design with atmospheric environment and strong mood lighting.

---

### 4. Cyberpunk Interior

**Prompt:**
`Interior of a hacker's den in a cyberpunk apartment, walls covered in screens showing scrolling code and surveillance feeds, desk cluttered with circuit boards and energy drink cans, single figure in a hooded jacket typing, window showing neon city skyline, room lit only by screen glow and one red LED strip, fisheye lens distortion --ar 16:9 --v 6`

**Expected Result:** Lived-in cyberpunk workspace with authentic clutter and screen-lit atmosphere.

---

### 5. Cyberpunk Landscape

**Prompt:**
`Panoramic aerial view of a cyberpunk megacity at twilight, enormous corporate towers with holographic logos, lower city obscured by smog and neon glow, flying vehicles creating light trails between buildings, a massive bridge connecting two mega-structures, scale of buildings dwarfs everything, inspired by Syd Mead concept art --ar 21:9 --v 6`

**Expected Result:** Epic scale cyberpunk cityscape with clear architectural hierarchy and atmospheric depth.

---

## Watercolor (6-10)

### 6. Watercolor Landscape

**Prompt:**
`Delicate watercolor painting of a misty mountain lake at dawn, soft wet-on-wet technique, colors bleeding at edges, gentle gradient from warm peach sky to cool blue water reflection, simple pine tree silhouettes in the mid-ground, white paper showing through in highlight areas, authentic watercolor texture with visible brush strokes and paint granulation --ar 3:2 --v 6 --style raw`

**Expected Result:** Authentic watercolor with visible paper texture, bleeding edges, and the transparency unique to the medium.

---

### 7. Watercolor Botanical

**Prompt:**
`Botanical watercolor illustration of a peony in full bloom, scientific illustration precision with artistic softness, deep magenta petals with lighter pink edges, visible veins in leaves, stems painted with a single confident brush stroke, white background, small paint splatters near the base, style of vintage botanical prints from Kew Gardens --ar 3:4 --v 6`

**Expected Result:** Detailed botanical illustration balancing scientific accuracy with watercolor fluidity.

---

### 8. Watercolor Urban Sketch

**Prompt:**
`Loose urban watercolor sketch of a Parisian café corner, hand-drawn ink line work with watercolor washes, slightly crooked perspective adding charm, warm ochre and sienna tones for buildings, cobalt blue for awnings, figures suggested with a few brush strokes, wet puddle reflections on the street, white space left intentionally --ar 4:5 --v 6`

**Expected Result:** Sketchy, charming urban scene that looks like it was painted on location.

---

### 9. Watercolor Animal Portrait

**Prompt:**
`Watercolor portrait of a fox, realistic proportions with painterly execution, warm orange and rust tones with cool blue-grey shadows, one ear slightly translucent where light passes through, eyes detailed and sharp against softer body, paint dripping deliberately from the chin area, white background --ar 1:1 --v 6`

**Expected Result:** Characterful animal portrait with selective detail and deliberate paint drips.

---

### 10. Watercolor Abstract

**Prompt:**
`Abstract watercolor composition, wet-on-wet technique creating organic blooms of indigo, emerald green, and burnt sienna, colors mixing where they meet creating unexpected transitions, salt texture creating crystalline effects in some areas, deliberate white space creating breathing room, meditative and contemplative mood --ar 1:1 --v 6`

**Expected Result:** Organic abstract composition that could work as fine art or high-end print.

---

## Film Noir (11-15)

### 11. Film Noir Detective

**Prompt:**
`Film noir detective standing under a single streetlight on an empty rain-slicked street at night, long shadow stretching behind him, fedora casting shadow over eyes, cigarette smoke curling upward, trench coat collar turned up, 1940s Los Angeles, shot in high contrast black and white, deep blacks and blown-out highlights, Venetian blind shadow pattern across the scene --ar 2:3 --v 6 --style raw`

**Expected Result:** Classic noir composition with dramatic chiaroscuro lighting and period-accurate costume.

---

### 12. Noir Femme Fatale

**Prompt:**
`Film noir portrait of a woman in a dimly lit jazz bar, black dress, pearls catching the light, seated at a bar with a martini glass, one hand holding a cigarette in a long holder, face half in shadow with one eye visible and reflecting bar lights, smoke creating layers of atmosphere, 1940s Hollywood glamour, Kodak Double-X film grain, high contrast black and white --ar 4:5 --v 6`

**Expected Result:** Glamorous noir portrait with period-accurate styling and atmospheric smoke layers.

---

### 13. Noir City Alley

**Prompt:**
`Narrow alley in a 1940s noir city, fire escape ladders casting geometric shadows on brick walls, puddles reflecting a single neon sign saying "BAR," a distant figure walking away silhouetted against foggy light, trash cans and newspapers on the ground, steam from a manhole creating atmosphere, black and white, style of classic Hollywood cinematography --ar 9:16 --v 6`

**Expected Result:** Moody urban environment with strong geometric composition and atmospheric depth.

---

### 14. Noir Interior

**Prompt:**
`Film noir office interior, private detective's desk with a desk lamp creating a cone of light, revolver and whiskey glass in the light, papers scattered, everything outside the lamp cone in deep shadow, Venetian blinds casting striped light on the back wall, clock showing 2 AM, overhead ceiling fan, black and white, high contrast --ar 16:9 --v 6`

**Expected Result:** Classic noir detective office with dramatic single-source lighting.

---

### 15. Color Noir / Neo-Noir

**Prompt:**
`Neo-noir scene in a modern city, lone figure standing at a rain-soaked intersection at 3 AM, single red traffic light reflecting on wet asphalt creating color through an otherwise desaturated scene, modern but empty buildings, long shadows from unseen streetlights, atmospheric fog, shot low angle looking up at the figure, cinematic wide lens --ar 16:9 --v 6`

**Expected Result:** Modern neo-noir with selective color in an otherwise desaturated palette.

---

## Oil Painting (16-20)

### 16. Classical Oil Portrait

**Prompt:**
`Oil painting portrait in the style of Rembrandt, a scholar reading by candlelight, dramatic chiaroscuro, warm golden light on face and hands against deep brown background, visible oil paint texture and brushstrokes, craquelure aging effect, thick impasto in the highlights, smooth glazes in the shadows, mounted in an ornate gold frame --ar 3:4 --v 6`

**Expected Result:** Museum-quality classical portrait with authentic oil painting technique.

---

### 17. Impressionist Landscape

**Prompt:**
`Impressionist oil painting of a sunlit wheat field in Provence, visible directional brushstrokes creating texture and movement, warm gold and cool purple complementary colors, white farmhouse in the middle distance, cypress trees like dark exclamation points, sky painted in broad strokes of cerulean and white, thick paint application creating physical texture, inspired by the light of southern France --ar 3:2 --v 6`

**Expected Result:** Vibrant impressionist landscape with visible paint texture and luminous color.

---

### 18. Abstract Expressionist

**Prompt:**
`Large-scale abstract expressionist oil painting, aggressive gestural brushstrokes in cadmium red and phthalo blue, paint drips and splatters across the canvas, areas of thick impasto next to thin washes, raw canvas showing at edges, sense of physical energy and emotional intensity, inspired by the scale and boldness of mid-century abstract expressionism --ar 4:3 --v 6`

**Expected Result:** Dynamic abstract with visible physicality of paint application.

---

### 19. Still Life Oil Painting

**Prompt:**
`Dutch Golden Age still life oil painting, arrangement of ripe fruit, a partially peeled lemon, crystal wine glass half-full, silver plate reflecting nearby objects, single wilting rose petal on the table, dramatic side lighting creating rich shadows, hyperrealistic detail in glass and metal, slightly dark and moody, vanitas symbolism --ar 4:5 --v 6`

**Expected Result:** Richly detailed still life with Dutch master lighting and symbolic elements.

---

### 20. Contemporary Oil Painting

**Prompt:**
`Contemporary large-format oil painting of an empty swimming pool in harsh California sunlight, David Hockney-inspired palette of turquoise pool, terracotta tiles, and bleached white concrete, flat areas of saturated color, slight distortion in perspective, clean geometric composition, light reflecting off the pool surface creating patterns, late afternoon shadows --ar 16:9 --v 6`

**Expected Result:** Clean, color-forward contemporary painting with Hockney-influenced palette.

---

## Photography Styles (21-30)

### 21. Street Photography

**Prompt:**
`Black and white street photograph of an elderly man feeding pigeons in an Italian piazza, morning light creating long shadows, shallow depth of field with background cafe-goers blurred, decisive moment captured mid-gesture, grain of Tri-X 400 film, shot on Leica M6 with 35mm Summicron lens, Henri Cartier-Bresson composition --ar 3:2 --v 6 --style raw`

**Expected Result:** Authentic-feeling street photograph with decisive moment and classic film grain.

---

### 22. Fashion Editorial

**Prompt:**
`High fashion editorial photograph, model in an oversized architectural white coat standing in a brutalist concrete building, dramatic pose with extended arm touching the wall, harsh directional light from above creating deep shadows, wind blowing fabric, minimal makeup, shot by a fashion photographer for Vogue, medium format film quality, slightly desaturated color palette --ar 3:4 --v 6`

**Expected Result:** High-end fashion editorial with strong pose, architecture, and lighting.

---

### 23. Nature Macro

**Prompt:**
`Extreme macro photograph of morning dew drops on a spider web, each droplet acting as a tiny lens reflecting the blurred garden behind it, shallow depth of field with only the center drops in focus, early morning golden light backlighting the web, bokeh circles from out-of-focus flowers behind, shot on Canon 100mm macro lens at f/2.8 --ar 3:2 --v 6 --style raw`

**Expected Result:** Detailed macro with the dew-drop-as-lens effect and beautiful bokeh.

---

### 24. Documentary Photography

**Prompt:**
`Documentary photograph of fishermen mending nets on a wooden dock at dawn, warm golden light, weathered hands in detailed close-up in the foreground, boats and harbor blurred in background, genuine expressions of concentration, Kodak Portra 800 color palette — warm, slightly desaturated, shot candidly from a low angle, photojournalism composition --ar 3:2 --v 6 --style raw`

**Expected Result:** Authentic documentary image with human connection and warm film tones.

---

### 25. Moody Landscape Photography

**Prompt:**
`Dramatic landscape photograph of an isolated lighthouse on a cliff during a storm, massive waves crashing against rocks below, dark threatening clouds with one break of golden light, long exposure blurring the ocean into mist, lighthouse beacon visible through the spray, shot on Fuji GFX 100S, Lee Big Stopper ND filter, 30-second exposure --ar 16:9 --v 6 --style raw`

**Expected Result:** Dramatic long-exposure seascape with atmospheric conditions.

---

### 26. Food Photography

**Prompt:**
`Overhead food photograph of a rustic Italian dinner spread on a worn wooden table, fresh pasta in a ceramic bowl, scattered cherry tomatoes, torn basil leaves, olive oil in a glass bottle catching the light, parmesan wedge with crumbles, hands reaching for bread at the edge of frame, warm natural light from a window to the left, shot on Phase One XF 100, shallow depth of field --ar 4:5 --v 6`

**Expected Result:** Warm, inviting overhead food spread with natural light and authentic styling.

---

### 27. Vintage Film Photography

**Prompt:**
`Photograph shot on expired Kodak Gold 200 film, beach scene from the 1970s, sun-bleached colors, strong orange and teal color cast, light leaks on the right edge, soft focus from a plastic lens, visible film grain and dust specks, subject is a person walking along the waterline in the distance, nostalgic and dreamy mood --ar 3:2 --v 6 --style raw`

**Expected Result:** Authentic vintage film aesthetic with color shifts, grain, and imperfections.

---

### 28. Minimalist Photography

**Prompt:**
`Minimalist architectural photograph, single geometric concrete staircase against a plain white wall, strong shadow creating a graphic pattern, one person at the top of the stairs providing scale, high key exposure, clean lines, maximum negative space, shot at noon when shadows are shortest and most geometric --ar 1:1 --v 6 --style raw`

**Expected Result:** Clean, geometric minimalist composition with strong use of negative space.

---

### 29. Night Photography

**Prompt:**
`Night photograph of a lone gas station on a desert highway, fluorescent lights creating an oasis of cold white light in the dark, long exposure star trails in the sky above, one car parked with headlights off, warm tungsten light from the station office contrasting with cool exterior lights, inspired by Edward Hopper's isolation --ar 16:9 --v 6 --style raw`

**Expected Result:** Cinematic night scene with contrasting light temperatures and Hopper-esque isolation.

---

### 30. Double Exposure

**Prompt:**
`In-camera double exposure photograph, silhouette of a woman's profile filled with a dense forest scene, trees visible within the head shape, outside the silhouette is pure white, autumn colors — orange, gold, and deep green — visible within the figure, shot on medium format film, clean blend between exposures --ar 3:4 --v 6`

**Expected Result:** Clean double exposure merging human form with nature imagery.

---

## Illustration & Concept Art (31-40)

### 31. Fantasy Concept Art

**Prompt:**
`Fantasy concept art of an ancient library carved into the interior of a giant hollow tree, spiral staircases growing organically from the trunk walls, bookshelves embedded in the bark, warm magical light from floating orbs, a scholar walking up one of the root-staircases, canopy visible far above with light filtering through leaves, epic scale, painterly digital illustration style --ar 9:16 --v 6`

**Expected Result:** Grand fantasy interior with organic architecture and atmospheric lighting.

---

### 32. Sci-Fi Concept Art

**Prompt:**
`Science fiction concept art of a generation ship approaching a habitable planet, massive cylindrical vessel showing signs of centuries of travel — patches, modifications, attached structures, planet looming large in the viewport with blue oceans and white clouds, scale indicated by tiny shuttle craft between ship and planet, deep space background with distant nebula, hard sci-fi aesthetic --ar 21:9 --v 6`

**Expected Result:** Hard sci-fi spacecraft with lived-in detail approaching a blue planet.

---

### 33. Anime/Manga Style

**Prompt:**
`Anime illustration of a girl standing on a rooftop at sunset watching cherry blossoms drift across a Tokyo skyline, school uniform billowing in the wind, warm golden hour lighting, detailed cityscape in the background, slightly melancholic expression, Makoto Shinkai-inspired lighting with volumetric god rays through clouds, high detail, vibrant color palette --ar 16:9 --v 6 --niji 6`

**Expected Result:** Cinematic anime scene with signature Shinkai lighting and emotional atmosphere.

---

### 34. Children's Book Illustration

**Prompt:**
`Children's book illustration of a small fox and a large bear sharing an umbrella in the rain, whimsical and warm, soft rounded shapes, limited color palette of muted greens, warm oranges, and gentle blues, rain drawn as visible diagonal lines, puddle splashes at their feet, both characters looking at each other with gentle expressions, textured paper background, Oliver Jeffers meets Jon Klassen style --ar 4:3 --v 6`

**Expected Result:** Charming children's illustration with warmth, simple shapes, and limited palette.

---

### 35. Pixel Art

**Prompt:**
`Pixel art scene of a cozy cottage in a snowy forest at night, warm yellow light glowing from windows, smoke rising from chimney, individual pixels visible, 16-bit color palette, small details like a snowman in the yard and footprints in the snow, stars twinkling in the dark sky, inspired by classic SNES RPG background art, 320x240 resolution aesthetic --ar 4:3 --v 6`

**Expected Result:** Detailed pixel art with authentic retro game aesthetic and cozy atmosphere.

---

### 36. Art Nouveau

**Prompt:**
`Art Nouveau illustration of a woman surrounded by flowing organic botanical frames, sinuous curves and whiplash lines, decorative border with lily motifs, muted gold, sage green, and dusty rose color palette, flat areas of color with fine decorative line work, inspired by Alphonse Mucha poster design, figure integrated with the decorative elements --ar 2:3 --v 6`

**Expected Result:** Decorative Art Nouveau poster design with Mucha-inspired composition and color.

---

### 37. Isometric Design

**Prompt:**
`Isometric illustration of a small Japanese neighborhood block, showing a ramen shop, tiny park, apartment building, and corner convenience store, warm afternoon lighting, people going about daily life, laundry hanging on balconies, a cat sleeping on a roof, vending machine glowing on the corner, clean vector-like rendering, pastel color palette --ar 1:1 --v 6`

**Expected Result:** Clean isometric scene with Japanese urban details and warm atmosphere.

---

### 38. Vintage Poster

**Prompt:**
`Vintage travel poster for "Mars — The Red Frontier" in 1950s retro-futurism style, bold flat colors, limited to 5 colors (red, cream, navy, gold, black), astronaut standing on rocky surface looking at domed colony in the distance, two moons in the sky, bold sans-serif typography, screen-printing texture, WPA poster proportions --ar 2:3 --v 6`

**Expected Result:** Retro-futuristic travel poster with limited color palette and print texture.

---

### 39. Stained Glass

**Prompt:**
`Stained glass window design depicting a phoenix rising from flames, traditional lead came lines creating geometric and organic shapes, rich saturated colors — ruby red, amber gold, and cobalt blue — with light appearing to pass through the glass, Gothic cathedral pointed arch frame, detailed feather work within the lead lines, radiant light emanating from the center --ar 3:5 --v 6`

**Expected Result:** Authentic stained glass design with lead lines, saturated color, and transmitted light effect.

---

### 40. Low Poly 3D Art

**Prompt:**
`Low poly 3D illustration of a mountain landscape at golden hour, geometric faceted terrain in shades of green and brown, triangulated sky in gradient from warm orange to deep blue, simple geometric trees as cones, a small low-poly cabin by a reflective geometric lake, flat-shaded surfaces with no smooth shading, subtle shadows, clean and modern aesthetic --ar 16:9 --v 6`

**Expected Result:** Clean low-poly landscape with geometric forms and gradient lighting.

---

*40 Midjourney prompts across 8 art styles. Copy. Modify. Generate.*
