# Logo & Branding Prompts

20 prompts for logo concepts, brand identity exploration, and visual systems.

---

### 1. Wordmark Logo
**Prompt:** "Minimalist wordmark logo for '[BRAND NAME]' — a [TYPE OF COMPANY]. Custom letterforms: [QUALITY — geometric/organic/sharp/rounded]. The word should feel [BRAND QUALITY — premium/playful/technical/warm]. Single color: [COLOR]. On white background. The 'key letter' — [SPECIFIC LETTER] — has a distinctive treatment: [DESCRIBE — ligature/negative space element/unique stroke]. Scalable from favicon to billboard. Vector-clean rendering."
**Expected Result:** Custom wordmark with one distinctive letter treatment.

### 2. Icon/Symbol Logo
**Prompt:** "Geometric logo symbol for '[BRAND NAME]' — a [TYPE OF COMPANY]. The mark combines [CONCEPT A] and [CONCEPT B] into a single abstract symbol using negative space. Maximum 3 shapes. Works in single color. Simple enough to sketch from memory. The symbol should have the feeling of [QUALITY — stability/movement/growth/precision]. Displayed at multiple sizes to show scalability."
**Expected Result:** Clean geometric mark that communicates through abstract form.

### 3. Combination Mark
**Prompt:** "Combination mark logo for '[BRAND NAME]' — a [TYPE OF COMPANY]. Icon sits to the left of the wordmark. Icon: [DESCRIBE SYMBOL — simplified/abstract version of CONCEPT]. Wordmark: clean [SERIF/SANS-SERIF] in [WEIGHT]. The icon and wordmark should feel like one unit, not two separate elements. Color palette: [PRIMARY COLOR] for the icon, [SECONDARY] for the text. Shown on both white and dark backgrounds."
**Expected Result:** Unified icon + wordmark combination that works as a system.

### 4. Monogram Logo
**Prompt:** "Monogram logo using the letters [LETTERS] for '[BRAND NAME]'. The letters interlock or overlap in a geometric pattern. Single line weight throughout. The negative space between letters creates a secondary pattern or shape. Works as a circular badge and as a standalone mark. Color: [COLOR] on white. Classic, timeless, would look good embossed on leather or etched in glass."
**Expected Result:** Elegant monogram with geometric interlocking letterforms.

### 5. Emblem/Badge Logo
**Prompt:** "Badge/emblem logo for '[BRAND NAME]' — a [TYPE OF COMPANY]. Circular or shield shape containing: the brand name in an arc along the top, [CENTRAL ICON/ILLUSTRATION], and [TAGLINE/EST. DATE] along the bottom. Detailed but not cluttered. Style: [vintage/modern/rustic/nautical]. Would look good on a label, stamp, or patch. Two-color maximum: [COLOR 1] and [COLOR 2]."
**Expected Result:** Detailed emblem that works for physical applications like patches and stamps.

### 6. Brand Color Exploration
**Prompt:** "Brand color palette exploration for '[BRAND NAME]' — a [TYPE OF COMPANY] that wants to feel [3 BRAND ATTRIBUTES]. Show 5 different color palette options, each with: 1 primary color, 1 secondary color, 1 accent color, plus light and dark neutrals. Each palette on its own row with hex codes. Show each palette applied to a simple business card mockup to visualize the feel."
**Expected Result:** Multiple palette options with applied mockups for comparison.

### 7. Typography Pairing
**Prompt:** "Typography pairing exploration for '[BRAND NAME]'. Show 4 different heading + body font combinations. Each pair shown as: the brand name in the heading font, a short paragraph in the body font, and the two fonts used together in a simple layout. Styles to explore: (1) Classic serif + clean sans, (2) Geometric sans + humanist sans, (3) Slab serif + modern sans, (4) Custom display + minimal body. Indicate font names or style references."
**Expected Result:** Typography system options showing heading/body relationships.

### 8. Logo Animation Concept
**Prompt:** "Storyboard for a 3-second logo animation for [BRAND NAME]. Show 6 key frames: how the logo builds, moves, or reveals itself. The animation should reflect the brand's personality: [QUALITY — energetic/elegant/playful/precise]. Frame 1: starting state. Frames 2-5: build sequence. Frame 6: final lock-up. Include arrows showing motion direction and timing notes."
**Expected Result:** Animation storyboard with clear motion path and timing.

### 9. Brand Pattern
**Prompt:** "Seamless brand pattern for '[BRAND NAME]' using elements from their logo/brand. The pattern is made from [DESCRIBE — repeated logo marks/abstract elements/geometric shapes derived from the logo]. Color: [BRAND COLOR] on [BACKGROUND COLOR]. Density: [tight/loose/medium]. The pattern works as: packaging background, social media backdrop, and fabric print. Show it applied to a shopping bag mockup."
**Expected Result:** Versatile brand pattern derived from logo elements.

### 10. Brand Mockup Suite
**Prompt:** "Brand identity mockup showing '[BRAND NAME]' logo applied to: business card (front and back), letterhead, envelope, coffee cup, tote bag, and a phone screen. All items arranged in a flat lay on a [COLOR/MATERIAL] surface. The logo is [DESCRIBE]. Color palette: [COLORS]. Clean, modern photography style. The mockup should sell the brand as a complete system, not individual pieces."
**Expected Result:** Complete brand identity mockup showing system consistency.

### 11-15. Industry-Specific Logos

### 11. Tech Startup Logo
**Prompt:** "Logo for '[NAME]' — a SaaS product that helps teams [FUNCTION]. The logo should feel: modern, trustworthy, slightly technical. Avoid: generic cloud/circuit icons. Instead: abstract geometric mark that suggests [CONCEPT — connection/flow/structure/clarity]. Blue-dominant palette with one accent. Shown on a website header mockup."

### 12. Restaurant/Food Logo
**Prompt:** "Logo for '[NAME]' — a [CUISINE TYPE] restaurant. The mark should feel: [approachable/upscale/rustic/modern]. Include a subtle reference to [SPECIFIC FOOD OR COOKING ELEMENT] without being literal (no chef hats, no forks). Custom lettering that feels hand-crafted. Color palette evokes [APPETITE QUALITY — warmth/freshness/earthiness]. Shown on a menu cover and exterior sign mockup."

### 13. Fitness/Wellness Logo
**Prompt:** "Logo for '[NAME]' — a [TYPE — gym/yoga studio/wellness app/supplement brand]. The mark communicates [QUALITY — strength/calm/energy/balance] through form, not through literal exercise imagery. Dynamic shape suggesting movement. Bold enough for apparel. Works in single color on a dark tank top and on a light app screen."

### 14. Creative Agency Logo
**Prompt:** "Logo for '[NAME]' — a creative/design agency. The logo itself should BE the portfolio piece — showing creativity in its construction. Could use: optical illusion, impossible geometry, playful typography, or clever negative space. It should make other designers say 'clever.' Black and white primary, with a signature accent color for secondary use."

### 15. Non-Profit Logo
**Prompt:** "Logo for '[NAME]' — a non-profit focused on [CAUSE]. The mark should feel: hopeful, trustworthy, human. Avoid: clip-art hands/hearts/globes. Instead: a simple, memorable symbol that captures [SPECIFIC ASPECT of the cause]. Warm color palette. Must work in single color for stamps, embroidery, and low-budget printing."

### 16-20. Brand System Prompts

### 16. App Icon Design
**Prompt:** "App icon for '[APP NAME]' — a [TYPE OF APP]. Must be readable at 29x29 pixels and beautiful at 1024x1024. Simple geometric form. Maximum 2 colors plus a white element. Rounded square format (iOS). The icon should communicate the app's function through abstract shape, not literal illustration. Show at: 1024px, 180px, and 60px sizes."

### 17. Social Media Brand Kit
**Prompt:** "Social media brand kit for '[BRAND NAME]'. Show: profile picture (logo adapted for circle crop), cover/banner image, post template (quote style), post template (photo + text), and story template. Consistent use of brand colors [COLORS], fonts, and visual style. The kit should make any content look professional and on-brand."

### 18. Brand Voice Visual
**Prompt:** "A single image that captures '[BRAND NAME]'s brand personality visually. The brand is: [3 PERSONALITY TRAITS]. The image isn't a logo — it's a mood. Think brand photography direction: what does this brand LOOK like? Color palette, texture, lighting, subject matter. This image would go on the first page of a brand book under 'Our Visual World.'"

### 19. Packaging System
**Prompt:** "Packaging design system for '[BRAND NAME]' — a [PRODUCT TYPE]. Show 3 product variants in the same packaging system: same structure, different colors/flavors. Each package: front face shown. Consistent logo placement, consistent typography, distinct color coding per variant. Materials: [MATERIAL TYPE]. The system should be immediately recognizable as one brand family."

### 20. Brand Guidelines Spread
**Prompt:** "A spread from a brand guidelines document for '[BRAND NAME]'. The spread shows: logo usage rules (minimum size, clear space, incorrect usage examples), color palette with hex/RGB/CMYK codes, and typography hierarchy. Clean, organized layout on a white background. Professional enough to send to a client. The guidelines spread itself should feel on-brand."
**Expected Result:** Professional brand guidelines layout showing system rules.

---

*20 logo and branding prompts. Build visual identities, not just pretty marks.*
