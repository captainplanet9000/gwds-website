# Composition & Art Direction Reference Guide

A reference for composition terms, camera angles, lighting setups, and art direction vocabulary. Use these terms in your AI image prompts for precise control over the output.

---

## Camera Angles

| Term | Description | Mood/Effect |
|------|-------------|-------------|
| **Eye level** | Camera at subject's eye height | Neutral, documentary, relatable |
| **Low angle** | Camera below subject, looking up | Power, dominance, heroic |
| **High angle** | Camera above subject, looking down | Vulnerability, smallness, overview |
| **Bird's eye / overhead** | Directly above, looking straight down | God-like perspective, pattern visibility |
| **Worm's eye** | Ground level, extreme low angle | Dramatic, towering, surreal |
| **Dutch angle / tilted** | Camera rotated off-axis | Tension, unease, dynamic energy |
| **Over-the-shoulder** | Behind one subject looking at another | Conversation, relationship, POV |
| **POV / first person** | Camera as the subject's eyes | Immersion, intimacy |

## Shot Types

| Term | Description | Best For |
|------|-------------|----------|
| **Extreme wide shot (EWS)** | Subject tiny in vast environment | Establishing location, isolation, scale |
| **Wide shot (WS)** | Full body + surrounding environment | Context, setting the scene |
| **Medium wide (MWS)** | Knees up | Walking, gestures, body language |
| **Medium shot (MS)** | Waist up | Conversation, standard portrait |
| **Medium close-up (MCU)** | Chest up | Emotion + some context |
| **Close-up (CU)** | Face fills the frame | Emotion, detail, intimacy |
| **Extreme close-up (ECU)** | Single feature (eye, hand) | Detail, tension, abstract |
| **Macro** | Magnified detail of small objects | Texture, scientific detail |

## Composition Rules

### Rule of Thirds
Subject placed at intersection of the 1/3 grid lines. Use: `subject positioned at the left third` or `eyes at the upper third intersection`.

### Golden Ratio / Fibonacci Spiral
Natural spiral leading the eye. Use: `composition following golden ratio spiral, subject at the focal point`.

### Leading Lines
Lines in the scene directing the eye to the subject. Use: `road/hallway/fence acting as leading lines toward the subject`.

### Framing
Using elements in the scene to frame the subject. Use: `subject framed by doorway/arch/tree branches/window`.

### Symmetry
Perfect or near-perfect mirror composition. Use: `perfectly symmetrical composition with subject centered`.

### Negative Space
Large areas of empty space around the subject. Use: `minimal composition with 60% negative space, subject small in the frame`.

### Depth Layering
Foreground, midground, background clearly defined. Use: `foreground element at bottom of frame, subject in midground, mountains in background`.

---

## Lighting Types

### Natural Light

| Term | Description | Prompt Language |
|------|-------------|----------------|
| **Golden hour** | 1 hour after sunrise / before sunset | `warm golden hour light, long shadows, amber tones` |
| **Blue hour** | 30 min before sunrise / after sunset | `blue hour twilight, cool ambient light, no shadows` |
| **Overcast** | Diffused light through clouds | `overcast sky creating soft, even light with no harsh shadows` |
| **Dappled light** | Light filtering through leaves | `dappled sunlight through tree canopy, light spots on the ground` |
| **Backlight** | Light source behind subject | `strong backlight creating rim light and silhouette` |
| **Side light** | Light from 90 degrees | `dramatic side light, half the face in shadow` |
| **Top light / noon** | Direct overhead sunlight | `harsh midday sun, deep shadows under features` |

### Studio/Artificial Light

| Term | Description | Prompt Language |
|------|-------------|----------------|
| **Key light** | Main light source | `single key light from 45 degrees above` |
| **Fill light** | Secondary light reducing shadows | `soft fill light on the shadow side` |
| **Rim/Back light** | Light behind subject creating edge glow | `rim light separating subject from background` |
| **Beauty dish** | Controlled, flattering light | `beauty dish lighting creating controlled highlight and shadow` |
| **Softbox** | Large, diffused light source | `large softbox creating wrapping, even light` |
| **Ring light** | Circular light around lens | `ring light creating even facial lighting with circular catchlights` |
| **Neon/practical** | Colored light from in-scene sources | `lit only by neon signs, colored light from practical sources` |
| **Chiaroscuro** | Extreme light/dark contrast | `dramatic chiaroscuro lighting, deep blacks, single light source` |

---

## Lens & Camera Terms

| Term | Effect | Prompt Language |
|------|--------|----------------|
| **Wide angle (14-35mm)** | Expansive, slight distortion at edges | `wide angle lens distortion, expansive field of view` |
| **Normal (50mm)** | Natural perspective, no distortion | `50mm lens, natural perspective, no distortion` |
| **Portrait (85-135mm)** | Compressed background, flattering | `85mm portrait lens, compressed background, creamy bokeh` |
| **Telephoto (200mm+)** | Extreme background compression | `telephoto compression, flat perspective, stacked elements` |
| **Macro (1:1+)** | Extreme close-up of small subjects | `macro lens, extreme detail, shallow depth of field` |
| **Tilt-shift** | Selective focus plane, miniature effect | `tilt-shift lens, miniature effect, selective focus band` |
| **Fisheye** | Extreme wide, circular distortion | `fisheye lens, barrel distortion, 180-degree field of view` |
| **Anamorphic** | Widescreen, oval bokeh, flares | `anamorphic lens, oval bokeh, horizontal lens flare` |

### Depth of Field

| Setting | Effect | Prompt Language |
|---------|--------|----------------|
| **Shallow (f/1.4-2.8)** | Subject sharp, background creamy blur | `shallow depth of field, f/1.4, creamy bokeh background` |
| **Medium (f/5.6-8)** | Subject and near elements sharp | `moderate depth of field, foreground and subject sharp` |
| **Deep (f/11-22)** | Everything sharp front to back | `deep focus, f/16, sharp throughout, landscape style` |

---

## Color & Mood

### Color Palettes

| Palette | Colors | Mood |
|---------|--------|------|
| **Warm** | Amber, rust, cream, golden | Cozy, nostalgic, inviting |
| **Cool** | Teal, slate, ice blue, silver | Calm, professional, clean |
| **Moody** | Deep navy, burgundy, charcoal | Dramatic, sophisticated, intense |
| **Pastel** | Soft pink, lavender, mint, peach | Gentle, playful, feminine |
| **Neon** | Electric pink, cyan, lime | Energetic, futuristic, bold |
| **Earth** | Olive, terra cotta, sand, sage | Natural, grounded, organic |
| **Monochrome** | Shades of one color | Unified, artistic, focused |

### Color Grading Terms

| Term | Description | Prompt Language |
|------|-------------|----------------|
| **Teal and orange** | Hollywood standard | `cinematic color grade, teal shadows, orange highlights` |
| **Desaturated** | Muted, reduced color intensity | `slightly desaturated color palette, muted tones` |
| **Cross-processed** | Color shift from intentional mismatch | `cross-processed color, shifted greens and purples` |
| **Bleach bypass** | Low saturation, high contrast | `bleach bypass look, reduced saturation, increased contrast` |
| **Split-toning** | Different tones in shadows vs highlights | `split-toned, warm highlights, cool shadows` |

---

## Film Stock References

Use these to get specific color science and grain characteristics:

| Film Stock | Look | Prompt Language |
|------------|------|----------------|
| **Kodak Portra 400** | Warm, natural skin tones | `Kodak Portra 400 color palette, warm, natural` |
| **Kodak Ektar 100** | Vivid, saturated colors | `Kodak Ektar vivid colors, deep saturation` |
| **Fuji Pro 400H** | Cool, pastel, airy | `Fuji Pro 400H tones, cool, pastel, light` |
| **Kodak Tri-X 400** | Classic B&W, medium grain | `Kodak Tri-X black and white, medium grain, rich blacks` |
| **Ilford HP5** | B&W, more grain, punchy | `Ilford HP5 black and white, visible grain, high contrast` |
| **Cinestill 800T** | Tungsten-balanced, halation, cinematic | `Cinestill 800T, halation glow around highlights, cinematic` |
| **Kodak Gold 200** | Consumer warm, nostalgic | `Kodak Gold warm tones, slight orange shift, nostalgic` |

---

## Art Medium References

| Medium | Visual Quality | Prompt Language |
|--------|---------------|----------------|
| **Oil painting** | Thick, textured, rich color | `oil paint texture, visible brushstrokes, impasto highlights` |
| **Watercolor** | Transparent, bleeding edges | `watercolor, wet-on-wet bleeding, paper texture visible` |
| **Charcoal** | Soft, smudged, dramatic | `charcoal drawing, smudged edges, dramatic value range` |
| **Ink wash** | Variable tone, fluid | `ink wash, varying density, fluid brushwork` |
| **Gouache** | Matte, opaque, flat color | `gouache painting, matte finish, opaque flat colors` |
| **Colored pencil** | Layered, visible strokes | `colored pencil, visible pencil strokes, layered color` |
| **Pastel** | Soft, chalky, vibrant | `soft pastel, chalky texture, vibrant blended colors` |
| **Acrylic** | Versatile, can be thick or thin | `acrylic painting, bold colors, visible paint texture` |
| **Digital painting** | Clean or textured, flexible | `digital painting, painterly brushwork, clean edges` |
| **Vector illustration** | Clean, scalable, geometric | `vector illustration, clean lines, flat color, scalable` |

---

## Rendering & Quality Terms

| Term | Use In Prompt |
|------|---------------|
| **Photorealistic** | `photorealistic, hyperdetailed` |
| **8K resolution** | `8K resolution, extremely detailed` |
| **Ray tracing** | `ray-traced lighting, realistic reflections` |
| **Unreal Engine** | `rendered in Unreal Engine 5, photorealistic` |
| **Octane Render** | `Octane render, cinema quality lighting` |
| **Studio quality** | `professional studio photography quality` |
| **Film grain** | `subtle film grain texture` |
| **Noise/grain-free** | `clean, noise-free, sharp` |

---

## Quick Reference: Mood → Settings

| Desired Mood | Lighting | Color | Lens | Composition |
|-------------|---------|-------|------|-------------|
| **Epic/heroic** | Backlight, low angle sun | Warm, high saturation | Wide angle | Low angle, leading lines |
| **Intimate** | Soft window light | Warm, muted | 85mm portrait | Close-up, shallow DOF |
| **Mysterious** | Single source, shadows | Cool, desaturated | Normal-wide | Negative space, silhouette |
| **Joyful** | Bright, even, golden | Warm, saturated | Normal-wide | Eye level, open composition |
| **Tense** | Harsh, directional | Cool, contrast | Wide angle | Dutch angle, tight framing |
| **Peaceful** | Soft, diffused | Cool pastels | Normal-tele | Symmetry, negative space |
| **Nostalgic** | Golden, hazy | Warm, faded | Vintage lens | Medium shot, film grain |

---

*Reference guide. Learn these terms. Use them in every prompt. Get better results.*
