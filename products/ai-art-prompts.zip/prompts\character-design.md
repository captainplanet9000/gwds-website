# Character Design Prompts

20 prompts for creating consistent characters across styles, poses, and scenes.

---

### 1. Character Reference Sheet
**Prompt:** "Character reference sheet for [CHARACTER DESCRIPTION: age, build, distinguishing features]. Three views: front, 3/4, and side profile on a white background. Consistent proportions across all three. Labeled with key features. Clean line art with flat color. Include: height reference line, color swatches for skin/hair/clothing, and notes on distinguishing marks. Animation studio character sheet style."
**Expected Result:** Professional character sheet with multiple consistent angles.

### 2. Expression Sheet
**Prompt:** "Expression sheet for [CHARACTER DESCRIPTION]. Six head shots showing: happy/laughing, angry/frustrated, sad/worried, surprised/shocked, confident/smug, and neutral/resting. Consistent character features across all expressions. Clean white background. Arranged in a 3x2 grid. [ART STYLE — anime/western animation/realistic/cartoon]. Each expression is distinct and readable at thumbnail size."
**Expected Result:** Range of expressions for a single consistent character.

### 3. Outfit Variations
**Prompt:** "Full-body outfit variations for [CHARACTER DESCRIPTION]. Five outfits: casual everyday, formal event, workout/athletic, sleepwear/relaxed, and work/professional. Same character, same pose (relaxed standing), different clothing. White background. Style: [CHOSEN STYLE]. Clothing should fit the character's personality: [PERSONALITY TRAITS]."
**Expected Result:** Wardrobe exploration for a single consistent character.

### 4. Character in Environment
**Prompt:** "Full illustration of [CHARACTER DESCRIPTION] in their natural environment: [DESCRIBE ENVIRONMENT]. Character occupies 40% of the frame. They're engaged in a characteristic activity: [WHAT THEY'RE DOING]. The environment tells us about them — [specific environmental details that reveal personality/backstory]. Warm lighting that matches the mood. [ART STYLE]."
**Expected Result:** Character illustration that communicates personality through environment.

### 5. Action Pose
**Prompt:** "Dynamic action pose of [CHARACTER DESCRIPTION] performing [SPECIFIC ACTION]. Exaggerated perspective for drama — [low angle/high angle/dutch angle]. Motion lines or effects suggesting speed. Clothing and hair responding to movement. Background is motion-blurred or minimal to keep focus on the character. [ART STYLE]. Professional animation key frame quality."
**Expected Result:** Dynamic character pose with clear movement and energy.

### 6. Character Lineup
**Prompt:** "Character lineup showing [NUMBER] characters standing side by side for height and design comparison. Characters (left to right): [DESCRIBE EACH]. All on the same ground plane. Horizontal reference lines showing relative heights. White background. Consistent art style across all characters. Each character's silhouette should be immediately recognizable — clear shape language."
**Expected Result:** Group comparison showing distinct character designs and silhouettes.

### 7. Character Age Progression
**Prompt:** "Age progression of [CHARACTER NAME/DESCRIPTION] at ages [LIST — 5, 15, 25, 45, 70]. Same character at different life stages. Consistent recognizable features (eye color, facial structure) but appropriate aging. Same pose for comparison. Clothing evolves with era and age. White background. [ART STYLE]."
**Expected Result:** Single character shown across their lifespan with consistent core features.

### 8. Turnaround Sheet
**Prompt:** "Full character turnaround for [CHARACTER DESCRIPTION]. Eight positions: front, front-3/4, side, back-3/4, back. All at the same scale on a white background with a baseline. Consistent proportions and detail across all angles. Clean line art with flat color fill. Technical enough for a 3D modeler to work from. Include: shoe sole pattern from below view."
**Expected Result:** Complete 360-degree character reference.

### 9. Chibi/Simplified Version
**Prompt:** "Chibi/simplified version of [CHARACTER DESCRIPTION]. 2-3 head tall proportions. Exaggerated head, simplified body. Maintain the character's key identifying features — [LIST 3 KEY FEATURES]. Three poses: standing, sitting, and one action pose. White background. Cute but recognizable as the same character. Could be used as an icon, sticker, or merchandise design."
**Expected Result:** Adorable simplified version maintaining character identity.

### 10. Character with Props
**Prompt:** "Character illustration of [CHARACTER DESCRIPTION] surrounded by their essential objects/props. The character is in a relaxed pose in the center. Around them, their key items float or are arranged: [LIST 5-8 SIGNATURE ITEMS]. Each item is detailed enough to be a reference. Items reflect the character's personality, job, and hobbies. White background. [ART STYLE]."
**Expected Result:** Character surrounded by defining possessions.

### 11-15. Style Variation Prompts

### 11. Same Character, Different Art Styles
**Prompt:** "The same character — [BRIEF DESCRIPTION: 1-2 features] — rendered in 4 different art styles in a 2x2 grid: (1) Japanese anime, (2) Disney/Pixar 3D, (3) comic book/graphic novel ink, (4) photorealistic portrait. Same pose, same expression across all four. The character should be unmistakably the same person in each style."

### 12. Fantasy RPG Character
**Prompt:** "Fantasy RPG character design: [RACE — human/elf/dwarf/orc] [CLASS — warrior/mage/rogue/ranger]. Full body with detailed armor/equipment. Each piece of equipment has a story — worn, customized, unique. Pose is confident but natural — this character has been adventuring for years. Detailed weapon design. Color palette: [3 DOMINANT COLORS]. Painterly digital art style."

### 13. Sci-Fi Character
**Prompt:** "Science fiction character design: [ROLE — pilot/engineer/scientist/soldier]. Futuristic but functional outfit — this is clothing designed for a purpose, not fashion. Visible technology integration (heads-up display, communication device, tool belt). Subtle signs of use — scuffs, patches, personal modifications. Full body, 3/4 angle. Hard sci-fi aesthetic — no fantasy elements."

### 14. Villain Design
**Prompt:** "Villain character design for [GENRE — fantasy/sci-fi/contemporary]. The design communicates threat through [SHARP ANGLES/DARK COLORS/IMPOSING SIZE/UNSETTLING BEAUTY]. Key design element: [ONE DISTINCTIVE FEATURE]. The villain should be visually interesting — not just 'evil looking.' There should be a hint of their backstory in their design. Full body. Dramatic lighting from below."

### 15. Mascot Design
**Prompt:** "Brand mascot character design for [BRAND/COMPANY TYPE]. The mascot is [ANIMAL/OBJECT/ABSTRACT FIGURE]. Friendly, approachable, memorable. Simple enough to work at small sizes (favicon, app icon). Distinctive enough to be recognized in silhouette. Color palette matches brand: [BRAND COLORS]. Three poses: waving/greeting, thumbs up, and thinking. Clean vector illustration style."
**Expected Result:** Versatile mascot design that works across applications.

### 16-20. Advanced Character Prompts

### 16. Character Interaction
**Prompt:** "Two characters interacting: [CHARACTER A] and [CHARACTER B] in a scene that shows their relationship — [DESCRIBE RELATIONSHIP: rivals/friends/mentor-student/siblings]. Body language and spacing communicate the dynamic without words. Environment suggests context for their meeting. Both characters maintain their individual design language."

### 17. Emotional Beat
**Prompt:** "A single powerful emotional moment: [CHARACTER DESCRIPTION] in the moment of [SPECIFIC EMOTION — receiving bad news/achieving a lifelong dream/saying goodbye]. Close-up, focus on expression and body language. Lighting matches the emotion — [warm for joy, cool for sadness, dramatic for shock]. Background is minimal — the character IS the image."

### 18. Character with Animal Companion
**Prompt:** "Character design of [CHARACTER DESCRIPTION] with their animal companion: [ANIMAL]. The animal's design complements the character — similar color palette, matching energy. Show the bond — the animal's positioning suggests loyalty and comfort. Both the character and animal should feel like they belong in the same world."

### 19. Culture-Specific Character
**Prompt:** "Character design inspired by [SPECIFIC CULTURE/ERA]. Research-accurate clothing, hairstyle, accessories, and color palette. The character is [ROLE IN THAT CULTURE]. Design should be respectful and specific — not stereotypical. Include cultural details that someone from that background would recognize as authentic."

### 20. Character Evolution
**Prompt:** "Three-stage character evolution showing [CHARACTER] at the beginning, middle, and end of their story arc. Stage 1: [STARTING STATE — naive/weak/ordinary]. Stage 2: [MID-JOURNEY — learning/growing/tested]. Stage 3: [FINAL FORM — powerful/wise/transformed]. Costume, posture, and expression evolve with each stage. Same character, visible growth."
**Expected Result:** Visual storytelling through character transformation.

---

*20 character design prompts. Build characters that feel like people.*
