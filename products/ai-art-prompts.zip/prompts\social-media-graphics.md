# Social Media Graphics Prompts

20 prompts for generating social media visual content across platforms.

---

### 1. Instagram Post — Quote Card
**Prompt:** "Social media graphic for Instagram (1080x1080). Bold motivational quote on a [COLOR — gradient/textured/photo] background. Quote: '[YOUR QUOTE]' in large [SERIF/SANS-SERIF] white text, centered. Attribution: '— [NAME]' in smaller text below. Subtle design element: [geometric lines/gradient overlay/grain texture]. Space at bottom for @handle. Clean, modern, shareable. Not a Canva template — custom designed."
**Expected Result:** Scroll-stopping quote card with professional design.

### 2. Instagram Carousel Cover
**Prompt:** "Instagram carousel first slide (1080x1350) that makes people swipe. Topic: '[TOPIC]'. Large, bold headline text: '[TITLE]' — maximum 8 words. Color: [BRAND COLORS]. Design element that suggests 'swipe' — arrow, partial text, or visual that extends beyond the frame. The slide should create curiosity without revealing the full content. Modern, clean, not busy."
**Expected Result:** High-contrast carousel hook slide designed for engagement.

### 3. YouTube Thumbnail
**Prompt:** "YouTube thumbnail (1280x720). Face of a person showing [EXPRESSION — shocked/excited/curious] on the left third. Large bold text on the right: '[TEXT — max 4 words]' in [COLOR] with black outline/shadow for readability. Background: [DESCRIBE — blurred context/solid color/relevant imagery]. High contrast, readable at small sizes. The thumbnail should make you want to click even without knowing the video topic."
**Expected Result:** Click-worthy YouTube thumbnail with face, text, and contrast.

### 4. Twitter/X Header
**Prompt:** "Twitter header banner (1500x500). [BRAND/PERSONAL] header for a [NICHE] account. Clean design with brand elements on the left (logo, tagline) and a visual element on the right that represents [WHAT YOU DO]. Middle section is relatively empty to avoid conflict with the profile picture overlay. Color palette: [COLORS]. Professional but not corporate."
**Expected Result:** Platform-optimized header that works with profile picture placement.

### 5. Story Template — Poll
**Prompt:** "Instagram story template (1080x1920) for an interactive poll. Question at the top: '[QUESTION]' in bold text. Two options below, each in a distinct colored box: '[OPTION A]' and '[OPTION B]'. Space between options for the Instagram poll sticker. Background: [COLOR/GRADIENT]. Brand elements: small logo and @handle. Fun, engaging, easy to respond to."
**Expected Result:** Story template designed for interactive engagement.

### 6. LinkedIn Banner
**Prompt:** "LinkedIn profile banner (1584x396) for a [PROFESSION/ROLE]. Professional design showing: your title/value proposition in clean text, subtle visual element representing your industry, and brand colors [COLORS]. The banner should answer 'what does this person do and why should I care?' in 2 seconds. Avoid: stock photo vibes. Instead: clean graphic design with intentional typography."
**Expected Result:** Professional LinkedIn banner communicating expertise.

### 7. Before/After Split
**Prompt:** "Before/after social media graphic (1080x1080). Split down the middle with a clear dividing line. Left side labeled 'BEFORE' in [COLOR]: [DESCRIBE BEFORE STATE — messy/cluttered/plain/broken]. Right side labeled 'AFTER' in [COLOR]: [DESCRIBE AFTER STATE — clean/organized/beautiful/fixed]. Same angle, same lighting, dramatic improvement. Text overlay at bottom describing the transformation."
**Expected Result:** Satisfying before/after comparison graphic.

### 8. Data Visualization Post
**Prompt:** "Social media infographic (1080x1350) presenting [STATISTIC/DATA]. The key number is displayed LARGE (occupying 40% of the frame): '[NUMBER]'. Below: brief context in 1-2 lines. Background: [DARK/LIGHT]. Visual element: simple chart, icon, or illustration supporting the data. Source credited in small text at bottom. The design should make the number impossible to scroll past."
**Expected Result:** Data-forward social graphic with impactful number display.

### 9. Event Announcement
**Prompt:** "Social media event announcement graphic (1080x1080). Event: '[EVENT NAME]'. Date: '[DATE]'. Time: '[TIME]'. Location/Link: '[DETAILS]'. Design hierarchy: event name largest, date second, details smallest. Background: [DESCRIBE]. Brand colors and fonts. The graphic should create excitement while clearly communicating the essential info. Include a visual element that hints at the event's nature."
**Expected Result:** Clear, exciting event announcement with proper info hierarchy.

### 10. Testimonial Graphic
**Prompt:** "Social media testimonial graphic (1080x1080). Quote: '[CUSTOMER QUOTE]' in large readable text with quotation marks. Attribution: '[NAME, TITLE]' below the quote. Small circular photo of the customer (or placeholder circle). Background: [BRAND COLOR or subtle pattern]. Brand logo in corner. The quote should be the hero — everything else supports it. Clean, trustworthy, professional."
**Expected Result:** Credibility-building testimonial designed for social sharing.

### 11-15. Platform-Specific Formats

### 11. Pinterest Pin
**Prompt:** "Pinterest pin (1000x1500). Topic: '[TOPIC]'. Large title text at top: '[TITLE]' — keyword-rich and descriptive. Supporting image in the middle 60% of the pin: [DESCRIBE RELEVANT IMAGERY]. Bottom section: brand logo and '[WEBSITE]'. Warm, inviting color palette. High-quality enough to get repinned. Designed for discovery — the title tells you exactly what you'll get."

### 12. TikTok Cover Frame
**Prompt:** "TikTok video cover frame (1080x1920). Bold text overlay: '[VIDEO TITLE — max 5 words]' centered in the frame. Background: a still that works as a thumbnail. The text should be readable even at the small TikTok grid size. High contrast: [TEXT COLOR] on [BACKGROUND]. This is the frame someone sees in your profile grid — it needs to communicate the video topic instantly."

### 13. Facebook Ad Creative
**Prompt:** "Facebook ad creative (1080x1080). Product: [YOUR PRODUCT]. The image shows [PRODUCT/LIFESTYLE SHOT]. Headline overlay: '[VALUE PROPOSITION — max 6 words]' in bold, high-contrast text in the top or bottom third. Avoid: cluttered text, small fonts, stock photo look. The image should stop the scroll in a newsfeed full of personal posts. Must comply with Facebook's <20% text guideline."

### 14. Newsletter Header
**Prompt:** "Email newsletter header graphic (600x200). Brand: '[NAME]'. The header sets the tone for the newsletter. Visual: [ILLUSTRATIVE ELEMENT — abstract/thematic/brand-specific]. Brand colors: [COLORS]. The header should be: memorable, quick to recognize as YOUR newsletter, and not so tall that it pushes content below the fold. Horizontal format, clean, modern."

### 15. Podcast Audiogram
**Prompt:** "Podcast audiogram template (1080x1080). Show: podcast artwork in the upper left (small, recognizable), guest name and episode title in clean typography, a key quote from the episode in large text: '[QUOTE]'. Space at the bottom for an audio waveform visualization bar. Background: [COLOR/GRADIENT]. The design should make someone want to hear the full episode."

### 16-20. Quick Social Graphics

### 16. Tip/Hack Post
**Prompt:** "Social media tip graphic (1080x1350). Large number/emoji at top: '[TIP NUMBER]'. Tip text in clean, large font: '[TIP TEXT]'. Visual: simple icon or illustration supporting the tip. Background: [BRAND COLOR]. The tip should be readable in 3 seconds. This is one slide in a multi-tip carousel — design it to work alone and in series."

### 17. Comparison Post
**Prompt:** "Social media comparison graphic (1080x1350). Two columns: '[OPTION A]' vs '[OPTION B]'. Each column lists 4-5 attributes with icons. Clear winner indicated by a [checkmark/highlight/color]. Clean, organized, scannable in seconds. Not cluttered — plenty of white space between items."

### 18. Countdown/Launch Post
**Prompt:** "Product launch countdown graphic (1080x1080). Large countdown number: '[NUMBER] DAYS'. Product silhouette or partial reveal in the background — enough to intrigue but not reveal fully. Date visible: '[LAUNCH DATE]'. Brand colors, clean typography. The graphic should build anticipation."

### 19. Behind the Scenes Post
**Prompt:** "BTS-style social media graphic. Frame: a phone screen or camera viewfinder showing a behind-the-scenes moment. Around the frame: the actual polished result. This 'reality vs. result' juxtaposition shows authenticity. Text overlay: 'Behind the scenes' or 'How it started / How it's going'. Casual, human, relatable."

### 20. Holiday/Seasonal Post
**Prompt:** "Seasonal social media graphic for [HOLIDAY/SEASON]. Brand: '[NAME]'. The design incorporates seasonal elements — [DESCRIBE — fall leaves/snowflakes/cherry blossoms/fireworks] — into the brand's existing visual language. Not a generic holiday graphic — it should be unmistakably YOUR brand celebrating the season. Brand colors adapted to include seasonal tones."

---

*20 social media graphic prompts. Make every post look intentional.*
