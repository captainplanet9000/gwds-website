# AI Art Direction Pack

**190+ prompts for Midjourney, Stable Diffusion, DALL-E, and AI image generation.**

Stop getting mid results from AI image tools. This pack gives you professional art direction prompts organized by style, use case, and platform. Each prompt is crafted by someone who understands composition, lighting, and visual storytelling — not just stringing keywords together.

---

## What's Inside

| File | Prompts | What It Covers |
|------|---------|----------------|
| `prompts/midjourney-styles.md` | 40 | Templates by art style — cyberpunk, watercolor, film noir, and more |
| `prompts/stable-diffusion.md` | 30 | SD prompts with negative prompt pairs for quality control |
| `prompts/dalle-creative.md` | 25 | DALL-E 3 prompts for creative and commercial use |
| `prompts/product-photography.md` | 20 | AI product shots, mockups, and commercial imagery |
| `prompts/character-design.md` | 20 | Consistent character creation across styles and scenes |
| `prompts/architecture.md` | 15 | Architectural visualization and interior design |
| `prompts/logo-branding.md` | 20 | Logo concepts, brand identity, and visual systems |
| `prompts/social-media-graphics.md` | 20 | Social media visual content and templates |
| `prompts/composition-guide.md` | — | Reference guide for composition, cameras, and lighting |
| **Total** | **190+** | |

## Who This Is For

- Designers using AI as part of their creative workflow
- Content creators who need custom visuals without a design background
- Marketing teams producing visual assets at scale
- Anyone frustrated by generic AI outputs

## How to Use

1. **Pick your tool** — Midjourney, Stable Diffusion, DALL-E, or similar
2. **Find a style/use case** — Browse the relevant file
3. **Copy the prompt** — Modify the bracketed fields
4. **Generate and iterate** — Use the prompt as a starting point, refine with variations

### Prompt Anatomy

Every prompt includes:
```
**Prompt:** [The actual generation prompt]
**Negative Prompt:** [What to avoid — for SD/tools that support it]
**Parameters:** [Aspect ratio, model, style settings]
**Expected Result:** [Description of what you should get]
```

### Pro Tips

- **Be specific about lighting.** "Golden hour side lighting" beats "good lighting" every time.
- **Reference real-world equivalents.** "Shot on Hasselblad 500C, Kodak Portra 400" gives the AI a concrete visual target.
- **Use the composition guide.** Learn the terms once, use them forever.
- **Iterate, don't restart.** Vary one element at a time to understand what each word changes.

## License

Personal and commercial use. See `LICENSE.md` for details.

---

*Built by Gamma Waves Design Studio — [gwds.co](https://gwds.co)*
