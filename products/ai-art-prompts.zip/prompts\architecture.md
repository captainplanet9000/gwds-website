# Architectural Visualization Prompts

15 prompts for AI-generated architectural visualization, interior design, and spatial concepts.

---

### 1. Modern Residential Exterior
**Prompt:** "Architectural visualization of a modern residential home. Two-story structure with flat roof, floor-to-ceiling glass walls on the ground floor, upper floor clad in warm cedar wood. Cantilevered upper floor extends over an infinity-edge pool. Landscaping: native grasses and a single mature olive tree. Shot at golden hour from the pool side. Sky has warm cirrus clouds. Professional 3D rendering quality — V-Ray or Corona render look."
**Expected Result:** Photorealistic residential visualization suitable for a portfolio.

### 2. Interior — Living Space
**Prompt:** "Interior visualization of a Scandinavian minimalist living room. Double-height ceiling with a mezzanine library visible above. White oak floors. Walls: warm white with one textured concrete accent wall. Furniture: low-profile linen sofa in oatmeal, Noguchi coffee table, single Arco floor lamp. Large window showing a forest view. Late afternoon light casting geometric shadows. A few carefully placed books and a ceramic vase with dried branches. Architectural photography style."
**Expected Result:** Warm, inviting interior with clean Scandinavian aesthetic.

### 3. Commercial Space — Restaurant
**Prompt:** "Interior visualization of an upscale Japanese restaurant. Dark, intimate atmosphere. Counter seating facing an open kitchen with a chef preparing sushi. Materials: blackened steel, natural hinoki wood, terrazzo floor. Lighting: warm pendants over the counter creating pools of light, rest of the space in dramatic shadow. A single ikebana arrangement on each table. Visible textures: wood grain, metal patina, fabric upholstery. Moody, cinematic lighting."
**Expected Result:** Atmospheric restaurant interior with material focus.

### 4. Urban Concept — Mixed Use
**Prompt:** "Architectural concept rendering of a mixed-use building in a dense urban neighborhood. Ground floor: open-air market with retractable glass walls. Upper floors: residential with deep planted balconies creating a vertical garden effect. Rooftop: community farm with solar canopy. The building integrates with the existing brick neighborhood rather than dominating it. Street-level view showing pedestrian activity. Daytime, partly cloudy. Concept art style — detailed but slightly painterly."
**Expected Result:** Urban architectural concept showing building in neighborhood context.

### 5. Interior — Bathroom
**Prompt:** "Interior visualization of a luxury spa-style bathroom. Freestanding stone bathtub as the centerpiece on a raised platform. Floor-to-ceiling window behind the tub looking out to a private garden with bamboo and river stones. Materials: honed limestone floor, tadelakt walls in warm cream, black matte fixtures. Towel warming rack with folded white towels. Steam rising from filled tub. Natural light + one recessed LED strip creating a horizon line of light. Zen, minimal, warm."
**Expected Result:** Luxurious bathroom visualization with spa atmosphere.

### 6. Adaptive Reuse
**Prompt:** "Architectural visualization of a converted industrial warehouse into a modern office space. Original features preserved: exposed steel trusses, brick walls, clerestory windows. New insertions: white-framed glass meeting rooms, a suspended mezzanine with steel stairs, plants cascading from the upper level. Mix of old patina and new clean materials. Workers visible but not dominant. Natural light flooding through industrial windows."
**Expected Result:** Industrial-to-office conversion showing contrast between old and new.

### 7. Landscape Architecture
**Prompt:** "Landscape architecture visualization of a waterfront public park. Terraced levels stepping down to the water. Materials: weathering steel retaining walls, reclaimed timber boardwalks, native coastal plantings. Features: a tidal pool for children, sheltered seating areas, a long pier extending into the water. People using the space naturally — walking dogs, reading, kayaking from the dock. Late afternoon. Landscape architectural rendering style."
**Expected Result:** Public space design showing human use and material choices.

### 8. Tiny House / Micro Living
**Prompt:** "Architectural cutaway section of a 300 sq ft tiny house showing the complete interior. Ground floor: combined kitchen/living with fold-down table, bathroom pod. Lofted sleeping area with skylight directly above the bed. Built-in storage in every surface — stairs are drawers, seating has hidden compartments. Materials: light plywood, white surfaces, brass hardware. One window frames a mountain view. Sectional drawing style with some 3D rendering."
**Expected Result:** Clever micro-living design shown in sectional cutaway.

### 9. Pavilion / Small Structure
**Prompt:** "Architectural visualization of a meditation pavilion in a Japanese garden. Open-sided structure with a dramatically overhanging roof in dark stained wood. Four slender columns. Raised platform with tatami. Surrounded by raked gravel, moss, and carefully placed stones. A single cherry blossom tree nearby. Morning mist. The structure is perfectly integrated with the landscape — it feels like it grew there."
**Expected Result:** Contemplative small structure in landscape context.

### 10. Futuristic Architecture
**Prompt:** "Architectural visualization of a near-future residential tower, 2040. Organic form — the building curves and narrows as it rises. Each floor plate is slightly rotated, creating a helical form. Facades are a mix of smart glass and living green walls. Ground level opens into a public garden. Vertical transport visible as external glass capsules. The building doesn't look like science fiction — it looks like the next logical step. Partly cloudy sky. Photorealistic rendering."
**Expected Result:** Believable near-future architecture that feels like a real proposal.

### 11-15. Specialized Architecture Prompts

### 11. Material Study
**Prompt:** "Close-up architectural detail photograph showing the joint where [MATERIAL A — rammed earth] meets [MATERIAL B — cor-ten steel]. Show the texture, color, and tactile quality of both materials. Natural light raking across the surfaces at a low angle. Visible construction detail — how the two materials are physically joined. Architectural photography, macro detail, showing craft."

### 12. Night Architecture
**Prompt:** "Architectural visualization of [BUILDING TYPE] at night. The building becomes a lantern — interior lighting makes the structure glow from within. Exterior materials visible only where light catches them. Landscape lighting creates pools of warm light on pathways. The sky shows deep twilight blue (not full dark). The building feels alive, warm, inviting."

### 13. Climate-Responsive Design
**Prompt:** "Architectural concept for a climate-responsive house in [HOT DESERT/TROPICAL HUMID/COLD NORTHERN/COASTAL STORM]. The design directly addresses the climate: [specific strategies — shade structures/cross ventilation/thermal mass/storm shutters]. Show the strategies clearly in the design. Section and exterior view. The house should look like it belongs in its climate."

### 14. Historic Preservation
**Prompt:** "Architectural visualization showing a modern glass extension attached to a [HISTORIC BUILDING — Victorian house/stone church/brick factory]. The new and old are clearly distinct — the glass addition doesn't mimic the historic building but respects it through scale, proportion, and a physical gap/link element. Show how the two eras of architecture coexist."

### 15. Bird's Eye / Master Plan
**Prompt:** "Bird's eye architectural visualization of a new neighborhood master plan. Mixed building heights (2-6 stories). Tree-lined streets, central park with a pond, mixed-use ground floors. The plan shows a real neighborhood — not a utopian grid. Slightly organic street layout, varying building footprints, community facilities (school, market). Autumn afternoon light. Rendered at a scale where individual trees and people are visible."

---

*15 architectural prompts. Design spaces worth inhabiting.*
