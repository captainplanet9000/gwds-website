# Stable Diffusion Prompts with Negative Prompt Pairs

30 prompts optimized for Stable Diffusion (SDXL, SD 1.5, and Flux). Each includes a positive prompt, negative prompt, and recommended settings.

---

## Photorealistic (1-10)

### 1. Portrait — Natural Light

**Positive Prompt:**
`professional portrait photograph of a 30-year-old woman with freckles, natural red hair, genuine warm smile, soft window light from the left side, shallow depth of field, sharp eyes, creamy bokeh background, shot on Sony A7III with 85mm f/1.4 lens, color graded warm and natural`

**Negative Prompt:**
`cartoon, anime, painting, illustration, oversaturated, plastic skin, airbrushed, doll-like, uncanny valley, extra fingers, deformed face, blurry, low quality, watermark, text`

**Settings:** SDXL, CFG 7, Steps 30, Sampler DPM++ 2M Karras
**Expected Result:** Natural, authentic portrait with realistic skin texture and photographic qualities.

---

### 2. Landscape — Dramatic

**Positive Prompt:**
`dramatic landscape photograph of Iceland's black sand beach at sunrise, massive basalt columns in the foreground, waves crashing in long exposure milky effect, orange and purple sky with dramatic clouds, sharp focus throughout using f/11, shot on Nikon Z9 with 14-24mm wide angle lens, National Geographic quality`

**Negative Prompt:**
`painting, illustration, cartoon, oversaturated, HDR, unrealistic colors, blurry, noisy, low resolution, watermark, text, people`

**Settings:** SDXL, CFG 7.5, Steps 35, Aspect 16:9
**Expected Result:** Magazine-quality landscape with dramatic natural lighting and tack-sharp focus.

---

### 3. Street Photography

**Positive Prompt:**
`candid street photograph of a man reading a newspaper at an outdoor cafe in Rome, morning light, espresso cup on the marble table, authentic Italian street in background, shot on Leica Q2, natural colors, slight film grain, decisive moment, photojournalistic style`

**Negative Prompt:**
`posed, staged, studio lighting, cartoon, illustration, oversaturated, HDR, blurry, deformed, extra limbs, bad anatomy, watermark`

**Settings:** SDXL, CFG 6.5, Steps 30, Aspect 3:2
**Expected Result:** Authentic-feeling candid street photograph with natural light.

---

### 4. Fashion — Studio

**Positive Prompt:**
`high fashion studio photograph, model wearing structured white geometric jacket, clean white cyclorama background, single beauty dish lighting creating controlled shadow under chin, sharp focus, minimal jewelry, strong pose with angular body position, shot by Steven Meisel for Italian Vogue, medium format quality`

**Negative Prompt:**
`casual, snapchat, low quality, blurry, oversaturated, HDR, cartoon, painting, extra fingers, deformed, bad anatomy, wrinkled clothing`

**Settings:** SDXL, CFG 7, Steps 35, Aspect 3:4
**Expected Result:** Clean editorial fashion photograph with professional studio lighting.

---

### 5. Food — Overhead

**Positive Prompt:**
`overhead food photography of artisan sourdough bread on a rustic cutting board, fresh from the oven with steam visible, scored crust showing ear, surrounded by flour dusting and wheat stalks, warm natural side light from left, on a dark slate countertop, shot on Canon 5D Mark IV with 50mm f/1.8, shallow depth of field, food magazine quality`

**Negative Prompt:**
`cartoon, illustration, painting, artificial looking, plastic, blurry, oversaturated, HDR, watermark, text, bad anatomy, deformed`

**Settings:** SDXL, CFG 7, Steps 30, Aspect 4:5
**Expected Result:** Appetizing food photography with warm tones and professional styling.

---

### 6. Architecture — Interior

**Positive Prompt:**
`interior architectural photograph of a modern minimalist living room, floor-to-ceiling windows overlooking a forest, concrete walls with wood accent panel, designer furniture in muted tones, single sculptural pendant lamp, late afternoon light casting warm rectangles on the polished concrete floor, Architectural Digest quality, shot on tilt-shift lens for perfect verticals`

**Negative Prompt:**
`cluttered, messy, low quality, blurry, cartoon, painting, HDR, oversaturated, people, animals, watermark, text, distorted perspective`

**Settings:** SDXL, CFG 7, Steps 35, Aspect 16:9
**Expected Result:** Clean architectural interior with professional composition and natural light.

---

### 7. Animal Portrait

**Positive Prompt:**
`close-up portrait of a Bengal cat with green eyes, sharp focus on the eyes, spotted coat catching studio light, shallow depth of field blurring the background, studio setup with dark grey backdrop, catchlights visible in both eyes, whiskers in detail, professional pet photography, shot on 70-200mm f/2.8 at close range`

**Negative Prompt:**
`cartoon, illustration, painting, blurry, deformed, extra limbs, bad anatomy, oversaturated, HDR, watermark, text, collar, harness`

**Settings:** SDXL, CFG 7, Steps 30, Aspect 1:1
**Expected Result:** Professional-quality pet portrait with sharp eyes and beautiful bokeh.

---

### 8. Night City

**Positive Prompt:**
`nighttime cityscape photograph of Tokyo's Shibuya crossing during rain, neon reflections on wet asphalt creating mirror effect, motion blur of pedestrians with umbrellas, sharp neon signs, long exposure traffic light trails, shot from an elevated position looking down, cinematic teal and orange color grade, Blade Runner atmosphere`

**Negative Prompt:**
`daytime, sunny, cartoon, illustration, painting, blurry, low quality, oversaturated, HDR, watermark, text, deformed people`

**Settings:** SDXL, CFG 7, Steps 35, Aspect 16:9
**Expected Result:** Atmospheric night cityscape with rain reflections and cinematic color.

---

### 9. Macro Close-Up

**Positive Prompt:**
`extreme macro photograph of a butterfly wing showing individual scales and color patterns, iridescent blue morpho wing, visible structural coloration, stack-focused for complete sharpness, scientific detail, dark background, studio ring flash lighting, shot on Canon MP-E 65mm at 5x magnification`

**Negative Prompt:**
`cartoon, illustration, painting, blurry, out of focus, low quality, oversaturated, watermark, text, unrealistic colors, dead butterfly`

**Settings:** SDXL, CFG 7.5, Steps 35, Aspect 3:2
**Expected Result:** Scientifically detailed macro with visible wing scale structure.

---

### 10. Cinematic Still

**Positive Prompt:**
`cinematic film still of a lone diner at night seen through a rain-spotted window, warm interior light contrasting cold blue exterior, person sitting alone at the counter, coffee cup and pie, analog film grain of Kodak Vision3 500T, anamorphic lens bokeh oval shapes, color graded teal shadows warm highlights, widescreen composition`

**Negative Prompt:**
`cartoon, illustration, painting, anime, happy, bright, oversaturated, HDR, blurry, watermark, text, bad anatomy, deformed`

**Settings:** SDXL, CFG 6.5, Steps 35, Aspect 21:9
**Expected Result:** Moody cinematic still with film-quality color and atmospheric lighting.

---

## Digital Art & Illustration (11-20)

### 11. Fantasy Character

**Positive Prompt:**
`digital painting of a forest druid character, elderly woman with bark-like skin and moss growing in her hair, eyes glowing soft green, holding a twisted wooden staff with a crystal embedded at the top, standing in an ancient grove with massive tree roots, volumetric light shafts through the canopy, painterly brushwork with fine detail, ArtStation trending quality`

**Negative Prompt:**
`photograph, photo, realistic, ugly, deformed, bad anatomy, extra fingers, blurry, low quality, watermark, text, amateur, simple`

**Settings:** SDXL, CFG 7.5, Steps 40
**Expected Result:** Detailed fantasy character illustration with painterly quality and atmospheric setting.

---

### 12. Sci-Fi Environment

**Positive Prompt:**
`science fiction environment concept art, massive space station interior with a city-sized atrium, artificial sky projected on the curved ceiling, terraced gardens and buildings climbing the curved walls, people visible as tiny figures for scale, warm artificial sunlight, flying transit vehicles, hard surface detail, matte painting quality, widescreen`

**Negative Prompt:**
`cartoon, anime, simple, flat, low detail, blurry, noisy, watermark, text, deformed, bad perspective, amateur`

**Settings:** SDXL, CFG 7, Steps 40, Aspect 21:9
**Expected Result:** Epic-scale sci-fi environment with architectural detail and human-scale reference.

---

### 13. Creature Design

**Positive Prompt:**
`creature design concept art, deep sea bioluminescent predator, translucent skin showing internal structure, rows of small glowing blue dots along its body, multiple fins adapted for deep-water movement, large eyes reflecting light, body between an anglerfish and a manta ray, dark ocean environment, naturalistic design that could exist in nature, scientific illustration quality`

**Negative Prompt:**
`cartoon, cute, chibi, amateur, blurry, noisy, low quality, watermark, text, deformed, unrealistic, silly`

**Settings:** SDXL, CFG 7.5, Steps 40
**Expected Result:** Believable creature concept with bio-inspired design elements.

---

### 14. Retro Poster Design

**Positive Prompt:**
`vintage 1960s space program poster design, bold flat color illustration of a rocket launching from a tropical island, limited color palette of 4 colors: navy blue, cream white, orange, and olive green, screen printing texture, bold geometric shapes, halftone dot pattern in background, condensed sans-serif typography placeholder, Soviet constructivism meets American mid-century modern`

**Negative Prompt:**
`photograph, realistic, 3D, blurry, noisy, watermark, many colors, gradient, photorealistic, complex, cluttered`

**Settings:** SDXL, CFG 7, Steps 35, Aspect 2:3
**Expected Result:** Clean retro poster with limited palette and screen-print texture.

---

### 15. Isometric Scene

**Positive Prompt:**
`isometric illustration of a cozy coffee shop interior, warm lighting, barista behind counter, customer reading on a couch, plants on windowsill, pastry display case, exposed brick wall, wooden floors, steam rising from cups, clean vector illustration style with soft shadows, pastel warm color palette`

**Negative Prompt:**
`photograph, realistic, 3D render, blurry, noisy, cluttered, dark, gloomy, watermark, text, perspective distortion`

**Settings:** SDXL, CFG 7, Steps 35, Aspect 1:1
**Expected Result:** Clean isometric illustration with warm tones and detailed interior elements.

---

### 16-20. Quick Illustration Prompts

### 16. Anime Style Portrait
**Positive:** `anime illustration, detailed portrait of a cyberpunk girl with glowing circuit tattoos, neon purple hair, confident expression, city lights bokeh behind, clean line art, vibrant colors, trending pixiv`
**Negative:** `photograph, realistic, blurry, low quality, extra fingers, bad anatomy, deformed, western cartoon, 3D, watermark`

### 17. Dark Fantasy
**Positive:** `dark fantasy illustration, corrupted knight in black crystalline armor, crimson cape flowing in supernatural wind, standing on a cliff overlooking a burning kingdom, dark clouds with red lightning, dramatic backlighting, oil painting digital art style`
**Negative:** `bright, happy, cartoon, cute, blurry, low quality, watermark, amateur, simple, flat`

### 18. Steampunk Scene
**Positive:** `steampunk workshop interior, massive clock mechanism being assembled, brass gears and copper pipes everywhere, inventor with welding goggles on forehead examining blueprints, warm gaslight illumination, atmospheric steam and dust particles, Victorian industrial aesthetic, detailed props`
**Negative:** `modern, contemporary, plastic, clean, minimal, cartoon, blurry, watermark, low quality`

### 19. Underwater Scene
**Positive:** `underwater digital painting, ancient sunken Greek temple overgrown with coral and kelp, school of tropical fish swimming through marble columns, god rays penetrating from the surface above, bioluminescent organisms providing accent lights, peaceful and serene atmosphere, matte painting quality`
**Negative:** `dry, above water, cartoon, blurry, low quality, watermark, text, dark, murky, scary`

### 20. Solarpunk City
**Positive:** `solarpunk cityscape, future city covered in lush green vegetation, solar panels integrated into organic building designs, vertical gardens on every surface, elevated walkways between tree-covered towers, clean energy, blue sky, diverse people using public spaces, utopian but believable, concept art`
**Negative:** `dystopian, dark, gloomy, destroyed, cyberpunk, pollution, blurry, low quality, watermark, text`

---

## Stylized & Abstract (21-30)

### 21. Geometric Abstract

**Positive Prompt:**
`geometric abstract art, interlocking triangular shapes in a gradient from deep teal to warm coral, clean edges with subtle shadow suggesting depth, metallic gold accent lines separating color fields, balanced composition with visual weight centered, suitable for large format print, contemporary art gallery quality`

**Negative Prompt:**
`photograph, realistic, figurative, blurry, noisy, cluttered, watermark, text, messy, paint splatters, organic shapes`

**Settings:** SDXL, CFG 7, Steps 30, Aspect 1:1

---

### 22. Paper Cut Art
**Positive:** `paper cut art illustration of a mountain landscape at sunset, multiple layers of cut paper creating depth, warm to cool color gradient from foreground to background, visible paper edge shadows between layers, deer silhouette in the valley, birds in the sky, delicate hand-cut precision`
**Negative:** `photograph, realistic, digital, flat, no depth, blurry, watermark, text`

### 23. Ink Wash / Sumi-e
**Positive:** `Japanese sumi-e ink wash painting of bamboo in wind, varying ink density from deep black to pale grey, dynamic brushstrokes showing the bend of stalks, leaves suggested with quick confident strokes, generous white space, subtle rain suggested by light ink mist, traditional rice paper texture`
**Negative:** `colorful, oversaturated, photograph, digital, cartoon, cluttered, busy, watermark`

### 24. Vaporwave Aesthetic
**Positive:** `vaporwave aesthetic digital art, Greek marble bust of Apollo fragmented and floating, neon pink and turquoise gradient background, palm trees and grid floor in perspective, chromatic aberration effect, VHS scan lines, Windows 95 dialog box floating nearby, Japanese text characters, nostalgic and surreal`
**Negative:** `realistic, photograph, natural, muted colors, blurry, low quality, watermark`

### 25. Art Deco
**Positive:** `Art Deco illustration of a luxury ocean liner at night, geometric stylized waves, golden sunburst pattern in the sky, limited palette of navy, gold, and cream, symmetric composition, sleek lines and stepped forms, metallic foil effect on gold elements, 1920s glamour`
**Negative:** `photograph, realistic, organic, messy, modern, blurry, watermark, text`

### 26. Glitch Art
**Positive:** `glitch art portrait, human face corrupted by digital artifacts, pixel sorting creating color streaks, data moshing effect distorting facial features, RGB color channel offset, scan lines and static noise, intentional digital corruption as aesthetic, cyberpunk influenced`
**Negative:** `clean, perfect, undistorted, cartoon, painting, blurry, low quality, watermark`

### 27. Claymation Style
**Positive:** `claymation style character, friendly robot made of visible clay with fingerprint texture, standing in a miniature clay set of a kitchen, slightly imperfect proportions adding charm, real clay material properties — matte, slightly shiny in highlights, practical miniature lighting with visible shadows, stop-motion film aesthetic`
**Negative:** `realistic, digital, smooth, perfect, photograph, 2D, flat, blurry, watermark`

### 28. Woodblock Print
**Positive:** `Japanese ukiyo-e woodblock print style, the great wave reimagined with a modern cargo ship, traditional indigo and cream color palette with touches of red, visible wood grain texture from the printing block, rain lines and foam detail, Hokusai-inspired composition and stylization`
**Negative:** `photograph, realistic, digital, blurry, oversaturated, modern, 3D, watermark`

### 29. Collage Art
**Positive:** `mixed media collage art, vintage magazine cutouts of eyes and hands arranged on a torn map background, geometric shapes in block colors overlapping the collage, visible paper textures and torn edges, red thread connecting elements, analog handmade quality, Dadaist influence`
**Negative:** `digital, clean, uniform, photograph, blurry, simple, minimal, watermark`

### 30. Neon Light Art
**Positive:** `photorealistic neon light sign spelling "OPEN" in warm pink cursive, mounted on a dark brick wall, neon glow illuminating the surrounding bricks, slight flickering quality, wire and transformer visible, glass tube imperfections, photographed at night, shallow depth of field focused on the sign`
**Negative:** `cartoon, illustration, painting, flat, blurry, daytime, watermark, text overlay`

---

*30 Stable Diffusion prompts with negative pairs. Generate. Iterate. Refine.*
