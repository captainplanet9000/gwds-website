# AI Product Photography Prompts

20 prompts for generating product shots, mockups, and commercial imagery using AI.

---

### 1. Clean Studio Product Shot
**Prompt:** "Professional product photograph of [PRODUCT] centered on a pure white background. Single overhead softbox creating clean, even lighting with a gentle shadow underneath. Product fills 60% of the frame. Sharp focus across the entire product. No reflections on background. E-commerce quality — Amazon listing standard."
**Negative:** "shadows, colored background, dark, moody, hands, people, cluttered, blurry"

### 2. Lifestyle Product Shot
**Prompt:** "Lifestyle product photograph of [PRODUCT] in a [SETTING — modern kitchen/cozy bedroom/outdoor café]. The product is the clear subject but placed naturally in the environment. Shallow depth of field keeps the product sharp while the background is softly blurred. Natural window light from the left. Warm, inviting color palette. The image tells a story about how the product fits into someone's life."
**Expected Result:** Commercial-quality lifestyle shot that contextualizes the product.

### 3. Hero Shot — Dramatic Angle
**Prompt:** "Dramatic hero product photograph of [PRODUCT] shot from a low angle, slightly below the product looking up. Dark background — deep charcoal gradient. Single directional light from the upper left creating dramatic highlights and shadows that emphasize the product's form and materials. Slight vignette. Premium, powerful, confident mood. Like a luxury car commercial still."
**Expected Result:** Premium product image with dramatic lighting and hero positioning.

### 4. Flat Lay Arrangement
**Prompt:** "Flat lay product photograph of [PRODUCT] surrounded by complementary accessories and props. Shot directly from above on a [COLOR — marble/wood/concrete] surface. Products arranged in an organized, visually balanced composition. Each item slightly angled for visual interest. Soft, even lighting with minimal shadows. Instagram-ready lifestyle flat lay."
**Expected Result:** Curated flat lay composition suitable for social media.

### 5. Splash/Action Shot
**Prompt:** "High-speed product photograph of [PRODUCT — beverage/skincare/perfume] with liquid splash effect. Frozen motion of [liquid type] splashing around the product at the moment of impact. Crystal clear droplets visible. Product remains sharp and in focus at center. Dark background with dramatic side lighting catching the liquid. 1/8000 shutter speed frozen action look."
**Expected Result:** Dynamic product shot with frozen liquid motion.

### 6. Packaging Mockup
**Prompt:** "Photorealistic packaging mockup of a [PRODUCT TYPE — box/bottle/bag/tube] with [DESIGN DESCRIPTION] printed on it. The package sits on a [SURFACE] with soft studio lighting. 45-degree angle showing front and one side panel. Clean shadow underneath. Background is [COLOR] gradient. Package material looks authentic — [matte paper/glossy cardboard/frosted glass/kraft paper]."
**Expected Result:** Realistic packaging visualization ready for client presentation.

### 7. Unboxing Scene
**Prompt:** "Overhead view of an unboxing experience for a premium [PRODUCT]. Custom box opened to reveal the product nestled in [packaging material — black foam/tissue paper/molded insert]. The box lid is open at 45 degrees showing the interior lid design. Hands reaching into frame from the bottom. Soft natural light. The experience looks premium and considered. Think Apple unboxing aesthetic."
**Expected Result:** Premium unboxing moment that sells the experience.

### 8. Environmental Product Shot
**Prompt:** "Product photograph of [PRODUCT — outdoor gear/camping equipment/sportswear] shot in its natural environment. [OUTDOOR SETTING — mountain trail/beach/forest clearing]. Product is the clear hero but the environment tells the story. Golden hour lighting. Shot on a wide lens showing product in context with landscape. National Geographic meets commercial advertising."
**Expected Result:** Product in its natural use environment with editorial quality.

### 9. Ingredient/Material Showcase
**Prompt:** "Product photograph of [SKINCARE/FOOD PRODUCT] deconstructed with its raw ingredients scattered around it. The product bottle/package in the center, surrounded by [specific ingredients — fresh botanicals/coffee beans/honey/citrus slices]. Each ingredient fresh and beautiful. White marble surface. Overhead light with gentle side fill. Clean, scientific but beautiful."
**Expected Result:** Ingredients-forward product shot for clean/natural brand positioning.

### 10. Scale/Size Context
**Prompt:** "Product photograph showing [PRODUCT] next to everyday objects for size reference. [PRODUCT] on a desk next to a standard coffee cup, smartphone, and pen. Clean white desk. Overhead soft lighting. The image's purpose is to communicate the product's actual size without needing measurements. Lifestyle editorial feel rather than sterile comparison."
**Expected Result:** Clear size communication in a visually appealing context.

### 11-15. Specific Product Categories

### 11. Tech Product — Minimal
**Prompt:** "Minimal product photograph of [TECH PRODUCT] on a seamless matte grey background. Single key light from 45-degrees above right. Subtle gradient on background from lighter to darker bottom-to-top. Product shadow is soft and natural. No props. The product's design and materials are the entire focus. Clean enough for a keynote presentation slide."

### 12. Fashion/Apparel
**Prompt:** "Fashion product photograph of [GARMENT] on an invisible mannequin (ghost mannequin effect). Product appears to be floating and maintaining its shape without a model or hanger. Clean white background. Even lighting shows fabric texture and color accurately. Front view. No wrinkles. E-commerce fashion photography standard."

### 13. Jewelry Close-Up
**Prompt:** "Macro product photograph of [JEWELRY PIECE] on a [dark velvet/white marble/natural stone] surface. Focus stacked for complete sharpness from front to back. Single sparkle highlight on the main stone/metal. Visible material texture — metal grain, stone facets. Shot at eye level. Black negative space filling 40% of the frame. Luxury jewelry brand aesthetic."

### 14. Furniture in Room
**Prompt:** "Interior styled product photograph of [FURNITURE PIECE] in a curated living room setting. The room is styled but not cluttered — supporting the hero product without competing. Natural light from large window. The furniture piece occupies the visual center. Color palette of the room complements the product. Architectural Digest editorial quality."

### 15. Food Product Styling
**Prompt:** "Food product photograph of [FOOD PRODUCT/BRAND] styled for maximum appetite appeal. [Product] as hero with fresh ingredients and a prepared dish visible. Steam rising from hot elements. Fresh herbs as garnish. Rustic wooden surface. Warm directional light creating depth. Food magazine cover quality — you should want to eat through the screen."

---

### 16-20. Advanced Product Shots

### 16. 360 View Angle
**Prompt:** "Product photograph of [PRODUCT] at a precise 3/4 angle (45 degrees rotated), showing both the front face and side profile simultaneously. This is the 'hero angle' that shows maximum product information in one shot. Clean background, studio lighting, sharp throughout."

### 17. Color Variants Display
**Prompt:** "Product photograph showing [PRODUCT] in all available color variants arranged in a row or grid. Each unit at the same angle and lighting. Colors: [LIST COLORS]. Clean white background. Even spacing. The lineup should look satisfying and complete. Suitable for a website's color selection section."

### 18. Texture Detail
**Prompt:** "Extreme close-up product photograph showing the material texture of [PRODUCT]. Fill the frame with the surface detail — visible [leather grain/fabric weave/wood grain/brushed metal]. Raking light from the side emphasizing texture depth. Sharp enough to see individual material fibers. This shot is about craft and quality."

### 19. Product in Hand
**Prompt:** "Product photograph of a hand holding [PRODUCT] naturally. The hand is neutral — clean, not too stylized. Product is the focus, hand provides scale and context. Soft natural light. Shallow depth of field with the product sharp and the background blurred. Shot at the level of the hand, not from above."

### 20. Before/After Product Shot
**Prompt:** "Split-frame product photograph showing before and after using [PRODUCT]. Left side: the 'before' scenario — [describe messy/untreated/plain state]. Right side: the 'after' — [describe clean/treated/improved state]. Same angle, same lighting, clear visual improvement. Clean dividing line between the two halves."

---

*20 product photography prompts. Make your products look like they belong on a billboard.*
