/**
 * Williams Alligator Strategy
 *
 * Created by Bill Williams. Uses 3 smoothed moving averages (SMMA) with different
 * periods and shifts, representing the Jaw, Teeth, and Lips of an alligator:
 *
 * - Jaw (Blue):  SMMA(13) shifted 8 bars forward — the slowest line
 * - Teeth (Red): SMMA(8) shifted 5 bars forward — the medium line
 * - Lips (Green): SMMA(5) shifted 3 bars forward — the fastest line
 *
 * Signals:
 * - All lines intertwined = alligator is "sleeping" (ranging market, no trade)
 * - Lines spread apart upward (Lips > Teeth > Jaw) = alligator is "eating" (uptrend, buy)
 * - Lines spread apart downward (Lips < Teeth < Jaw) = eating downward (downtrend, sell)
 * - Lines converging after spread = alligator is "sated" (trend ending, exit)
 */

import type { OHLCV } from '../hyperliquid'
import { smma } from '../indicators'
import type { TradingSignal, StrategyConfig, Strategy } from './types'

export class WilliamsAlligatorStrategy implements Strategy {
  config: StrategyConfig

  constructor(config?: Partial<StrategyConfig>) {
    this.config = { ...this.getDefaultConfig(), ...config }
  }

  getDefaultConfig(): StrategyConfig {
    return {
      name: 'Williams Alligator',
      id: 'williams_alligator',
      enabled: true,
      symbols: ['BTC', 'ETH', 'SOL'],
      timeframe: '1h',
      riskLevel: 'medium',
      maxPositions: 3,
      params: {
        jawPeriod: 13,
        jawShift: 8,
        teethPeriod: 8,
        teethShift: 5,
        lipsPeriod: 5,
        lipsShift: 3,
        spreadThreshold: 0.003, // minimum spread % to confirm trend
      },
    }
  }

  analyze(symbol: string, candles: OHLCV[]): TradingSignal {
    const { jawPeriod, teethPeriod, lipsPeriod, spreadThreshold } = this.config.params
    const price = candles[candles.length - 1].close
    const ts = candles[candles.length - 1].timestamp

    // Use median price (HL/2) as input — standard for Alligator
    const medianPrices = candles.map(c => (c.high + c.low) / 2)

    if (medianPrices.length < jawPeriod + 10) {
      return { strategy: 'williams_alligator', symbol, action: 'hold', confidence: 0, price, stopLoss: null, takeProfit: null, size: 0, reasoning: 'Insufficient data', timestamp: ts, metadata: {} }
    }

    const jawValues = smma(medianPrices, jawPeriod)
    const teethValues = smma(medianPrices, teethPeriod)
    const lipsValues = smma(medianPrices, lipsPeriod)

    if (jawValues.length === 0 || teethValues.length === 0 || lipsValues.length === 0) {
      return { strategy: 'williams_alligator', symbol, action: 'hold', confidence: 0, price, stopLoss: null, takeProfit: null, size: 0, reasoning: 'Insufficient data for SMMA', timestamp: ts, metadata: {} }
    }

    const jaw = jawValues[jawValues.length - 1]
    const teeth = teethValues[teethValues.length - 1]
    const lips = lipsValues[lipsValues.length - 1]

    // Calculate spread (normalized)
    const spread = Math.abs(lips - jaw) / jaw
    const isBullishAlignment = lips > teeth && teeth > jaw
    const isBearishAlignment = lips < teeth && teeth < jaw

    // Check if lines are spreading (momentum increasing)
    const prevJaw = jawValues.length > 2 ? jawValues[jawValues.length - 3] : jaw
    const prevTeeth = teethValues.length > 2 ? teethValues[teethValues.length - 3] : teeth
    const prevLips = lipsValues.length > 2 ? lipsValues[lipsValues.length - 3] : lips
    const prevSpread = Math.abs(prevLips - prevJaw) / prevJaw
    const isSpreading = spread > prevSpread

    if (isBullishAlignment && spread > spreadThreshold && isSpreading) {
      return {
        strategy: 'williams_alligator', symbol, action: 'buy',
        confidence: Math.min(spread * 50, 1), price,
        stopLoss: jaw, // Jaw as dynamic stop
        takeProfit: price + (price - jaw) * 2, // 2:1 R:R
        size: 1,
        reasoning: `Alligator eating upward. Lips ($${lips.toFixed(2)}) > Teeth ($${teeth.toFixed(2)}) > Jaw ($${jaw.toFixed(2)}). Spread: ${(spread * 100).toFixed(2)}%`,
        timestamp: ts,
        metadata: { jaw, teeth, lips, spread, isSpreading },
      }
    }

    if (isBearishAlignment && spread > spreadThreshold && isSpreading) {
      return {
        strategy: 'williams_alligator', symbol, action: 'sell',
        confidence: Math.min(spread * 50, 1), price,
        stopLoss: jaw,
        takeProfit: price - (jaw - price) * 2,
        size: 1,
        reasoning: `Alligator eating downward. Lips ($${lips.toFixed(2)}) < Teeth ($${teeth.toFixed(2)}) < Jaw ($${jaw.toFixed(2)}). Spread: ${(spread * 100).toFixed(2)}%`,
        timestamp: ts,
        metadata: { jaw, teeth, lips, spread, isSpreading },
      }
    }

    const state = spread < spreadThreshold * 0.5 ? 'sleeping' : 'sated'
    return {
      strategy: 'williams_alligator', symbol, action: 'hold', confidence: 0, price,
      stopLoss: null, takeProfit: null, size: 0,
      reasoning: `Alligator ${state}. Lines intertwined. Spread: ${(spread * 100).toFixed(2)}%`,
      timestamp: ts, metadata: { jaw, teeth, lips, spread, state },
    }
  }
}
