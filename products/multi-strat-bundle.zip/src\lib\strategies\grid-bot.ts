/**
 * Grid Bot Strategy
 *
 * Places buy and sell orders at evenly spaced price intervals within a range.
 * Profits from price oscillation within the grid:
 *
 * - Define upper and lower price bounds
 * - Divide into N grid levels
 * - Buy at each level below current price
 * - Sell at each level above current price
 * - When price crosses a level, the order executes and a new order is placed
 *
 * Best for ranging/sideways markets. Loses money in strong one-directional moves.
 */

import type { OHLCV } from '../hyperliquid'
import { bollingerBands, adx as calcADX, atr as calcATR } from '../indicators'
import type { TradingSignal, StrategyConfig, Strategy } from './types'

interface GridLevel {
  price: number
  type: 'buy' | 'sell'
  active: boolean
}

export class GridBotStrategy implements Strategy {
  config: StrategyConfig

  constructor(config?: Partial<StrategyConfig>) {
    this.config = { ...this.getDefaultConfig(), ...config }
  }

  getDefaultConfig(): StrategyConfig {
    return {
      name: 'Grid Bot',
      id: 'grid_bot',
      enabled: true,
      symbols: ['BTC', 'ETH'],
      timeframe: '1h',
      riskLevel: 'low',
      maxPositions: 10,
      params: {
        gridLevels: 10,
        rangePct: 10,             // total range as % of current price
        maxADX: 20,               // only run grid in low-ADX (ranging) markets
        autoRange: true,          // auto-detect range from Bollinger Bands
        bbPeriod: 20,
        bbStdDev: 2,
        sizePerGrid: 0.1,         // position size per grid level
      },
    }
  }

  analyze(symbol: string, candles: OHLCV[]): TradingSignal {
    const { gridLevels, rangePct, maxADX, autoRange, bbPeriod, bbStdDev, sizePerGrid } = this.config.params
    const price = candles[candles.length - 1].close
    const ts = candles[candles.length - 1].timestamp

    if (candles.length < bbPeriod + 10) {
      return { strategy: 'grid_bot', symbol, action: 'hold', confidence: 0, price, stopLoss: null, takeProfit: null, size: 0, reasoning: 'Insufficient data', timestamp: ts, metadata: {} }
    }

    // Check if market is ranging (low ADX)
    const adxVal = calcADX(candles)
    if (adxVal > maxADX) {
      return {
        strategy: 'grid_bot', symbol, action: 'hold', confidence: 0, price,
        stopLoss: null, takeProfit: null, size: 0,
        reasoning: `Market trending (ADX ${adxVal.toFixed(1)} > ${maxADX}). Grid bot works best in ranging markets.`,
        timestamp: ts, metadata: { adx: adxVal },
      }
    }

    // Determine grid range
    let rangeUpper: number
    let rangeLower: number

    if (autoRange) {
      const closes = candles.map(c => c.close)
      const bb = bollingerBands(closes, bbPeriod, bbStdDev)
      rangeUpper = bb.upper[bb.upper.length - 1]
      rangeLower = bb.lower[bb.lower.length - 1]
    } else {
      const halfRange = price * (rangePct / 200)
      rangeUpper = price + halfRange
      rangeLower = price - halfRange
    }

    // Build grid levels
    const gridSpacing = (rangeUpper - rangeLower) / gridLevels
    const levels: GridLevel[] = []
    for (let i = 0; i <= gridLevels; i++) {
      const levelPrice = rangeLower + gridSpacing * i
      levels.push({
        price: levelPrice,
        type: levelPrice < price ? 'buy' : 'sell',
        active: true,
      })
    }

    // Find nearest buy and sell levels
    const buyLevels = levels.filter(l => l.type === 'buy').sort((a, b) => b.price - a.price)
    const sellLevels = levels.filter(l => l.type === 'sell').sort((a, b) => a.price - b.price)

    const nearestBuy = buyLevels[0]
    const nearestSell = sellLevels[0]

    // Check if price is near a grid level (within 0.5 grid spacing)
    const threshold = gridSpacing * 0.5

    if (nearestBuy && Math.abs(price - nearestBuy.price) < threshold) {
      return {
        strategy: 'grid_bot', symbol, action: 'buy',
        confidence: 0.6, price,
        stopLoss: rangeLower * 0.98,
        takeProfit: nearestSell?.price ?? rangeUpper,
        size: sizePerGrid,
        reasoning: `Price near grid buy level $${nearestBuy.price.toFixed(2)}. Grid: $${rangeLower.toFixed(2)} - $${rangeUpper.toFixed(2)} (${gridLevels} levels)`,
        timestamp: ts,
        metadata: { adx: adxVal, rangeUpper, rangeLower, gridSpacing, nearestBuy: nearestBuy.price, nearestSell: nearestSell?.price, levels: levels.length },
      }
    }

    if (nearestSell && Math.abs(price - nearestSell.price) < threshold) {
      return {
        strategy: 'grid_bot', symbol, action: 'sell',
        confidence: 0.6, price,
        stopLoss: rangeUpper * 1.02,
        takeProfit: nearestBuy?.price ?? rangeLower,
        size: sizePerGrid,
        reasoning: `Price near grid sell level $${nearestSell.price.toFixed(2)}. Grid: $${rangeLower.toFixed(2)} - $${rangeUpper.toFixed(2)} (${gridLevels} levels)`,
        timestamp: ts,
        metadata: { adx: adxVal, rangeUpper, rangeLower, gridSpacing, nearestBuy: nearestBuy?.price, nearestSell: nearestSell.price, levels: levels.length },
      }
    }

    return {
      strategy: 'grid_bot', symbol, action: 'hold', confidence: 0, price,
      stopLoss: null, takeProfit: null, size: 0,
      reasoning: `Price between grid levels. Range: $${rangeLower.toFixed(2)} - $${rangeUpper.toFixed(2)}, ADX: ${adxVal.toFixed(1)}`,
      timestamp: ts, metadata: { adx: adxVal, rangeUpper, rangeLower, gridSpacing },
    }
  }
}
