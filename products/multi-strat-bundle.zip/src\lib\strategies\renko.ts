/**
 * Renko Strategy
 *
 * Renko charts use fixed-size "bricks" based on price movement, ignoring time.
 * A new brick is drawn only when price moves by the brick size.
 *
 * This filters out noise and makes trends crystal clear:
 * - Series of up bricks = uptrend
 * - Series of down bricks = downtrend
 * - Reversal (color change) = potential entry/exit
 *
 * Brick size is typically set to ATR or a fixed percentage of price.
 */

import type { OHLCV } from '../hyperliquid'
import { atr as calcATR } from '../indicators'
import type { TradingSignal, StrategyConfig, Strategy } from './types'

interface RenkoBrick {
  open: number
  close: number
  direction: 'up' | 'down'
  index: number
}

function buildRenkoBricks(candles: OHLCV[], brickSize: number): RenkoBrick[] {
  if (candles.length === 0 || brickSize <= 0) return []

  const bricks: RenkoBrick[] = []
  let currentBase = Math.round(candles[0].close / brickSize) * brickSize

  for (const candle of candles) {
    const price = candle.close

    // Up bricks
    while (price >= currentBase + brickSize) {
      bricks.push({
        open: currentBase,
        close: currentBase + brickSize,
        direction: 'up',
        index: bricks.length,
      })
      currentBase += brickSize
    }

    // Down bricks
    while (price <= currentBase - brickSize) {
      bricks.push({
        open: currentBase,
        close: currentBase - brickSize,
        direction: 'down',
        index: bricks.length,
      })
      currentBase -= brickSize
    }
  }

  return bricks
}

export class RenkoStrategy implements Strategy {
  config: StrategyConfig

  constructor(config?: Partial<StrategyConfig>) {
    this.config = { ...this.getDefaultConfig(), ...config }
  }

  getDefaultConfig(): StrategyConfig {
    return {
      name: 'Renko',
      id: 'renko',
      enabled: true,
      symbols: ['BTC', 'ETH'],
      timeframe: '1h',
      riskLevel: 'medium',
      maxPositions: 2,
      params: {
        brickSizeMode: 'atr',    // 'atr' or 'fixed'
        atrPeriod: 14,
        atrMultiplier: 1.0,
        fixedBrickPct: 1.0,      // % of price for fixed mode
        confirmBricks: 3,         // bricks in same direction to confirm
        reversalBricks: 2,        // bricks in opposite direction for reversal signal
      },
    }
  }

  analyze(symbol: string, candles: OHLCV[]): TradingSignal {
    const { brickSizeMode, atrPeriod, atrMultiplier, fixedBrickPct, confirmBricks, reversalBricks } = this.config.params
    const price = candles[candles.length - 1].close
    const ts = candles[candles.length - 1].timestamp

    if (candles.length < atrPeriod + 10) {
      return { strategy: 'renko', symbol, action: 'hold', confidence: 0, price, stopLoss: null, takeProfit: null, size: 0, reasoning: 'Insufficient data', timestamp: ts, metadata: {} }
    }

    // Determine brick size
    let brickSize: number
    if (brickSizeMode === 'atr') {
      const atrValues = calcATR(candles, atrPeriod)
      brickSize = (atrValues[atrValues.length - 1] || price * 0.01) * atrMultiplier
    } else {
      brickSize = price * (fixedBrickPct / 100)
    }

    if (brickSize <= 0) brickSize = price * 0.01

    const bricks = buildRenkoBricks(candles, brickSize)

    if (bricks.length < confirmBricks + reversalBricks) {
      return { strategy: 'renko', symbol, action: 'hold', confidence: 0, price, stopLoss: null, takeProfit: null, size: 0, reasoning: `Only ${bricks.length} bricks formed`, timestamp: ts, metadata: { brickSize, totalBricks: bricks.length } }
    }

    const recentBricks = bricks.slice(-Math.max(confirmBricks, reversalBricks))
    const lastBrick = bricks[bricks.length - 1]
    const lastDirection = lastBrick.direction

    // Count consecutive bricks in same direction
    let consecutiveCount = 0
    for (let i = bricks.length - 1; i >= 0; i--) {
      if (bricks[i].direction === lastDirection) consecutiveCount++
      else break
    }

    // Check for reversal (direction change after a trend)
    const prevDirection = bricks.length > consecutiveCount
      ? bricks[bricks.length - consecutiveCount - 1].direction
      : null

    const isReversal = prevDirection !== null && prevDirection !== lastDirection && consecutiveCount >= reversalBricks

    if (lastDirection === 'up' && (consecutiveCount >= confirmBricks || isReversal)) {
      const conf = Math.min(consecutiveCount / (confirmBricks * 2), 1)
      return {
        strategy: 'renko', symbol, action: 'buy',
        confidence: isReversal ? conf + 0.2 : conf, price,
        stopLoss: lastBrick.open - brickSize * 2,
        takeProfit: price + brickSize * confirmBricks,
        size: 1,
        reasoning: isReversal
          ? `Renko reversal to UP after ${consecutiveCount} up bricks (brick: $${brickSize.toFixed(2)})`
          : `${consecutiveCount} consecutive UP bricks (brick: $${brickSize.toFixed(2)})`,
        timestamp: ts,
        metadata: { brickSize, consecutiveCount, isReversal, direction: 'up', totalBricks: bricks.length },
      }
    }

    if (lastDirection === 'down' && (consecutiveCount >= confirmBricks || isReversal)) {
      const conf = Math.min(consecutiveCount / (confirmBricks * 2), 1)
      return {
        strategy: 'renko', symbol, action: 'sell',
        confidence: isReversal ? conf + 0.2 : conf, price,
        stopLoss: lastBrick.open + brickSize * 2,
        takeProfit: price - brickSize * confirmBricks,
        size: 1,
        reasoning: isReversal
          ? `Renko reversal to DOWN after ${consecutiveCount} down bricks (brick: $${brickSize.toFixed(2)})`
          : `${consecutiveCount} consecutive DOWN bricks (brick: $${brickSize.toFixed(2)})`,
        timestamp: ts,
        metadata: { brickSize, consecutiveCount, isReversal, direction: 'down', totalBricks: bricks.length },
      }
    }

    return {
      strategy: 'renko', symbol, action: 'hold', confidence: 0, price,
      stopLoss: null, takeProfit: null, size: 0,
      reasoning: `${consecutiveCount} ${lastDirection} brick(s), need ${confirmBricks} to confirm. Brick: $${brickSize.toFixed(2)}`,
      timestamp: ts, metadata: { brickSize, consecutiveCount, direction: lastDirection, totalBricks: bricks.length },
    }
  }
}
