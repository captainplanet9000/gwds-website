/**
 * Shared types for all trading strategies
 */

import type { OHLCV } from '../hyperliquid'

export interface TradingSignal {
  strategy: string
  symbol: string
  action: 'buy' | 'sell' | 'hold'
  confidence: number     // 0-1
  price: number
  stopLoss: number | null
  takeProfit: number | null
  size: number
  reasoning: string
  timestamp: number
  metadata: Record<string, any>
}

export interface StrategyConfig {
  name: string
  id: string
  enabled: boolean
  symbols: string[]
  timeframe: string
  riskLevel: 'low' | 'medium' | 'high'
  maxPositions: number
  params: Record<string, any>
}

export interface Strategy {
  config: StrategyConfig
  analyze(symbol: string, candles: OHLCV[]): TradingSignal
  getDefaultConfig(): StrategyConfig
}

export type StrategyId =
  | 'momentum'
  | 'mean_reversion'
  | 'trend_following'
  | 'breakout'
  | 'scalping'
  | 'darvas_box'
  | 'elliott_wave'
  | 'williams_alligator'
  | 'heikin_ashi'
  | 'renko'
  | 'grid_bot'
  | 'dca'
