/**
 * Momentum Strategy
 * Extracted from Cival Trading Dashboard
 * Follows trend using EMA crossovers + RSI filter
 */

import type { OHLCV } from '../hyperliquid'
import { ema, rsi as calcRSI } from '../indicators'
import type { TradingSignal, StrategyConfig, Strategy } from './types'

export class MomentumStrategy implements Strategy {
  config: StrategyConfig

  constructor(config?: Partial<StrategyConfig>) {
    this.config = { ...this.getDefaultConfig(), ...config }
  }

  getDefaultConfig(): StrategyConfig {
    return {
      name: 'Momentum',
      id: 'momentum',
      enabled: true,
      symbols: ['BTC', 'ETH', 'SOL'],
      timeframe: '1h',
      riskLevel: 'medium',
      maxPositions: 3,
      params: {
        fastPeriod: 12,
        slowPeriod: 26,
        rsiPeriod: 14,
        rsiOverbought: 70,
        rsiOversold: 30,
        threshold: 0.02,
      },
    }
  }

  analyze(symbol: string, candles: OHLCV[]): TradingSignal {
    const closes = candles.map(c => c.close)
    const { fastPeriod, slowPeriod, rsiPeriod, rsiOverbought, rsiOversold, threshold } = this.config.params
    const price = closes[closes.length - 1]
    const ts = candles[candles.length - 1].timestamp

    if (closes.length < slowPeriod + 5) {
      return { strategy: 'momentum', symbol, action: 'hold', confidence: 0, price, stopLoss: null, takeProfit: null, size: 0, reasoning: 'Insufficient data', timestamp: ts, metadata: {} }
    }

    const fastEMA = ema(closes, fastPeriod)
    const slowEMA = ema(closes, slowPeriod)
    const rsiValues = calcRSI(closes, rsiPeriod)

    const fastVal = fastEMA[fastEMA.length - 1]
    const slowVal = slowEMA[slowEMA.length - 1]
    const rsiVal = rsiValues[rsiValues.length - 1] ?? 50
    const momentum = (fastVal - slowVal) / slowVal

    if (momentum > threshold && rsiVal < rsiOverbought) {
      const conf = Math.min(Math.abs(momentum) * 10, 1)
      return {
        strategy: 'momentum', symbol, action: 'buy', confidence: conf, price,
        stopLoss: price * 0.95, takeProfit: price * 1.15,
        size: 1, reasoning: `Bullish momentum ${(momentum * 100).toFixed(2)}%, RSI ${rsiVal.toFixed(1)}`,
        timestamp: ts, metadata: { momentum, rsi: rsiVal, fastEMA: fastVal, slowEMA: slowVal },
      }
    }

    if (momentum < -threshold && rsiVal > rsiOversold) {
      const conf = Math.min(Math.abs(momentum) * 10, 1)
      return {
        strategy: 'momentum', symbol, action: 'sell', confidence: conf, price,
        stopLoss: price * 1.05, takeProfit: price * 0.85,
        size: 1, reasoning: `Bearish momentum ${(momentum * 100).toFixed(2)}%, RSI ${rsiVal.toFixed(1)}`,
        timestamp: ts, metadata: { momentum, rsi: rsiVal },
      }
    }

    return { strategy: 'momentum', symbol, action: 'hold', confidence: 0, price, stopLoss: null, takeProfit: null, size: 0, reasoning: `Weak signal. Momentum: ${(momentum * 100).toFixed(2)}%`, timestamp: ts, metadata: { momentum, rsi: rsiVal } }
  }
}
