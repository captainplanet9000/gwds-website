/**
 * Trend Following Strategy
 * Extracted from Cival Trading Dashboard
 * EMA crossover with ADX filter for trend strength
 */

import type { OHLCV } from '../hyperliquid'
import { ema as calcEMA, rsi as calcRSI, adx as calcADX } from '../indicators'
import type { TradingSignal, StrategyConfig, Strategy } from './types'

export class TrendFollowingStrategy implements Strategy {
  config: StrategyConfig

  constructor(config?: Partial<StrategyConfig>) {
    this.config = { ...this.getDefaultConfig(), ...config }
  }

  getDefaultConfig(): StrategyConfig {
    return {
      name: 'Trend Following',
      id: 'trend_following',
      enabled: true,
      symbols: ['BTC', 'ETH', 'SOL'],
      timeframe: '4h',
      riskLevel: 'medium',
      maxPositions: 3,
      params: {
        fastPeriod: 10,
        slowPeriod: 30,
        adxThreshold: 25,
      },
    }
  }

  analyze(symbol: string, candles: OHLCV[]): TradingSignal {
    const closes = candles.map(c => c.close)
    const { fastPeriod, slowPeriod, adxThreshold } = this.config.params
    const price = closes[closes.length - 1]
    const ts = candles[candles.length - 1].timestamp

    if (closes.length < slowPeriod + 10) {
      return { strategy: 'trend_following', symbol, action: 'hold', confidence: 0, price, stopLoss: null, takeProfit: null, size: 0, reasoning: 'Insufficient data', timestamp: ts, metadata: {} }
    }

    const fastEMA = calcEMA(closes, fastPeriod)
    const slowEMA = calcEMA(closes, slowPeriod)
    const rsiValues = calcRSI(closes, 14)
    const adxVal = calcADX(candles)

    const fast = fastEMA[fastEMA.length - 1]
    const slow = slowEMA[slowEMA.length - 1]
    const trend = (fast - slow) / slow
    const rsiVal = rsiValues[rsiValues.length - 1] ?? 50

    if (fast > slow && trend > 0.01 && rsiVal < 70 && adxVal > adxThreshold) {
      return {
        strategy: 'trend_following', symbol, action: 'buy', confidence: Math.min(trend * 20, 1), price,
        stopLoss: slow, takeProfit: price * 1.2,
        size: 1, reasoning: `Uptrend confirmed. EMA spread ${(trend * 100).toFixed(2)}%, ADX ${adxVal.toFixed(1)}`,
        timestamp: ts, metadata: { trend, adx: adxVal, rsi: rsiVal },
      }
    }

    if (fast < slow && trend < -0.01 && rsiVal > 30 && adxVal > adxThreshold) {
      return {
        strategy: 'trend_following', symbol, action: 'sell', confidence: Math.min(Math.abs(trend) * 20, 1), price,
        stopLoss: slow, takeProfit: price * 0.8,
        size: 1, reasoning: `Downtrend confirmed. EMA spread ${(trend * 100).toFixed(2)}%, ADX ${adxVal.toFixed(1)}`,
        timestamp: ts, metadata: { trend, adx: adxVal, rsi: rsiVal },
      }
    }

    return { strategy: 'trend_following', symbol, action: 'hold', confidence: 0, price, stopLoss: null, takeProfit: null, size: 0, reasoning: `No clear trend. Spread: ${(trend * 100).toFixed(2)}%, ADX: ${adxVal.toFixed(1)}`, timestamp: ts, metadata: { trend, adx: adxVal } }
  }
}
