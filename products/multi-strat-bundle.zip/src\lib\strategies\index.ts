/**
 * Strategy Registry — all available strategies
 */

export { MomentumStrategy } from './momentum'
export { MeanReversionStrategy } from './mean-reversion'
export { TrendFollowingStrategy } from './trend-following'
export { WilliamsAlligatorStrategy } from './williams-alligator'
export { HeikinAshiStrategy } from './heikin-ashi'
export { RenkoStrategy } from './renko'
export { GridBotStrategy } from './grid-bot'
export { DCAStrategy } from './dca'

export type { TradingSignal, StrategyConfig, Strategy, StrategyId } from './types'

import { MomentumStrategy } from './momentum'
import { MeanReversionStrategy } from './mean-reversion'
import { TrendFollowingStrategy } from './trend-following'
import { WilliamsAlligatorStrategy } from './williams-alligator'
import { HeikinAshiStrategy } from './heikin-ashi'
import { RenkoStrategy } from './renko'
import { GridBotStrategy } from './grid-bot'
import { DCAStrategy } from './dca'
import type { Strategy, StrategyId, StrategyConfig } from './types'

/**
 * Create a strategy instance by ID
 */
export function createStrategy(id: StrategyId, config?: Partial<StrategyConfig>): Strategy {
  switch (id) {
    case 'momentum': return new MomentumStrategy(config)
    case 'mean_reversion': return new MeanReversionStrategy(config)
    case 'trend_following': return new TrendFollowingStrategy(config)
    case 'williams_alligator': return new WilliamsAlligatorStrategy(config)
    case 'heikin_ashi': return new HeikinAshiStrategy(config)
    case 'renko': return new RenkoStrategy(config)
    case 'grid_bot': return new GridBotStrategy(config)
    case 'dca': return new DCAStrategy(config)
    default: throw new Error(`Unknown strategy: ${id}`)
  }
}

/**
 * Get all available strategy IDs
 */
export function getAvailableStrategies(): { id: StrategyId; name: string; description: string; riskLevel: string }[] {
  return [
    { id: 'momentum', name: 'Momentum', description: 'EMA crossover + RSI trend following', riskLevel: 'medium' },
    { id: 'mean_reversion', name: 'Mean Reversion', description: 'Bollinger Bands bounce strategy', riskLevel: 'low' },
    { id: 'trend_following', name: 'Trend Following', description: 'EMA crossover with ADX filter', riskLevel: 'medium' },
    { id: 'williams_alligator', name: 'Williams Alligator', description: '3 smoothed MAs — Jaw, Teeth, Lips', riskLevel: 'medium' },
    { id: 'heikin_ashi', name: 'Heikin Ashi', description: 'Smoothed candlestick trend detection', riskLevel: 'medium' },
    { id: 'renko', name: 'Renko', description: 'Price brick charts for noise reduction', riskLevel: 'medium' },
    { id: 'grid_bot', name: 'Grid Bot', description: 'Range-bound grid orders', riskLevel: 'low' },
    { id: 'dca', name: 'DCA Bot', description: 'Dollar cost average on dips', riskLevel: 'low' },
  ]
}
