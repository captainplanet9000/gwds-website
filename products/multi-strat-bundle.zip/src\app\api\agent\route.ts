import { NextResponse } from 'next/server'
import {
  getFarmState,
  initializeFarm,
  addAgent,
  removeAgent,
  runFarmCycle,
  closeFarmTrade,
  resetFarm,
} from '@/lib/orchestrator'
import { getAvailableStrategies, type StrategyId } from '@/lib/strategies'

export const dynamic = 'force-dynamic'

export async function GET() {
  const state = getFarmState()
  const available = getAvailableStrategies()
  return NextResponse.json({ state, availableStrategies: available })
}

export async function POST(request: Request) {
  try {
    const body = await request.json()

    switch (body.action) {
      case 'init': {
        const strategies = body.strategies || ['momentum', 'mean_reversion', 'trend_following']
        const state = initializeFarm(strategies as StrategyId[], body.configs)
        return NextResponse.json({ state })
      }

      case 'add_agent': {
        const agent = addAgent(body.strategyId as StrategyId, body.config)
        return NextResponse.json({ agent, state: getFarmState() })
      }

      case 'remove_agent': {
        removeAgent(body.agentId)
        return NextResponse.json({ state: getFarmState() })
      }

      case 'run': {
        const result = await runFarmCycle()
        return NextResponse.json({ ...result, state: getFarmState() })
      }

      case 'close_trade': {
        const trade = closeFarmTrade(body.tradeId, body.reason)
        return NextResponse.json({ trade, state: getFarmState() })
      }

      case 'reset': {
        resetFarm()
        return NextResponse.json({ state: getFarmState() })
      }

      default:
        return NextResponse.json({ error: `Unknown action: ${body.action}` }, { status: 400 })
    }
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 })
  }
}
