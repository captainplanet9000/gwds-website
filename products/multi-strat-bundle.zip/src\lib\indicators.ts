/**
 * Technical Indicators Library
 * Extracted from Cival Trading Dashboard
 */

import type { OHLCV } from './hyperliquid'

export function sma(data: number[], period: number): number[] {
  const result: number[] = []
  for (let i = period - 1; i < data.length; i++) {
    const sum = data.slice(i - period + 1, i + 1).reduce((a, b) => a + b, 0)
    result.push(sum / period)
  }
  return result
}

export function ema(data: number[], period: number): number[] {
  if (data.length === 0) return []
  const k = 2 / (period + 1)
  const result: number[] = [data[0]]
  for (let i = 1; i < data.length; i++) {
    result.push(data[i] * k + result[i - 1] * (1 - k))
  }
  return result
}

/**
 * Smoothed Moving Average (SMMA) — used by Williams Alligator
 * First value = SMA, then SMMA[i] = (SMMA[i-1] * (period-1) + data[i]) / period
 */
export function smma(data: number[], period: number): number[] {
  if (data.length < period) return []
  const result: number[] = []
  // First value = SMA
  let sum = 0
  for (let i = 0; i < period; i++) sum += data[i]
  result.push(sum / period)
  // SMMA
  for (let i = period; i < data.length; i++) {
    result.push((result[result.length - 1] * (period - 1) + data[i]) / period)
  }
  return result
}

export function rsi(closes: number[], period: number = 14): number[] {
  if (closes.length < period + 1) return []
  const gains: number[] = []
  const losses: number[] = []
  for (let i = 1; i < closes.length; i++) {
    const change = closes[i] - closes[i - 1]
    gains.push(change > 0 ? change : 0)
    losses.push(change < 0 ? Math.abs(change) : 0)
  }
  const result: number[] = []
  for (let i = period - 1; i < gains.length; i++) {
    const avgGain = gains.slice(i - period + 1, i + 1).reduce((a, b) => a + b, 0) / period
    const avgLoss = losses.slice(i - period + 1, i + 1).reduce((a, b) => a + b, 0) / period
    if (avgLoss === 0) { result.push(100); continue }
    result.push(100 - (100 / (1 + avgGain / avgLoss)))
  }
  return result
}

export function macd(
  data: number[],
  fastPeriod: number = 12,
  slowPeriod: number = 26,
  signalPeriod: number = 9
): { macd: number[]; signal: number[]; histogram: number[] } {
  const fastEMA = ema(data, fastPeriod)
  const slowEMA = ema(data, slowPeriod)
  const macdLine: number[] = []
  for (let i = 0; i < Math.min(fastEMA.length, slowEMA.length); i++) {
    macdLine.push(fastEMA[i] - slowEMA[i])
  }
  const signalLine = ema(macdLine, signalPeriod)
  const histogram: number[] = []
  for (let i = 0; i < Math.min(macdLine.length, signalLine.length); i++) {
    histogram.push(macdLine[i] - signalLine[i])
  }
  return { macd: macdLine, signal: signalLine, histogram }
}

export function bollingerBands(
  closes: number[],
  period: number = 20,
  stdDevMultiplier: number = 2
): { upper: number[]; middle: number[]; lower: number[] } {
  const upper: number[] = []
  const middle: number[] = []
  const lower: number[] = []
  for (let i = period - 1; i < closes.length; i++) {
    const slice = closes.slice(i - period + 1, i + 1)
    const mean = slice.reduce((a, b) => a + b, 0) / period
    const variance = slice.reduce((a, b) => a + Math.pow(b - mean, 2), 0) / period
    const stdDev = Math.sqrt(variance)
    middle.push(mean)
    upper.push(mean + stdDev * stdDevMultiplier)
    lower.push(mean - stdDev * stdDevMultiplier)
  }
  return { upper, middle, lower }
}

export function atr(candles: OHLCV[], period: number = 14): number[] {
  if (candles.length < 2) return []
  const trueRanges: number[] = [candles[0].high - candles[0].low]
  for (let i = 1; i < candles.length; i++) {
    trueRanges.push(Math.max(
      candles[i].high - candles[i].low,
      Math.abs(candles[i].high - candles[i - 1].close),
      Math.abs(candles[i].low - candles[i - 1].close)
    ))
  }
  const result: number[] = []
  let sum = 0
  for (let i = 0; i < trueRanges.length; i++) {
    sum += trueRanges[i]
    if (i >= period) sum -= trueRanges[i - period]
    result.push(i >= period - 1 ? sum / period : sum / (i + 1))
  }
  return result
}

export function stochastic(
  high: number[],
  low: number[],
  close: number[],
  kPeriod: number = 14,
  dPeriod: number = 3
): { k: number[]; d: number[] } {
  const k: number[] = []
  for (let i = kPeriod - 1; i < close.length; i++) {
    const hh = Math.max(...high.slice(i - kPeriod + 1, i + 1))
    const ll = Math.min(...low.slice(i - kPeriod + 1, i + 1))
    k.push(hh !== ll ? ((close[i] - ll) / (hh - ll)) * 100 : 50)
  }
  const d = sma(k, dPeriod)
  return { k, d }
}

export function adx(candles: OHLCV[], period: number = 14): number {
  if (candles.length < period + 1) return 0
  let plusDMSum = 0, minusDMSum = 0, trSum = 0
  const dxValues: number[] = []
  for (let i = 1; i < candles.length; i++) {
    const upMove = candles[i].high - candles[i - 1].high
    const downMove = candles[i - 1].low - candles[i].low
    const plusDM = upMove > downMove && upMove > 0 ? upMove : 0
    const minusDM = downMove > upMove && downMove > 0 ? downMove : 0
    const tr = Math.max(
      candles[i].high - candles[i].low,
      Math.abs(candles[i].high - candles[i - 1].close),
      Math.abs(candles[i].low - candles[i - 1].close)
    )
    if (i <= period) { plusDMSum += plusDM; minusDMSum += minusDM; trSum += tr }
    else { plusDMSum = plusDMSum - plusDMSum / period + plusDM; minusDMSum = minusDMSum - minusDMSum / period + minusDM; trSum = trSum - trSum / period + tr }
    if (i >= period) {
      const plusDI = trSum > 0 ? (plusDMSum / trSum) * 100 : 0
      const minusDI = trSum > 0 ? (minusDMSum / trSum) * 100 : 0
      const diSum = plusDI + minusDI
      dxValues.push(diSum > 0 ? (Math.abs(plusDI - minusDI) / diSum) * 100 : 0)
    }
  }
  if (dxValues.length === 0) return 0
  return dxValues.slice(-period).reduce((a, b) => a + b, 0) / Math.min(dxValues.length, period)
}
