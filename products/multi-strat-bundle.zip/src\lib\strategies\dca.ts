/**
 * DCA (Dollar Cost Averaging) Strategy
 *
 * Buys on dips using a progressive averaging approach:
 * - Monitors for price drops from recent highs
 * - Buys more as price drops further (scaling in)
 * - Each buy level increases position size (safety orders)
 * - Take profit when price recovers to average entry + target %
 *
 * Parameters:
 * - Base order size
 * - Safety order size (increases each level)
 * - Safety order step % (price drop between orders)
 * - Max safety orders
 * - Take profit %
 */

import type { OHLCV } from '../hyperliquid'
import { rsi as calcRSI, sma as calcSMA } from '../indicators'
import type { TradingSignal, StrategyConfig, Strategy } from './types'

export class DCAStrategy implements Strategy {
  config: StrategyConfig

  constructor(config?: Partial<StrategyConfig>) {
    this.config = { ...this.getDefaultConfig(), ...config }
  }

  getDefaultConfig(): StrategyConfig {
    return {
      name: 'DCA Bot',
      id: 'dca',
      enabled: true,
      symbols: ['BTC', 'ETH', 'SOL'],
      timeframe: '4h',
      riskLevel: 'low',
      maxPositions: 5,
      params: {
        baseOrderSize: 1,
        safetyOrderSize: 1.5,        // multiplier on each level
        safetyOrderStepPct: 2,       // % drop for each safety order
        maxSafetyOrders: 5,
        takeProfitPct: 3,            // % above average entry
        cooldownBars: 6,             // bars between DCA buys
        rsiOversoldFilter: 40,       // only DCA when RSI < this
        trendFilter: true,           // only DCA above 200 SMA
      },
    }
  }

  analyze(symbol: string, candles: OHLCV[]): TradingSignal {
    const {
      safetyOrderStepPct, maxSafetyOrders, takeProfitPct,
      rsiOversoldFilter, trendFilter,
    } = this.config.params
    const price = candles[candles.length - 1].close
    const ts = candles[candles.length - 1].timestamp
    const closes = candles.map(c => c.close)

    if (closes.length < 50) {
      return { strategy: 'dca', symbol, action: 'hold', confidence: 0, price, stopLoss: null, takeProfit: null, size: 0, reasoning: 'Insufficient data', timestamp: ts, metadata: {} }
    }

    const rsiValues = calcRSI(closes, 14)
    const rsiVal = rsiValues[rsiValues.length - 1] ?? 50

    // Trend filter: only DCA if above 50-period SMA (buying the dip, not the crash)
    const sma50 = calcSMA(closes, 50)
    const smaVal = sma50[sma50.length - 1]
    const aboveTrend = price > smaVal

    // Find recent high (last 30 bars)
    const recentHigh = Math.max(...closes.slice(-30))
    const dropPct = ((recentHigh - price) / recentHigh) * 100

    // Determine which safety order level we're at
    let dcaLevel = 0
    for (let i = 1; i <= maxSafetyOrders; i++) {
      if (dropPct >= safetyOrderStepPct * i) {
        dcaLevel = i
      }
    }

    // Buy conditions
    const isOversold = rsiVal < rsiOversoldFilter
    const hasDipped = dropPct >= safetyOrderStepPct
    const trendOk = !trendFilter || aboveTrend

    if (hasDipped && isOversold && trendOk && dcaLevel > 0) {
      const sizeMultiplier = Math.pow(1.5, dcaLevel) // exponential scaling
      return {
        strategy: 'dca', symbol, action: 'buy',
        confidence: Math.min(0.3 + dcaLevel * 0.1, 1), price,
        stopLoss: null,  // DCA doesn't use hard stops — it averages down
        takeProfit: price * (1 + takeProfitPct / 100),
        size: sizeMultiplier,
        reasoning: `DCA level ${dcaLevel}/${maxSafetyOrders}. Price dropped ${dropPct.toFixed(1)}% from recent high ($${recentHigh.toFixed(2)}). RSI: ${rsiVal.toFixed(1)}`,
        timestamp: ts,
        metadata: { dcaLevel, dropPct, recentHigh, rsi: rsiVal, aboveTrend, sizeMultiplier },
      }
    }

    // Check if we should take profit (price recovered to above average)
    if (dropPct < 0.5 && dcaLevel === 0) {
      // Price near highs — potential take profit zone
      return {
        strategy: 'dca', symbol, action: 'hold', confidence: 0, price,
        stopLoss: null, takeProfit: null, size: 0,
        reasoning: `Price near highs ($${recentHigh.toFixed(2)}). No DCA opportunity. RSI: ${rsiVal.toFixed(1)}`,
        timestamp: ts, metadata: { dropPct, recentHigh, rsi: rsiVal },
      }
    }

    return {
      strategy: 'dca', symbol, action: 'hold', confidence: 0, price,
      stopLoss: null, takeProfit: null, size: 0,
      reasoning: `Waiting for DCA trigger. Drop: ${dropPct.toFixed(1)}%, RSI: ${rsiVal.toFixed(1)}${!trendOk ? ', below trend (SMA50)' : ''}`,
      timestamp: ts, metadata: { dcaLevel, dropPct, rsi: rsiVal, aboveTrend },
    }
  }
}
