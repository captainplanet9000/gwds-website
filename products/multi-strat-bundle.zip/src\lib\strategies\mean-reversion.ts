/**
 * Mean Reversion Strategy
 * Extracted from Cival Trading Dashboard
 * Bollinger Bands + RSI for overbought/oversold entries
 */

import type { OHLCV } from '../hyperliquid'
import { bollingerBands, rsi as calcRSI } from '../indicators'
import type { TradingSignal, StrategyConfig, Strategy } from './types'

export class MeanReversionStrategy implements Strategy {
  config: StrategyConfig

  constructor(config?: Partial<StrategyConfig>) {
    this.config = { ...this.getDefaultConfig(), ...config }
  }

  getDefaultConfig(): StrategyConfig {
    return {
      name: 'Mean Reversion',
      id: 'mean_reversion',
      enabled: true,
      symbols: ['BTC', 'ETH'],
      timeframe: '1h',
      riskLevel: 'low',
      maxPositions: 2,
      params: {
        bbPeriod: 20,
        bbStdDev: 2,
        rsiPeriod: 14,
        rsiOverbought: 80,
        rsiOversold: 20,
      },
    }
  }

  analyze(symbol: string, candles: OHLCV[]): TradingSignal {
    const closes = candles.map(c => c.close)
    const { bbPeriod, bbStdDev, rsiPeriod, rsiOverbought, rsiOversold } = this.config.params
    const price = closes[closes.length - 1]
    const ts = candles[candles.length - 1].timestamp

    if (closes.length < bbPeriod + 5) {
      return { strategy: 'mean_reversion', symbol, action: 'hold', confidence: 0, price, stopLoss: null, takeProfit: null, size: 0, reasoning: 'Insufficient data', timestamp: ts, metadata: {} }
    }

    const bb = bollingerBands(closes, bbPeriod, bbStdDev)
    const rsiValues = calcRSI(closes, rsiPeriod)
    const upper = bb.upper[bb.upper.length - 1]
    const lower = bb.lower[bb.lower.length - 1]
    const middle = bb.middle[bb.middle.length - 1]
    const rsiVal = rsiValues[rsiValues.length - 1] ?? 50

    if (price < lower && rsiVal < rsiOversold) {
      const deviation = Math.abs(price - middle) / middle
      return {
        strategy: 'mean_reversion', symbol, action: 'buy', confidence: Math.min(deviation * 5, 1), price,
        stopLoss: lower * 0.98, takeProfit: middle,
        size: 1, reasoning: `Oversold. Price below lower BB ($${lower.toFixed(2)}), RSI ${rsiVal.toFixed(1)}`,
        timestamp: ts, metadata: { rsi: rsiVal, upper, lower, middle },
      }
    }

    if (price > upper && rsiVal > rsiOverbought) {
      const deviation = Math.abs(price - middle) / middle
      return {
        strategy: 'mean_reversion', symbol, action: 'sell', confidence: Math.min(deviation * 5, 1), price,
        stopLoss: upper * 1.02, takeProfit: middle,
        size: 1, reasoning: `Overbought. Price above upper BB ($${upper.toFixed(2)}), RSI ${rsiVal.toFixed(1)}`,
        timestamp: ts, metadata: { rsi: rsiVal, upper, lower, middle },
      }
    }

    return { strategy: 'mean_reversion', symbol, action: 'hold', confidence: 0, price, stopLoss: null, takeProfit: null, size: 0, reasoning: `Within bands. SMA: $${middle.toFixed(2)}`, timestamp: ts, metadata: { rsi: rsiVal, upper, lower, middle } }
  }
}
