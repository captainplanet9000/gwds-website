/**
 * Heikin Ashi Strategy
 *
 * Heikin Ashi candles smooth price action to better identify trends:
 *
 * HA Close = (Open + High + Low + Close) / 4
 * HA Open  = (Previous HA Open + Previous HA Close) / 2
 * HA High  = max(High, HA Open, HA Close)
 * HA Low   = min(Low, HA Open, HA Close)
 *
 * Signals:
 * - Green HA candles with no lower wick = strong uptrend
 * - Red HA candles with no upper wick = strong downtrend
 * - Small body with wicks on both sides = indecision/reversal
 * - Color change from red→green = potential buy
 * - Color change from green→red = potential sell
 */

import type { OHLCV } from '../hyperliquid'
import { ema as calcEMA } from '../indicators'
import type { TradingSignal, StrategyConfig, Strategy } from './types'

interface HACandle {
  open: number
  high: number
  low: number
  close: number
  isBullish: boolean
  hasLowerWick: boolean
  hasUpperWick: boolean
  bodySize: number
}

function computeHeikinAshi(candles: OHLCV[]): HACandle[] {
  const ha: HACandle[] = []

  for (let i = 0; i < candles.length; i++) {
    const c = candles[i]
    const haClose = (c.open + c.high + c.low + c.close) / 4
    const haOpen = i === 0
      ? (c.open + c.close) / 2
      : (ha[i - 1].open + ha[i - 1].close) / 2
    const haHigh = Math.max(c.high, haOpen, haClose)
    const haLow = Math.min(c.low, haOpen, haClose)

    const isBullish = haClose > haOpen
    const bodySize = Math.abs(haClose - haOpen)
    const totalRange = haHigh - haLow

    ha.push({
      open: haOpen,
      high: haHigh,
      low: haLow,
      close: haClose,
      isBullish,
      hasLowerWick: isBullish
        ? (Math.min(haOpen, haClose) - haLow) > bodySize * 0.1
        : true,
      hasUpperWick: !isBullish
        ? (haHigh - Math.max(haOpen, haClose)) > bodySize * 0.1
        : true,
      bodySize: totalRange > 0 ? bodySize / totalRange : 0,
    })
  }

  return ha
}

export class HeikinAshiStrategy implements Strategy {
  config: StrategyConfig

  constructor(config?: Partial<StrategyConfig>) {
    this.config = { ...this.getDefaultConfig(), ...config }
  }

  getDefaultConfig(): StrategyConfig {
    return {
      name: 'Heikin Ashi',
      id: 'heikin_ashi',
      enabled: true,
      symbols: ['BTC', 'ETH', 'SOL'],
      timeframe: '1h',
      riskLevel: 'medium',
      maxPositions: 3,
      params: {
        confirmBars: 3,       // consecutive same-color HA bars to confirm trend
        emaPeriod: 21,        // EMA filter for trend direction
        minBodySize: 0.3,     // min body/range ratio for strong candle
      },
    }
  }

  analyze(symbol: string, candles: OHLCV[]): TradingSignal {
    const { confirmBars, emaPeriod, minBodySize } = this.config.params
    const price = candles[candles.length - 1].close
    const ts = candles[candles.length - 1].timestamp

    if (candles.length < emaPeriod + confirmBars + 5) {
      return { strategy: 'heikin_ashi', symbol, action: 'hold', confidence: 0, price, stopLoss: null, takeProfit: null, size: 0, reasoning: 'Insufficient data', timestamp: ts, metadata: {} }
    }

    const ha = computeHeikinAshi(candles)
    const closes = candles.map(c => c.close)
    const emaValues = calcEMA(closes, emaPeriod)
    const emaVal = emaValues[emaValues.length - 1]

    const recent = ha.slice(-confirmBars)
    const current = ha[ha.length - 1]
    const prev = ha[ha.length - 2]

    // Count consecutive bullish/bearish HA candles
    const allBullish = recent.every(c => c.isBullish)
    const allBearish = recent.every(c => !c.isBullish)

    // Strong uptrend: consecutive green HA candles with no lower wicks
    const strongBull = allBullish && recent.every(c => !c.hasLowerWick && c.bodySize >= minBodySize)
    // Strong downtrend: consecutive red HA candles with no upper wicks
    const strongBear = allBearish && recent.every(c => !c.hasUpperWick && c.bodySize >= minBodySize)

    // Color change signals
    const colorChangeToBull = !prev.isBullish && current.isBullish
    const colorChangeToBear = prev.isBullish && !current.isBullish

    if ((strongBull || (colorChangeToBull && price > emaVal)) && price > emaVal) {
      const conf = strongBull ? 0.8 : 0.5
      return {
        strategy: 'heikin_ashi', symbol, action: 'buy', confidence: conf, price,
        stopLoss: ha[ha.length - 1].low,
        takeProfit: price + (price - ha[ha.length - 1].low) * 2,
        size: 1,
        reasoning: strongBull
          ? `Strong HA uptrend — ${confirmBars} green candles with no lower wicks, above EMA(${emaPeriod})`
          : `HA color change to bullish above EMA(${emaPeriod})`,
        timestamp: ts,
        metadata: { haBullish: current.isBullish, bodySize: current.bodySize, ema: emaVal, strongBull, colorChange: colorChangeToBull },
      }
    }

    if ((strongBear || (colorChangeToBear && price < emaVal)) && price < emaVal) {
      const conf = strongBear ? 0.8 : 0.5
      return {
        strategy: 'heikin_ashi', symbol, action: 'sell', confidence: conf, price,
        stopLoss: ha[ha.length - 1].high,
        takeProfit: price - (ha[ha.length - 1].high - price) * 2,
        size: 1,
        reasoning: strongBear
          ? `Strong HA downtrend — ${confirmBars} red candles with no upper wicks, below EMA(${emaPeriod})`
          : `HA color change to bearish below EMA(${emaPeriod})`,
        timestamp: ts,
        metadata: { haBullish: current.isBullish, bodySize: current.bodySize, ema: emaVal, strongBear, colorChange: colorChangeToBear },
      }
    }

    return {
      strategy: 'heikin_ashi', symbol, action: 'hold', confidence: 0, price,
      stopLoss: null, takeProfit: null, size: 0,
      reasoning: `No clear HA signal. Current: ${current.isBullish ? 'green' : 'red'}, body: ${(current.bodySize * 100).toFixed(0)}%`,
      timestamp: ts, metadata: { haBullish: current.isBullish, bodySize: current.bodySize },
    }
  }
}
