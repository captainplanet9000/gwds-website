'use client'

import { useState, useEffect, useCallback } from 'react'
import type { FarmState, AgentInstance, AgentTrade } from '@/lib/orchestrator'
import type { TradingSignal, StrategyId } from '@/lib/strategies'

const NAV = ['Farm', 'Signals', 'Trades', 'Performance'] as const
type Tab = typeof NAV[number]

const STRAT_COLORS: Record<string, string> = {
  momentum: '#3b82f6',
  mean_reversion: '#8b5cf6',
  trend_following: '#10b981',
  williams_alligator: '#f59e0b',
  heikin_ashi: '#ec4899',
  renko: '#06b6d4',
  grid_bot: '#f97316',
  dca: '#14b8a6',
}

export default function Home() {
  const [tab, setTab] = useState<Tab>('Farm')
  const [farmState, setFarmState] = useState<FarmState | null>(null)
  const [available, setAvailable] = useState<{ id: StrategyId; name: string; description: string; riskLevel: string }[]>([])
  const [signals, setSignals] = useState<TradingSignal[]>([])
  const [loading, setLoading] = useState(false)
  const [running, setRunning] = useState(false)
  const [signalSymbol, setSignalSymbol] = useState('BTC')

  const loadState = useCallback(async () => {
    const res = await fetch('/api/agent')
    const data = await res.json()
    setFarmState(data.state)
    setAvailable(data.availableStrategies || [])
  }, [])

  const initFarm = async (strategies: StrategyId[]) => {
    setLoading(true)
    await fetch('/api/agent', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ action: 'init', strategies }),
    })
    await loadState()
    setLoading(false)
  }

  const runCycle = async () => {
    setRunning(true)
    try {
      const res = await fetch('/api/agent', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'run' }),
      })
      const data = await res.json()
      setFarmState(data.state)
    } catch (err) {
      console.error(err)
    }
    setRunning(false)
  }

  const loadSignals = async (sym: string) => {
    const res = await fetch('/api/signals', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ symbol: sym }),
    })
    const data = await res.json()
    setSignals(data.signals || [])
  }

  const addAgent = async (strategyId: StrategyId) => {
    await fetch('/api/agent', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ action: 'add_agent', strategyId }),
    })
    await loadState()
  }

  const removeAgent = async (agentId: string) => {
    await fetch('/api/agent', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ action: 'remove_agent', agentId }),
    })
    await loadState()
  }

  useEffect(() => {
    loadState()
  }, [])

  const allTrades = farmState?.agents.flatMap(a => a.trades) || []
  const openTrades = allTrades.filter(t => t.status === 'open')
  const closedTrades = allTrades.filter(t => t.status !== 'open')

  return (
    <div style={{ minHeight: '100vh', background: '#09090b' }}>
      {/* Nav */}
      <div style={{ display: 'flex', alignItems: 'center', gap: 24, padding: '16px 24px', borderBottom: '1px solid #27272a' }}>
        <span style={{ color: '#10b981', fontWeight: 700, fontSize: 18 }}>Multi-Strategy Farm</span>
        <div style={{ display: 'flex', gap: 4 }}>
          {NAV.map(item => (
            <button key={item} onClick={() => setTab(item)} style={{
              background: tab === item ? '#27272a' : 'transparent',
              color: tab === item ? '#fafafa' : '#71717a',
              border: 'none', borderRadius: 6, padding: '6px 14px', fontSize: 14, cursor: 'pointer',
            }}>{item}</button>
          ))}
        </div>
        <div style={{ marginLeft: 'auto', display: 'flex', gap: 8, alignItems: 'center' }}>
          <span style={{ color: '#71717a', fontSize: 12 }}>
            {farmState?.agents.length || 0} agents · {farmState?.totalOpenPositions || 0} positions
          </span>
          <button onClick={runCycle} disabled={running || !farmState?.agents.length} style={{
            background: '#10b981', color: '#fff', border: 'none', borderRadius: 6,
            padding: '6px 16px', fontSize: 13, fontWeight: 600, cursor: 'pointer',
            opacity: running || !farmState?.agents.length ? 0.5 : 1,
          }}>{running ? 'Running...' : 'Run Cycle'}</button>
        </div>
      </div>

      <div style={{ padding: 24 }}>
        {/* Farm Tab */}
        {tab === 'Farm' && (
          <>
            {/* Stats */}
            {farmState && (
              <div style={{ display: 'grid', gridTemplateColumns: 'repeat(5, 1fr)', gap: 16, marginBottom: 24 }}>
                {[
                  { label: 'Agents', value: farmState.agents.length, color: '#fafafa' },
                  { label: 'Open Positions', value: farmState.totalOpenPositions, color: '#3b82f6' },
                  { label: 'Total Trades', value: farmState.performance.totalTrades, color: '#fafafa' },
                  { label: 'Win Rate', value: `${farmState.performance.winRate.toFixed(1)}%`, color: '#10b981' },
                  { label: 'Combined PnL', value: `$${farmState.combinedPnl.toFixed(2)}`, color: farmState.combinedPnl >= 0 ? '#10b981' : '#ef4444' },
                ].map((s, i) => (
                  <div key={i} style={{ background: '#18181b', border: '1px solid #27272a', borderRadius: 8, padding: 16 }}>
                    <div style={{ color: '#71717a', fontSize: 12, marginBottom: 4 }}>{s.label}</div>
                    <div style={{ color: s.color, fontSize: 24, fontWeight: 700 }}>{s.value}</div>
                  </div>
                ))}
              </div>
            )}

            {/* Agent Cards */}
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 16 }}>
              <h2 style={{ color: '#fafafa', fontSize: 18, fontWeight: 600, margin: 0 }}>Active Agents</h2>
              {(!farmState?.agents.length) && (
                <button onClick={() => initFarm(['momentum', 'mean_reversion', 'trend_following', 'williams_alligator', 'heikin_ashi', 'renko', 'grid_bot', 'dca'])} disabled={loading} style={{
                  background: '#10b981', color: '#fff', border: 'none', borderRadius: 6,
                  padding: '8px 20px', fontSize: 14, fontWeight: 600, cursor: 'pointer',
                }}>Launch All Strategies</button>
              )}
            </div>

            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(300px, 1fr))', gap: 16, marginBottom: 32 }}>
              {(farmState?.agents || []).map(agent => {
                const stratId = agent.strategy.config.id
                const color = STRAT_COLORS[stratId] || '#71717a'
                const openCount = agent.trades.filter(t => t.status === 'open').length
                const lastSignal = agent.signals[agent.signals.length - 1]

                return (
                  <div key={agent.id} style={{
                    background: '#18181b', border: `1px solid ${color}30`, borderRadius: 12, padding: 16,
                  }}>
                    <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 8 }}>
                      <div style={{ display: 'flex', gap: 8, alignItems: 'center' }}>
                        <div style={{ width: 8, height: 8, borderRadius: 4, background: agent.status === 'active' ? '#10b981' : '#ef4444' }} />
                        <span style={{ color: '#fafafa', fontWeight: 600, fontSize: 15 }}>{agent.strategy.config.name}</span>
                      </div>
                      <button onClick={() => removeAgent(agent.id)} style={{
                        background: 'transparent', border: 'none', color: '#71717a', cursor: 'pointer', fontSize: 16,
                      }}>×</button>
                    </div>
                    <div style={{ fontSize: 13, color: '#a1a1aa', marginBottom: 8 }}>
                      {available.find(a => a.id === stratId)?.description}
                    </div>
                    <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 4, fontSize: 12, color: '#71717a' }}>
                      <div>Symbols: <span style={{ color: '#a1a1aa' }}>{agent.strategy.config.symbols.join(', ')}</span></div>
                      <div>Timeframe: <span style={{ color: '#a1a1aa' }}>{agent.strategy.config.timeframe}</span></div>
                      <div>Risk: <span style={{ color, fontWeight: 600 }}>{agent.strategy.config.riskLevel}</span></div>
                      <div>Open: <span style={{ color: '#a1a1aa' }}>{openCount}</span></div>
                    </div>
                    {lastSignal && (
                      <div style={{ marginTop: 8, padding: 8, background: '#27272a', borderRadius: 6, fontSize: 12 }}>
                        <span style={{
                          color: lastSignal.action === 'buy' ? '#10b981' : lastSignal.action === 'sell' ? '#ef4444' : '#71717a',
                          fontWeight: 600,
                        }}>
                          {lastSignal.action.toUpperCase()} {lastSignal.symbol}
                        </span>
                        <span style={{ color: '#52525b', marginLeft: 8 }}>
                          {lastSignal.reasoning.slice(0, 60)}...
                        </span>
                      </div>
                    )}
                  </div>
                )
              })}
            </div>

            {/* Add Agent */}
            {(farmState?.agents.length ?? 0) > 0 && (
              <>
                <h3 style={{ color: '#fafafa', fontSize: 14, fontWeight: 600, marginBottom: 12 }}>Add Strategy</h3>
                <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap' }}>
                  {available.map(strat => {
                    const alreadyActive = farmState?.agents.some(a => a.strategy.config.id === strat.id)
                    return (
                      <button key={strat.id} onClick={() => !alreadyActive && addAgent(strat.id)} disabled={alreadyActive} style={{
                        background: alreadyActive ? '#18181b' : '#27272a',
                        color: alreadyActive ? '#52525b' : STRAT_COLORS[strat.id] || '#a1a1aa',
                        border: `1px solid ${alreadyActive ? '#27272a' : (STRAT_COLORS[strat.id] || '#52525b')}30`,
                        borderRadius: 6, padding: '6px 14px', fontSize: 13, cursor: alreadyActive ? 'default' : 'pointer',
                      }}>
                        {strat.name} {alreadyActive ? '✓' : '+'}
                      </button>
                    )
                  })}
                </div>
              </>
            )}
          </>
        )}

        {/* Signals Tab */}
        {tab === 'Signals' && (
          <>
            <div style={{ display: 'flex', gap: 12, marginBottom: 24, alignItems: 'center' }}>
              <input
                value={signalSymbol}
                onChange={e => setSignalSymbol(e.target.value.toUpperCase())}
                placeholder="Symbol"
                style={{
                  background: '#18181b', border: '1px solid #3f3f46', borderRadius: 6,
                  padding: '8px 12px', color: '#fafafa', fontSize: 14, width: 120, outline: 'none',
                }}
              />
              <button onClick={() => loadSignals(signalSymbol)} style={{
                background: '#3b82f6', color: '#fff', border: 'none', borderRadius: 6,
                padding: '8px 16px', fontSize: 14, fontWeight: 600, cursor: 'pointer',
              }}>Run All Strategies</button>
            </div>

            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(350px, 1fr))', gap: 16 }}>
              {signals.map((signal, i) => (
                <div key={i} style={{
                  background: '#18181b',
                  border: `1px solid ${signal.action === 'buy' ? '#10b98140' : signal.action === 'sell' ? '#ef444440' : '#27272a'}`,
                  borderRadius: 8, padding: 16,
                }}>
                  <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 8 }}>
                    <div style={{ display: 'flex', gap: 8, alignItems: 'center' }}>
                      <span style={{ color: STRAT_COLORS[signal.strategy] || '#fafafa', fontWeight: 600 }}>
                        {signal.strategy.replace(/_/g, ' ')}
                      </span>
                    </div>
                    <span style={{
                      fontWeight: 700, fontSize: 14,
                      color: signal.action === 'buy' ? '#10b981' : signal.action === 'sell' ? '#ef4444' : '#71717a',
                    }}>
                      {signal.action.toUpperCase()}
                    </span>
                  </div>
                  <div style={{ fontSize: 13, color: '#a1a1aa', lineHeight: 1.6 }}>
                    <div>Price: <span style={{ color: '#fafafa' }}>${signal.price.toFixed(2)}</span></div>
                    <div>Confidence: <span style={{ color: '#fafafa' }}>{(signal.confidence * 100).toFixed(0)}%</span></div>
                    {signal.stopLoss && <div>SL: <span style={{ color: '#ef4444' }}>${signal.stopLoss.toFixed(2)}</span></div>}
                    {signal.takeProfit && <div>TP: <span style={{ color: '#10b981' }}>${signal.takeProfit.toFixed(2)}</span></div>}
                  </div>
                  <p style={{ fontSize: 12, color: '#71717a', marginTop: 8, lineHeight: 1.4 }}>
                    {signal.reasoning}
                  </p>
                </div>
              ))}
              {signals.length === 0 && (
                <div style={{ color: '#71717a', fontSize: 14, padding: 16 }}>
                  Enter a symbol and click "Run All Strategies" to see signals from every strategy.
                </div>
              )}
            </div>
          </>
        )}

        {/* Trades Tab */}
        {tab === 'Trades' && (
          <>
            <h2 style={{ color: '#fafafa', fontSize: 18, fontWeight: 600, margin: '0 0 16px' }}>
              Open Positions ({openTrades.length})
            </h2>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 8, marginBottom: 32 }}>
              {openTrades.map(trade => (
                <TradeCard key={trade.id} trade={trade} />
              ))}
              {openTrades.length === 0 && (
                <div style={{ color: '#71717a', fontSize: 14, padding: 16 }}>No open positions.</div>
              )}
            </div>

            <h2 style={{ color: '#fafafa', fontSize: 18, fontWeight: 600, margin: '0 0 16px' }}>
              Closed Trades ({closedTrades.length})
            </h2>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
              {closedTrades.slice(-20).reverse().map(trade => (
                <TradeCard key={trade.id} trade={trade} />
              ))}
              {closedTrades.length === 0 && (
                <div style={{ color: '#71717a', fontSize: 14, padding: 16 }}>No closed trades yet.</div>
              )}
            </div>
          </>
        )}

        {/* Performance Tab */}
        {tab === 'Performance' && farmState && (
          <>
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 16, marginBottom: 32 }}>
              {[
                { label: 'Total Trades', value: farmState.performance.totalTrades },
                { label: 'Wins', value: farmState.performance.wins, color: '#10b981' },
                { label: 'Losses', value: farmState.performance.losses, color: '#ef4444' },
                { label: 'Win Rate', value: `${farmState.performance.winRate.toFixed(1)}%`, color: '#10b981' },
              ].map((s, i) => (
                <div key={i} style={{ background: '#18181b', border: '1px solid #27272a', borderRadius: 8, padding: 16 }}>
                  <div style={{ color: '#71717a', fontSize: 12, marginBottom: 4 }}>{s.label}</div>
                  <div style={{ color: s.color || '#fafafa', fontSize: 28, fontWeight: 700 }}>{s.value}</div>
                </div>
              ))}
            </div>

            <h3 style={{ color: '#fafafa', fontSize: 16, fontWeight: 600, marginBottom: 12 }}>Per-Strategy Breakdown</h3>
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(250px, 1fr))', gap: 16 }}>
              {farmState.agents.map(agent => {
                const trades = agent.trades
                const closed = trades.filter(t => t.status !== 'open')
                const wins = closed.filter(t => t.pnl > 0)
                const totalPnl = trades.reduce((s, t) => s + t.pnl, 0)
                const color = STRAT_COLORS[agent.strategy.config.id] || '#71717a'

                return (
                  <div key={agent.id} style={{ background: '#18181b', border: `1px solid ${color}30`, borderRadius: 8, padding: 16 }}>
                    <div style={{ color, fontWeight: 600, marginBottom: 8 }}>{agent.strategy.config.name}</div>
                    <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 4, fontSize: 13, color: '#a1a1aa' }}>
                      <div>Trades: <span style={{ color: '#fafafa' }}>{trades.length}</span></div>
                      <div>Open: <span style={{ color: '#fafafa' }}>{trades.filter(t => t.status === 'open').length}</span></div>
                      <div>Win Rate: <span style={{ color: '#fafafa' }}>{closed.length > 0 ? ((wins.length / closed.length) * 100).toFixed(0) : 0}%</span></div>
                      <div>PnL: <span style={{ color: totalPnl >= 0 ? '#10b981' : '#ef4444' }}>${totalPnl.toFixed(2)}</span></div>
                    </div>
                  </div>
                )
              })}
            </div>

            <div style={{ marginTop: 32, textAlign: 'center' }}>
              <button onClick={async () => {
                await fetch('/api/agent', {
                  method: 'POST',
                  headers: { 'Content-Type': 'application/json' },
                  body: JSON.stringify({ action: 'reset' }),
                })
                loadState()
              }} style={{
                background: '#27272a', color: '#ef4444', border: '1px solid #ef444440',
                borderRadius: 6, padding: '8px 20px', fontSize: 14, cursor: 'pointer',
              }}>Reset All Data</button>
            </div>
          </>
        )}
      </div>
    </div>
  )
}

function TradeCard({ trade }: { trade: AgentTrade }) {
  const color = STRAT_COLORS[trade.strategyId] || '#71717a'
  return (
    <div style={{
      background: '#18181b',
      border: `1px solid ${trade.status === 'open' ? '#3b82f640' : '#27272a'}`,
      borderRadius: 8, padding: 14,
    }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 6 }}>
        <div style={{ display: 'flex', gap: 8, alignItems: 'center' }}>
          <span style={{ color: '#fafafa', fontWeight: 700 }}>{trade.symbol}</span>
          <span style={{
            fontSize: 12, padding: '2px 8px', borderRadius: 4,
            background: trade.side === 'long' ? '#10b98120' : '#ef444420',
            color: trade.side === 'long' ? '#10b981' : '#ef4444',
          }}>{trade.side.toUpperCase()}</span>
          <span style={{
            fontSize: 12, padding: '2px 8px', borderRadius: 4,
            background: `${color}20`, color,
          }}>{trade.strategyId.replace(/_/g, ' ')}</span>
        </div>
        <span style={{ color: trade.pnlPct >= 0 ? '#10b981' : '#ef4444', fontWeight: 700 }}>
          {trade.pnlPct >= 0 ? '+' : ''}{trade.pnlPct.toFixed(2)}%
        </span>
      </div>
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 8, fontSize: 12, color: '#a1a1aa' }}>
        <div>Entry: <span style={{ color: '#fafafa' }}>${trade.entryPrice.toFixed(2)}</span></div>
        <div>Current: <span style={{ color: '#fafafa' }}>${trade.currentPrice.toFixed(2)}</span></div>
        <div>SL: <span style={{ color: '#ef4444' }}>{trade.stopLoss ? `$${trade.stopLoss.toFixed(2)}` : '—'}</span></div>
        <div>Status: <span style={{ color: trade.status === 'open' ? '#3b82f6' : '#71717a' }}>{trade.status}</span></div>
      </div>
    </div>
  )
}
