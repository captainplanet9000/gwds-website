# Multi-Strategy Agent Bundle

Autonomous multi-strategy trading farm for Hyperliquid. Run 8 different trading strategies simultaneously with a unified orchestrator, combined performance tracking, and a single dashboard.

## Included Strategies

| Strategy | Type | Risk | Description |
|----------|------|------|-------------|
| **Momentum** | Trend | Medium | EMA crossover + RSI trend following |
| **Mean Reversion** | Counter-trend | Low | Bollinger Bands oversold/overbought bounces |
| **Trend Following** | Trend | Medium | EMA crossover with ADX trend strength filter |
| **Williams Alligator** | Trend | Medium | 3 smoothed MAs (Jaw/Teeth/Lips) — detects trend starts |
| **Heikin Ashi** | Trend | Medium | Smoothed candlestick analysis for noise reduction |
| **Renko** | Trend | Medium | Price brick charts — filters time-based noise entirely |
| **Grid Bot** | Range | Low | Auto-places buy/sell orders at intervals in a range |
| **DCA Bot** | Accumulation | Low | Dollar cost averaging on dips with scaling |

## Quick Start

```bash
npm install
cp .env.example .env.local
npm run dev
```

Open [http://localhost:3300](http://localhost:3300)

## How It Works

### Farm Orchestrator
The orchestrator (`src/lib/orchestrator.ts`) manages multiple agent instances:
- Each agent runs one strategy independently
- Global position limits prevent over-exposure
- Signal aggregation shows what every strategy thinks about a symbol
- Performance tracked per-strategy and combined

### Recommended Strategy Combos

**Conservative:**
- Mean Reversion + Grid Bot + DCA
- Best for sideways/ranging markets
- Lower drawdown, steady small profits

**Balanced:**
- Momentum + Trend Following + Williams Alligator + DCA
- Works in trending and ranging markets
- Moderate risk/reward

**Aggressive:**
- All 8 strategies active
- Maximum coverage across market conditions
- Higher potential returns but more trades to manage

## Dashboard

- **Farm** — Agent overview cards, start/stop agents, add strategies
- **Signals** — Run all strategies against any symbol to see consensus
- **Trades** — Open positions and closed trade history
- **Performance** — Win rate, PnL, per-strategy breakdown

## API

### GET /api/agent
Full farm state (agents, trades, performance).

### POST /api/agent
Actions: `init`, `add_agent`, `remove_agent`, `run`, `close_trade`, `reset`.

### POST /api/signals
Run all strategies against a symbol: `{ "symbol": "BTC", "timeframe": "1h" }`

## Project Structure

```
src/
├── lib/
│   ├── strategies/
│   │   ├── types.ts              — Shared strategy interfaces
│   │   ├── momentum.ts           — Momentum (EMA + RSI)
│   │   ├── mean-reversion.ts     — Mean Reversion (BB + RSI)
│   │   ├── trend-following.ts    — Trend Following (EMA + ADX)
│   │   ├── williams-alligator.ts — Williams Alligator (SMMA)
│   │   ├── heikin-ashi.ts        — Heikin Ashi candles
│   │   ├── renko.ts              — Renko brick charts
│   │   ├── grid-bot.ts           — Grid Bot (range trading)
│   │   ├── dca.ts                — DCA Bot (buy dips)
│   │   └── index.ts              — Strategy registry + factory
│   ├── orchestrator.ts           — Farm orchestrator
│   ├── indicators.ts             — Technical indicators (SMA, EMA, RSI, MACD, BB, ATR, ADX)
│   └── hyperliquid.ts            — Market data API
└── app/
    ├── page.tsx                  — Main dashboard
    └── api/
        ├── agent/route.ts        — Farm control
        └── signals/route.ts      — Signal generation
```

## Adding Your Own Strategy

1. Create `src/lib/strategies/my-strategy.ts` implementing the `Strategy` interface
2. Add it to `src/lib/strategies/index.ts` (createStrategy + getAvailableStrategies)
3. Add the ID to `StrategyId` type in `types.ts`

```typescript
import type { Strategy, StrategyConfig, TradingSignal } from './types'

export class MyStrategy implements Strategy {
  config: StrategyConfig
  
  constructor(config?: Partial<StrategyConfig>) {
    this.config = { ...this.getDefaultConfig(), ...config }
  }

  getDefaultConfig(): StrategyConfig {
    return { name: 'My Strategy', id: 'my_strategy', ... }
  }

  analyze(symbol: string, candles: OHLCV[]): TradingSignal {
    // Your logic here
  }
}
```

## License

Commercial single-developer license. See LICENSE.md.
