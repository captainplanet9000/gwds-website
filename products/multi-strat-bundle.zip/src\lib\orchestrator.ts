/**
 * Multi-Strategy Farm Orchestrator
 *
 * Coordinates multiple trading agents running different strategies.
 * Each agent is independent but the orchestrator manages:
 * - Concurrent analysis across symbols and strategies
 * - Position limit enforcement across all agents
 * - Combined performance tracking
 * - Signal aggregation and conflict resolution
 */

import { createStrategy, getAvailableStrategies, type Strategy, type TradingSignal, type StrategyId, type StrategyConfig } from './strategies'
import { fetchCandles, type OHLCV } from './hyperliquid'

export interface AgentInstance {
  id: string
  strategy: Strategy
  status: 'active' | 'paused' | 'error'
  lastRun: number | null
  signals: TradingSignal[]
  trades: AgentTrade[]
}

export interface AgentTrade {
  id: string
  agentId: string
  strategyId: string
  symbol: string
  side: 'long' | 'short'
  entryPrice: number
  currentPrice: number
  size: number
  stopLoss: number | null
  takeProfit: number | null
  pnl: number
  pnlPct: number
  status: 'open' | 'closed' | 'stopped'
  openedAt: number
  closedAt: number | null
  reasoning: string
}

export interface FarmState {
  agents: AgentInstance[]
  globalMaxPositions: number
  totalOpenPositions: number
  combinedPnl: number
  lastCycleAt: number | null
  cycleCount: number
  performance: {
    totalTrades: number
    wins: number
    losses: number
    winRate: number
    bestStrategy: string | null
    worstStrategy: string | null
  }
}

// In-memory state
let farmState: FarmState = {
  agents: [],
  globalMaxPositions: 10,
  totalOpenPositions: 0,
  combinedPnl: 0,
  lastCycleAt: null,
  cycleCount: 0,
  performance: {
    totalTrades: 0,
    wins: 0,
    losses: 0,
    winRate: 0,
    bestStrategy: null,
    worstStrategy: null,
  },
}

/**
 * Initialize the farm with selected strategies
 */
export function initializeFarm(
  strategyIds: StrategyId[],
  configs?: Partial<Record<StrategyId, Partial<StrategyConfig>>>
): FarmState {
  farmState.agents = strategyIds.map(id => ({
    id: `agent-${id}-${Date.now()}`,
    strategy: createStrategy(id, configs?.[id]),
    status: 'active' as const,
    lastRun: null,
    signals: [],
    trades: [],
  }))

  return farmState
}

/**
 * Add a new agent to the farm
 */
export function addAgent(strategyId: StrategyId, config?: Partial<StrategyConfig>): AgentInstance {
  const agent: AgentInstance = {
    id: `agent-${strategyId}-${Date.now()}`,
    strategy: createStrategy(strategyId, config),
    status: 'active',
    lastRun: null,
    signals: [],
    trades: [],
  }
  farmState.agents.push(agent)
  return agent
}

/**
 * Remove an agent from the farm
 */
export function removeAgent(agentId: string): boolean {
  const idx = farmState.agents.findIndex(a => a.id === agentId)
  if (idx === -1) return false
  farmState.agents.splice(idx, 1)
  return true
}

/**
 * Run a full analysis cycle across all agents
 */
export async function runFarmCycle(): Promise<{
  signals: TradingSignal[]
  tradesOpened: AgentTrade[]
  tradesClosed: AgentTrade[]
}> {
  const allSignals: TradingSignal[] = []
  const tradesOpened: AgentTrade[] = []
  const tradesClosed: AgentTrade[] = []

  for (const agent of farmState.agents) {
    if (agent.status !== 'active') continue

    try {
      const config = agent.strategy.config
      for (const symbol of config.symbols) {
        const candles = await fetchCandles(symbol, config.timeframe, 336)
        if (candles.length < 50) continue

        const signal = agent.strategy.analyze(symbol, candles)
        allSignals.push(signal)
        agent.signals = [...agent.signals.slice(-50), signal]

        // Update existing positions
        const openTrades = agent.trades.filter(t => t.status === 'open' && t.symbol === symbol)
        for (const trade of openTrades) {
          trade.currentPrice = candles[candles.length - 1].close
          trade.pnl = trade.side === 'long'
            ? (trade.currentPrice - trade.entryPrice) * trade.size
            : (trade.entryPrice - trade.currentPrice) * trade.size
          trade.pnlPct = trade.side === 'long'
            ? ((trade.currentPrice - trade.entryPrice) / trade.entryPrice) * 100
            : ((trade.entryPrice - trade.currentPrice) / trade.entryPrice) * 100

          // Check SL/TP
          if (trade.stopLoss !== null) {
            const hit = trade.side === 'long'
              ? trade.currentPrice <= trade.stopLoss
              : trade.currentPrice >= trade.stopLoss
            if (hit) {
              trade.status = 'stopped'
              trade.closedAt = Date.now()
              tradesClosed.push(trade)
            }
          }
          if (trade.takeProfit !== null && trade.status === 'open') {
            const hit = trade.side === 'long'
              ? trade.currentPrice >= trade.takeProfit
              : trade.currentPrice <= trade.takeProfit
            if (hit) {
              trade.status = 'closed'
              trade.closedAt = Date.now()
              tradesClosed.push(trade)
            }
          }
        }

        // Open new position
        if (
          signal.action !== 'hold' &&
          signal.confidence >= 0.4 &&
          openTrades.length < config.maxPositions &&
          getTotalOpenPositions() < farmState.globalMaxPositions
        ) {
          const existing = agent.trades.find(t => t.status === 'open' && t.symbol === symbol)
          if (!existing) {
            const trade: AgentTrade = {
              id: `trade-${agent.strategy.config.id}-${symbol}-${Date.now()}`,
              agentId: agent.id,
              strategyId: agent.strategy.config.id,
              symbol,
              side: signal.action === 'buy' ? 'long' : 'short',
              entryPrice: signal.price,
              currentPrice: signal.price,
              size: signal.size,
              stopLoss: signal.stopLoss,
              takeProfit: signal.takeProfit,
              pnl: 0,
              pnlPct: 0,
              status: 'open',
              openedAt: Date.now(),
              closedAt: null,
              reasoning: signal.reasoning,
            }
            agent.trades.push(trade)
            tradesOpened.push(trade)
          }
        }
      }

      agent.lastRun = Date.now()
    } catch (err) {
      agent.status = 'error'
      console.error(`Agent ${agent.id} error:`, err)
    }
  }

  farmState.lastCycleAt = Date.now()
  farmState.cycleCount++
  updateFarmStats()

  return { signals: allSignals, tradesOpened, tradesClosed }
}

function getTotalOpenPositions(): number {
  return farmState.agents.reduce(
    (sum, agent) => sum + agent.trades.filter(t => t.status === 'open').length,
    0
  )
}

function updateFarmStats() {
  const allTrades = farmState.agents.flatMap(a => a.trades)
  const closedTrades = allTrades.filter(t => t.status !== 'open')
  const openTrades = allTrades.filter(t => t.status === 'open')
  const wins = closedTrades.filter(t => t.pnl > 0)

  farmState.totalOpenPositions = openTrades.length
  farmState.combinedPnl = allTrades.reduce((sum, t) => sum + t.pnl, 0)

  // Per-strategy performance
  const stratPerf: Record<string, { wins: number; total: number; pnl: number }> = {}
  for (const trade of closedTrades) {
    if (!stratPerf[trade.strategyId]) {
      stratPerf[trade.strategyId] = { wins: 0, total: 0, pnl: 0 }
    }
    stratPerf[trade.strategyId].total++
    if (trade.pnl > 0) stratPerf[trade.strategyId].wins++
    stratPerf[trade.strategyId].pnl += trade.pnl
  }

  let bestStrategy: string | null = null
  let worstStrategy: string | null = null
  let bestPnl = -Infinity
  let worstPnl = Infinity

  for (const [id, perf] of Object.entries(stratPerf)) {
    if (perf.pnl > bestPnl) { bestPnl = perf.pnl; bestStrategy = id }
    if (perf.pnl < worstPnl) { worstPnl = perf.pnl; worstStrategy = id }
  }

  farmState.performance = {
    totalTrades: allTrades.length,
    wins: wins.length,
    losses: closedTrades.length - wins.length,
    winRate: closedTrades.length > 0 ? (wins.length / closedTrades.length) * 100 : 0,
    bestStrategy,
    worstStrategy,
  }
}

/**
 * Get current farm state
 */
export function getFarmState(): FarmState {
  return farmState
}

/**
 * Close a trade manually
 */
export function closeFarmTrade(tradeId: string, reason: string = 'Manual close'): AgentTrade | null {
  for (const agent of farmState.agents) {
    const trade = agent.trades.find(t => t.id === tradeId)
    if (trade && trade.status === 'open') {
      trade.status = 'closed'
      trade.closedAt = Date.now()
      updateFarmStats()
      return trade
    }
  }
  return null
}

/**
 * Reset farm state
 */
export function resetFarm(): void {
  for (const agent of farmState.agents) {
    agent.signals = []
    agent.trades = []
    agent.lastRun = null
    agent.status = 'active'
  }
  farmState.lastCycleAt = null
  farmState.cycleCount = 0
  farmState.totalOpenPositions = 0
  farmState.combinedPnl = 0
  farmState.performance = { totalTrades: 0, wins: 0, losses: 0, winRate: 0, bestStrategy: null, worstStrategy: null }
}
