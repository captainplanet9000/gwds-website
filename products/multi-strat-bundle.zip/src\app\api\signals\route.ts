import { NextResponse } from 'next/server'
import { createStrategy, getAvailableStrategies, type StrategyId } from '@/lib/strategies'
import { fetchCandles } from '@/lib/hyperliquid'

export const dynamic = 'force-dynamic'

/**
 * GET /api/signals?symbol=BTC&strategy=momentum&timeframe=1h
 * Generate signal for a single strategy + symbol
 */
export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url)
    const symbol = searchParams.get('symbol') || 'BTC'
    const strategyId = (searchParams.get('strategy') || 'momentum') as StrategyId
    const timeframe = searchParams.get('timeframe') || '1h'

    const strategy = createStrategy(strategyId, { timeframe })
    const candles = await fetchCandles(symbol, timeframe, 336)
    const signal = strategy.analyze(symbol, candles)

    return NextResponse.json({
      signal,
      candleCount: candles.length,
      strategy: strategy.config,
    })
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 })
  }
}

/**
 * POST /api/signals — Run all strategies against a symbol
 */
export async function POST(request: Request) {
  try {
    const body = await request.json()
    const symbol = body.symbol || 'BTC'
    const timeframe = body.timeframe || '1h'

    const candles = await fetchCandles(symbol, timeframe, 336)
    const available = getAvailableStrategies()
    const signals = []

    for (const strat of available) {
      try {
        const strategy = createStrategy(strat.id, { timeframe })
        const signal = strategy.analyze(symbol, candles)
        signals.push(signal)
      } catch (err) {
        console.error(`Error in ${strat.id}:`, err)
      }
    }

    return NextResponse.json({
      symbol,
      timeframe,
      candleCount: candles.length,
      signals,
    })
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 })
  }
}
