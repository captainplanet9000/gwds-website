# Elliott Wave Trading Agent

Autonomous trading agent that uses Elliott Wave analysis to identify high-probability entries on Hyperliquid.

## Elliott Wave Theory (60-second version)

Markets move in predictable wave patterns:
- **Impulse waves (1-2-3-4-5)** — the main trend direction
- **Corrective waves (A-B-C)** — counter-trend pullbacks

Rules the algorithm enforces:
1. Wave 2 never retraces more than 100% of Wave 1
2. Wave 3 is never the shortest impulse wave
3. Wave 4 doesn't overlap Wave 1's price territory

The agent looks for entries at wave termination points — end of Wave 2 (Wave 3 incoming), end of Wave 4 (Wave 5 incoming), and end of Wave C (new impulse incoming).

## Quick Start

```bash
npm install
npm run setup     # Interactive setup wizard
npm run dev
```

Open [http://localhost:3200](http://localhost:3200)

## Features

### Wave Analysis
- Swing high/low detection with configurable strength
- 5-wave impulse pattern recognition
- ABC corrective pattern recognition
- Fibonacci retracement/extension validation
- Wave scoring based on Fibonacci conformity

### Autonomous Agent
- Scheduled analysis across multiple symbols and timeframes
- High-probability entry detection (Wave 2 end, Wave 4 end, Wave C end)
- Automatic SL/TP placement using Fibonacci levels
- Position monitoring with stop loss management
- Full decision logging with reasoning

### Dashboard
- **Overview** — Interactive chart with wave labels, targets, and swing points
- **Scanner** — Multi-symbol wave analysis
- **Agent** — Start/stop the agent, view decisions, configure parameters
- **Trades** — Open positions, trade history, P&L tracking

## Configuration

The agent is configurable via the dashboard or API:

| Parameter | Default | Description |
|-----------|---------|-------------|
| `symbols` | BTC, ETH, SOL | Assets to analyze |
| `timeframes` | 1h | Chart timeframes |
| `maxPositions` | 3 | Max concurrent positions |
| `minConfidence` | 40% | Minimum confidence to enter |
| `swingStrength` | 5 | Bars for swing point detection |
| `lookbackHours` | 336 | Hours of history (14 days) |

## API

### GET /api/waves?symbol=BTC&timeframe=1h
Wave analysis for a single symbol.

### GET /api/agent
Current agent state (config, decisions, trades, stats).

### POST /api/agent
Agent actions: `run`, `configure`, `close_trade`, `reset`.

## Database (Optional)

For persistent state, run `setup.sql` in Supabase:
- `agents` — Agent configuration and status
- `agent_trades` — Trade history
- `agent_decisions` — Decision log

## Project Structure

```
src/
├── lib/
│   ├── elliott-wave.ts   — Wave detection engine
│   ├── fibonacci.ts      — Fibonacci calculations
│   ├── agent.ts          — Autonomous agent logic
│   └── hyperliquid.ts    — Market data API
├── components/
│   └── WaveChart.tsx     — Chart with wave labels
└── app/
    ├── page.tsx          — Main dashboard
    └── api/
        ├── waves/        — Wave analysis endpoint
        └── agent/        — Agent control endpoint
```

## License

Commercial single-developer license. See LICENSE.md.
