'use client'

import { useEffect, useRef } from 'react'
import {
  createChart,
  type IChartApi,
  type CandlestickData,
  type Time,
  ColorType,
} from 'lightweight-charts'
import type { OHLCV, SwingPoint, WaveCount } from '@/lib/elliott-wave'

const WAVE_COLORS: Record<string, string> = {
  '0': '#71717a',
  '1': '#3b82f6',
  '2': '#f59e0b',
  '3': '#10b981',
  '4': '#ef4444',
  '5': '#8b5cf6',
  'A': '#f97316',
  'B': '#06b6d4',
  'C': '#ec4899',
}

interface WaveChartProps {
  candles: OHLCV[]
  swingPoints: SwingPoint[]
  waveCounts: WaveCount[]
  bestCount: WaveCount | null
  symbol: string
  height?: number
}

export default function WaveChart({
  candles,
  swingPoints,
  waveCounts,
  bestCount,
  symbol,
  height = 500,
}: WaveChartProps) {
  const containerRef = useRef<HTMLDivElement>(null)
  const chartRef = useRef<IChartApi | null>(null)

  useEffect(() => {
    if (!containerRef.current || candles.length === 0) return

    if (chartRef.current) {
      chartRef.current.remove()
      chartRef.current = null
    }

    const chart = createChart(containerRef.current, {
      width: containerRef.current.clientWidth,
      height,
      layout: {
        background: { type: ColorType.Solid, color: '#09090b' },
        textColor: '#a1a1aa',
      },
      grid: {
        vertLines: { color: '#27272a' },
        horzLines: { color: '#27272a' },
      },
      crosshair: {
        vertLine: { color: '#71717a', width: 1, style: 2 },
        horzLine: { color: '#71717a', width: 1, style: 2 },
      },
      timeScale: { borderColor: '#3f3f46', timeVisible: true },
      rightPriceScale: { borderColor: '#3f3f46' },
    })

    chartRef.current = chart

    // Candlestick series
    const candleSeries = chart.addCandlestickSeries({
      upColor: '#10b981',
      downColor: '#ef4444',
      borderUpColor: '#10b981',
      borderDownColor: '#ef4444',
      wickUpColor: '#10b981',
      wickDownColor: '#ef4444',
    })

    candleSeries.setData(
      candles.map(c => ({
        time: (c.timestamp / 1000) as Time,
        open: c.open,
        high: c.high,
        low: c.low,
        close: c.close,
      }))
    )

    // Volume
    const volumeSeries = chart.addHistogramSeries({
      color: '#3b82f680',
      priceFormat: { type: 'volume' },
      priceScaleId: 'volume',
    })
    chart.priceScale('volume').applyOptions({
      scaleMargins: { top: 0.85, bottom: 0 },
    })
    volumeSeries.setData(
      candles.map(c => ({
        time: (c.timestamp / 1000) as Time,
        value: c.volume,
        color: c.close >= c.open ? '#10b98130' : '#ef444430',
      }))
    )

    // Draw wave labels as markers on the best count
    const countToDraw = bestCount || (waveCounts.length > 0 ? waveCounts[0] : null)

    if (countToDraw) {
      const markers = countToDraw.waves.map(wave => ({
        time: (wave.timestamp / 1000) as Time,
        position: wave.price > candles[wave.index]?.close
          ? 'aboveBar' as const
          : 'belowBar' as const,
        color: WAVE_COLORS[wave.label] || '#fafafa',
        shape: 'circle' as const,
        text: wave.label,
      }))

      // Add target lines
      for (const target of countToDraw.targets) {
        const targetLine = chart.addLineSeries({
          color: target.type === 'tp' ? '#10b98180' : '#ef444480',
          lineWidth: 1,
          lineStyle: 2,
          priceLineVisible: false,
          lastValueVisible: true,
          crosshairMarkerVisible: false,
          title: target.label,
        })

        const lastTime = (candles[candles.length - 1].timestamp / 1000) as Time
        const startTime = countToDraw.waves.length > 0
          ? (countToDraw.waves[countToDraw.waves.length - 1].timestamp / 1000) as Time
          : lastTime

        targetLine.setData([
          { time: startTime, value: target.price },
          { time: lastTime, value: target.price },
        ])
      }

      // Draw wave connection lines
      if (countToDraw.waves.length >= 2) {
        const waveLine = chart.addLineSeries({
          color: countToDraw.type === 'impulse' ? '#8b5cf680' : '#f9731680',
          lineWidth: 2,
          lineStyle: 0,
          priceLineVisible: false,
          lastValueVisible: false,
          crosshairMarkerVisible: false,
        })

        waveLine.setData(
          countToDraw.waves.map(w => ({
            time: (w.timestamp / 1000) as Time,
            value: w.price,
          }))
        )
      }

      candleSeries.setMarkers(markers)
    }

    // Resize
    const handleResize = () => {
      if (containerRef.current && chartRef.current) {
        chartRef.current.applyOptions({ width: containerRef.current.clientWidth })
      }
    }
    window.addEventListener('resize', handleResize)
    chart.timeScale().fitContent()

    return () => {
      window.removeEventListener('resize', handleResize)
      chart.remove()
      chartRef.current = null
    }
  }, [candles, swingPoints, waveCounts, bestCount, height])

  return (
    <div style={{ position: 'relative' }}>
      <div
        style={{
          position: 'absolute',
          top: 12,
          left: 12,
          zIndex: 10,
          display: 'flex',
          gap: 12,
          alignItems: 'center',
        }}
      >
        <span style={{ color: '#fafafa', fontWeight: 600, fontSize: 16 }}>{symbol}</span>
        {bestCount && (
          <>
            <span
              style={{
                fontSize: 12,
                padding: '2px 8px',
                borderRadius: 4,
                background: bestCount.direction === 'bullish' ? '#10b98120' : '#ef444420',
                color: bestCount.direction === 'bullish' ? '#10b981' : '#ef4444',
              }}
            >
              {bestCount.type === 'impulse' ? 'Impulse' : 'Corrective'} — {bestCount.direction}
            </span>
            <span style={{ color: '#a1a1aa', fontSize: 12 }}>
              Fib Score: {bestCount.fibScore}/100
            </span>
          </>
        )}
      </div>
      <div ref={containerRef} />
    </div>
  )
}
