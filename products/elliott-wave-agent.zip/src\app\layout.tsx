import type { Metadata } from 'next'
import './globals.css'

export const metadata: Metadata = {
  title: 'Elliott Wave Trading Agent',
  description: 'Autonomous Elliott Wave analysis and trading on Hyperliquid',
}

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body className="antialiased">{children}</body>
    </html>
  )
}
