#!/usr/bin/env node

/**
 * Elliott Wave Trading Agent — Setup Wizard
 */

import { createInterface } from 'readline'
import { writeFileSync, existsSync, readFileSync } from 'fs'

const rl = createInterface({ input: process.stdin, output: process.stdout })
const ask = (q) => new Promise((resolve) => rl.question(q, resolve))

async function main() {
  console.log('\n🌊 Elliott Wave Trading Agent — Setup\n')
  console.log('This wizard will create your .env.local file.\n')

  const network = (await ask('Hyperliquid network (mainnet/testnet) [mainnet]: ')).trim() || 'mainnet'
  const supabaseUrl = (await ask('Supabase URL [skip]: ')).trim()
  const supabaseAnon = supabaseUrl ? (await ask('Supabase anon key: ')).trim() : ''
  const supabaseService = supabaseUrl ? (await ask('Supabase service role key: ')).trim() : ''

  const envContent = [
    `NEXT_PUBLIC_HYPERLIQUID_NETWORK=${network}`,
    supabaseUrl ? `NEXT_PUBLIC_SUPABASE_URL=${supabaseUrl}` : '# NEXT_PUBLIC_SUPABASE_URL=',
    supabaseAnon ? `NEXT_PUBLIC_SUPABASE_ANON_KEY=${supabaseAnon}` : '# NEXT_PUBLIC_SUPABASE_ANON_KEY=',
    supabaseService ? `SUPABASE_SERVICE_ROLE_KEY=${supabaseService}` : '# SUPABASE_SERVICE_ROLE_KEY=',
    '# WALLET_PRIVATE_KEY=0x...',
    '# OPENROUTER_API_KEY=sk-or-...',
  ].join('\n')

  writeFileSync('.env.local', envContent)
  console.log('\n✅ Created .env.local')

  if (supabaseUrl) {
    console.log('\n📋 Next: Run the SQL in setup.sql in your Supabase SQL editor to create tables.')
  }

  console.log('\n🚀 Run `npm run dev` to start the agent dashboard.\n')
  rl.close()
}

main().catch(console.error)
