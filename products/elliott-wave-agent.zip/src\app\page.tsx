'use client'

import { useState, useEffect, useCallback } from 'react'
import WaveChart from '@/components/WaveChart'
import type { OHLCV, SwingPoint, WaveCount, TradingSetup } from '@/lib/elliott-wave'
import type { AgentState, AgentDecision } from '@/lib/agent'

const TIMEFRAMES = ['5m', '15m', '1h', '4h', '1d'] as const
const NAV_ITEMS = ['Overview', 'Scanner', 'Agent', 'Trades'] as const
type NavItem = typeof NAV_ITEMS[number]

export default function Home() {
  const [activeTab, setActiveTab] = useState<NavItem>('Overview')
  const [symbol, setSymbol] = useState('BTC')
  const [timeframe, setTimeframe] = useState('1h')
  const [candles, setCandles] = useState<OHLCV[]>([])
  const [swingPoints, setSwingPoints] = useState<SwingPoint[]>([])
  const [waveCounts, setWaveCounts] = useState<WaveCount[]>([])
  const [bestCount, setBestCount] = useState<WaveCount | null>(null)
  const [tradingSetup, setTradingSetup] = useState<TradingSetup | null>(null)
  const [agentState, setAgentState] = useState<AgentState | null>(null)
  const [loading, setLoading] = useState(false)
  const [agentRunning, setAgentRunning] = useState(false)

  const loadWaves = useCallback(async (sym: string, tf: string) => {
    setLoading(true)
    try {
      const res = await fetch(`/api/waves?symbol=${sym}&timeframe=${tf}`)
      const data = await res.json()
      setCandles(data.candles || [])
      setSwingPoints(data.swingPoints || [])
      setWaveCounts(data.waveCounts || [])
      setBestCount(data.bestCount || null)
      setTradingSetup(data.tradingSetup || null)
    } catch (err) {
      console.error(err)
    } finally {
      setLoading(false)
    }
  }, [])

  const loadAgentState = useCallback(async () => {
    try {
      const res = await fetch('/api/agent')
      const data = await res.json()
      setAgentState(data)
    } catch (err) {
      console.error(err)
    }
  }, [])

  const runAgent = async () => {
    setAgentRunning(true)
    try {
      const res = await fetch('/api/agent', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'run' }),
      })
      const data = await res.json()
      setAgentState(data.state)
    } catch (err) {
      console.error(err)
    } finally {
      setAgentRunning(false)
    }
  }

  useEffect(() => {
    loadWaves(symbol, timeframe)
    loadAgentState()
  }, [])

  const handleSymbolSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    const input = (e.target as HTMLFormElement).elements.namedItem('sym') as HTMLInputElement
    const val = input.value.trim().toUpperCase()
    if (val) {
      setSymbol(val)
      loadWaves(val, timeframe)
    }
  }

  return (
    <div style={{ minHeight: '100vh', background: '#09090b' }}>
      {/* Nav */}
      <div
        style={{
          display: 'flex',
          alignItems: 'center',
          gap: 24,
          padding: '16px 24px',
          borderBottom: '1px solid #27272a',
        }}
      >
        <span style={{ color: '#8b5cf6', fontWeight: 700, fontSize: 18 }}>
          Elliott Wave Agent
        </span>
        <div style={{ display: 'flex', gap: 4 }}>
          {NAV_ITEMS.map(item => (
            <button
              key={item}
              onClick={() => setActiveTab(item)}
              style={{
                background: activeTab === item ? '#27272a' : 'transparent',
                color: activeTab === item ? '#fafafa' : '#71717a',
                border: 'none',
                borderRadius: 6,
                padding: '6px 14px',
                fontSize: 14,
                cursor: 'pointer',
              }}
            >
              {item}
            </button>
          ))}
        </div>
        <div style={{ marginLeft: 'auto', display: 'flex', gap: 8, alignItems: 'center' }}>
          {agentState && (
            <span style={{
              fontSize: 12,
              padding: '2px 8px',
              borderRadius: 4,
              background: agentState.status === 'running' ? '#10b98120' : '#27272a',
              color: agentState.status === 'running' ? '#10b981' : '#71717a',
            }}>
              Agent: {agentState.status}
            </span>
          )}
        </div>
      </div>

      <div style={{ padding: 24 }}>
        {/* Overview / Scanner */}
        {(activeTab === 'Overview' || activeTab === 'Scanner') && (
          <>
            {/* Controls */}
            <div style={{ display: 'flex', gap: 12, marginBottom: 20, flexWrap: 'wrap', alignItems: 'center' }}>
              <form onSubmit={handleSymbolSubmit} style={{ display: 'flex', gap: 8 }}>
                <input
                  name="sym"
                  defaultValue={symbol}
                  placeholder="Symbol"
                  style={{
                    background: '#18181b',
                    border: '1px solid #3f3f46',
                    borderRadius: 6,
                    padding: '8px 12px',
                    color: '#fafafa',
                    fontSize: 14,
                    width: 120,
                    outline: 'none',
                  }}
                />
                <button
                  type="submit"
                  disabled={loading}
                  style={{
                    background: '#8b5cf6',
                    color: '#fff',
                    border: 'none',
                    borderRadius: 6,
                    padding: '8px 16px',
                    fontSize: 14,
                    fontWeight: 600,
                    cursor: 'pointer',
                    opacity: loading ? 0.5 : 1,
                  }}
                >
                  Analyze
                </button>
              </form>
              <div style={{ display: 'flex', gap: 4 }}>
                {TIMEFRAMES.map(tf => (
                  <button
                    key={tf}
                    onClick={() => { setTimeframe(tf); loadWaves(symbol, tf) }}
                    style={{
                      background: timeframe === tf ? '#8b5cf6' : '#27272a',
                      color: timeframe === tf ? '#fff' : '#a1a1aa',
                      border: 'none',
                      borderRadius: 4,
                      padding: '6px 12px',
                      fontSize: 13,
                      cursor: 'pointer',
                    }}
                  >
                    {tf}
                  </button>
                ))}
              </div>
            </div>

            {/* Chart */}
            <div
              style={{
                background: '#18181b',
                border: '1px solid #27272a',
                borderRadius: 12,
                overflow: 'hidden',
                marginBottom: 24,
              }}
            >
              {candles.length > 0 ? (
                <WaveChart
                  candles={candles}
                  swingPoints={swingPoints}
                  waveCounts={waveCounts}
                  bestCount={bestCount}
                  symbol={symbol}
                  height={480}
                />
              ) : (
                <div style={{ height: 480, display: 'flex', alignItems: 'center', justifyContent: 'center', color: '#71717a' }}>
                  {loading ? 'Analyzing waves...' : 'No data'}
                </div>
              )}
            </div>

            {/* Setup + Counts */}
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 24 }}>
              {/* Trading Setup */}
              <div>
                <h2 style={{ color: '#fafafa', fontSize: 16, fontWeight: 600, margin: '0 0 12px' }}>
                  Trading Setup
                </h2>
                {tradingSetup ? (
                  <div
                    style={{
                      background: '#18181b',
                      border: `1px solid ${tradingSetup.direction === 'long' ? '#10b981' : '#ef4444'}40`,
                      borderRadius: 8,
                      padding: 16,
                    }}
                  >
                    <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 8 }}>
                      <span style={{
                        fontWeight: 700, fontSize: 16,
                        color: tradingSetup.direction === 'long' ? '#10b981' : '#ef4444'
                      }}>
                        {tradingSetup.direction === 'long' ? '▲ LONG' : '▼ SHORT'}
                      </span>
                      <span style={{ color: '#a1a1aa', fontSize: 13 }}>
                        {tradingSetup.type.replace(/_/g, ' ')}
                      </span>
                    </div>
                    <div style={{ fontSize: 13, color: '#a1a1aa', lineHeight: 1.8 }}>
                      <div>Entry: <span style={{ color: '#fafafa' }}>${tradingSetup.entryPrice.toFixed(2)}</span></div>
                      <div>Stop: <span style={{ color: '#ef4444' }}>${tradingSetup.stopLoss.toFixed(2)}</span></div>
                      {tradingSetup.targets.map((t, i) => (
                        <div key={i}>
                          {t.label}: <span style={{ color: '#10b981' }}>${t.price.toFixed(2)}</span>
                        </div>
                      ))}
                      <div>Confidence: <span style={{ color: '#fafafa' }}>{(tradingSetup.confidence * 100).toFixed(0)}%</span></div>
                    </div>
                    <p style={{ fontSize: 13, color: '#71717a', marginTop: 12, lineHeight: 1.5 }}>
                      {tradingSetup.reasoning}
                    </p>
                  </div>
                ) : (
                  <div style={{ background: '#18181b', border: '1px solid #27272a', borderRadius: 8, padding: 16, color: '#71717a', fontSize: 14 }}>
                    No high-probability setup detected right now.
                  </div>
                )}
              </div>

              {/* Wave Counts */}
              <div>
                <h2 style={{ color: '#fafafa', fontSize: 16, fontWeight: 600, margin: '0 0 12px' }}>
                  Wave Counts ({waveCounts.length})
                </h2>
                <div style={{ display: 'flex', flexDirection: 'column', gap: 8, maxHeight: 400, overflowY: 'auto' }}>
                  {waveCounts.length === 0 && (
                    <div style={{ background: '#18181b', border: '1px solid #27272a', borderRadius: 8, padding: 16, color: '#71717a', fontSize: 14 }}>
                      No Elliott Wave patterns found.
                    </div>
                  )}
                  {waveCounts.map(count => (
                    <div
                      key={count.id}
                      style={{
                        background: count === bestCount ? '#1e1b4b' : '#18181b',
                        border: `1px solid ${count === bestCount ? '#8b5cf680' : '#27272a'}`,
                        borderRadius: 8,
                        padding: 12,
                      }}
                    >
                      <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 4 }}>
                        <span style={{ color: '#fafafa', fontWeight: 600, fontSize: 13 }}>
                          {count.type === 'impulse' ? '5-Wave' : 'ABC'} {count.direction}
                        </span>
                        <span style={{ fontSize: 12, color: '#a1a1aa' }}>
                          Fib: {count.fibScore}/100
                        </span>
                      </div>
                      <div style={{ fontSize: 12, color: '#71717a' }}>
                        Waves: {count.waves.map(w => w.label).join(' → ')} | {count.isActive ? 'Active' : 'Complete'}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </>
        )}

        {/* Agent Tab */}
        {activeTab === 'Agent' && (
          <div>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 24 }}>
              <h2 style={{ color: '#fafafa', fontSize: 20, fontWeight: 600, margin: 0 }}>
                Agent Control
              </h2>
              <div style={{ display: 'flex', gap: 8 }}>
                <button
                  onClick={runAgent}
                  disabled={agentRunning}
                  style={{
                    background: '#8b5cf6',
                    color: '#fff',
                    border: 'none',
                    borderRadius: 6,
                    padding: '8px 20px',
                    fontSize: 14,
                    fontWeight: 600,
                    cursor: 'pointer',
                    opacity: agentRunning ? 0.5 : 1,
                  }}
                >
                  {agentRunning ? 'Running...' : 'Run Analysis Cycle'}
                </button>
                <button
                  onClick={async () => {
                    await fetch('/api/agent', {
                      method: 'POST',
                      headers: { 'Content-Type': 'application/json' },
                      body: JSON.stringify({ action: 'reset' }),
                    })
                    loadAgentState()
                  }}
                  style={{
                    background: '#27272a',
                    color: '#ef4444',
                    border: '1px solid #ef444440',
                    borderRadius: 6,
                    padding: '8px 16px',
                    fontSize: 14,
                    cursor: 'pointer',
                  }}
                >
                  Reset
                </button>
              </div>
            </div>

            {agentState && (
              <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 16, marginBottom: 24 }}>
                {[
                  { label: 'Total Trades', value: agentState.stats.totalTrades, color: '#fafafa' },
                  { label: 'Open Positions', value: agentState.stats.openTrades, color: '#3b82f6' },
                  { label: 'Win Rate', value: `${agentState.stats.winRate.toFixed(1)}%`, color: '#10b981' },
                  { label: 'Total PnL', value: `$${agentState.stats.totalPnl.toFixed(2)}`, color: agentState.stats.totalPnl >= 0 ? '#10b981' : '#ef4444' },
                ].map((stat, i) => (
                  <div key={i} style={{ background: '#18181b', border: '1px solid #27272a', borderRadius: 8, padding: 16 }}>
                    <div style={{ color: '#71717a', fontSize: 12, marginBottom: 4 }}>{stat.label}</div>
                    <div style={{ color: stat.color, fontSize: 24, fontWeight: 700 }}>{stat.value}</div>
                  </div>
                ))}
              </div>
            )}

            {/* Recent Decisions */}
            <h3 style={{ color: '#fafafa', fontSize: 16, fontWeight: 600, margin: '0 0 12px' }}>
              Recent Decisions
            </h3>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 8, maxHeight: 500, overflowY: 'auto' }}>
              {(agentState?.decisions || []).slice().reverse().map(dec => (
                <div
                  key={dec.id}
                  style={{
                    background: '#18181b',
                    border: '1px solid #27272a',
                    borderRadius: 8,
                    padding: 12,
                    display: 'flex',
                    gap: 16,
                    alignItems: 'center',
                  }}
                >
                  <span style={{ color: '#fafafa', fontWeight: 600, minWidth: 50 }}>{dec.symbol}</span>
                  <span style={{
                    fontSize: 12,
                    padding: '2px 8px',
                    borderRadius: 4,
                    background: dec.action.includes('long') ? '#10b98120' : dec.action.includes('short') ? '#ef444420' : '#27272a',
                    color: dec.action.includes('long') ? '#10b981' : dec.action.includes('short') ? '#ef4444' : '#71717a',
                  }}>
                    {dec.action}
                  </span>
                  <span style={{ color: '#71717a', fontSize: 13, flex: 1 }}>{dec.reasoning}</span>
                  <span style={{ color: '#52525b', fontSize: 12 }}>
                    {new Date(dec.timestamp).toLocaleTimeString()}
                  </span>
                </div>
              ))}
              {(!agentState?.decisions || agentState.decisions.length === 0) && (
                <div style={{ color: '#71717a', fontSize: 14, padding: 16 }}>
                  No decisions yet. Click "Run Analysis Cycle" to start.
                </div>
              )}
            </div>
          </div>
        )}

        {/* Trades Tab */}
        {activeTab === 'Trades' && (
          <div>
            <h2 style={{ color: '#fafafa', fontSize: 20, fontWeight: 600, margin: '0 0 24px' }}>
              Trade History
            </h2>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
              {(agentState?.trades || []).map(trade => (
                <div
                  key={trade.id}
                  style={{
                    background: '#18181b',
                    border: `1px solid ${trade.status === 'open' ? '#3b82f640' : '#27272a'}`,
                    borderRadius: 8,
                    padding: 16,
                  }}
                >
                  <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 8 }}>
                    <div style={{ display: 'flex', gap: 8, alignItems: 'center' }}>
                      <span style={{ color: '#fafafa', fontWeight: 700 }}>{trade.symbol}</span>
                      <span style={{
                        fontSize: 12,
                        padding: '2px 8px',
                        borderRadius: 4,
                        background: trade.side === 'long' ? '#10b98120' : '#ef444420',
                        color: trade.side === 'long' ? '#10b981' : '#ef4444',
                      }}>
                        {trade.side.toUpperCase()}
                      </span>
                      <span style={{
                        fontSize: 12,
                        padding: '2px 8px',
                        borderRadius: 4,
                        background: '#8b5cf620',
                        color: '#8b5cf6',
                      }}>
                        {trade.waveLabel}
                      </span>
                    </div>
                    <span style={{
                      color: trade.pnlPct >= 0 ? '#10b981' : '#ef4444',
                      fontWeight: 700,
                    }}>
                      {trade.pnlPct >= 0 ? '+' : ''}{trade.pnlPct.toFixed(2)}%
                    </span>
                  </div>
                  <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 8, fontSize: 13, color: '#a1a1aa' }}>
                    <div>Entry: <span style={{ color: '#fafafa' }}>${trade.entryPrice.toFixed(2)}</span></div>
                    <div>Current: <span style={{ color: '#fafafa' }}>${trade.currentPrice.toFixed(2)}</span></div>
                    <div>Stop: <span style={{ color: '#ef4444' }}>${trade.stopLoss.toFixed(2)}</span></div>
                    <div>Status: <span style={{ color: trade.status === 'open' ? '#3b82f6' : '#71717a' }}>{trade.status}</span></div>
                  </div>
                </div>
              ))}
              {(!agentState?.trades || agentState.trades.length === 0) && (
                <div style={{ color: '#71717a', fontSize: 14, padding: 16 }}>
                  No trades yet. The agent will create trades when it finds high-probability setups.
                </div>
              )}
            </div>
          </div>
        )}
      </div>
    </div>
  )
}
