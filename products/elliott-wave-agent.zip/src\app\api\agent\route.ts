import { NextResponse } from 'next/server'
import {
  getAgentState,
  updateAgentConfig,
  runAnalysisCycle,
  closeTrade,
  resetAgent,
} from '@/lib/agent'

export const dynamic = 'force-dynamic'

/**
 * GET /api/agent — Get agent state
 */
export async function GET() {
  return NextResponse.json(getAgentState())
}

/**
 * POST /api/agent — Agent actions
 * Body: { action: "run" | "configure" | "close_trade" | "reset", ... }
 */
export async function POST(request: Request) {
  try {
    const body = await request.json()

    switch (body.action) {
      case 'run': {
        const decisions = await runAnalysisCycle()
        return NextResponse.json({
          decisions,
          state: getAgentState(),
        })
      }

      case 'configure': {
        const config = updateAgentConfig(body.config || {})
        return NextResponse.json({ config })
      }

      case 'close_trade': {
        const trade = closeTrade(body.tradeId, body.reason || 'Manual close')
        if (!trade) {
          return NextResponse.json({ error: 'Trade not found or already closed' }, { status: 404 })
        }
        return NextResponse.json({ trade, state: getAgentState() })
      }

      case 'reset': {
        resetAgent()
        return NextResponse.json({ message: 'Agent reset', state: getAgentState() })
      }

      default:
        return NextResponse.json({ error: `Unknown action: ${body.action}` }, { status: 400 })
    }
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 })
  }
}
