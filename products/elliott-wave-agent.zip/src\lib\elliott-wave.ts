/**
 * Elliott Wave Detection Engine
 *
 * Implements:
 * - Swing high/low detection
 * - 5-wave impulse pattern detection with validation rules
 * - 3-wave corrective (ABC) pattern detection
 * - Wave counting algorithm
 * - Fibonacci target calculation for each wave
 *
 * Core Rules:
 * 1. Wave 2 never retraces more than 100% of Wave 1
 * 2. Wave 3 is never the shortest impulse wave
 * 3. Wave 4 does not overlap with Wave 1 price territory
 */

import { fibRetracement, fibExtension, validateWaveFibonacci } from './fibonacci'

export interface OHLCV {
  timestamp: number
  open: number
  high: number
  low: number
  close: number
  volume: number
}

export interface SwingPoint {
  index: number
  price: number
  timestamp: number
  type: 'high' | 'low'
  strength: number // 1-5, how many bars on each side confirm it
}

export interface WaveLabel {
  label: string       // "1", "2", "3", "4", "5", "A", "B", "C"
  price: number
  timestamp: number
  index: number
  type: 'impulse' | 'corrective'
}

export interface WaveCount {
  id: string
  direction: 'bullish' | 'bearish'
  type: 'impulse' | 'corrective'
  waves: WaveLabel[]
  completedWaves: number  // how many waves are confirmed
  fibScore: number        // 0-100 based on Fibonacci conformity
  startPrice: number
  currentPrice: number
  targets: {
    label: string
    price: number
    type: 'tp' | 'sl'
  }[]
  isActive: boolean       // is this count still developing
  confidence: number      // 0-1
}

export interface ElliottWaveResult {
  swingPoints: SwingPoint[]
  waveCounts: WaveCount[]
  bestCount: WaveCount | null
  tradingSetup: TradingSetup | null
}

export interface TradingSetup {
  type: 'wave2_end' | 'wave4_end' | 'waveC_end' | 'wave3_entry'
  direction: 'long' | 'short'
  entryPrice: number
  stopLoss: number
  targets: { price: number; label: string }[]
  confidence: number
  waveCount: WaveCount
  reasoning: string
}

/**
 * Find swing highs and lows in OHLCV data
 */
export function findSwingPoints(
  candles: OHLCV[],
  leftBars: number = 5,
  rightBars: number = 5
): SwingPoint[] {
  const points: SwingPoint[] = []

  for (let i = leftBars; i < candles.length - rightBars; i++) {
    // Check for swing high
    let isHigh = true
    let highStrength = 0
    for (let j = 1; j <= Math.max(leftBars, rightBars); j++) {
      if (j <= leftBars && i - j >= 0 && candles[i].high <= candles[i - j].high) {
        isHigh = false
        break
      }
      if (j <= rightBars && i + j < candles.length && candles[i].high <= candles[i + j].high) {
        isHigh = false
        break
      }
      highStrength++
    }

    if (isHigh) {
      points.push({
        index: i,
        price: candles[i].high,
        timestamp: candles[i].timestamp,
        type: 'high',
        strength: Math.min(highStrength, 5),
      })
    }

    // Check for swing low
    let isLow = true
    let lowStrength = 0
    for (let j = 1; j <= Math.max(leftBars, rightBars); j++) {
      if (j <= leftBars && i - j >= 0 && candles[i].low >= candles[i - j].low) {
        isLow = false
        break
      }
      if (j <= rightBars && i + j < candles.length && candles[i].low >= candles[i + j].low) {
        isLow = false
        break
      }
      lowStrength++
    }

    if (isLow) {
      points.push({
        index: i,
        price: candles[i].low,
        timestamp: candles[i].timestamp,
        type: 'low',
        strength: Math.min(lowStrength, 5),
      })
    }
  }

  // Sort by index
  points.sort((a, b) => a.index - b.index)

  return points
}

/**
 * Build alternating swing sequence (high-low-high-low...)
 */
function buildAlternatingSwings(points: SwingPoint[]): SwingPoint[] {
  if (points.length < 2) return points

  const result: SwingPoint[] = [points[0]]

  for (let i = 1; i < points.length; i++) {
    const last = result[result.length - 1]

    if (points[i].type !== last.type) {
      result.push(points[i])
    } else {
      // Same type — keep the more extreme one
      if (points[i].type === 'high' && points[i].price > last.price) {
        result[result.length - 1] = points[i]
      } else if (points[i].type === 'low' && points[i].price < last.price) {
        result[result.length - 1] = points[i]
      }
    }
  }

  return result
}

/**
 * Detect 5-wave impulse patterns
 */
function detectImpulseWaves(
  swings: SwingPoint[],
  candles: OHLCV[]
): WaveCount[] {
  const counts: WaveCount[] = []

  // Need at least 6 swing points for a 5-wave pattern (start + 5 wave endpoints)
  for (let i = 0; i < swings.length - 5; i++) {
    const s = swings.slice(i, i + 6)

    // Check for bullish impulse: low-high-low-high-low-high
    if (
      s[0].type === 'low' &&
      s[1].type === 'high' &&
      s[2].type === 'low' &&
      s[3].type === 'high' &&
      s[4].type === 'low' &&
      s[5].type === 'high'
    ) {
      const count = validateBullishImpulse(s, candles)
      if (count) counts.push(count)
    }

    // Check for bearish impulse: high-low-high-low-high-low
    if (
      s[0].type === 'high' &&
      s[1].type === 'low' &&
      s[2].type === 'high' &&
      s[3].type === 'low' &&
      s[4].type === 'high' &&
      s[5].type === 'low'
    ) {
      const count = validateBearishImpulse(s, candles)
      if (count) counts.push(count)
    }
  }

  // Also look for partial counts (2-4 waves completed)
  for (let i = 0; i < swings.length - 2; i++) {
    // Partial bullish: at least wave 1 and 2
    if (
      swings[i].type === 'low' &&
      i + 2 < swings.length &&
      swings[i + 1].type === 'high' &&
      swings[i + 2].type === 'low'
    ) {
      const partial = validatePartialBullish(swings.slice(i), candles)
      if (partial) counts.push(partial)
    }
  }

  return counts
}

function validateBullishImpulse(s: SwingPoint[], candles: OHLCV[]): WaveCount | null {
  const w1Start = s[0].price
  const w1End = s[1].price
  const w2End = s[2].price
  const w3End = s[3].price
  const w4End = s[4].price
  const w5End = s[5].price

  // Rule 1: Wave 2 cannot retrace 100% of Wave 1
  if (w2End <= w1Start) return null

  // Rule 2: Wave 3 cannot be the shortest
  const w1Len = w1End - w1Start
  const w3Len = w3End - w2End
  const w5Len = w5End - w4End
  if (w3Len < w1Len && w3Len < w5Len) return null

  // Rule 3: Wave 4 cannot overlap Wave 1 territory
  if (w4End < w1End) return null

  // Must be overall uptrend
  if (w5End <= w1Start) return null

  const fib = validateWaveFibonacci({
    wave1Start: w1Start,
    wave1End: w1End,
    wave2End: w2End,
    wave3End: w3End,
    wave4End: w4End,
    wave5End: w5End,
  })

  const targets = fibExtension(w1Start, w1End, w2End)

  return {
    id: `impulse-bull-${s[0].index}`,
    direction: 'bullish',
    type: 'impulse',
    waves: [
      { label: '0', price: w1Start, timestamp: s[0].timestamp, index: s[0].index, type: 'impulse' },
      { label: '1', price: w1End, timestamp: s[1].timestamp, index: s[1].index, type: 'impulse' },
      { label: '2', price: w2End, timestamp: s[2].timestamp, index: s[2].index, type: 'impulse' },
      { label: '3', price: w3End, timestamp: s[3].timestamp, index: s[3].index, type: 'impulse' },
      { label: '4', price: w4End, timestamp: s[4].timestamp, index: s[4].index, type: 'impulse' },
      { label: '5', price: w5End, timestamp: s[5].timestamp, index: s[5].index, type: 'impulse' },
    ],
    completedWaves: 5,
    fibScore: fib.overallScore,
    startPrice: w1Start,
    currentPrice: w5End,
    targets: [
      ...targets.slice(0, 3).map(t => ({
        label: `${t.label} ext`,
        price: t.price,
        type: 'tp' as const,
      })),
      { label: 'SL (below W4)', price: w4End * 0.99, type: 'sl' as const },
    ],
    isActive: false,
    confidence: fib.overallScore / 100,
  }
}

function validateBearishImpulse(s: SwingPoint[], candles: OHLCV[]): WaveCount | null {
  const w1Start = s[0].price
  const w1End = s[1].price
  const w2End = s[2].price
  const w3End = s[3].price
  const w4End = s[4].price
  const w5End = s[5].price

  if (w2End >= w1Start) return null
  const w1Len = Math.abs(w1Start - w1End)
  const w3Len = Math.abs(w2End - w3End)
  const w5Len = Math.abs(w4End - w5End)
  if (w3Len < w1Len && w3Len < w5Len) return null
  if (w4End > w1End) return null
  if (w5End >= w1Start) return null

  const fib = validateWaveFibonacci({
    wave1Start: w1Start,
    wave1End: w1End,
    wave2End: w2End,
    wave3End: w3End,
    wave4End: w4End,
    wave5End: w5End,
  })

  return {
    id: `impulse-bear-${s[0].index}`,
    direction: 'bearish',
    type: 'impulse',
    waves: [
      { label: '0', price: w1Start, timestamp: s[0].timestamp, index: s[0].index, type: 'impulse' },
      { label: '1', price: w1End, timestamp: s[1].timestamp, index: s[1].index, type: 'impulse' },
      { label: '2', price: w2End, timestamp: s[2].timestamp, index: s[2].index, type: 'impulse' },
      { label: '3', price: w3End, timestamp: s[3].timestamp, index: s[3].index, type: 'impulse' },
      { label: '4', price: w4End, timestamp: s[4].timestamp, index: s[4].index, type: 'impulse' },
      { label: '5', price: w5End, timestamp: s[5].timestamp, index: s[5].index, type: 'impulse' },
    ],
    completedWaves: 5,
    fibScore: fib.overallScore,
    startPrice: w1Start,
    currentPrice: w5End,
    targets: [
      { label: 'SL (above W4)', price: w4End * 1.01, type: 'sl' as const },
    ],
    isActive: false,
    confidence: fib.overallScore / 100,
  }
}

function validatePartialBullish(swings: SwingPoint[], candles: OHLCV[]): WaveCount | null {
  if (swings.length < 3) return null

  const w1Start = swings[0].price
  const w1End = swings[1].price
  const w2End = swings[2].price

  // Must be up-move then retracement
  if (w1End <= w1Start) return null
  if (w2End >= w1End) return null
  if (w2End <= w1Start) return null

  const w1Range = w1End - w1Start
  const retracePct = (w1End - w2End) / w1Range

  // Wave 2 should retrace 38-78.6%
  if (retracePct < 0.3 || retracePct > 0.9) return null

  const completedWaves = Math.min(swings.length - 1, 5)
  const waves: WaveLabel[] = [
    { label: '0', price: w1Start, timestamp: swings[0].timestamp, index: swings[0].index, type: 'impulse' },
    { label: '1', price: w1End, timestamp: swings[1].timestamp, index: swings[1].index, type: 'impulse' },
    { label: '2', price: w2End, timestamp: swings[2].timestamp, index: swings[2].index, type: 'impulse' },
  ]

  // Add more waves if available
  for (let i = 3; i < Math.min(swings.length, 6); i++) {
    waves.push({
      label: `${i}`,
      price: swings[i].price,
      timestamp: swings[i].timestamp,
      index: swings[i].index,
      type: 'impulse',
    })
  }

  // Calculate targets based on what we have
  const targets = fibExtension(w1Start, w1End, w2End)
  const retracement = fibRetracement(w1End, w1Start, 'up')

  return {
    id: `partial-bull-${swings[0].index}`,
    direction: 'bullish',
    type: 'impulse',
    waves,
    completedWaves,
    fibScore: Math.abs(retracePct - 0.618) < 0.1 ? 70 : 50,
    startPrice: w1Start,
    currentPrice: candles[candles.length - 1].close,
    targets: [
      { label: 'W3 target (161.8%)', price: targets.find(t => t.ratio === 1.618)?.price ?? w1End + w1Range * 1.618, type: 'tp' as const },
      { label: 'W3 target (100%)', price: targets.find(t => t.ratio === 1.0)?.price ?? w1End + w1Range, type: 'tp' as const },
      { label: 'SL (below W2)', price: w2End * 0.99, type: 'sl' as const },
    ],
    isActive: true,
    confidence: 0.5,
  }
}

/**
 * Detect ABC corrective patterns
 */
function detectCorrectiveWaves(
  swings: SwingPoint[],
  candles: OHLCV[]
): WaveCount[] {
  const counts: WaveCount[] = []

  for (let i = 0; i < swings.length - 3; i++) {
    const s = swings.slice(i, i + 4)

    // Bearish correction: high-low-high-low (after an uptrend)
    if (
      s[0].type === 'high' &&
      s[1].type === 'low' &&
      s[2].type === 'high' &&
      s[3].type === 'low'
    ) {
      const aLen = s[0].price - s[1].price
      const bLen = s[2].price - s[1].price
      const cLen = s[2].price - s[3].price

      if (aLen <= 0 || bLen <= 0 || cLen <= 0) continue

      // Wave B typically retraces 38-78.6% of Wave A
      const bRetrace = bLen / aLen
      if (bRetrace < 0.3 || bRetrace > 0.9) continue

      const fibScore = Math.abs(bRetrace - 0.618) < 0.1 ? 75 : 55

      counts.push({
        id: `abc-bear-${s[0].index}`,
        direction: 'bearish',
        type: 'corrective',
        waves: [
          { label: 'A', price: s[1].price, timestamp: s[1].timestamp, index: s[1].index, type: 'corrective' },
          { label: 'B', price: s[2].price, timestamp: s[2].timestamp, index: s[2].index, type: 'corrective' },
          { label: 'C', price: s[3].price, timestamp: s[3].timestamp, index: s[3].index, type: 'corrective' },
        ],
        completedWaves: 3,
        fibScore,
        startPrice: s[0].price,
        currentPrice: s[3].price,
        targets: [
          { label: 'Recovery target', price: s[0].price, type: 'tp' as const },
          { label: 'SL (below C)', price: s[3].price * 0.98, type: 'sl' as const },
        ],
        isActive: false,
        confidence: fibScore / 100,
      })
    }

    // Bullish correction: low-high-low-high
    if (
      s[0].type === 'low' &&
      s[1].type === 'high' &&
      s[2].type === 'low' &&
      s[3].type === 'high'
    ) {
      const aLen = s[1].price - s[0].price
      const bLen = s[1].price - s[2].price
      const cLen = s[3].price - s[2].price

      if (aLen <= 0 || bLen <= 0 || cLen <= 0) continue

      const bRetrace = bLen / aLen
      if (bRetrace < 0.3 || bRetrace > 0.9) continue

      const fibScore = Math.abs(bRetrace - 0.618) < 0.1 ? 75 : 55

      counts.push({
        id: `abc-bull-${s[0].index}`,
        direction: 'bullish',
        type: 'corrective',
        waves: [
          { label: 'A', price: s[1].price, timestamp: s[1].timestamp, index: s[1].index, type: 'corrective' },
          { label: 'B', price: s[2].price, timestamp: s[2].timestamp, index: s[2].index, type: 'corrective' },
          { label: 'C', price: s[3].price, timestamp: s[3].timestamp, index: s[3].index, type: 'corrective' },
        ],
        completedWaves: 3,
        fibScore,
        startPrice: s[0].price,
        currentPrice: s[3].price,
        targets: [
          { label: 'Recovery target', price: s[0].price, type: 'tp' as const },
          { label: 'SL (above C)', price: s[3].price * 1.02, type: 'sl' as const },
        ],
        isActive: false,
        confidence: fibScore / 100,
      })
    }
  }

  return counts
}

/**
 * Identify trading setups from wave counts
 */
function findTradingSetups(counts: WaveCount[], currentPrice: number): TradingSetup | null {
  // Best setup: end of Wave 2 in an active bullish impulse (wave 3 incoming)
  for (const count of counts) {
    if (!count.isActive) continue

    if (count.direction === 'bullish' && count.completedWaves === 2) {
      const w2 = count.waves[2]
      const w1 = count.waves[1]
      const w0 = count.waves[0]
      const w1Range = w1.price - w0.price

      return {
        type: 'wave2_end',
        direction: 'long',
        entryPrice: currentPrice,
        stopLoss: w0.price * 0.99,
        targets: [
          { price: w2.price + w1Range * 1.618, label: 'W3 (161.8% ext)' },
          { price: w2.price + w1Range * 2.618, label: 'W3 (261.8% ext)' },
        ],
        confidence: count.confidence,
        waveCount: count,
        reasoning: `Wave 2 completed at $${w2.price.toFixed(2)}. Wave 3 typically extends 161.8% of Wave 1. Entry near end of Wave 2 retracement offers best risk/reward.`,
      }
    }

    if (count.direction === 'bullish' && count.completedWaves === 4) {
      const w4 = count.waves[4]
      const w0 = count.waves[0]
      const w1 = count.waves[1]
      const w1Range = w1.price - w0.price

      return {
        type: 'wave4_end',
        direction: 'long',
        entryPrice: currentPrice,
        stopLoss: w4.price * 0.99,
        targets: [
          { price: w4.price + w1Range * 0.618, label: 'W5 (61.8% of W1)' },
          { price: w4.price + w1Range, label: 'W5 (100% of W1)' },
        ],
        confidence: count.confidence * 0.8,
        waveCount: count,
        reasoning: `Wave 4 completed at $${w4.price.toFixed(2)}. Wave 5 typically equals 61.8-100% of Wave 1 length. Last impulse wave before correction.`,
      }
    }
  }

  // End of ABC correction — reversal setup
  for (const count of counts) {
    if (count.type !== 'corrective' || count.isActive) continue

    const waveC = count.waves.find(w => w.label === 'C')
    if (!waveC) continue

    // Price near wave C end
    const distFromC = Math.abs(currentPrice - waveC.price) / waveC.price
    if (distFromC > 0.03) continue

    return {
      type: 'waveC_end',
      direction: count.direction === 'bearish' ? 'long' : 'short',
      entryPrice: currentPrice,
      stopLoss: count.direction === 'bearish'
        ? waveC.price * 0.97
        : waveC.price * 1.03,
      targets: [
        { price: count.startPrice, label: 'Return to origin' },
      ],
      confidence: count.confidence * 0.7,
      waveCount: count,
      reasoning: `ABC correction appears complete at Wave C ($${waveC.price.toFixed(2)}). New impulse wave expected in opposite direction.`,
    }
  }

  return null
}

/**
 * Run full Elliott Wave analysis on OHLCV data
 */
export function analyzeElliottWaves(
  candles: OHLCV[],
  swingStrength: number = 5
): ElliottWaveResult {
  if (candles.length < 30) {
    return { swingPoints: [], waveCounts: [], bestCount: null, tradingSetup: null }
  }

  // Find swing points
  const swingPoints = findSwingPoints(candles, swingStrength, swingStrength)
  const alternating = buildAlternatingSwings(swingPoints)

  // Detect patterns
  const impulseWaves = detectImpulseWaves(alternating, candles)
  const correctiveWaves = detectCorrectiveWaves(alternating, candles)

  const allCounts = [...impulseWaves, ...correctiveWaves]
    .sort((a, b) => b.fibScore - a.fibScore)

  const bestCount = allCounts.length > 0 ? allCounts[0] : null
  const currentPrice = candles[candles.length - 1].close
  const tradingSetup = findTradingSetups(allCounts, currentPrice)

  return {
    swingPoints,
    waveCounts: allCounts,
    bestCount,
    tradingSetup,
  }
}
