import { NextResponse } from 'next/server'
import { analyzeElliottWaves } from '@/lib/elliott-wave'
import { fetchCandles } from '@/lib/hyperliquid'

export const dynamic = 'force-dynamic'

export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url)
    const symbol = searchParams.get('symbol') || 'BTC'
    const timeframe = searchParams.get('timeframe') || '1h'
    const lookback = parseInt(searchParams.get('lookback') || '336')
    const strength = parseInt(searchParams.get('strength') || '5')

    const candles = await fetchCandles(symbol, timeframe, lookback)
    const result = analyzeElliottWaves(candles, strength)

    return NextResponse.json({
      symbol,
      timeframe,
      candleCount: candles.length,
      candles,
      ...result,
    })
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 })
  }
}
