-- Elliott Wave Trading Agent — Database Setup
-- Run this in your Supabase SQL editor

-- Agents table
CREATE TABLE IF NOT EXISTS agents (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  config JSONB NOT NULL DEFAULT '{}',
  status TEXT NOT NULL DEFAULT 'idle',
  last_run TIMESTAMPTZ,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Agent trades
CREATE TABLE IF NOT EXISTS agent_trades (
  id TEXT PRIMARY KEY,
  agent_id TEXT NOT NULL REFERENCES agents(id),
  symbol TEXT NOT NULL,
  side TEXT NOT NULL CHECK (side IN ('long', 'short')),
  entry_price NUMERIC NOT NULL,
  current_price NUMERIC,
  size NUMERIC NOT NULL DEFAULT 1,
  stop_loss NUMERIC NOT NULL,
  targets JSONB NOT NULL DEFAULT '[]',
  pnl NUMERIC DEFAULT 0,
  pnl_pct NUMERIC DEFAULT 0,
  status TEXT NOT NULL DEFAULT 'open' CHECK (status IN ('open', 'closed', 'stopped')),
  wave_label TEXT,
  closing_reason TEXT,
  opened_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  closed_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Agent decisions
CREATE TABLE IF NOT EXISTS agent_decisions (
  id TEXT PRIMARY KEY,
  agent_id TEXT NOT NULL REFERENCES agents(id),
  symbol TEXT NOT NULL,
  timeframe TEXT NOT NULL,
  action TEXT NOT NULL,
  setup JSONB,
  wave_analysis JSONB,
  reasoning TEXT,
  executed BOOLEAN DEFAULT FALSE,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Indexes
CREATE INDEX IF NOT EXISTS idx_agent_trades_agent ON agent_trades(agent_id);
CREATE INDEX IF NOT EXISTS idx_agent_trades_status ON agent_trades(status);
CREATE INDEX IF NOT EXISTS idx_agent_trades_symbol ON agent_trades(symbol);
CREATE INDEX IF NOT EXISTS idx_agent_decisions_agent ON agent_decisions(agent_id);
CREATE INDEX IF NOT EXISTS idx_agent_decisions_created ON agent_decisions(created_at DESC);

-- RLS (optional — enable if needed)
-- ALTER TABLE agents ENABLE ROW LEVEL SECURITY;
-- ALTER TABLE agent_trades ENABLE ROW LEVEL SECURITY;
-- ALTER TABLE agent_decisions ENABLE ROW LEVEL SECURITY;
