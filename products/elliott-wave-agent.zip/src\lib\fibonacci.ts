/**
 * Fibonacci Calculation Helpers for Elliott Wave Analysis
 */

/** Standard Fibonacci ratios */
export const FIB_RATIOS = {
  /** Retracement levels */
  retracement: [0.236, 0.382, 0.5, 0.618, 0.786, 0.886] as const,
  /** Extension levels */
  extension: [1.0, 1.272, 1.618, 2.0, 2.618, 3.618, 4.236] as const,
}

export interface FibLevel {
  ratio: number
  price: number
  label: string
}

/**
 * Calculate Fibonacci retracement levels between a swing high and swing low
 */
export function fibRetracement(
  swingHigh: number,
  swingLow: number,
  direction: 'up' | 'down' = 'up'
): FibLevel[] {
  const range = swingHigh - swingLow

  if (direction === 'up') {
    // Retracement of an upswing — levels are below the high
    return FIB_RATIOS.retracement.map(ratio => ({
      ratio,
      price: swingHigh - range * ratio,
      label: `${(ratio * 100).toFixed(1)}%`,
    }))
  } else {
    // Retracement of a downswing — levels are above the low
    return FIB_RATIOS.retracement.map(ratio => ({
      ratio,
      price: swingLow + range * ratio,
      label: `${(ratio * 100).toFixed(1)}%`,
    }))
  }
}

/**
 * Calculate Fibonacci extension levels
 */
export function fibExtension(
  swingStart: number,
  swingEnd: number,
  retracementPoint: number
): FibLevel[] {
  const range = Math.abs(swingEnd - swingStart)
  const direction = swingEnd > swingStart ? 1 : -1

  return FIB_RATIOS.extension.map(ratio => ({
    ratio,
    price: retracementPoint + range * ratio * direction,
    label: `${(ratio * 100).toFixed(1)}%`,
  }))
}

/**
 * Find the closest Fibonacci level to a given price
 */
export function closestFibLevel(
  price: number,
  levels: FibLevel[]
): { level: FibLevel; distance: number; distancePct: number } | null {
  if (levels.length === 0) return null

  let closest = levels[0]
  let minDist = Math.abs(price - levels[0].price)

  for (const level of levels) {
    const dist = Math.abs(price - level.price)
    if (dist < minDist) {
      minDist = dist
      closest = level
    }
  }

  return {
    level: closest,
    distance: minDist,
    distancePct: price > 0 ? (minDist / price) * 100 : 0,
  }
}

/**
 * Validate Elliott Wave rules using Fibonacci relationships
 * Wave 2: 50-78.6% retracement of Wave 1 (ideal: 61.8%)
 * Wave 3: 161.8-261.8% extension of Wave 1 (never the shortest)
 * Wave 4: 23.6-50% retracement of Wave 1-3 (doesn't overlap Wave 1)
 * Wave 5: 61.8-100% of Wave 1 length
 */
export function validateWaveFibonacci(waves: {
  wave1Start: number
  wave1End: number
  wave2End: number
  wave3End?: number
  wave4End?: number
  wave5End?: number
}): {
  wave2RetracementPct: number
  wave2Valid: boolean
  wave3ExtensionPct: number | null
  wave3Valid: boolean | null
  wave4RetracementPct: number | null
  wave4Valid: boolean | null
  wave4OverlapsWave1: boolean | null
  wave5LengthRatio: number | null
  overallScore: number
} {
  const w1Range = waves.wave1End - waves.wave1Start
  const direction = w1Range > 0 ? 1 : -1

  // Wave 2 retracement of Wave 1
  const w2Retrace = Math.abs(waves.wave1End - waves.wave2End) / Math.abs(w1Range)

  const w2Valid = w2Retrace >= 0.382 && w2Retrace <= 0.886

  let score = w2Valid ? 25 : 0
  // Bonus for ideal 61.8%
  if (Math.abs(w2Retrace - 0.618) < 0.05) score += 10

  let w3Ext: number | null = null
  let w3Valid: boolean | null = null
  let w4Retrace: number | null = null
  let w4Valid: boolean | null = null
  let w4Overlaps: boolean | null = null
  let w5Ratio: number | null = null

  if (waves.wave3End !== undefined) {
    const w3Range = Math.abs(waves.wave3End - waves.wave2End)
    w3Ext = w3Range / Math.abs(w1Range)
    // Wave 3 must not be shortest of waves 1, 3, 5
    w3Valid = w3Ext >= 1.0
    if (w3Valid) score += 25
    if (w3Ext >= 1.5 && w3Ext <= 2.8) score += 10
  }

  if (waves.wave4End !== undefined && waves.wave3End !== undefined) {
    const w1to3Range = Math.abs(waves.wave3End - waves.wave1Start)
    w4Retrace = Math.abs(waves.wave3End - waves.wave4End) / w1to3Range

    w4Valid = w4Retrace >= 0.15 && w4Retrace <= 0.618

    // Wave 4 cannot overlap with Wave 1 territory
    if (direction > 0) {
      w4Overlaps = waves.wave4End < waves.wave1End
    } else {
      w4Overlaps = waves.wave4End > waves.wave1End
    }

    if (w4Valid && !w4Overlaps) score += 25
  }

  if (waves.wave5End !== undefined && waves.wave4End !== undefined) {
    const w5Range = Math.abs(waves.wave5End - waves.wave4End)
    w5Ratio = w5Range / Math.abs(w1Range)

    if (w5Ratio >= 0.382 && w5Ratio <= 1.618) score += 15
  }

  return {
    wave2RetracementPct: w2Retrace * 100,
    wave2Valid: w2Valid,
    wave3ExtensionPct: w3Ext !== null ? w3Ext * 100 : null,
    wave3Valid: w3Valid,
    wave4RetracementPct: w4Retrace !== null ? w4Retrace * 100 : null,
    wave4Valid: w4Valid,
    wave4OverlapsWave1: w4Overlaps,
    wave5LengthRatio: w5Ratio,
    overallScore: Math.min(score, 100),
  }
}
