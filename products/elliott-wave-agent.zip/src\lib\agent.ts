/**
 * Autonomous Elliott Wave Trading Agent
 *
 * Runs wave analysis on a schedule, identifies high-probability entries,
 * sets SL/TP based on Fibonacci levels, and logs all decisions.
 */

import { analyzeElliottWaves, type ElliottWaveResult, type TradingSetup, type OHLCV } from './elliott-wave'
import { fetchCandles } from './hyperliquid'

export type AgentStatus = 'idle' | 'running' | 'paused' | 'error'

export interface AgentConfig {
  id: string
  name: string
  symbols: string[]
  timeframes: string[]
  maxPositions: number
  maxRiskPerTrade: number    // % of portfolio
  minConfidence: number      // 0-1
  lookbackHours: number
  swingStrength: number      // bars for swing point detection
  enabled: boolean
}

export interface AgentDecision {
  id: string
  agentId: string
  timestamp: number
  symbol: string
  timeframe: string
  action: 'enter_long' | 'enter_short' | 'exit' | 'hold' | 'skip'
  setup: TradingSetup | null
  waveAnalysis: {
    totalCounts: number
    bestCountId: string | null
    bestFibScore: number
    swingPointCount: number
  }
  reasoning: string
  executed: boolean
}

export interface AgentTrade {
  id: string
  agentId: string
  symbol: string
  side: 'long' | 'short'
  entryPrice: number
  currentPrice: number
  size: number
  stopLoss: number
  targets: { price: number; label: string; hit: boolean }[]
  pnl: number
  pnlPct: number
  status: 'open' | 'closed' | 'stopped'
  openedAt: number
  closedAt: number | null
  waveLabel: string      // "Wave 2 end" etc.
  closingReason: string | null
}

export interface AgentState {
  config: AgentConfig
  status: AgentStatus
  lastRun: number | null
  decisions: AgentDecision[]
  trades: AgentTrade[]
  stats: {
    totalDecisions: number
    totalTrades: number
    openTrades: number
    winRate: number
    totalPnl: number
    bestTrade: number
    worstTrade: number
  }
}

const DEFAULT_CONFIG: AgentConfig = {
  id: 'ew-agent-1',
  name: 'Elliott Wave Agent',
  symbols: ['BTC', 'ETH', 'SOL'],
  timeframes: ['1h'],
  maxPositions: 3,
  maxRiskPerTrade: 2,
  minConfidence: 0.4,
  lookbackHours: 336,
  swingStrength: 5,
  enabled: true,
}

// In-memory state (persisted via API to Supabase in production)
let agentState: AgentState = {
  config: DEFAULT_CONFIG,
  status: 'idle',
  lastRun: null,
  decisions: [],
  trades: [],
  stats: {
    totalDecisions: 0,
    totalTrades: 0,
    openTrades: 0,
    winRate: 0,
    totalPnl: 0,
    bestTrade: 0,
    worstTrade: 0,
  },
}

export function getAgentState(): AgentState {
  return agentState
}

export function updateAgentConfig(config: Partial<AgentConfig>): AgentConfig {
  agentState.config = { ...agentState.config, ...config }
  return agentState.config
}

/**
 * Run a single analysis cycle
 */
export async function runAnalysisCycle(): Promise<AgentDecision[]> {
  const { config } = agentState
  agentState.status = 'running'
  const decisions: AgentDecision[] = []

  try {
    for (const symbol of config.symbols) {
      for (const timeframe of config.timeframes) {
        try {
          const candles = await fetchCandles(symbol, timeframe, config.lookbackHours)
          if (candles.length < 50) continue

          const result = analyzeElliottWaves(candles, config.swingStrength)

          const decision = evaluateSetup(config, symbol, timeframe, result, candles)
          decisions.push(decision)

          // Execute if actionable
          if (
            decision.action !== 'hold' &&
            decision.action !== 'skip' &&
            decision.setup &&
            decision.setup.confidence >= config.minConfidence
          ) {
            const trade = createTradeFromDecision(decision, candles[candles.length - 1])
            if (trade && agentState.trades.filter(t => t.status === 'open').length < config.maxPositions) {
              agentState.trades.push(trade)
              decision.executed = true
            }
          }
        } catch (err) {
          console.error(`Agent error analyzing ${symbol} ${timeframe}:`, err)
        }
      }
    }

    agentState.decisions = [...agentState.decisions, ...decisions].slice(-100)
    agentState.lastRun = Date.now()
    agentState.status = 'idle'
    updateStats()

    return decisions
  } catch (err) {
    agentState.status = 'error'
    throw err
  }
}

function evaluateSetup(
  config: AgentConfig,
  symbol: string,
  timeframe: string,
  result: ElliottWaveResult,
  candles: OHLCV[]
): AgentDecision {
  const { tradingSetup, waveCounts, swingPoints, bestCount } = result
  const currentPrice = candles[candles.length - 1].close

  // Check if already in a position for this symbol
  const existingPosition = agentState.trades.find(
    t => t.symbol === symbol && t.status === 'open'
  )

  if (existingPosition) {
    // Update current price and check SL/TP
    existingPosition.currentPrice = currentPrice
    existingPosition.pnl = existingPosition.side === 'long'
      ? (currentPrice - existingPosition.entryPrice) * existingPosition.size
      : (existingPosition.entryPrice - currentPrice) * existingPosition.size
    existingPosition.pnlPct = existingPosition.side === 'long'
      ? ((currentPrice - existingPosition.entryPrice) / existingPosition.entryPrice) * 100
      : ((existingPosition.entryPrice - currentPrice) / existingPosition.entryPrice) * 100

    // Check stop loss
    if (
      (existingPosition.side === 'long' && currentPrice <= existingPosition.stopLoss) ||
      (existingPosition.side === 'short' && currentPrice >= existingPosition.stopLoss)
    ) {
      existingPosition.status = 'stopped'
      existingPosition.closedAt = Date.now()
      existingPosition.closingReason = 'Stop loss hit'

      return {
        id: `dec-${Date.now()}-${symbol}`,
        agentId: config.id,
        timestamp: Date.now(),
        symbol,
        timeframe,
        action: 'exit',
        setup: null,
        waveAnalysis: {
          totalCounts: waveCounts.length,
          bestCountId: bestCount?.id ?? null,
          bestFibScore: bestCount?.fibScore ?? 0,
          swingPointCount: swingPoints.length,
        },
        reasoning: `Stop loss triggered at $${currentPrice.toFixed(2)}`,
        executed: true,
      }
    }

    // Check targets
    for (const target of existingPosition.targets) {
      if (target.hit) continue
      if (
        (existingPosition.side === 'long' && currentPrice >= target.price) ||
        (existingPosition.side === 'short' && currentPrice <= target.price)
      ) {
        target.hit = true
      }
    }

    return {
      id: `dec-${Date.now()}-${symbol}`,
      agentId: config.id,
      timestamp: Date.now(),
      symbol,
      timeframe,
      action: 'hold',
      setup: null,
      waveAnalysis: {
        totalCounts: waveCounts.length,
        bestCountId: bestCount?.id ?? null,
        bestFibScore: bestCount?.fibScore ?? 0,
        swingPointCount: swingPoints.length,
      },
      reasoning: `Holding ${existingPosition.side} position. PnL: ${existingPosition.pnlPct.toFixed(2)}%`,
      executed: false,
    }
  }

  // No position — evaluate new setup
  if (!tradingSetup || tradingSetup.confidence < config.minConfidence) {
    return {
      id: `dec-${Date.now()}-${symbol}`,
      agentId: config.id,
      timestamp: Date.now(),
      symbol,
      timeframe,
      action: 'skip',
      setup: tradingSetup,
      waveAnalysis: {
        totalCounts: waveCounts.length,
        bestCountId: bestCount?.id ?? null,
        bestFibScore: bestCount?.fibScore ?? 0,
        swingPointCount: swingPoints.length,
      },
      reasoning: tradingSetup
        ? `Setup found (${tradingSetup.type}) but confidence ${(tradingSetup.confidence * 100).toFixed(0)}% below threshold ${(config.minConfidence * 100).toFixed(0)}%`
        : `No Elliott Wave trading setup detected. ${waveCounts.length} wave count(s) found.`,
      executed: false,
    }
  }

  return {
    id: `dec-${Date.now()}-${symbol}`,
    agentId: config.id,
    timestamp: Date.now(),
    symbol,
    timeframe,
    action: tradingSetup.direction === 'long' ? 'enter_long' : 'enter_short',
    setup: tradingSetup,
    waveAnalysis: {
      totalCounts: waveCounts.length,
      bestCountId: bestCount?.id ?? null,
      bestFibScore: bestCount?.fibScore ?? 0,
      swingPointCount: swingPoints.length,
    },
    reasoning: tradingSetup.reasoning,
    executed: false,
  }
}

function createTradeFromDecision(
  decision: AgentDecision,
  currentCandle: OHLCV
): AgentTrade | null {
  if (!decision.setup) return null

  const { setup } = decision
  const size = 1 // Normalized to 1 unit for now

  return {
    id: `trade-${Date.now()}-${decision.symbol}`,
    agentId: decision.agentId,
    symbol: decision.symbol,
    side: setup.direction,
    entryPrice: currentCandle.close,
    currentPrice: currentCandle.close,
    size,
    stopLoss: setup.stopLoss,
    targets: setup.targets.map(t => ({ ...t, hit: false })),
    pnl: 0,
    pnlPct: 0,
    status: 'open',
    openedAt: Date.now(),
    closedAt: null,
    waveLabel: setup.type.replace(/_/g, ' '),
    closingReason: null,
  }
}

function updateStats() {
  const closedTrades = agentState.trades.filter(t => t.status !== 'open')
  const openTrades = agentState.trades.filter(t => t.status === 'open')
  const wins = closedTrades.filter(t => t.pnl > 0)

  agentState.stats = {
    totalDecisions: agentState.decisions.length,
    totalTrades: agentState.trades.length,
    openTrades: openTrades.length,
    winRate: closedTrades.length > 0 ? (wins.length / closedTrades.length) * 100 : 0,
    totalPnl: agentState.trades.reduce((sum, t) => sum + t.pnl, 0),
    bestTrade: closedTrades.length > 0 ? Math.max(...closedTrades.map(t => t.pnlPct)) : 0,
    worstTrade: closedTrades.length > 0 ? Math.min(...closedTrades.map(t => t.pnlPct)) : 0,
  }
}

/**
 * Close a trade manually
 */
export function closeTrade(tradeId: string, reason: string): AgentTrade | null {
  const trade = agentState.trades.find(t => t.id === tradeId)
  if (!trade || trade.status !== 'open') return null

  trade.status = 'closed'
  trade.closedAt = Date.now()
  trade.closingReason = reason
  updateStats()
  return trade
}

/**
 * Reset agent state
 */
export function resetAgent(): void {
  agentState = {
    config: agentState.config,
    status: 'idle',
    lastRun: null,
    decisions: [],
    trades: [],
    stats: {
      totalDecisions: 0,
      totalTrades: 0,
      openTrades: 0,
      winRate: 0,
      totalPnl: 0,
      bestTrade: 0,
      worstTrade: 0,
    },
  }
}
