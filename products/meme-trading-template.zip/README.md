# 🤖 Meme Agent Trading System

Autonomous meme coin trading system with AI-driven agents. Each agent runs its own strategy, analyzes DexScreener data in real-time, and executes trades with adaptive position sizing, trailing stops, and circuit breakers.

**Built with:** Next.js 15 · React 19 · SQLite · TailwindCSS · Recharts · Lucide React

![Dark Theme Dashboard](https://img.shields.io/badge/theme-dark-111118?style=flat-square) ![6 Strategies](https://img.shields.io/badge/strategies-6-a855f7?style=flat-square) ![DexScreener](https://img.shields.io/badge/data-DexScreener-22c55e?style=flat-square)

---

## Quick Start

```bash
# Install dependencies
npm install

# Copy environment variables
cp .env.example .env

# Start development server
npm run dev
```

Open [http://localhost:3000](http://localhost:3000) — you'll be redirected to the dashboard.

## Architecture

```
src/
├── lib/                          # Core engine (the brains)
│   ├── meme-agent-engine.ts      # Trading cycle orchestrator
│   ├── meme-agent-signal-engine.ts  # Multi-timeframe analysis, regime detection
│   ├── meme-agent-strategies.ts  # 6 trading strategies
│   ├── meme-agent-sync.ts        # On-chain position sync (implement your RPC)
│   ├── meme-agents-db.ts         # Agent/trade/position database (SQLite)
│   ├── meme-coins-styles.ts      # Theme-aware inline styles
│   └── meme-db.ts                # Watchlist & token cache database
├── app/
│   ├── dashboard/page.tsx        # Main dashboard UI
│   └── api/meme-agents/
│       ├── route.ts              # CRUD: list/create agents
│       ├── [id]/route.ts         # CRUD: get/update/delete agent
│       ├── scheduler/route.ts    # Run trading cycles
│       ├── monitor/route.ts      # Get all open positions
│       └── discovery/route.ts    # Signal feed (agent thoughts)
└── components/
    ├── MemeAgentCard.tsx          # Agent card with stats & controls
    ├── SignalFeed.tsx             # Real-time thought/signal stream
    └── PositionGrid.tsx          # Open positions with P&L
```

## 6 Trading Strategies

| Strategy | Emoji | Style | Risk |
|----------|-------|-------|------|
| **Momentum Surfer** | 🏄 | Rides strong upward momentum, exits on reversal | Medium |
| **New Launch Sniper** | 🎯 | Targets tokens < 2h old, quick in-and-out | High |
| **Smart Money Follower** | 🐋 | Follows whale-like volume patterns | Medium |
| **Safety First** | 🛡️ | Only trades security-verified tokens | Low |
| **Dip Buyer** | 📉 | Buys established tokens on -20%+ dips | Medium |
| **Volume Spike Detector** | 📊 | Enters on unusual volume spikes | Medium |

## Signal Engine

Beyond basic strategy signals, the enhanced signal engine adds:

- **Market Regime Detection** — Classifies conditions as `trending_up`, `trending_down`, `ranging`, or `volatile`
- **Multi-Timeframe Analysis** — Combines 5m, 1h, 6h, 24h data for alignment scoring
- **Confidence-Based Position Sizing** — Kelly Criterion-inspired sizing based on signal confidence
- **Adaptive Stop-Loss/Take-Profit** — SL/TP levels adjust to volatility and regime
- **Trailing Stops** — Locks in profit as price rises, with partial take-profit at intermediate levels
- **Partial Exits** — Sells 50% at partial TP, moves SL to breakeven

## Safety Features

- **Circuit Breaker** — Max 10 trades/hour per agent, auto-pause on 20% daily loss
- **Token Blocklist** — Tokens that fail 3+ times are blocked for 1 hour
- **Security Scanning** — Heuristic-based honeypot, LP, and contract checks
- **Simulated Mode** — Paper trade before going live (default)
- **Slippage Simulation** — Realistic 0.5-2% slippage in simulated mode

## API Reference

### Agents

```
GET    /api/meme-agents              # List all agents
POST   /api/meme-agents              # Create agent
GET    /api/meme-agents/:id          # Get agent + positions + trades
PATCH  /api/meme-agents/:id          # Update agent (status, config)
DELETE /api/meme-agents/:id          # Delete agent and all data
```

### Trading

```
POST   /api/meme-agents/scheduler    # Run cycle (body: { agentId } or all active)
GET    /api/meme-agents/scheduler    # Scheduler status
GET    /api/meme-agents/monitor      # All open positions
GET    /api/meme-agents/discovery    # Signal feed (thoughts)
```

### Create Agent Example

```bash
curl -X POST http://localhost:3000/api/meme-agents \
  -H "Content-Type: application/json" \
  -d '{
    "name": "Momentum Alpha",
    "strategy": "momentum_surfer",
    "allocated_budget": 500,
    "risk_tolerance": "medium",
    "preferred_chains": ["solana"],
    "max_position_size": 100
  }'
```

### Run Trading Cycle

```bash
# Run all active agents
curl -X POST http://localhost:3000/api/meme-agents/scheduler

# Run specific agent
curl -X POST http://localhost:3000/api/meme-agents/scheduler \
  -H "Content-Type: application/json" \
  -d '{"agentId": "your-agent-id"}'
```

## Customization

### Add a New Strategy

1. Open `src/lib/meme-agent-strategies.ts`
2. Create a new strategy object following the pattern (must implement `analyzeMarket`, `shouldBuy`, `shouldSell`)
3. Add it to the `STRATEGIES` registry at the bottom
4. It will appear in the dashboard's strategy picker

### Go Live

1. Implement wallet management in `meme-agent-sync.ts` using your preferred Solana SDK
2. Add a trade executor (see the `buyToken`/`sellToken` pattern in the engine)
3. Set `execution_mode: 'live'` on the agent
4. Fund the wallet and enable the agent

### Automate Cycles

Set up a cron job to hit the scheduler endpoint:

```bash
# Run every 5 minutes
*/5 * * * * curl -X POST http://localhost:3000/api/meme-agents/scheduler
```

Or use `setInterval` in a separate Node.js process.

### Add Notifications

The engine has notification hooks ready — implement `sendNotification()` with:
- Telegram Bot API
- Discord webhooks
- Email (Resend, SendGrid)
- Push notifications

## Tech Stack

| Layer | Tech |
|-------|------|
| Framework | Next.js 15 (App Router) |
| UI | React 19 + Inline Styles + TailwindCSS |
| Database | SQLite via better-sqlite3 (WAL mode) |
| Data Source | DexScreener API (free, no key needed) |
| Icons | Lucide React |
| Charts | Recharts |
| Theme | Dark (#0a0a0a bg, purple/green accents) |

## Database

SQLite databases are created automatically in `./data/`:
- `meme-agents.db` — Agents, trades, positions, thoughts, config
- `meme.db` — Watchlist, alerts, token cache, security scores

Both use WAL mode for concurrent read performance.

## License

MIT — Build whatever you want with it.

---

*Built by [GWDS](https://gwds.dev) — extracted from the Cival Trading Dashboard production codebase.*
