import type { Metadata } from 'next';
import './globals.css';

export const metadata: Metadata = {
  title: 'Meme Agent Trading System',
  description: 'Autonomous meme coin trading with AI agents — 6 strategies, real-time DexScreener data, trailing stops, adaptive position sizing',
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body style={{ margin: 0, padding: 0, background: '#0a0a0a', color: '#e2e8f0' }}>
        {children}
      </body>
    </html>
  );
}
