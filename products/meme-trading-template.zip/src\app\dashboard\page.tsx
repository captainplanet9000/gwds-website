'use client';

import { useState, useEffect, useCallback } from 'react';
import { Bot, Activity, TrendingUp, Brain, Plus, RefreshCw, Wallet, BarChart3 } from 'lucide-react';
import { MemeAgentCard } from '@/components/MemeAgentCard';
import { SignalFeed } from '@/components/SignalFeed';
import { PositionGrid } from '@/components/PositionGrid';
import { s, colors, AGENT_STATUS_COLORS } from '@/lib/meme-coins-styles';
import { STRATEGIES } from '@/lib/meme-agent-strategies';

type Tab = 'agents' | 'positions' | 'signals' | 'trades';

export default function MemeAgentDashboard() {
  const [tab, setTab] = useState<Tab>('agents');
  const [agents, setAgents] = useState<any[]>([]);
  const [positions, setPositions] = useState<any[]>([]);
  const [thoughts, setThoughts] = useState<any[]>([]);
  const [trades, setTrades] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [showCreate, setShowCreate] = useState(false);
  const [cycleResults, setCycleResults] = useState<Record<string, any>>({});

  const fetchData = useCallback(async () => {
    try {
      const [agentsRes, positionsRes, thoughtsRes, tradesRes] = await Promise.all([
        fetch('/api/meme-agents'),
        fetch('/api/meme-agents/monitor'),
        fetch('/api/meme-agents/discovery'),
        fetch('/api/meme-agents?type=trades'),
      ]);
      if (agentsRes.ok) setAgents(await agentsRes.json());
      if (positionsRes.ok) setPositions(await positionsRes.json());
      if (thoughtsRes.ok) setThoughts(await thoughtsRes.json());
      if (tradesRes.ok) setTrades(await tradesRes.json());
    } catch (e) {
      console.error('Fetch error:', e);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchData();
    const interval = setInterval(fetchData, 15000);
    return () => clearInterval(interval);
  }, [fetchData]);

  const handleToggle = async (id: string, status: string) => {
    await fetch(`/api/meme-agents/${id}`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ status }),
    });
    fetchData();
  };

  const handleDelete = async (id: string) => {
    if (!confirm('Delete this agent and all its data?')) return;
    await fetch(`/api/meme-agents/${id}`, { method: 'DELETE' });
    fetchData();
  };

  const handleRunCycle = async (id: string) => {
    setCycleResults(prev => ({ ...prev, [id]: { running: true } }));
    try {
      const res = await fetch('/api/meme-agents/scheduler', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ agentId: id }),
      });
      const data = await res.json();
      setCycleResults(prev => ({ ...prev, [id]: data }));
      fetchData();
    } catch {
      setCycleResults(prev => ({ ...prev, [id]: { error: 'Failed' } }));
    }
  };

  const agentNames: Record<string, string> = {};
  agents.forEach(a => { agentNames[a.id] = a.name; });

  // Stats
  const activeAgents = agents.filter(a => a.status === 'active').length;
  const totalPnl = agents.reduce((sum, a) => sum + (a.total_pnl || 0), 0);
  const totalBalance = agents.reduce((sum, a) => sum + (a.current_balance || 0), 0);
  const totalTrades = agents.reduce((sum, a) => sum + (a.total_trades || 0), 0);

  return (
    <div style={s.page}>
      {/* Header */}
      <div style={s.header}>
        <h1 style={s.title}>🤖 Meme Agent Trading System</h1>
        <div style={s.headerRight}>
          <button onClick={fetchData} style={{ ...s.btn('#1e1e2e', colors.foreground), display: 'flex', alignItems: 'center', gap: '4px' }}>
            <RefreshCw size={14} /> Refresh
          </button>
          <button onClick={() => setShowCreate(true)} style={{ ...s.btn('#a855f7', '#000'), display: 'flex', alignItems: 'center', gap: '4px' }}>
            <Plus size={14} /> New Agent
          </button>
        </div>
      </div>

      {/* Stats Cards */}
      <div style={s.cards}>
        <div style={s.card}>
          <div style={s.cardLabel}>Active Agents</div>
          <div style={{ ...s.cardValue, color: '#a855f7' }}>
            <Bot size={18} style={{ display: 'inline', marginRight: '6px', verticalAlign: 'middle' }} />
            {activeAgents}/{agents.length}
          </div>
        </div>
        <div style={s.card}>
          <div style={s.cardLabel}>Total Balance</div>
          <div style={s.cardValue}>
            <Wallet size={18} style={{ display: 'inline', marginRight: '6px', verticalAlign: 'middle', color: '#3b82f6' }} />
            ${totalBalance.toFixed(2)}
          </div>
        </div>
        <div style={s.card}>
          <div style={s.cardLabel}>Total P&L</div>
          <div style={{ ...s.cardValue, color: totalPnl >= 0 ? '#22c55e' : '#ef4444' }}>
            <TrendingUp size={18} style={{ display: 'inline', marginRight: '6px', verticalAlign: 'middle' }} />
            {totalPnl >= 0 ? '+' : ''}${totalPnl.toFixed(2)}
          </div>
        </div>
        <div style={s.card}>
          <div style={s.cardLabel}>Open Positions</div>
          <div style={s.cardValue}>
            <Activity size={18} style={{ display: 'inline', marginRight: '6px', verticalAlign: 'middle', color: '#f59e0b' }} />
            {positions.length}
          </div>
        </div>
        <div style={s.card}>
          <div style={s.cardLabel}>Total Trades</div>
          <div style={s.cardValue}>
            <BarChart3 size={18} style={{ display: 'inline', marginRight: '6px', verticalAlign: 'middle', color: '#ec4899' }} />
            {totalTrades}
          </div>
        </div>
      </div>

      {/* Tabs */}
      <div style={s.tabs}>
        {(['agents', 'positions', 'signals', 'trades'] as Tab[]).map(t => (
          <button key={t} style={s.tab(tab === t)} onClick={() => setTab(t)}>
            {t === 'agents' && '🤖 '}
            {t === 'positions' && '📊 '}
            {t === 'signals' && '🧠 '}
            {t === 'trades' && '📈 '}
            {t.charAt(0).toUpperCase() + t.slice(1)}
          </button>
        ))}
      </div>

      {/* Content */}
      <div style={s.content}>
        {loading ? (
          <div style={s.emptyState}>
            <RefreshCw size={32} style={{ animation: 'spin 1s linear infinite', opacity: 0.4 }} />
            <p>Loading...</p>
          </div>
        ) : tab === 'agents' ? (
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(340px, 1fr))', gap: '12px' }}>
            {agents.length === 0 ? (
              <div style={s.emptyState}>
                <Bot size={48} style={{ margin: '0 auto 12px', opacity: 0.3 }} />
                <p>No agents yet. Click &quot;New Agent&quot; to create one.</p>
              </div>
            ) : agents.map(agent => (
              <div key={agent.id}>
                <MemeAgentCard
                  agent={agent}
                  onToggle={handleToggle}
                  onDelete={handleDelete}
                />
                <button
                  onClick={() => handleRunCycle(agent.id)}
                  disabled={agent.status !== 'active' || cycleResults[agent.id]?.running}
                  style={{
                    ...s.btn(agent.status === 'active' ? '#22c55e22' : '#1e1e2e', agent.status === 'active' ? '#22c55e' : '#64748b'),
                    width: '100%', marginTop: '6px', fontSize: '11px',
                    opacity: agent.status !== 'active' ? 0.5 : 1,
                  }}
                >
                  {cycleResults[agent.id]?.running ? '⏳ Running cycle...' : '▶ Run Cycle Now'}
                </button>
                {cycleResults[agent.id] && !cycleResults[agent.id].running && (
                  <div style={{ fontSize: '10px', color: colors.muted, marginTop: '4px', padding: '0 4px' }}>
                    {cycleResults[agent.id].buysExecuted ?? 0} buys, {cycleResults[agent.id].sellsExecuted ?? 0} sells, {cycleResults[agent.id].tokensAnalyzed ?? 0} analyzed
                  </div>
                )}
              </div>
            ))}
          </div>
        ) : tab === 'positions' ? (
          <PositionGrid positions={positions} agentNames={agentNames} />
        ) : tab === 'signals' ? (
          <SignalFeed thoughts={thoughts} agentNames={agentNames} maxItems={50} />
        ) : tab === 'trades' ? (
          <TradeHistory trades={trades} agentNames={agentNames} />
        ) : null}
      </div>

      {/* Create Agent Modal */}
      {showCreate && (
        <CreateAgentModal
          onClose={() => setShowCreate(false)}
          onCreated={() => { setShowCreate(false); fetchData(); }}
        />
      )}

      <style>{`@keyframes spin { to { transform: rotate(360deg); } }`}</style>
    </div>
  );
}

// ─── Trade History ───────────────────────────────────────────
function TradeHistory({ trades, agentNames }: { trades: any[]; agentNames: Record<string, string> }) {
  if (trades.length === 0) {
    return <div style={s.emptyState}><p>No trades yet.</p></div>;
  }

  return (
    <div style={{ overflowX: 'auto' }}>
      <table style={s.table}>
        <thead>
          <tr>
            <th style={s.th}>Time</th>
            <th style={s.th}>Agent</th>
            <th style={s.th}>Token</th>
            <th style={s.th}>Side</th>
            <th style={s.th}>Amount</th>
            <th style={s.th}>Price</th>
            <th style={s.th}>P&L</th>
            <th style={s.th}>Reason</th>
          </tr>
        </thead>
        <tbody>
          {trades.map((trade: any) => (
            <tr key={trade.id}>
              <td style={s.td}>{new Date(trade.timestamp).toLocaleString()}</td>
              <td style={s.td}>{agentNames[trade.agent_id] || trade.agent_id?.slice(0, 8)}</td>
              <td style={{ ...s.td, fontWeight: 600 }}>{trade.symbol}</td>
              <td style={s.td}>
                <span style={s.badge(trade.side === 'buy' ? '#22c55e' : '#ef4444')}>
                  {trade.side.toUpperCase()}
                </span>
              </td>
              <td style={s.td}>${trade.amount_usd?.toFixed(2)}</td>
              <td style={s.td}>${trade.price?.toFixed(6)}</td>
              <td style={{ ...s.td, ...s.pnl(trade.pnl || 0) }}>
                {trade.pnl >= 0 ? '+' : ''}${(trade.pnl || 0).toFixed(2)}
              </td>
              <td style={{ ...s.td, fontSize: '11px', color: colors.muted, maxWidth: '200px', overflow: 'hidden', textOverflow: 'ellipsis' }}>
                {trade.entry_reason || trade.exit_reason || '-'}
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

// ─── Create Agent Modal ──────────────────────────────────────
function CreateAgentModal({ onClose, onCreated }: { onClose: () => void; onCreated: () => void }) {
  const [form, setForm] = useState({
    name: '', strategy: 'momentum_surfer', allocated_budget: 100,
    risk_tolerance: 'medium', preferred_chains: ['solana'],
    max_position_size: 50, min_liquidity: 10000,
  });
  const [submitting, setSubmitting] = useState(false);

  const handleSubmit = async () => {
    setSubmitting(true);
    try {
      const res = await fetch('/api/meme-agents', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(form),
      });
      if (res.ok) onCreated();
    } catch {
    } finally {
      setSubmitting(false);
    }
  };

  const strategyList = Object.entries(STRATEGIES).map(([id, strat]) => ({
    id, name: strat.name, emoji: strat.emoji, description: strat.getDescription(),
  }));

  return (
    <div style={s.modal} onClick={onClose}>
      <div style={s.modalContent} onClick={e => e.stopPropagation()}>
        <h2 style={{ fontSize: '18px', fontWeight: 700, marginBottom: '16px', color: colors.foreground }}>
          🤖 Create Meme Agent
        </h2>

        <div style={{ display: 'flex', flexDirection: 'column', gap: '14px' }}>
          <div>
            <label style={{ fontSize: '12px', color: colors.muted, fontWeight: 600 }}>Agent Name</label>
            <input
              style={s.input}
              value={form.name}
              onChange={e => setForm(f => ({ ...f, name: e.target.value }))}
              placeholder="e.g. Momentum Alpha"
            />
          </div>

          <div>
            <label style={{ fontSize: '12px', color: colors.muted, fontWeight: 600 }}>Strategy</label>
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(200px, 1fr))', gap: '8px', marginTop: '6px' }}>
              {strategyList.map(strat => (
                <div
                  key={strat.id}
                  onClick={() => setForm(f => ({ ...f, strategy: strat.id }))}
                  style={{
                    padding: '10px', borderRadius: '8px', cursor: 'pointer',
                    border: `2px solid ${form.strategy === strat.id ? '#a855f7' : '#1e1e2e'}`,
                    background: form.strategy === strat.id ? '#a855f710' : '#111118',
                  }}
                >
                  <div style={{ fontSize: '13px', fontWeight: 600, marginBottom: '2px' }}>
                    {strat.emoji} {strat.name}
                  </div>
                  <div style={{ fontSize: '10px', color: colors.muted, lineHeight: '1.3' }}>
                    {strat.description.slice(0, 80)}...
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: '12px' }}>
            <div>
              <label style={{ fontSize: '12px', color: colors.muted, fontWeight: 600 }}>Budget ($)</label>
              <input
                style={s.input}
                type="number"
                value={form.allocated_budget}
                onChange={e => setForm(f => ({ ...f, allocated_budget: parseFloat(e.target.value) || 0 }))}
              />
            </div>
            <div>
              <label style={{ fontSize: '12px', color: colors.muted, fontWeight: 600 }}>Max Position ($)</label>
              <input
                style={s.input}
                type="number"
                value={form.max_position_size}
                onChange={e => setForm(f => ({ ...f, max_position_size: parseFloat(e.target.value) || 0 }))}
              />
            </div>
            <div>
              <label style={{ fontSize: '12px', color: colors.muted, fontWeight: 600 }}>Risk</label>
              <select
                style={{ ...s.select, width: '100%' }}
                value={form.risk_tolerance}
                onChange={e => setForm(f => ({ ...f, risk_tolerance: e.target.value }))}
              >
                <option value="conservative">Conservative</option>
                <option value="medium">Medium</option>
                <option value="aggressive">Aggressive</option>
              </select>
            </div>
          </div>

          <div style={{ display: 'flex', gap: '10px', justifyContent: 'flex-end', marginTop: '8px' }}>
            <button onClick={onClose} style={s.btn('#1e1e2e', colors.foreground)}>Cancel</button>
            <button
              onClick={handleSubmit}
              disabled={!form.name || submitting}
              style={{
                ...s.btn('#a855f7', '#000'),
                opacity: !form.name || submitting ? 0.5 : 1,
              }}
            >
              {submitting ? 'Creating...' : 'Create Agent'}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
