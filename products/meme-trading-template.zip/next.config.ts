import type { NextConfig } from 'next';

const nextConfig: NextConfig = {
  // Enable server-side external packages (better-sqlite3 is native)
  serverExternalPackages: ['better-sqlite3'],
};

export default nextConfig;
