import { NextRequest, NextResponse } from 'next/server';
import * as db from '@/lib/meme-agents-db';

// GET /api/meme-agents/monitor — Get all open positions across all agents
export async function GET() {
  const positions = db.getAllPositions();
  return NextResponse.json(positions);
}
