/**
 * Theme-aware styles for Meme Trading Dashboard
 * Dark theme with purple/green accents
 */
import React from 'react'

// ── Theme-Aware Styles ─────────────────────────────────────────────────────
export const s = {
  page: { 
    minHeight: '100vh', 
    background: '#0a0a0a', 
    color: '#e2e8f0', 
    fontFamily: '-apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif', 
    paddingBottom: '40px', 
    boxSizing: 'border-box' as const, 
    maxWidth: '100%', 
    overflowX: 'hidden' as const 
  } as React.CSSProperties,
  
  header: { 
    display: 'flex', 
    alignItems: 'center', 
    justifyContent: 'space-between', 
    padding: '16px', 
    flexWrap: 'wrap' as const, 
    gap: '12px', 
    borderBottom: '1px solid #1e1e2e', 
    boxSizing: 'border-box' as const, 
    maxWidth: '100%' 
  } as React.CSSProperties,
  
  title: { 
    fontSize: 'clamp(16px, 4vw, 24px)', 
    fontWeight: 700, 
    margin: 0, 
    background: 'linear-gradient(135deg, #a855f7, #22c55e)', 
    WebkitBackgroundClip: 'text', 
    WebkitTextFillColor: 'transparent' 
  } as React.CSSProperties,
  
  headerRight: { 
    display: 'flex', 
    alignItems: 'center', 
    gap: '12px', 
    flexWrap: 'wrap' as const 
  } as React.CSSProperties,
  
  cards: { 
    display: 'grid', 
    gridTemplateColumns: 'repeat(auto-fit, minmax(min(100%, 150px), 1fr))', 
    gap: '12px', 
    padding: '16px', 
    boxSizing: 'border-box' as const, 
    maxWidth: '100%' 
  } as React.CSSProperties,
  
  card: { 
    background: '#111118', 
    borderRadius: '12px', 
    padding: '14px', 
    border: '1px solid #1e1e2e', 
    boxSizing: 'border-box' as const, 
    overflow: 'hidden' as const, 
    minWidth: 0 
  } as React.CSSProperties,
  
  cardLabel: { 
    fontSize: '12px', 
    color: '#64748b', 
    marginBottom: '4px' 
  } as React.CSSProperties,
  
  cardValue: { 
    fontSize: 'clamp(14px, 3.5vw, 20px)', 
    fontWeight: 700, 
    wordBreak: 'break-word' as const, 
    overflowWrap: 'break-word' as const 
  } as React.CSSProperties,
  
  tabs: { 
    display: 'flex', 
    gap: '0', 
    padding: '0 16px', 
    borderBottom: '1px solid #1e1e2e', 
    overflowX: 'auto' as const, 
    maxWidth: '100%', 
    boxSizing: 'border-box' as const 
  } as React.CSSProperties,
  
  tab: (active: boolean) => ({ 
    padding: '10px 20px', 
    cursor: 'pointer', 
    fontSize: '14px', 
    fontWeight: active ? 600 : 400, 
    color: active ? '#a855f7' : '#64748b', 
    background: 'none', 
    border: 'none', 
    borderBottomStyle: 'solid' as const, 
    borderBottomWidth: '2px', 
    borderBottomColor: active ? '#a855f7' : 'transparent', 
    whiteSpace: 'nowrap' as const 
  }) as React.CSSProperties,
  
  content: { 
    padding: '16px', 
    boxSizing: 'border-box' as const, 
    maxWidth: '100%', 
    overflowX: 'auto' as const 
  } as React.CSSProperties,
  
  table: { 
    width: '100%', 
    borderCollapse: 'collapse' as const, 
    fontSize: '13px', 
    minWidth: '900px' 
  } as React.CSSProperties,
  
  th: { 
    textAlign: 'left' as const, 
    padding: '10px 12px', 
    color: '#64748b', 
    borderBottom: '1px solid #1e1e2e', 
    fontSize: '12px', 
    fontWeight: 600, 
    cursor: 'pointer', 
    userSelect: 'none' as const 
  } as React.CSSProperties,
  
  td: { 
    padding: '10px 12px', 
    borderBottom: '1px solid rgba(30,30,46,0.5)' 
  } as React.CSSProperties,
  
  badge: (color: string) => ({ 
    display: 'inline-block', 
    padding: '2px 8px', 
    borderRadius: '4px', 
    fontSize: '11px', 
    fontWeight: 600, 
    background: color + '22', 
    color 
  }) as React.CSSProperties,
  
  pnl: (v: number) => ({ 
    color: v >= 0 ? '#22c55e' : '#ef4444', 
    fontWeight: 600 
  }) as React.CSSProperties,
  
  btn: (bg: string, color = '#fff') => ({ 
    background: bg, 
    color, 
    border: 'none', 
    borderRadius: '6px', 
    padding: '6px 14px', 
    cursor: 'pointer', 
    fontSize: '13px', 
    fontWeight: 600, 
    transition: 'opacity .15s' 
  }) as React.CSSProperties,
  
  btnSm: (bg: string, fg = '#fff') => ({ 
    background: bg, 
    color: fg, 
    border: 'none', 
    borderRadius: '4px', 
    padding: '3px 8px', 
    cursor: 'pointer', 
    fontSize: '11px', 
    fontWeight: 600, 
    transition: 'opacity .15s' 
  }) as React.CSSProperties,
  
  input: { 
    background: '#1a1a2e', 
    border: '1px solid #1e1e2e', 
    borderRadius: '6px', 
    padding: '8px 12px', 
    color: '#e2e8f0', 
    fontSize: '14px', 
    outline: 'none', 
    width: '100%', 
    boxSizing: 'border-box' as const 
  } as React.CSSProperties,
  
  select: { 
    background: '#1a1a2e', 
    border: '1px solid #1e1e2e', 
    borderRadius: '6px', 
    padding: '8px 12px', 
    color: '#e2e8f0', 
    fontSize: '14px', 
    outline: 'none' 
  } as React.CSSProperties,
  
  emptyState: { 
    textAlign: 'center' as const, 
    padding: '60px 20px', 
    color: '#64748b' 
  } as React.CSSProperties,
  
  section: { 
    marginBottom: '20px' 
  } as React.CSSProperties,
  
  sectionTitle: { 
    fontSize: '16px', 
    fontWeight: 600, 
    marginBottom: '12px', 
    color: '#e2e8f0' 
  } as React.CSSProperties,
  
  modal: { 
    position: 'fixed' as const, 
    top: 0, left: 0, right: 0, bottom: 0, 
    background: 'rgba(0,0,0,0.7)', 
    display: 'flex', 
    alignItems: 'center', 
    justifyContent: 'center', 
    zIndex: 1000, 
    padding: '20px' 
  } as React.CSSProperties,
  
  modalContent: { 
    background: '#111118', 
    borderRadius: '16px', 
    padding: '24px', 
    border: '1px solid #1e1e2e', 
    maxWidth: '700px', 
    width: '100%', 
    maxHeight: '85vh', 
    overflowY: 'auto' as const 
  } as React.CSSProperties,
  
  agentCard: { 
    background: '#111118', 
    borderRadius: '12px', 
    padding: '16px', 
    border: '1px solid #1e1e2e' 
  } as React.CSSProperties,
  
  agentHeader: { 
    display: 'flex', 
    justifyContent: 'space-between', 
    alignItems: 'center', 
    marginBottom: '12px' 
  } as React.CSSProperties,
  
  agentName: { 
    fontSize: '16px', 
    fontWeight: 600, 
    color: '#e2e8f0' 
  } as React.CSSProperties,
  
  agentStats: { 
    display: 'grid', 
    gridTemplateColumns: 'repeat(3, 1fr)', 
    gap: '12px' 
  } as React.CSSProperties,
  
  thoughtBubble: { 
    background: '#1a1a2e', 
    borderRadius: '8px', 
    padding: '12px', 
    marginBottom: '8px', 
    borderLeft: '3px solid #a855f7' 
  } as React.CSSProperties,
  
  dot: (on: boolean) => ({ 
    width: '8px', 
    height: '8px', 
    borderRadius: '50%', 
    background: on ? '#22c55e' : '#ef4444', 
    display: 'inline-block', 
    marginRight: '4px' 
  }) as React.CSSProperties,
  
  chainBadge: (chain: string) => {
    const colors: Record<string, string> = { 
      solana: '#9945FF', base: '#0052FF', ethereum: '#627EEA', 
      bsc: '#F0B90B', arbitrum: '#28A0F0', polygon: '#8247E5' 
    }
    const c = colors[chain] || '#a855f7'
    return { 
      display: 'inline-block', padding: '2px 8px', borderRadius: '4px', 
      fontSize: '10px', fontWeight: 600, background: c + '22', color: c, marginRight: '4px' 
    } as React.CSSProperties
  },
}

// Color constants
export const colors = {
  accent: '#a855f7',
  secondary: '#8b5cf6',
  success: '#22c55e',
  danger: '#ef4444',
  warning: '#f59e0b',
  muted: '#64748b',
  foreground: '#e2e8f0',
  background: '#0a0a0a',
  surface: '#111118',
  border: '#1e1e2e',
}

export const pctColor = (v: number) => v >= 0 ? '#22c55e' : '#ef4444'

export const AGENT_STATUS_COLORS: Record<string, string> = {
  active: '#00ff88', paused: '#f59e0b', stopped: '#ff4444', error: '#ff4444', idle: '#94a3b8'
}

export const AGENT_STRATEGIES: Record<string, { name: string; emoji: string; color: string }> = {
  safety_first: { name: 'Safety First', emoji: '🛡️', color: '#22c55e' },
  momentum_surfer: { name: 'Momentum Surfer', emoji: '🏄', color: '#3b82f6' },
  dip_buyer: { name: 'Dip Buyer', emoji: '📉', color: '#f59e0b' },
  smart_money_follower: { name: 'Smart Money Follower', emoji: '🐋', color: '#8b5cf6' },
  new_launch_sniper: { name: 'New Launch Sniper', emoji: '🎯', color: '#ff6b9d' },
  volume_spike_detector: { name: 'Volume Spike', emoji: '📊', color: '#ef4444' },
}

export const getAgentStrategyInfo = (strategy: string) => 
  AGENT_STRATEGIES[strategy] || { name: strategy, emoji: '🤖', color: '#94a3b8' }
