import { NextRequest, NextResponse } from 'next/server';
import * as db from '@/lib/meme-agents-db';

// GET /api/meme-agents/discovery — Get all agent thoughts/signals (signal feed)
export async function GET(req: NextRequest) {
  const limit = parseInt(req.nextUrl.searchParams.get('limit') || '50');
  const agentId = req.nextUrl.searchParams.get('agentId');

  if (agentId) {
    const thoughts = db.getAgentThoughts(agentId, limit);
    return NextResponse.json(thoughts);
  }

  const thoughts = db.getAllThoughts(limit);
  return NextResponse.json(thoughts);
}
