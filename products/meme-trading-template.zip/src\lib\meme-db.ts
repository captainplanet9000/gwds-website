// Meme Coin Watchlist & Trades Database — SQLite via better-sqlite3
import Database from 'better-sqlite3';
import path from 'path';
import fs from 'fs';
import crypto from 'crypto';

const DB_PATH = path.join(process.cwd(), 'data', 'meme.db');
const DATA_DIR = path.dirname(DB_PATH);

if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });

let _db: Database.Database | null = null;

function getDb(): Database.Database {
  if (_db) return _db;
  _db = new Database(DB_PATH);
  _db.pragma('journal_mode = WAL');
  _db.pragma('foreign_keys = ON');
  initTables(_db);
  return _db;
}

function initTables(db: Database.Database) {
  db.exec(`
    CREATE TABLE IF NOT EXISTS watchlist (
      id TEXT PRIMARY KEY,
      chain_id TEXT NOT NULL,
      token_address TEXT NOT NULL,
      name TEXT DEFAULT '',
      symbol TEXT DEFAULT '',
      entry_price TEXT DEFAULT '0',
      allocated_amount REAL DEFAULT 0,
      notes TEXT DEFAULT '',
      added_at TEXT NOT NULL,
      current_price TEXT DEFAULT '0',
      price_change_24h REAL DEFAULT 0,
      volume_24h REAL DEFAULT 0,
      liquidity REAL DEFAULT 0,
      market_cap REAL DEFAULT 0,
      pnl REAL DEFAULT 0,
      pnl_usd REAL DEFAULT 0
    );

    CREATE TABLE IF NOT EXISTS trades (
      id TEXT PRIMARY KEY,
      token_address TEXT DEFAULT '',
      chain_id TEXT DEFAULT 'solana',
      symbol TEXT DEFAULT '',
      name TEXT DEFAULT '',
      side TEXT DEFAULT 'buy',
      amount REAL DEFAULT 0,
      price TEXT DEFAULT '0',
      quantity REAL DEFAULT 0,
      pnl REAL DEFAULT 0,
      tx_hash TEXT DEFAULT '',
      notes TEXT DEFAULT '',
      timestamp TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS alerts (
      id TEXT PRIMARY KEY,
      token_address TEXT DEFAULT '',
      chain_id TEXT DEFAULT '',
      symbol TEXT DEFAULT '',
      name TEXT DEFAULT '',
      alert_type TEXT DEFAULT 'price_above',
      target_value REAL DEFAULT 0,
      current_price_at_creation TEXT DEFAULT '0',
      triggered INTEGER DEFAULT 0,
      triggered_at TEXT,
      created_at TEXT NOT NULL,
      sound_enabled INTEGER DEFAULT 1
    );

    CREATE TABLE IF NOT EXISTS settings (
      key TEXT PRIMARY KEY,
      value TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS wallets (
      id TEXT PRIMARY KEY,
      label TEXT DEFAULT '',
      address TEXT NOT NULL,
      chain TEXT DEFAULT 'solana',
      added_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS token_cache (
      token_address TEXT NOT NULL,
      chain_id TEXT NOT NULL,
      data_json TEXT NOT NULL,
      fetched_at INTEGER NOT NULL,
      PRIMARY KEY (token_address, chain_id)
    );

    CREATE TABLE IF NOT EXISTS security_scores (
      token_address TEXT NOT NULL,
      chain_id TEXT NOT NULL,
      rugcheck_score REAL,
      goplus_data TEXT,
      honeypot INTEGER DEFAULT 0,
      last_checked TEXT NOT NULL,
      PRIMARY KEY (token_address, chain_id)
    );

    CREATE UNIQUE INDEX IF NOT EXISTS idx_watchlist_token ON watchlist(chain_id, token_address);
  `);

  // Generate API key on first run
  const settingsCount = db.prepare('SELECT COUNT(*) as c FROM settings').get() as any;
  if (settingsCount.c === 0) {
    const apiKey = crypto.randomBytes(32).toString('hex');
    db.prepare('INSERT OR IGNORE INTO settings (key, value) VALUES (?, ?)').run('api_key', JSON.stringify(apiKey));
  }
}

// ==================== WATCHLIST ====================
export function getWatchlist(): any[] {
  return getDb().prepare('SELECT * FROM watchlist ORDER BY added_at DESC').all().map((r: any) => ({
    id: r.id, chainId: r.chain_id, tokenAddress: r.token_address,
    name: r.name, symbol: r.symbol, entryPrice: r.entry_price,
    allocatedAmount: r.allocated_amount, notes: r.notes, addedAt: r.added_at,
    currentPrice: r.current_price, priceChange24h: r.price_change_24h,
    volume24h: r.volume_24h, liquidity: r.liquidity, marketCap: r.market_cap,
    pnl: r.pnl, pnlUsd: r.pnl_usd,
  }));
}

export function addToWatchlist(item: any): any {
  const id = `wl-${Date.now()}`;
  getDb().prepare(`INSERT INTO watchlist (id, chain_id, token_address, name, symbol, entry_price, allocated_amount, notes, added_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`).run(
    id, item.chainId, item.tokenAddress, item.name || '', item.symbol || '', item.entryPrice || '0', item.allocatedAmount || 0, item.notes || '', new Date().toISOString()
  );
  return { id, ...item, addedAt: new Date().toISOString() };
}

export function removeFromWatchlist(idOrAddress: string): void {
  getDb().prepare('DELETE FROM watchlist WHERE id = ? OR token_address = ?').run(idOrAddress, idOrAddress);
}

export function updateWatchlistPrices(tokenAddress: string, data: { currentPrice?: string; priceChange24h?: number; volume24h?: number; liquidity?: number; marketCap?: number; pnl?: number; pnlUsd?: number }): void {
  getDb().prepare('UPDATE watchlist SET current_price=?, price_change_24h=?, volume_24h=?, liquidity=?, market_cap=?, pnl=?, pnl_usd=? WHERE token_address=?').run(
    data.currentPrice || '0', data.priceChange24h || 0, data.volume24h || 0, data.liquidity || 0, data.marketCap || 0, data.pnl || 0, data.pnlUsd || 0, tokenAddress
  );
}

export function isInWatchlist(tokenAddress: string): boolean {
  return !!getDb().prepare('SELECT 1 FROM watchlist WHERE token_address = ?').get(tokenAddress);
}

// ==================== TRADES ====================
export function getTrades(filters?: { symbol?: string; side?: string }): any[] {
  let sql = 'SELECT * FROM trades';
  const params: any[] = [];
  const conditions: string[] = [];
  if (filters?.symbol) { conditions.push('symbol = ?'); params.push(filters.symbol); }
  if (filters?.side) { conditions.push('side = ?'); params.push(filters.side); }
  if (conditions.length) sql += ' WHERE ' + conditions.join(' AND ');
  sql += ' ORDER BY timestamp DESC';
  return getDb().prepare(sql).all(...params).map((r: any) => ({
    id: r.id, tokenAddress: r.token_address, chainId: r.chain_id, symbol: r.symbol,
    name: r.name, side: r.side, amount: r.amount, price: r.price, quantity: r.quantity,
    pnl: r.pnl, txHash: r.tx_hash, notes: r.notes, timestamp: r.timestamp,
  }));
}

export function addTrade(trade: any): any {
  const id = `mt-${Date.now()}`;
  const timestamp = trade.timestamp || new Date().toISOString();
  getDb().prepare('INSERT INTO trades (id, token_address, chain_id, symbol, name, side, amount, price, quantity, pnl, tx_hash, notes, timestamp) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)').run(
    id, trade.tokenAddress || '', trade.chainId || 'solana', trade.symbol || '', trade.name || '',
    trade.side || 'buy', trade.amount || 0, trade.price || '0', trade.quantity || 0, trade.pnl || 0,
    trade.txHash || '', trade.notes || '', timestamp
  );
  return { id, ...trade, timestamp };
}

export function deleteTrade(id: string): void {
  getDb().prepare('DELETE FROM trades WHERE id = ?').run(id);
}

// ==================== ALERTS ====================
export function getAlerts(): any[] {
  return getDb().prepare('SELECT * FROM alerts ORDER BY created_at DESC').all().map((r: any) => ({
    id: r.id, tokenAddress: r.token_address, chainId: r.chain_id, symbol: r.symbol,
    name: r.name, type: r.alert_type, value: r.target_value, triggered: !!r.triggered,
    triggeredAt: r.triggered_at, createdAt: r.created_at, soundEnabled: !!r.sound_enabled,
  }));
}

export function addAlert(alert: any): any {
  const id = `alert-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`;
  getDb().prepare('INSERT INTO alerts (id, token_address, chain_id, symbol, name, alert_type, target_value, current_price_at_creation, triggered, created_at, sound_enabled) VALUES (?,?,?,?,?,?,?,?,0,?,?)').run(
    id, alert.tokenAddress || '', alert.chainId || '', alert.symbol || '', alert.name || '',
    alert.type || 'price_above', alert.value || 0, alert.currentPrice || '0',
    new Date().toISOString(), alert.soundEnabled !== false ? 1 : 0
  );
  return { id, ...alert, triggered: false, createdAt: new Date().toISOString() };
}

export function markAlertTriggered(id: string): void {
  getDb().prepare('UPDATE alerts SET triggered = 1, triggered_at = ? WHERE id = ?').run(new Date().toISOString(), id);
}

export function deleteAlert(id: string): void {
  getDb().prepare('DELETE FROM alerts WHERE id = ?').run(id);
}

// ==================== SETTINGS ====================
export function getSettings(): any {
  const row = getDb().prepare("SELECT value FROM settings WHERE key = 'meme_settings'").get() as any;
  if (row) return JSON.parse(row.value);
  return { minLiquidity: 10000, minVolume24h: 50000, chains: ['solana', 'base', 'bsc', 'ethereum'] };
}

export function updateSettings(settings: any): void {
  getDb().prepare("INSERT OR REPLACE INTO settings (key, value) VALUES ('meme_settings', ?)").run(JSON.stringify(settings));
}

export function getApiKey(): string {
  const row = getDb().prepare("SELECT value FROM settings WHERE key = 'api_key'").get() as any;
  if (row) return JSON.parse(row.value);
  const key = crypto.randomBytes(32).toString('hex');
  getDb().prepare("INSERT OR REPLACE INTO settings (key, value) VALUES ('api_key', ?)").run(JSON.stringify(key));
  return key;
}

// ==================== TOKEN CACHE ====================
const CACHE_TTL_MS = 30_000;

export function getCachedToken(tokenAddress: string, chainId: string): any | null {
  const row = getDb().prepare('SELECT data_json, fetched_at FROM token_cache WHERE token_address = ? AND chain_id = ?').get(tokenAddress, chainId) as any;
  if (!row) return null;
  if (Date.now() - row.fetched_at > CACHE_TTL_MS) return null;
  return JSON.parse(row.data_json);
}

export function cacheToken(tokenAddress: string, chainId: string, data: any): void {
  getDb().prepare('INSERT OR REPLACE INTO token_cache (token_address, chain_id, data_json, fetched_at) VALUES (?,?,?,?)').run(
    tokenAddress, chainId, JSON.stringify(data), Date.now()
  );
}

// ==================== SECURITY SCORES ====================
export function getSecurityScore(tokenAddress: string, chainId: string): any | null {
  const row = getDb().prepare('SELECT * FROM security_scores WHERE token_address = ? AND chain_id = ?').get(tokenAddress, chainId) as any;
  if (!row) return null;
  return { tokenAddress: row.token_address, chainId: row.chain_id, rugcheckScore: row.rugcheck_score, goplusData: row.goplus_data ? JSON.parse(row.goplus_data) : null, honeypot: !!row.honeypot, lastChecked: row.last_checked };
}

export function saveSecurityScore(data: any): void {
  getDb().prepare('INSERT OR REPLACE INTO security_scores (token_address, chain_id, rugcheck_score, goplus_data, honeypot, last_checked) VALUES (?,?,?,?,?,?)').run(
    data.tokenAddress, data.chainId, data.rugcheckScore || null, data.goplusData ? JSON.stringify(data.goplusData) : null, data.honeypot ? 1 : 0, new Date().toISOString()
  );
}

// ==================== AUTH ====================
export function validateApiKey(req: Request): boolean {
  const host = req.headers.get('host') || '';
  if (host.startsWith('localhost') || host.startsWith('127.0.0.1')) return true;
  const url = new URL(req.url);
  const key = req.headers.get('x-api-key') || url.searchParams.get('apiKey');
  if (!key) return false;
  return key === getApiKey();
}
