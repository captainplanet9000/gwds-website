'use client';

import { Bot, TrendingUp, TrendingDown, Pause, Play, Trash2, Activity } from 'lucide-react';
import { s, colors, AGENT_STATUS_COLORS, getAgentStrategyInfo, pctColor } from '@/lib/meme-coins-styles';

interface MemeAgentCardProps {
  agent: {
    id: string;
    name: string;
    strategy: string;
    status: string;
    allocated_budget: number;
    current_balance: number;
    total_pnl: number;
    total_trades: number;
    win_rate: number;
    risk_tolerance: string;
    execution_mode: string;
    preferred_chains: string[];
  };
  onToggle?: (id: string, status: string) => void;
  onDelete?: (id: string) => void;
  onSelect?: (id: string) => void;
}

export function MemeAgentCard({ agent, onToggle, onDelete, onSelect }: MemeAgentCardProps) {
  const strategyInfo = getAgentStrategyInfo(agent.strategy);
  const statusColor = AGENT_STATUS_COLORS[agent.status] || '#94a3b8';
  const pnlPct = agent.allocated_budget > 0 ? (agent.total_pnl / agent.allocated_budget) * 100 : 0;
  const isActive = agent.status === 'active';

  return (
    <div
      style={{
        ...s.agentCard,
        cursor: onSelect ? 'pointer' : 'default',
        transition: 'border-color 0.2s',
      }}
      onClick={() => onSelect?.(agent.id)}
      onMouseOver={(e) => (e.currentTarget.style.borderColor = colors.accent)}
      onMouseOut={(e) => (e.currentTarget.style.borderColor = '#1e1e2e')}
    >
      {/* Header */}
      <div style={s.agentHeader}>
        <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
          <div style={{
            width: '36px', height: '36px', borderRadius: '10px',
            background: strategyInfo.color + '22', display: 'flex',
            alignItems: 'center', justifyContent: 'center', fontSize: '18px',
          }}>
            {strategyInfo.emoji}
          </div>
          <div>
            <div style={s.agentName}>{agent.name}</div>
            <div style={{ fontSize: '11px', color: colors.muted, display: 'flex', alignItems: 'center', gap: '6px' }}>
              <span style={s.dot(isActive)} />
              {agent.status}
              <span style={{ color: strategyInfo.color }}>• {strategyInfo.name}</span>
              {agent.execution_mode === 'live' && (
                <span style={{ background: '#22c55e22', color: '#22c55e', padding: '1px 5px', borderRadius: '3px', fontSize: '9px', fontWeight: 700 }}>
                  LIVE
                </span>
              )}
            </div>
          </div>
        </div>
        <div style={{ display: 'flex', gap: '6px' }} onClick={(e) => e.stopPropagation()}>
          <button
            onClick={() => onToggle?.(agent.id, isActive ? 'paused' : 'active')}
            style={{
              ...s.btn(isActive ? '#f59e0b' : '#22c55e', '#000'),
              display: 'flex', alignItems: 'center', gap: '4px', padding: '4px 10px',
            }}
          >
            {isActive ? <Pause size={12} /> : <Play size={12} />}
            {isActive ? 'Pause' : 'Start'}
          </button>
          <button
            onClick={() => onDelete?.(agent.id)}
            style={{ ...s.btn('#ef444422', '#ef4444'), padding: '4px 8px' }}
          >
            <Trash2 size={12} />
          </button>
        </div>
      </div>

      {/* Stats Grid */}
      <div style={s.agentStats}>
        <div>
          <div style={s.cardLabel}>Balance</div>
          <div style={{ fontSize: '14px', fontWeight: 600, color: colors.foreground }}>
            ${agent.current_balance.toFixed(2)}
          </div>
        </div>
        <div>
          <div style={s.cardLabel}>P&L</div>
          <div style={{ fontSize: '14px', fontWeight: 600, color: pctColor(agent.total_pnl), display: 'flex', alignItems: 'center', gap: '4px' }}>
            {agent.total_pnl >= 0 ? <TrendingUp size={12} /> : <TrendingDown size={12} />}
            {agent.total_pnl >= 0 ? '+' : ''}${agent.total_pnl.toFixed(2)}
          </div>
          <div style={{ fontSize: '10px', color: pctColor(pnlPct) }}>
            ({pnlPct >= 0 ? '+' : ''}{pnlPct.toFixed(1)}%)
          </div>
        </div>
        <div>
          <div style={s.cardLabel}>Win Rate</div>
          <div style={{ fontSize: '14px', fontWeight: 600, color: colors.foreground }}>
            {agent.win_rate.toFixed(0)}%
          </div>
          <div style={{ fontSize: '10px', color: colors.muted }}>{agent.total_trades} trades</div>
        </div>
      </div>

      {/* Chain badges */}
      <div style={{ marginTop: '10px', display: 'flex', flexWrap: 'wrap', gap: '4px' }}>
        {agent.preferred_chains.map((chain) => (
          <span key={chain} style={s.chainBadge(chain)}>{chain}</span>
        ))}
        <span style={{
          ...s.badge(agent.risk_tolerance === 'aggressive' ? '#ef4444' : agent.risk_tolerance === 'conservative' ? '#22c55e' : '#f59e0b'),
          fontSize: '9px',
        }}>
          {agent.risk_tolerance}
        </span>
      </div>
    </div>
  );
}
