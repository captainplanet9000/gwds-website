import { NextRequest, NextResponse } from 'next/server';
import * as db from '@/lib/meme-agents-db';

// GET /api/meme-agents — List agents or trades
export async function GET(req: NextRequest) {
  const type = req.nextUrl.searchParams.get('type');

  if (type === 'trades') {
    const trades = db.getAllTrades(100);
    return NextResponse.json(trades);
  }

  const agents = db.getAllAgents();
  return NextResponse.json(agents);
}

// POST /api/meme-agents — Create agent
export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const { name, strategy, allocated_budget, risk_tolerance, preferred_chains, max_position_size, min_liquidity } = body;

    if (!name || !strategy) {
      return NextResponse.json({ error: 'name and strategy required' }, { status: 400 });
    }

    const agent = db.createAgent({
      name,
      strategy,
      allocated_budget: allocated_budget || 100,
      risk_tolerance: risk_tolerance || 'medium',
      preferred_chains: preferred_chains || ['solana'],
      max_position_size: max_position_size || 50,
      min_liquidity: min_liquidity || 10000,
    });

    return NextResponse.json(agent, { status: 201 });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}
