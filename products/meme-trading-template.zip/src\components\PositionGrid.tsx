'use client';

import { TrendingUp, TrendingDown, ExternalLink } from 'lucide-react';
import { s, colors, pctColor } from '@/lib/meme-coins-styles';

interface Position {
  id: string;
  agent_id: string;
  token_address: string;
  chain_id: string;
  symbol: string;
  name: string;
  entry_price: number;
  current_price: number;
  quantity: number;
  amount_usd: number;
  unrealized_pnl: number;
  unrealized_pnl_pct: number;
  stop_loss: number | null;
  take_profit: number | null;
  opened_at: string;
}

interface PositionGridProps {
  positions: Position[];
  agentNames?: Record<string, string>;
}

function formatPrice(price: number): string {
  if (price < 0.00001) return price.toExponential(2);
  if (price < 0.01) return price.toFixed(6);
  if (price < 1) return price.toFixed(4);
  return price.toFixed(2);
}

function holdTime(openedAt: string): string {
  const ms = Date.now() - new Date(openedAt).getTime();
  const hours = Math.floor(ms / 3600000);
  if (hours < 1) return `${Math.floor(ms / 60000)}m`;
  if (hours < 24) return `${hours}h`;
  return `${Math.floor(hours / 24)}d ${hours % 24}h`;
}

export function PositionGrid({ positions, agentNames = {} }: PositionGridProps) {
  if (positions.length === 0) {
    return (
      <div style={s.emptyState}>
        <TrendingUp size={48} style={{ margin: '0 auto 12px', opacity: 0.3 }} />
        <p style={{ fontSize: '14px' }}>No open positions. Agents will buy when signals align.</p>
      </div>
    );
  }

  const totalUnrealizedPnl = positions.reduce((sum, p) => sum + p.unrealized_pnl, 0);
  const totalValue = positions.reduce((sum, p) => sum + p.amount_usd + p.unrealized_pnl, 0);

  return (
    <div>
      {/* Summary bar */}
      <div style={{
        display: 'flex', gap: '20px', padding: '12px 16px', marginBottom: '12px',
        background: '#111118', borderRadius: '8px', border: '1px solid #1e1e2e',
      }}>
        <div>
          <span style={{ fontSize: '11px', color: colors.muted }}>Positions</span>
          <div style={{ fontSize: '16px', fontWeight: 700 }}>{positions.length}</div>
        </div>
        <div>
          <span style={{ fontSize: '11px', color: colors.muted }}>Total Value</span>
          <div style={{ fontSize: '16px', fontWeight: 700 }}>${totalValue.toFixed(2)}</div>
        </div>
        <div>
          <span style={{ fontSize: '11px', color: colors.muted }}>Unrealized P&L</span>
          <div style={{ fontSize: '16px', fontWeight: 700, color: pctColor(totalUnrealizedPnl) }}>
            {totalUnrealizedPnl >= 0 ? '+' : ''}${totalUnrealizedPnl.toFixed(2)}
          </div>
        </div>
      </div>

      {/* Position cards */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(280px, 1fr))', gap: '10px' }}>
        {positions.map((pos) => {
          const agentName = agentNames[pos.agent_id] || pos.agent_id.slice(0, 8);
          const pnlColor = pctColor(pos.unrealized_pnl);
          const dexUrl = pos.chain_id === 'solana'
            ? `https://dexscreener.com/solana/${pos.token_address}`
            : `https://dexscreener.com/${pos.chain_id}/${pos.token_address}`;

          return (
            <div key={pos.id} style={{
              background: '#111118', borderRadius: '10px', padding: '14px',
              border: `1px solid #1e1e2e`, position: 'relative',
            }}>
              {/* Header */}
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '10px' }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                  <span style={{ fontSize: '15px', fontWeight: 700 }}>{pos.symbol}</span>
                  <span style={s.chainBadge(pos.chain_id)}>{pos.chain_id}</span>
                </div>
                <a href={dexUrl} target="_blank" rel="noopener noreferrer" style={{ color: colors.muted }}>
                  <ExternalLink size={14} />
                </a>
              </div>

              {/* P&L */}
              <div style={{
                display: 'flex', alignItems: 'center', gap: '6px', marginBottom: '10px',
              }}>
                {pos.unrealized_pnl >= 0 ? <TrendingUp size={16} style={{ color: pnlColor }} /> : <TrendingDown size={16} style={{ color: pnlColor }} />}
                <span style={{ fontSize: '18px', fontWeight: 700, color: pnlColor }}>
                  {pos.unrealized_pnl >= 0 ? '+' : ''}${pos.unrealized_pnl.toFixed(2)}
                </span>
                <span style={{ fontSize: '12px', color: pnlColor }}>
                  ({pos.unrealized_pnl_pct >= 0 ? '+' : ''}{pos.unrealized_pnl_pct.toFixed(1)}%)
                </span>
              </div>

              {/* Details grid */}
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '6px', fontSize: '11px' }}>
                <div>
                  <span style={{ color: colors.muted }}>Entry</span>
                  <div style={{ fontWeight: 600 }}>${formatPrice(pos.entry_price)}</div>
                </div>
                <div>
                  <span style={{ color: colors.muted }}>Current</span>
                  <div style={{ fontWeight: 600 }}>${formatPrice(pos.current_price)}</div>
                </div>
                <div>
                  <span style={{ color: colors.muted }}>Size</span>
                  <div style={{ fontWeight: 600 }}>${pos.amount_usd.toFixed(2)}</div>
                </div>
                <div>
                  <span style={{ color: colors.muted }}>Hold Time</span>
                  <div style={{ fontWeight: 600 }}>{holdTime(pos.opened_at)}</div>
                </div>
                {pos.stop_loss && (
                  <div>
                    <span style={{ color: '#ef4444' }}>SL</span>
                    <div style={{ fontWeight: 600, color: '#ef4444' }}>${formatPrice(pos.stop_loss)}</div>
                  </div>
                )}
                {pos.take_profit && (
                  <div>
                    <span style={{ color: '#22c55e' }}>TP</span>
                    <div style={{ fontWeight: 600, color: '#22c55e' }}>${formatPrice(pos.take_profit)}</div>
                  </div>
                )}
              </div>

              {/* Agent tag */}
              <div style={{
                marginTop: '8px', fontSize: '10px', color: colors.muted,
                borderTop: '1px solid #1e1e2e', paddingTop: '6px',
              }}>
                Agent: {agentName}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
