/**
 * Enhanced Meme Agent Signal Engine
 * Multi-timeframe analysis, confidence-based position sizing,
 * adaptive stop-loss/take-profit, and market regime detection.
 */

import type { TokenData, AgentConfig, SecurityInfo, PositionData } from './meme-agent-strategies';

// ─── Market Regime Detection ──────────────────────────────────────
export type MarketRegime = 'trending_up' | 'trending_down' | 'ranging' | 'volatile' | 'unknown';

export interface RegimeAnalysis {
  regime: MarketRegime;
  confidence: number;
  volatility: number;
  momentum: number;
  trendStrength: number;
}

export function detectMarketRegime(token: TokenData): RegimeAnalysis {
  const m5 = token.priceChange?.m5 || 0;
  const h1 = token.priceChange?.h1 || 0;
  const h6 = token.priceChange?.h6 || 0;
  const h24 = token.priceChange?.h24 || 0;

  const volatility = Math.min(1, (Math.abs(m5) * 4 + Math.abs(h1) * 2 + Math.abs(h6) + Math.abs(h24) * 0.5) / 200);
  const momentum = Math.max(-1, Math.min(1, (m5 * 0.15 + h1 * 0.35 + h6 * 0.30 + h24 * 0.20) / 50));

  const allPositive = m5 >= 0 && h1 >= 0 && h6 >= 0 && h24 >= 0;
  const allNegative = m5 <= 0 && h1 <= 0 && h6 <= 0 && h24 <= 0;
  const signs = [Math.sign(m5), Math.sign(h1), Math.sign(h6), Math.sign(h24)];
  const positiveCount = signs.filter(s => s > 0).length;
  const negativeCount = signs.filter(s => s < 0).length;
  const trendStrength = Math.max(positiveCount, negativeCount) / 4;

  let regime: MarketRegime = 'unknown';
  let confidence = 30;

  if (volatility > 0.7) {
    regime = 'volatile';
    confidence = 50 + volatility * 30;
  } else if (allPositive && h1 > 3) {
    regime = 'trending_up';
    confidence = 50 + trendStrength * 40;
  } else if (allNegative && h1 < -3) {
    regime = 'trending_down';
    confidence = 50 + trendStrength * 40;
  } else if (Math.abs(h1) < 3 && Math.abs(h6) < 5) {
    regime = 'ranging';
    confidence = 60;
  } else if (momentum > 0.2) {
    regime = 'trending_up';
    confidence = 40 + momentum * 30;
  } else if (momentum < -0.2) {
    regime = 'trending_down';
    confidence = 40 + Math.abs(momentum) * 30;
  } else {
    regime = 'ranging';
    confidence = 40;
  }

  return { regime, confidence: Math.min(95, confidence), volatility, momentum, trendStrength };
}

// ─── Multi-Timeframe Signal Analysis ──────────────────────────────

export interface MultiTimeframeSignal {
  direction: 'bullish' | 'bearish' | 'neutral';
  strength: number;
  alignment: number;
  shortTermBias: number;
  mediumTermBias: number;
  longTermBias: number;
  volumeConfirmation: boolean;
  buyPressure: number;
}

export function analyzeMultiTimeframe(token: TokenData): MultiTimeframeSignal {
  const m5 = token.priceChange?.m5 || 0;
  const h1 = token.priceChange?.h1 || 0;
  const h6 = token.priceChange?.h6 || 0;
  const h24 = token.priceChange?.h24 || 0;

  const shortTermBias = Math.max(-1, Math.min(1, m5 / 20));
  const mediumTermBias = Math.max(-1, Math.min(1, h1 / 30));
  const longTermBias = Math.max(-1, Math.min(1, (h6 + h24) / 80));

  const biases = [shortTermBias, mediumTermBias, longTermBias];
  const avgBias = biases.reduce((s, b) => s + b, 0) / 3;
  const alignment = 1 - (biases.reduce((s, b) => s + Math.abs(b - avgBias), 0) / 3);

  const vol1 = token.volume?.h1 || 0;
  const vol24 = token.volume?.h24 || 0;
  const avgHourlyVol = vol24 / 24;
  const volumeConfirmation = vol1 > avgHourlyVol * 1.3;

  const h1Txns = token.txns?.h1;
  let buyPressure = 0.5;
  if (h1Txns && (h1Txns.buys + h1Txns.sells) > 0) {
    buyPressure = h1Txns.buys / (h1Txns.buys + h1Txns.sells);
  }

  const rawStrength = Math.abs(avgBias) * 50 + alignment * 30 + (volumeConfirmation ? 15 : 0) + (buyPressure > 0.6 ? 10 : 0);
  const strength = Math.min(100, rawStrength);

  let direction: 'bullish' | 'bearish' | 'neutral' = 'neutral';
  if (avgBias > 0.15 && strength > 30) direction = 'bullish';
  else if (avgBias < -0.15 && strength > 30) direction = 'bearish';

  return { direction, strength, alignment, shortTermBias, mediumTermBias, longTermBias, volumeConfirmation, buyPressure };
}

// ─── Confidence-Based Position Sizing ─────────────────────────────

export interface PositionSizeResult {
  sizeUSD: number;
  sizePercent: number;
  reason: string;
  riskLevel: 'low' | 'medium' | 'high';
}

export function calculatePositionSize(
  confidence: number,
  regime: RegimeAnalysis,
  agent: AgentConfig,
  signal: MultiTimeframeSignal,
): PositionSizeResult {
  const riskMult = agent.risk_tolerance === 'aggressive' ? 1.6 : agent.risk_tolerance === 'conservative' ? 0.5 : 1.0;

  const confidenceFactor = Math.max(0.05, Math.min(0.20, (confidence - 30) / 350));

  let regimeMultiplier = 1.0;
  switch (regime.regime) {
    case 'trending_up': regimeMultiplier = 1.2; break;
    case 'trending_down': regimeMultiplier = 0.5; break;
    case 'volatile': regimeMultiplier = 0.6; break;
    case 'ranging': regimeMultiplier = 0.8; break;
    default: regimeMultiplier = 0.7;
  }

  const alignmentBonus = signal.alignment > 0.7 ? 1.15 : 1.0;
  const volumeBonus = signal.volumeConfirmation ? 1.1 : 0.9;

  let sizePercent = confidenceFactor * riskMult * regimeMultiplier * alignmentBonus * volumeBonus;
  sizePercent = Math.max(0.02, Math.min(0.25, sizePercent));

  const maxSize = Math.min(agent.max_position_size, agent.current_balance * 0.3);
  let sizeUSD = Math.min(maxSize, agent.current_balance * sizePercent);
  sizeUSD = Math.round(sizeUSD * 100) / 100;

  let riskLevel: 'low' | 'medium' | 'high' = 'medium';
  if (sizePercent < 0.08) riskLevel = 'low';
  else if (sizePercent > 0.15) riskLevel = 'high';

  const reason = `${(sizePercent * 100).toFixed(1)}% of balance (conf=${confidence.toFixed(0)}, regime=${regime.regime}, align=${signal.alignment.toFixed(2)})`;

  return { sizeUSD, sizePercent, reason, riskLevel };
}

// ─── Adaptive Stop-Loss / Take-Profit ─────────────────────────────

export interface StopLevels {
  stopLoss: number;
  takeProfit: number;
  trailingStopPct: number | null;
  partialTakeProfitPct: number | null;
  reason: string;
}

export function calculateAdaptiveStopLevels(
  entryPrice: number,
  confidence: number,
  regime: RegimeAnalysis,
  agent: AgentConfig,
): StopLevels {
  const riskMult = agent.risk_tolerance === 'aggressive' ? 1.5 : agent.risk_tolerance === 'conservative' ? 0.6 : 1.0;

  let baseSLPct: number;
  let baseTPPct: number;

  switch (regime.regime) {
    case 'trending_up': baseSLPct = 0.10; baseTPPct = 0.50; break;
    case 'trending_down': baseSLPct = 0.08; baseTPPct = 0.20; break;
    case 'volatile': baseSLPct = 0.15; baseTPPct = 0.35; break;
    case 'ranging': baseSLPct = 0.08; baseTPPct = 0.18; break;
    default: baseSLPct = 0.12; baseTPPct = 0.30;
  }

  const volAdj = 1 + regime.volatility * 0.5;
  baseSLPct *= volAdj;
  baseTPPct *= volAdj;
  baseSLPct *= riskMult;
  baseTPPct *= riskMult;

  const confFactor = 0.8 + (confidence / 100) * 0.4;
  baseSLPct *= confFactor;
  baseTPPct *= confFactor;

  baseSLPct = Math.max(0.05, Math.min(0.25, baseSLPct));
  baseTPPct = Math.max(0.10, Math.min(1.00, baseTPPct));

  const stopLoss = entryPrice * (1 - baseSLPct);
  const takeProfit = entryPrice * (1 + baseTPPct);

  let trailingStopPct: number | null = null;
  if (regime.regime === 'trending_up' && confidence > 60) {
    trailingStopPct = baseSLPct * 0.8;
  }

  let partialTakeProfitPct: number | null = null;
  if (baseTPPct > 0.25 && confidence > 50) {
    partialTakeProfitPct = baseTPPct * 0.6;
  }

  const reason = `SL=${(baseSLPct * 100).toFixed(1)}% TP=${(baseTPPct * 100).toFixed(1)}% (regime=${regime.regime}, vol=${regime.volatility.toFixed(2)})`;

  return { stopLoss, takeProfit, trailingStopPct, partialTakeProfitPct, reason };
}

// ─── Enhanced Entry Signal Scoring ────────────────────────────────

export interface EnhancedEntrySignal {
  shouldEnter: boolean;
  confidence: number;
  adjustedAmount: number;
  stopLevels: StopLevels;
  regime: RegimeAnalysis;
  mtfSignal: MultiTimeframeSignal;
  reasons: string[];
  warnings: string[];
}

export function enhancedEntryAnalysis(
  token: TokenData,
  security: SecurityInfo,
  agent: AgentConfig,
  strategyConfidence: number,
  strategyAmount: number,
): EnhancedEntrySignal {
  const regime = detectMarketRegime(token);
  const mtfSignal = analyzeMultiTimeframe(token);
  const reasons: string[] = [];
  const warnings: string[] = [];

  let adjustedConfidence = strategyConfidence;

  if (mtfSignal.direction === 'bullish' && mtfSignal.alignment > 0.6) {
    adjustedConfidence += 10;
    reasons.push(`MTF aligned bullish (${(mtfSignal.alignment * 100).toFixed(0)}%)`);
  } else if (mtfSignal.direction === 'bearish') {
    adjustedConfidence -= 15;
    warnings.push('MTF signals bearish — conflicting with entry');
  }

  if (mtfSignal.volumeConfirmation) {
    adjustedConfidence += 5;
    reasons.push('Volume confirms');
  } else {
    adjustedConfidence -= 5;
    warnings.push('Low volume');
  }

  if (mtfSignal.buyPressure > 0.65) {
    adjustedConfidence += 5;
    reasons.push(`Buy pressure ${(mtfSignal.buyPressure * 100).toFixed(0)}%`);
  } else if (mtfSignal.buyPressure < 0.4) {
    adjustedConfidence -= 10;
    warnings.push('Weak buy pressure');
  }

  if (regime.regime === 'trending_down') {
    adjustedConfidence -= 15;
    warnings.push('Downtrend regime');
  } else if (regime.regime === 'volatile') {
    adjustedConfidence -= 5;
    warnings.push('High volatility');
  } else if (regime.regime === 'trending_up') {
    adjustedConfidence += 5;
    reasons.push('Uptrend regime');
  }

  if (security.overallScore === 'warning') {
    adjustedConfidence -= 5;
    warnings.push('Security: warning');
  }

  adjustedConfidence = Math.max(0, Math.min(100, adjustedConfidence));

  const posSize = calculatePositionSize(adjustedConfidence, regime, agent, mtfSignal);
  const adjustedAmount = Math.min(posSize.sizeUSD, strategyAmount * 1.2);

  const entryPrice = parseFloat(token.priceUsd || '0');
  const stopLevels = calculateAdaptiveStopLevels(entryPrice, adjustedConfidence, regime, agent);

  const shouldEnter = adjustedConfidence >= 45 && adjustedAmount >= 2 && mtfSignal.direction !== 'bearish';

  return { shouldEnter, confidence: adjustedConfidence, adjustedAmount, stopLevels, regime, mtfSignal, reasons, warnings };
}

// ─── Enhanced Exit Signal ─────────────────────────────────────────

export interface EnhancedExitSignal {
  shouldExit: boolean;
  urgency: 'low' | 'medium' | 'high' | 'critical';
  exitPercent: number;
  reason: string;
}

export function enhancedExitAnalysis(
  position: PositionData,
  token: TokenData,
  agent: AgentConfig,
): EnhancedExitSignal {
  const regime = detectMarketRegime(token);
  const mtf = analyzeMultiTimeframe(token);
  const pnlPct = position.unrealized_pnl_pct;
  const holdTimeMs = Date.now() - new Date(position.opened_at).getTime();
  const holdTimeHours = holdTimeMs / 3600000;

  if (pnlPct < -25) {
    return { shouldExit: true, urgency: 'critical', exitPercent: 100, reason: `Emergency stop: ${pnlPct.toFixed(1)}% loss` };
  }

  if (regime.regime === 'trending_down' && pnlPct > 5) {
    return { shouldExit: true, urgency: 'high', exitPercent: 75, reason: `Regime shift to downtrend, locking ${pnlPct.toFixed(1)}% profit` };
  }

  if (mtf.direction === 'bearish' && pnlPct > 10 && mtf.strength > 40) {
    return { shouldExit: true, urgency: 'medium', exitPercent: 50, reason: `MTF bearish reversal, partial exit at +${pnlPct.toFixed(1)}%` };
  }

  if (holdTimeHours > 24 && pnlPct > 0 && pnlPct < 10) {
    return { shouldExit: true, urgency: 'low', exitPercent: 100, reason: `Stale position (${holdTimeHours.toFixed(0)}h), taking +${pnlPct.toFixed(1)}%` };
  }

  if (!mtf.volumeConfirmation && pnlPct > 15 && mtf.buyPressure < 0.45) {
    return { shouldExit: true, urgency: 'medium', exitPercent: 50, reason: `Volume drying up, securing partial profit at +${pnlPct.toFixed(1)}%` };
  }

  if (regime.volatility > 0.7 && pnlPct < -10) {
    return { shouldExit: true, urgency: 'high', exitPercent: 100, reason: `High volatility + ${pnlPct.toFixed(1)}% loss — cutting` };
  }

  return { shouldExit: false, urgency: 'low', exitPercent: 0, reason: 'Holding' };
}
