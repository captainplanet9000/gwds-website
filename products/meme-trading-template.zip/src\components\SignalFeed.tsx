'use client';

import { Brain, Eye, Zap, BarChart3 } from 'lucide-react';
import { s, colors } from '@/lib/meme-coins-styles';

interface Thought {
  id: string;
  agent_id: string;
  thought_type: string;
  content: string;
  confidence: number | null;
  created_at: string;
}

interface SignalFeedProps {
  thoughts: Thought[];
  agentNames?: Record<string, string>;
  maxItems?: number;
}

const THOUGHT_ICONS: Record<string, { icon: any; color: string }> = {
  observation: { icon: Eye, color: '#3b82f6' },
  analysis: { icon: BarChart3, color: '#a855f7' },
  decision: { icon: Brain, color: '#f59e0b' },
  execution: { icon: Zap, color: '#22c55e' },
};

function timeAgo(dateStr: string): string {
  const diff = Date.now() - new Date(dateStr).getTime();
  const mins = Math.floor(diff / 60000);
  if (mins < 1) return 'just now';
  if (mins < 60) return `${mins}m ago`;
  const hours = Math.floor(mins / 60);
  if (hours < 24) return `${hours}h ago`;
  return `${Math.floor(hours / 24)}d ago`;
}

export function SignalFeed({ thoughts, agentNames = {}, maxItems = 20 }: SignalFeedProps) {
  const items = thoughts.slice(0, maxItems);

  if (items.length === 0) {
    return (
      <div style={s.emptyState}>
        <Brain size={48} style={{ margin: '0 auto 12px', opacity: 0.3 }} />
        <p style={{ fontSize: '14px' }}>No signals yet. Start an agent to see its thought process.</p>
      </div>
    );
  }

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '6px' }}>
      {items.map((thought) => {
        const { icon: Icon, color } = THOUGHT_ICONS[thought.thought_type] || THOUGHT_ICONS.observation;
        const agentName = agentNames[thought.agent_id] || thought.agent_id.slice(0, 8);

        return (
          <div key={thought.id} style={s.thoughtBubble}>
            <div style={{ display: 'flex', alignItems: 'flex-start', gap: '10px' }}>
              <div style={{
                width: '28px', height: '28px', borderRadius: '6px',
                background: color + '22', display: 'flex', flexShrink: 0,
                alignItems: 'center', justifyContent: 'center',
              }}>
                <Icon size={14} style={{ color }} />
              </div>
              <div style={{ flex: 1, minWidth: 0 }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '2px' }}>
                  <div style={{ display: 'flex', alignItems: 'center', gap: '6px' }}>
                    <span style={{ fontSize: '11px', fontWeight: 600, color }}>{thought.thought_type}</span>
                    <span style={{ fontSize: '10px', color: colors.muted }}>• {agentName}</span>
                  </div>
                  <div style={{ display: 'flex', alignItems: 'center', gap: '6px' }}>
                    {thought.confidence !== null && (
                      <span style={{
                        fontSize: '10px', fontWeight: 600, padding: '1px 5px',
                        borderRadius: '3px', background: color + '22', color,
                      }}>
                        {thought.confidence.toFixed(0)}%
                      </span>
                    )}
                    <span style={{ fontSize: '10px', color: colors.muted }}>
                      {timeAgo(thought.created_at)}
                    </span>
                  </div>
                </div>
                <div style={{ fontSize: '12px', color: colors.foreground, lineHeight: '1.4', wordBreak: 'break-word' }}>
                  {thought.content}
                </div>
              </div>
            </div>
          </div>
        );
      })}
    </div>
  );
}
