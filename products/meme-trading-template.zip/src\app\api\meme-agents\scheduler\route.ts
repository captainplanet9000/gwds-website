import { NextRequest, NextResponse } from 'next/server';
import { runAgentCycle } from '@/lib/meme-agent-engine';
import * as db from '@/lib/meme-agents-db';

// POST /api/meme-agents/scheduler — Run a trading cycle
// Body: { agentId?: string } — runs specific agent or all active agents
export async function POST(req: NextRequest) {
  try {
    const body = await req.json().catch(() => ({}));
    const { agentId } = body;

    if (agentId) {
      // Run single agent
      const result = await runAgentCycle(agentId);
      return NextResponse.json(result);
    }

    // Run all active agents
    const agents = db.getAllAgents().filter(a => a.status === 'active');
    const results = [];

    for (const agent of agents) {
      try {
        const result = await runAgentCycle(agent.id);
        results.push(result);
      } catch (err: any) {
        results.push({ agentId: agent.id, error: err.message });
      }
    }

    return NextResponse.json({
      agentsRun: results.length,
      results,
      timestamp: new Date().toISOString(),
    });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}

// GET /api/meme-agents/scheduler — Get scheduler status
export async function GET() {
  const agents = db.getAllAgents();
  const active = agents.filter(a => a.status === 'active');

  return NextResponse.json({
    totalAgents: agents.length,
    activeAgents: active.length,
    agents: active.map(a => ({
      id: a.id,
      name: a.name,
      strategy: a.strategy,
      balance: a.current_balance,
      pnl: a.total_pnl,
    })),
  });
}
