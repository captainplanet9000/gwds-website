import { NextRequest, NextResponse } from 'next/server';
import * as db from '@/lib/meme-agents-db';

// GET /api/meme-agents/[id] — Get agent details
export async function GET(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const agent = db.getAgent(id);
  if (!agent) return NextResponse.json({ error: 'Agent not found' }, { status: 404 });

  const positions = db.getAgentPositions(id);
  const trades = db.getAgentTrades(id, 20);
  const thoughts = db.getAgentThoughts(id, 20);

  return NextResponse.json({ agent, positions, trades, thoughts });
}

// PATCH /api/meme-agents/[id] — Update agent
export async function PATCH(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  try {
    const body = await req.json();
    const agent = db.updateAgent(id, body);
    if (!agent) return NextResponse.json({ error: 'Agent not found' }, { status: 404 });
    return NextResponse.json(agent);
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}

// DELETE /api/meme-agents/[id] — Delete agent
export async function DELETE(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  db.deleteAgent(id);
  return NextResponse.json({ ok: true });
}
