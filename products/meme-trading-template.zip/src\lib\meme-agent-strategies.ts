// Meme Agent Trading Strategies
// 6 battle-tested strategies for autonomous meme token trading

export interface TokenData {
  chainId: string; pairAddress: string; dexId: string;
  baseToken: { address: string; name: string; symbol: string };
  priceUsd: string;
  priceChange: { m5?: number; h1?: number; h6?: number; h24?: number };
  txns: { m5?: { buys: number; sells: number }; h1?: { buys: number; sells: number }; h6?: { buys: number; sells: number }; h24?: { buys: number; sells: number } };
  volume: { h24?: number; h6?: number; h1?: number; m5?: number };
  liquidity: { usd?: number };
  fdv: number; marketCap: number; pairCreatedAt: number;
  boostAmount?: number;
}

export interface AgentConfig {
  risk_tolerance: string; max_position_size: number; min_liquidity: number;
  min_volume: number; max_token_age_hours: number; security_min_score: string;
  current_balance: number; allocated_budget: number; preferred_chains: string[];
}

export interface SecurityInfo {
  overallScore: 'safe' | 'warning' | 'danger' | 'critical';
  details: {
    honeypot: boolean | null; mintable: boolean | null; lpLocked: boolean | null;
    taxInfo: { buyTax: number | null; sellTax: number | null };
    topHolderPct: number | null; contractVerified: boolean | null;
  };
}

export interface PositionData {
  token_address: string; symbol: string; entry_price: number; current_price: number;
  quantity: number; amount_usd: number; unrealized_pnl: number; unrealized_pnl_pct: number;
  stop_loss: number | null; take_profit: number | null; opened_at: string;
}

export interface AnalysisResult {
  scores: { token: TokenData; score: number; reasons: string[] }[];
  summary: string;
}

export interface BuySignal {
  buy: boolean; reason: string; confidence: number; suggestedAmount: number;
}

export interface SellSignal {
  sell: boolean; reason: string; confidence: number;
}

function tokenAgeHours(token: TokenData): number {
  return (Date.now() - (token.pairCreatedAt || 0)) / 3600000;
}

function buySellRatio(txns: any, period: string): number {
  const t = txns?.[period];
  if (!t || (t.buys + t.sells) === 0) return 1;
  return t.buys / (t.sells || 1);
}

function riskMultiplier(risk: string): number {
  return risk === 'aggressive' ? 1.5 : risk === 'conservative' ? 0.5 : 1;
}

function securityPasses(sec: SecurityInfo, minScore: string): boolean {
  const order = ['safe', 'warning', 'danger', 'critical'];
  return order.indexOf(sec.overallScore) <= order.indexOf(minScore);
}

function suggestAmount(agent: AgentConfig, confidence: number): number {
  const base = Math.min(agent.max_position_size, agent.current_balance * 0.15);
  return Math.round(base * (confidence / 100) * riskMultiplier(agent.risk_tolerance) * 100) / 100;
}

// ═══════════════════════════════════════════════════════════════
// Strategy 1: Momentum Surfer
// ═══════════════════════════════════════════════════════════════
export const MomentumSurfer = {
  id: 'momentum_surfer',
  name: 'Momentum Surfer',
  emoji: '🏄',
  color: '#00d4ff',
  getDescription: () => 'Buys tokens with strong upward momentum — high 1h/6h price change, increasing volume, good buy/sell ratio. Sells on momentum reversal.',

  analyzeMarket(tokens: TokenData[], agent: AgentConfig): AnalysisResult {
    const scores = tokens.map(token => {
      let score = 0; const reasons: string[] = [];
      const h1 = token.priceChange?.h1 || 0;
      const h6 = token.priceChange?.h6 || 0;
      if (h1 > 10) { score += 25; reasons.push(`+${h1.toFixed(1)}% 1h momentum`); }
      if (h1 > 30) { score += 15; reasons.push('Strong 1h surge'); }
      if (h6 > 20) { score += 20; reasons.push(`+${h6.toFixed(1)}% 6h trend`); }
      const ratio = buySellRatio(token.txns, 'h1');
      if (ratio > 1.5) { score += 20; reasons.push(`Buy/sell ratio ${ratio.toFixed(1)}`); }
      const vol = token.volume?.h1 || 0;
      if (vol > 50000) { score += 10; reasons.push(`$${(vol/1000).toFixed(0)}K 1h vol`); }
      if ((token.liquidity?.usd || 0) > agent.min_liquidity) { score += 10; reasons.push('Good liquidity'); }
      return { token, score: Math.min(score, 100), reasons };
    }).sort((a, b) => b.score - a.score);
    return { scores, summary: `Analyzed ${tokens.length} tokens for momentum signals` };
  },

  shouldBuy(token: TokenData, sec: SecurityInfo, agent: AgentConfig): BuySignal {
    if (!securityPasses(sec, agent.security_min_score)) return { buy: false, reason: 'Failed security', confidence: 0, suggestedAmount: 0 };
    const h1 = token.priceChange?.h1 || 0;
    const ratio = buySellRatio(token.txns, 'h1');
    if (h1 < 5) return { buy: false, reason: 'Insufficient momentum', confidence: 0, suggestedAmount: 0 };
    if (ratio < 1.2) return { buy: false, reason: 'Weak buy pressure', confidence: 0, suggestedAmount: 0 };
    const confidence = Math.min(90, 30 + h1 * 0.8 + ratio * 10);
    return { buy: true, reason: `Momentum: +${h1.toFixed(1)}% 1h, ${ratio.toFixed(1)}x buy ratio`, confidence, suggestedAmount: suggestAmount(agent, confidence) };
  },

  shouldSell(pos: PositionData, token: TokenData, agent: AgentConfig): SellSignal {
    const h1 = token.priceChange?.h1 || 0;
    if (pos.unrealized_pnl_pct < -15 * riskMultiplier(agent.risk_tolerance)) return { sell: true, reason: `Stop loss hit: ${pos.unrealized_pnl_pct.toFixed(1)}%`, confidence: 95 };
    if (h1 < -5) return { sell: true, reason: `Momentum reversal: ${h1.toFixed(1)}% 1h`, confidence: 80 };
    if (pos.unrealized_pnl_pct > 50) return { sell: true, reason: `Taking profit at +${pos.unrealized_pnl_pct.toFixed(1)}%`, confidence: 70 };
    return { sell: false, reason: 'Momentum holding', confidence: 0 };
  },
};

// ═══════════════════════════════════════════════════════════════
// Strategy 2: New Launch Sniper
// ═══════════════════════════════════════════════════════════════
export const NewLaunchSniper = {
  id: 'new_launch_sniper',
  name: 'New Launch Sniper',
  emoji: '🎯',
  color: '#ff6b9d',
  getDescription: () => 'Focuses on tokens < 2 hours old with growing liquidity. Quick in-and-out trades. High risk, high reward.',

  analyzeMarket(tokens: TokenData[], agent: AgentConfig): AnalysisResult {
    const scores = tokens.map(token => {
      let score = 0; const reasons: string[] = [];
      const age = tokenAgeHours(token);
      if (age < 2) { score += 30; reasons.push(`${age.toFixed(1)}h old — fresh launch`); }
      else if (age < 6) { score += 15; reasons.push(`${age.toFixed(1)}h old`); }
      else { return { token, score: 0, reasons: ['Too old for sniping'] }; }
      const liq = token.liquidity?.usd || 0;
      if (liq > 5000 && liq < 500000) { score += 25; reasons.push(`$${(liq/1000).toFixed(0)}K liquidity`); }
      const m5vol = token.volume?.m5 || 0;
      if (m5vol > 1000) { score += 20; reasons.push(`$${(m5vol/1000).toFixed(1)}K 5m vol`); }
      const ratio = buySellRatio(token.txns, 'm5');
      if (ratio > 2) { score += 20; reasons.push(`${ratio.toFixed(1)}x 5m buy ratio`); }
      if (token.boostAmount && token.boostAmount > 0) { score += 10; reasons.push('Has DEX boost'); }
      return { token, score: Math.min(score, 100), reasons };
    }).sort((a, b) => b.score - a.score);
    return { scores, summary: `Found ${scores.filter(s => s.score > 30).length} new launches worth watching` };
  },

  shouldBuy(token: TokenData, sec: SecurityInfo, agent: AgentConfig): BuySignal {
    const age = tokenAgeHours(token);
    if (age > 4) return { buy: false, reason: 'Token too old', confidence: 0, suggestedAmount: 0 };
    if (sec.details.honeypot) return { buy: false, reason: 'Honeypot detected', confidence: 0, suggestedAmount: 0 };
    const liq = token.liquidity?.usd || 0;
    if (liq < 3000) return { buy: false, reason: 'Liquidity too low', confidence: 0, suggestedAmount: 0 };
    const confidence = Math.min(85, 40 + (liq > 20000 ? 20 : 0) + (buySellRatio(token.txns, 'm5') > 2 ? 20 : 0));
    const amt = suggestAmount(agent, confidence) * 0.6;
    return { buy: true, reason: `New launch: ${age.toFixed(1)}h old, $${(liq/1000).toFixed(0)}K liq`, confidence, suggestedAmount: amt };
  },

  shouldSell(pos: PositionData, token: TokenData, agent: AgentConfig): SellSignal {
    if (pos.unrealized_pnl_pct > 30) return { sell: true, reason: `Quick profit: +${pos.unrealized_pnl_pct.toFixed(1)}%`, confidence: 85 };
    if (pos.unrealized_pnl_pct < -20) return { sell: true, reason: `Cut losses: ${pos.unrealized_pnl_pct.toFixed(1)}%`, confidence: 90 };
    const ageMs = Date.now() - new Date(pos.opened_at).getTime();
    if (ageMs > 3600000) return { sell: true, reason: 'Position too old for snipe (>1h)', confidence: 75 };
    return { sell: false, reason: 'Holding snipe', confidence: 0 };
  },
};

// ═══════════════════════════════════════════════════════════════
// Strategy 3: Smart Money Follower
// ═══════════════════════════════════════════════════════════════
export const SmartMoneyFollower = {
  id: 'smart_money_follower',
  name: 'Smart Money Follower',
  emoji: '🐋',
  color: '#c084fc',
  getDescription: () => 'Tracks high-volume tokens that whales are accumulating. Enters on whale-like volume patterns. Exits when smart money exits.',

  analyzeMarket(tokens: TokenData[], agent: AgentConfig): AnalysisResult {
    const scores = tokens.map(token => {
      let score = 0; const reasons: string[] = [];
      const vol24 = token.volume?.h24 || 0;
      const vol6 = token.volume?.h6 || 0;
      if (vol6 > vol24 * 0.5 && vol6 > 100000) { score += 30; reasons.push('Recent volume spike (whale signal)'); }
      if (vol24 > 500000) { score += 20; reasons.push(`$${(vol24/1000).toFixed(0)}K daily volume`); }
      const liq = token.liquidity?.usd || 0;
      if (liq > 100000) { score += 15; reasons.push(`$${(liq/1000).toFixed(0)}K liquidity`); }
      const h1txns = token.txns?.h1;
      if (h1txns && (h1txns.buys + h1txns.sells) > 0) {
        const avgTxn = (token.volume?.h1 || 0) / (h1txns.buys + h1txns.sells);
        if (avgTxn > 500) { score += 20; reasons.push(`Avg txn $${avgTxn.toFixed(0)} (whale-sized)`); }
      }
      if ((token.priceChange?.h1 || 0) > 5) { score += 10; reasons.push('Price rising with volume'); }
      return { token, score: Math.min(score, 100), reasons };
    }).sort((a, b) => b.score - a.score);
    return { scores, summary: `Identified ${scores.filter(s => s.score > 40).length} whale-activity tokens` };
  },

  shouldBuy(token: TokenData, sec: SecurityInfo, agent: AgentConfig): BuySignal {
    if (!securityPasses(sec, agent.security_min_score)) return { buy: false, reason: 'Failed security', confidence: 0, suggestedAmount: 0 };
    const vol6 = token.volume?.h6 || 0;
    const vol24 = token.volume?.h24 || 0;
    if (vol6 < 50000) return { buy: false, reason: 'Volume too low for whale signal', confidence: 0, suggestedAmount: 0 };
    const volRatio = vol24 > 0 ? vol6 / vol24 : 0;
    if (volRatio < 0.3) return { buy: false, reason: 'No recent volume spike', confidence: 0, suggestedAmount: 0 };
    const confidence = Math.min(85, 40 + volRatio * 40 + ((token.priceChange?.h1 || 0) > 0 ? 10 : 0));
    return { buy: true, reason: `Whale activity: ${(volRatio * 100).toFixed(0)}% of 24h vol in 6h`, confidence, suggestedAmount: suggestAmount(agent, confidence) };
  },

  shouldSell(pos: PositionData, token: TokenData, agent: AgentConfig): SellSignal {
    if (pos.unrealized_pnl_pct < -12) return { sell: true, reason: `Stop loss: ${pos.unrealized_pnl_pct.toFixed(1)}%`, confidence: 90 };
    const sellRatio = buySellRatio(token.txns, 'h1');
    if (sellRatio < 0.5) return { sell: true, reason: 'Whales exiting (high sell ratio)', confidence: 85 };
    if (pos.unrealized_pnl_pct > 40) return { sell: true, reason: `Profit target: +${pos.unrealized_pnl_pct.toFixed(1)}%`, confidence: 75 };
    return { sell: false, reason: 'Smart money still in', confidence: 0 };
  },
};

// ═══════════════════════════════════════════════════════════════
// Strategy 4: Safety First
// ═══════════════════════════════════════════════════════════════
export const SafetyFirst = {
  id: 'safety_first',
  name: 'Safety First',
  emoji: '🛡️',
  color: '#34d399',
  getDescription: () => 'Only trades tokens that pass full security scanning — no honeypots, low tax, verified contracts, locked LP. Conservative allocation.',

  analyzeMarket(tokens: TokenData[], agent: AgentConfig): AnalysisResult {
    const scores = tokens.map(token => {
      let score = 0; const reasons: string[] = [];
      const liq = token.liquidity?.usd || 0;
      if (liq > 50000) { score += 20; reasons.push(`$${(liq/1000).toFixed(0)}K liquidity`); }
      if (liq > 200000) { score += 10; reasons.push('High liquidity'); }
      const age = tokenAgeHours(token);
      if (age > 24) { score += 15; reasons.push(`${(age/24).toFixed(1)}d old — established`); }
      const vol24 = token.volume?.h24 || 0;
      if (vol24 > 100000) { score += 15; reasons.push(`$${(vol24/1000).toFixed(0)}K daily volume`); }
      if ((token.priceChange?.h24 || 0) > 0) { score += 10; reasons.push('Positive 24h trend'); }
      if (token.marketCap > 1000000) { score += 10; reasons.push(`$${(token.marketCap/1e6).toFixed(1)}M mcap`); }
      return { token, score: Math.min(score, 100), reasons };
    }).sort((a, b) => b.score - a.score);
    return { scores, summary: `Found ${scores.filter(s => s.score > 50).length} security-approved candidates` };
  },

  shouldBuy(token: TokenData, sec: SecurityInfo, agent: AgentConfig): BuySignal {
    if (sec.overallScore !== 'safe' && sec.overallScore !== 'warning') return { buy: false, reason: `Security: ${sec.overallScore}`, confidence: 0, suggestedAmount: 0 };
    if (sec.details.honeypot) return { buy: false, reason: 'Honeypot', confidence: 0, suggestedAmount: 0 };
    if (sec.details.mintable) return { buy: false, reason: 'Mintable token', confidence: 0, suggestedAmount: 0 };
    if ((sec.details.taxInfo.buyTax || 0) > 5 || (sec.details.taxInfo.sellTax || 0) > 5) return { buy: false, reason: 'High tax', confidence: 0, suggestedAmount: 0 };
    const liq = token.liquidity?.usd || 0;
    if (liq < 50000) return { buy: false, reason: 'Liquidity too low for safe entry', confidence: 0, suggestedAmount: 0 };
    const confidence = Math.min(80, 50 + (sec.details.lpLocked ? 15 : 0) + (sec.details.contractVerified ? 10 : 0));
    return { buy: true, reason: `Safe token: score=${sec.overallScore}, liq=$${(liq/1000).toFixed(0)}K`, confidence, suggestedAmount: suggestAmount(agent, confidence) * 0.8 };
  },

  shouldSell(pos: PositionData, token: TokenData, agent: AgentConfig): SellSignal {
    if (pos.unrealized_pnl_pct < -10) return { sell: true, reason: `Conservative stop: ${pos.unrealized_pnl_pct.toFixed(1)}%`, confidence: 95 };
    if (pos.unrealized_pnl_pct > 25) return { sell: true, reason: `Taking conservative profit: +${pos.unrealized_pnl_pct.toFixed(1)}%`, confidence: 80 };
    return { sell: false, reason: 'Within safe parameters', confidence: 0 };
  },
};

// ═══════════════════════════════════════════════════════════════
// Strategy 5: Dip Buyer
// ═══════════════════════════════════════════════════════════════
export const DipBuyer = {
  id: 'dip_buyer',
  name: 'Dip Buyer',
  emoji: '📉',
  color: '#fbbf24',
  getDescription: () => 'Watches established meme coins (>7 days old, good liquidity) for significant dips (-20%+ in 24h) and buys the dip. Sells on recovery.',

  analyzeMarket(tokens: TokenData[], agent: AgentConfig): AnalysisResult {
    const scores = tokens.map(token => {
      let score = 0; const reasons: string[] = [];
      const age = tokenAgeHours(token);
      if (age < 168) return { token, score: 0, reasons: ['Too young for dip buying'] };
      const h24 = token.priceChange?.h24 || 0;
      if (h24 < -20) { score += 35; reasons.push(`Down ${h24.toFixed(1)}% — significant dip`); }
      else if (h24 < -10) { score += 15; reasons.push(`Down ${h24.toFixed(1)}% — moderate dip`); }
      else return { token, score: 0, reasons: ['No significant dip'] };
      const liq = token.liquidity?.usd || 0;
      if (liq > 50000) { score += 20; reasons.push(`$${(liq/1000).toFixed(0)}K liquidity`); }
      const vol24 = token.volume?.h24 || 0;
      if (vol24 > 100000) { score += 15; reasons.push('High volume on dip'); }
      if ((token.priceChange?.h1 || 0) > 0) { score += 15; reasons.push('Early recovery signal'); }
      return { token, score: Math.min(score, 100), reasons };
    }).sort((a, b) => b.score - a.score);
    return { scores, summary: `Found ${scores.filter(s => s.score > 30).length} dip buying opportunities` };
  },

  shouldBuy(token: TokenData, sec: SecurityInfo, agent: AgentConfig): BuySignal {
    if (!securityPasses(sec, agent.security_min_score)) return { buy: false, reason: 'Failed security', confidence: 0, suggestedAmount: 0 };
    const h24 = token.priceChange?.h24 || 0;
    if (h24 > -15) return { buy: false, reason: 'Not enough of a dip', confidence: 0, suggestedAmount: 0 };
    const liq = token.liquidity?.usd || 0;
    if (liq < 30000) return { buy: false, reason: 'Low liquidity for dip buy', confidence: 0, suggestedAmount: 0 };
    const confidence = Math.min(85, 40 + Math.abs(h24) * 0.8 + ((token.priceChange?.h1 || 0) > 0 ? 15 : 0));
    return { buy: true, reason: `Dip buy: ${h24.toFixed(1)}% 24h drop, $${(liq/1000).toFixed(0)}K liq`, confidence, suggestedAmount: suggestAmount(agent, confidence) };
  },

  shouldSell(pos: PositionData, token: TokenData, agent: AgentConfig): SellSignal {
    if (pos.unrealized_pnl_pct < -25) return { sell: true, reason: `Deep loss: ${pos.unrealized_pnl_pct.toFixed(1)}%`, confidence: 90 };
    if (pos.unrealized_pnl_pct > 20) return { sell: true, reason: `Recovery target hit: +${pos.unrealized_pnl_pct.toFixed(1)}%`, confidence: 80 };
    return { sell: false, reason: 'Waiting for recovery', confidence: 0 };
  },
};

// ═══════════════════════════════════════════════════════════════
// Strategy 6: Volume Spike Detector
// ═══════════════════════════════════════════════════════════════
export const VolumeSpikeDetector = {
  id: 'volume_spike_detector',
  name: 'Volume Spike Detector',
  emoji: '📊',
  color: '#f472b6',
  getDescription: () => 'Monitors for unusual volume spikes relative to historical average. Enters on volume confirmation with price uptick.',

  analyzeMarket(tokens: TokenData[], agent: AgentConfig): AnalysisResult {
    const scores = tokens.map(token => {
      let score = 0; const reasons: string[] = [];
      const vol1 = token.volume?.h1 || 0;
      const vol24 = token.volume?.h24 || 0;
      const avgHourlyVol = vol24 / 24;
      const spike = avgHourlyVol > 0 ? vol1 / avgHourlyVol : 0;
      if (spike > 5) { score += 35; reasons.push(`${spike.toFixed(1)}x volume spike`); }
      else if (spike > 3) { score += 20; reasons.push(`${spike.toFixed(1)}x above average`); }
      else if (spike > 2) { score += 10; reasons.push(`${spike.toFixed(1)}x volume`); }
      else return { token, score: 0, reasons: ['No volume spike'] };
      if ((token.priceChange?.h1 || 0) > 0) { score += 20; reasons.push('Price rising with volume'); }
      if ((token.liquidity?.usd || 0) > agent.min_liquidity) { score += 15; reasons.push('Adequate liquidity'); }
      if (buySellRatio(token.txns, 'h1') > 1.3) { score += 15; reasons.push('Buy-heavy volume'); }
      return { token, score: Math.min(score, 100), reasons };
    }).sort((a, b) => b.score - a.score);
    return { scores, summary: `Detected ${scores.filter(s => s.score > 30).length} volume spikes` };
  },

  shouldBuy(token: TokenData, sec: SecurityInfo, agent: AgentConfig): BuySignal {
    if (!securityPasses(sec, agent.security_min_score)) return { buy: false, reason: 'Failed security', confidence: 0, suggestedAmount: 0 };
    const vol1 = token.volume?.h1 || 0;
    const vol24 = token.volume?.h24 || 0;
    const spike = vol24 > 0 ? vol1 / (vol24 / 24) : 0;
    if (spike < 2.5) return { buy: false, reason: 'Volume spike insufficient', confidence: 0, suggestedAmount: 0 };
    if ((token.priceChange?.h1 || 0) <= 0) return { buy: false, reason: 'Price not confirming spike', confidence: 0, suggestedAmount: 0 };
    const confidence = Math.min(85, 35 + spike * 5 + ((token.priceChange?.h1 || 0) * 2));
    return { buy: true, reason: `Volume spike ${spike.toFixed(1)}x with price uptick`, confidence, suggestedAmount: suggestAmount(agent, confidence) };
  },

  shouldSell(pos: PositionData, token: TokenData, agent: AgentConfig): SellSignal {
    if (pos.unrealized_pnl_pct < -15) return { sell: true, reason: `Stop loss: ${pos.unrealized_pnl_pct.toFixed(1)}%`, confidence: 90 };
    const vol1 = token.volume?.h1 || 0;
    const vol24 = token.volume?.h24 || 0;
    const spike = vol24 > 0 ? vol1 / (vol24 / 24) : 0;
    if (spike < 1.5 && pos.unrealized_pnl_pct > 5) return { sell: true, reason: `Volume normalizing, locking +${pos.unrealized_pnl_pct.toFixed(1)}%`, confidence: 75 };
    if (pos.unrealized_pnl_pct > 35) return { sell: true, reason: `Profit target: +${pos.unrealized_pnl_pct.toFixed(1)}%`, confidence: 80 };
    return { sell: false, reason: 'Volume still elevated', confidence: 0 };
  },
};

// ═══════════════ Registry
export const STRATEGIES = {
  momentum_surfer: MomentumSurfer,
  new_launch_sniper: NewLaunchSniper,
  smart_money_follower: SmartMoneyFollower,
  safety_first: SafetyFirst,
  dip_buyer: DipBuyer,
  volume_spike_detector: VolumeSpikeDetector,
} as const;

export type StrategyId = keyof typeof STRATEGIES;

export function getStrategy(id: string) {
  return STRATEGIES[id as StrategyId] || MomentumSurfer;
}

export function getAllStrategies() {
  return Object.values(STRATEGIES);
}
