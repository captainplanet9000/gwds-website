// Meme Agent Engine — Autonomous trading cycle
// Sanitized template version — no private keys, uses env vars for wallet management
import * as db from './meme-agents-db';
import { getStrategy, type TokenData, type SecurityInfo } from './meme-agent-strategies';
import {
  enhancedEntryAnalysis,
  enhancedExitAnalysis,
  detectMarketRegime,
  calculateAdaptiveStopLevels,
  type EnhancedEntrySignal,
  type EnhancedExitSignal,
} from './meme-agent-signal-engine';

// ─── SOL/USD price cache ───
const SOL_MINT = 'So11111111111111111111111111111111111111112';
let cachedSolPrice: { price: number; fetchedAt: number } | null = null;
const SOL_PRICE_CACHE_MS = 30_000;

async function getSolUsdPrice(): Promise<number> {
  if (cachedSolPrice && Date.now() - cachedSolPrice.fetchedAt < SOL_PRICE_CACHE_MS) {
    return cachedSolPrice.price;
  }
  try {
    const res = await fetch(`https://api.jup.ag/price/v2?ids=${SOL_MINT}`);
    if (res.ok) {
      const data = await res.json();
      const price = data.data?.[SOL_MINT]?.price;
      if (price && price > 0) {
        cachedSolPrice = { price, fetchedAt: Date.now() };
        return price;
      }
    }
  } catch {}
  return cachedSolPrice?.price || 150;
}

// Circuit breaker state (in-memory, resets on server restart)
const tradeCounters: Record<string, { count: number; hourStart: number }> = {};
const dailyPnL: Record<string, { pnl: number; dayStart: number }> = {};

// ─── Trailing Stop State ──────────────────────────────────────
interface TrailingStopState {
  highWaterMark: number;
  trailingStopPct: number;
  trailingStopPrice: number;
  partialTakeProfitPct: number | null;
  partialExitDone: boolean;
}

const trailingStops: Record<string, TrailingStopState> = {};

function updateTrailingStop(posId: string, currentPrice: number, entryPrice: number, trailingPct: number, partialTPPct: number | null): TrailingStopState {
  if (!trailingStops[posId]) {
    trailingStops[posId] = {
      highWaterMark: currentPrice,
      trailingStopPct: trailingPct,
      trailingStopPrice: currentPrice * (1 - trailingPct),
      partialTakeProfitPct: partialTPPct,
      partialExitDone: false,
    };
  }
  const state = trailingStops[posId];
  if (currentPrice > state.highWaterMark) {
    state.highWaterMark = currentPrice;
    state.trailingStopPrice = currentPrice * (1 - state.trailingStopPct);
  }
  return state;
}

function clearTrailingStop(posId: string) {
  delete trailingStops[posId];
}

// Failed token blocklist
const failedTokens: Record<string, { count: number; lastFail: number }> = {};
const FAIL_THRESHOLD = 3;
const FAIL_COOLDOWN_MS = 3600000;

function isTokenBlocked(tokenAddress: string): boolean {
  const entry = failedTokens[tokenAddress];
  if (!entry) return false;
  if (Date.now() - entry.lastFail > FAIL_COOLDOWN_MS) {
    delete failedTokens[tokenAddress];
    return false;
  }
  return entry.count >= FAIL_THRESHOLD;
}

function recordTokenFailure(tokenAddress: string) {
  if (!failedTokens[tokenAddress]) {
    failedTokens[tokenAddress] = { count: 0, lastFail: 0 };
  }
  failedTokens[tokenAddress].count++;
  failedTokens[tokenAddress].lastFail = Date.now();
}

function checkCircuitBreaker(agentId: string, agent: db.MemeAgent): string | null {
  const now = Date.now();
  if (!tradeCounters[agentId] || now - tradeCounters[agentId].hourStart > 3600000) {
    tradeCounters[agentId] = { count: 0, hourStart: now };
  }
  if (tradeCounters[agentId].count >= 10) {
    return 'Circuit breaker: max 10 trades/hour reached';
  }
  if (!dailyPnL[agentId] || now - dailyPnL[agentId].dayStart > 86400000) {
    dailyPnL[agentId] = { pnl: 0, dayStart: now };
  }
  if (agent.allocated_budget > 0 && dailyPnL[agentId].pnl < -(agent.allocated_budget * 0.2)) {
    db.updateAgent(agentId, { status: 'paused' } as any);
    return 'Circuit breaker: daily loss > 20%, agent auto-paused';
  }
  return null;
}

function recordTrade(agentId: string, pnl: number) {
  if (tradeCounters[agentId]) tradeCounters[agentId].count++;
  if (dailyPnL[agentId]) dailyPnL[agentId].pnl += pnl;
}

export interface CycleResult {
  agentId: string;
  tokensAnalyzed: number;
  buysExecuted: number;
  sellsExecuted: number;
  thoughtsGenerated: number;
  errors: string[];
  duration: number;
}

// Fetch trending tokens from DexScreener
async function fetchDexScreenerTokens(chains: string[]): Promise<TokenData[]> {
  const tokens: TokenData[] = [];
  try {
    const boostRes = await fetch('https://api.dexscreener.com/token-boosts/latest/v1');
    if (boostRes.ok) {
      const boosts = await boostRes.json();
      if (Array.isArray(boosts)) {
        for (const b of boosts.slice(0, 20)) {
          if (chains.length && !chains.some(c => b.chainId?.toLowerCase().includes(c.toLowerCase()))) continue;
          try {
            const pairRes = await fetch(`https://api.dexscreener.com/latest/dex/tokens/${b.tokenAddress}`);
            if (pairRes.ok) {
              const pd = await pairRes.json();
              if (pd.pairs?.[0]) tokens.push({ ...pd.pairs[0], boostAmount: b.amount || 0 });
            }
          } catch {}
        }
      }
    }
  } catch {}

  try {
    const trendRes = await fetch('https://api.dexscreener.com/token-boosts/top/v1');
    if (trendRes.ok) {
      const trends = await trendRes.json();
      if (Array.isArray(trends)) {
        const existing = new Set(tokens.map(t => t.baseToken?.address));
        for (const t of trends.slice(0, 15)) {
          if (existing.has(t.tokenAddress)) continue;
          if (chains.length && !chains.some(c => t.chainId?.toLowerCase().includes(c.toLowerCase()))) continue;
          try {
            const pairRes = await fetch(`https://api.dexscreener.com/latest/dex/tokens/${t.tokenAddress}`);
            if (pairRes.ok) {
              const pd = await pairRes.json();
              if (pd.pairs?.[0]) { tokens.push({ ...pd.pairs[0], boostAmount: t.totalAmount || 0 }); existing.add(pd.pairs[0].baseToken?.address); }
            }
          } catch {}
        }
      }
    }
  } catch {}

  return tokens;
}

// Security scan using heuristics
function quickSecurityScan(token: TokenData): SecurityInfo {
  const age = (Date.now() - (token.pairCreatedAt || 0)) / 3600000;
  const liq = token.liquidity?.usd || 0;

  let score: SecurityInfo['overallScore'] = 'safe';
  const honeypot = false;
  const mintable = age < 1 ? null : false;
  const lpLocked = liq > 100000 ? true : null;
  const contractVerified = age > 24 ? true : null;

  if (age < 1 && liq < 5000) score = 'danger';
  else if (age < 6 && liq < 20000) score = 'warning';
  else if (liq < 10000) score = 'warning';

  return {
    overallScore: score,
    details: { honeypot, mintable, lpLocked, contractVerified, taxInfo: { buyTax: null, sellTax: null }, topHolderPct: null },
  };
}

// Simulated buy
function simulateBuy(agent: db.MemeAgent, token: TokenData, amount: number, reason: string, secScore: string, customStopLoss?: number, customTakeProfit?: number) {
  const price = parseFloat(token.priceUsd || '0');
  if (price <= 0 || amount <= 0) return null;
  if (amount > agent.current_balance) amount = agent.current_balance * 0.9;
  if (amount < 1) return null;

  const slippage = 1 + (Math.random() * 0.015 + 0.005);
  const fillPrice = price * slippage;

  const trade = db.createTrade({
    agent_id: agent.id, token_address: token.baseToken.address, chain_id: token.chainId,
    symbol: token.baseToken.symbol, name: token.baseToken.name, side: 'buy',
    amount_usd: amount, price: fillPrice, quantity: amount / fillPrice,
    pnl: 0, pnl_pct: 0, entry_reason: reason, exit_reason: '', security_score: secScore,
  });

  const riskMult = agent.risk_tolerance === 'aggressive' ? 1.5 : agent.risk_tolerance === 'conservative' ? 0.6 : 1;
  const stopLoss = customStopLoss ?? fillPrice * (1 - 0.15 * riskMult);
  const takeProfit = customTakeProfit ?? fillPrice * (1 + 0.4 * riskMult);
  const position = db.createPosition({
    agent_id: agent.id, token_address: token.baseToken.address, chain_id: token.chainId,
    symbol: token.baseToken.symbol, name: token.baseToken.name,
    entry_price: fillPrice, current_price: fillPrice,
    quantity: amount / fillPrice, amount_usd: amount,
    unrealized_pnl: 0, unrealized_pnl_pct: 0,
    stop_loss: stopLoss, take_profit: takeProfit,
  });

  db.updateAgent(agent.id, {
    current_balance: agent.current_balance - amount,
    total_trades: agent.total_trades + 1,
  } as any);

  return { trade, position };
}

// Simulated sell
function simulateSell(agent: db.MemeAgent, position: db.MemeAgentPosition, token: TokenData, reason: string) {
  const price = parseFloat(token.priceUsd || '0');
  if (price <= 0) return null;

  const slippage = 1 - (Math.random() * 0.015 + 0.005);
  const fillPrice = price * slippage;
  const proceeds = position.quantity * fillPrice;
  const pnl = proceeds - position.amount_usd;
  const pnlPct = (pnl / position.amount_usd) * 100;

  const trade = db.createTrade({
    agent_id: agent.id, token_address: position.token_address, chain_id: position.chain_id,
    symbol: position.symbol, name: position.name, side: 'sell',
    amount_usd: proceeds, price: fillPrice, quantity: position.quantity,
    pnl, pnl_pct: pnlPct, entry_reason: '', exit_reason: reason, security_score: '',
  });

  const wins = pnl > 0 ? 1 : 0;
  const newTotalTrades = agent.total_trades + 1;
  const oldWins = Math.round(agent.win_rate * agent.total_trades / 100);
  const newWinRate = newTotalTrades > 0 ? ((oldWins + wins) / newTotalTrades) * 100 : 0;

  db.updateAgent(agent.id, {
    current_balance: agent.current_balance + proceeds,
    total_pnl: agent.total_pnl + pnl,
    total_trades: newTotalTrades,
    win_rate: newWinRate,
  } as any);

  db.deletePosition(position.id);
  return trade;
}

// Simulated partial sell
function simulatePartialSell(agent: db.MemeAgent, position: db.MemeAgentPosition, token: TokenData, reason: string, exitPercent: number) {
  const price = parseFloat(token.priceUsd || '0');
  if (price <= 0 || exitPercent <= 0 || exitPercent > 100) return null;

  const fraction = exitPercent / 100;
  const sellQty = position.quantity * fraction;
  const sellAmountUsd = position.amount_usd * fraction;

  const slippage = 1 - (Math.random() * 0.015 + 0.005);
  const fillPrice = price * slippage;
  const proceeds = sellQty * fillPrice;
  const pnl = proceeds - sellAmountUsd;
  const pnlPct = (pnl / sellAmountUsd) * 100;

  const trade = db.createTrade({
    agent_id: agent.id, token_address: position.token_address, chain_id: position.chain_id,
    symbol: position.symbol, name: position.name, side: 'sell',
    amount_usd: proceeds, price: fillPrice, quantity: sellQty,
    pnl, pnl_pct: pnlPct, entry_reason: '', exit_reason: `${reason} (${exitPercent}% partial)`, security_score: '',
  });

  const wins = pnl > 0 ? 1 : 0;
  const newTotalTrades = agent.total_trades + 1;
  const oldWins = Math.round(agent.win_rate * agent.total_trades / 100);
  const newWinRate = newTotalTrades > 0 ? ((oldWins + wins) / newTotalTrades) * 100 : 0;

  db.updateAgent(agent.id, {
    current_balance: agent.current_balance + proceeds,
    total_pnl: agent.total_pnl + pnl,
    total_trades: newTotalTrades,
    win_rate: newWinRate,
  } as any);

  const remainingQty = position.quantity - sellQty;
  const remainingAmountUsd = position.amount_usd - sellAmountUsd;
  db.updatePosition(position.id, {
    quantity: remainingQty,
    amount_usd: remainingAmountUsd,
    current_price: fillPrice,
    unrealized_pnl: (fillPrice - position.entry_price) * remainingQty,
    unrealized_pnl_pct: ((fillPrice - position.entry_price) / position.entry_price) * 100,
  });

  return trade;
}

export async function runAgentCycle(agentId: string): Promise<CycleResult> {
  const start = Date.now();
  const result: CycleResult = { agentId, tokensAnalyzed: 0, buysExecuted: 0, sellsExecuted: 0, thoughtsGenerated: 0, errors: [], duration: 0 };

  const agent = db.getAgent(agentId);
  if (!agent) { result.errors.push('Agent not found'); return result; }
  if (agent.status !== 'active') { result.errors.push(`Agent is ${agent.status}`); return result; }

  const strategy = getStrategy(agent.strategy);

  // Circuit breaker
  const cbError = checkCircuitBreaker(agentId, agent);
  if (cbError) {
    db.createThought({ agent_id: agentId, thought_type: 'observation', content: `🛑 ${cbError}` });
    result.errors.push(cbError);
    result.duration = Date.now() - start;
    return result;
  }

  // Step 1: Fetch market data
  db.createThought({ agent_id: agentId, thought_type: 'observation', content: `Starting cycle. Strategy: ${strategy.name}. Balance: $${agent.current_balance.toFixed(2)}` });
  result.thoughtsGenerated++;

  let tokens: TokenData[] = [];
  try {
    tokens = await fetchDexScreenerTokens(agent.preferred_chains);
    db.createThought({ agent_id: agentId, thought_type: 'observation', content: `Fetched ${tokens.length} tokens from DexScreener`, market_context: { tokenCount: tokens.length, chains: agent.preferred_chains } });
    result.thoughtsGenerated++;
  } catch (err: any) {
    result.errors.push(`Fetch error: ${err.message}`);
    result.duration = Date.now() - start;
    return result;
  }

  result.tokensAnalyzed = tokens.length;
  if (tokens.length === 0) {
    result.duration = Date.now() - start;
    return result;
  }

  // Step 2: Analysis
  const agentConfig = {
    risk_tolerance: agent.risk_tolerance, max_position_size: agent.max_position_size,
    min_liquidity: agent.min_liquidity, min_volume: agent.min_volume,
    max_token_age_hours: agent.max_token_age_hours, security_min_score: agent.security_min_score,
    current_balance: agent.current_balance, allocated_budget: agent.allocated_budget,
    preferred_chains: agent.preferred_chains,
  };

  const analysis = strategy.analyzeMarket(tokens, agentConfig);
  const topCandidates = analysis.scores.filter(s => s.score > 30).slice(0, 5);

  db.createThought({
    agent_id: agentId, thought_type: 'analysis',
    content: `${analysis.summary}. Top candidates: ${topCandidates.map(c => `${c.token.baseToken?.symbol} (${c.score}pts)`).join(', ') || 'none'}`,
    confidence: topCandidates.length > 0 ? topCandidates[0].score : 10,
    market_context: { candidateCount: topCandidates.length },
  });
  result.thoughtsGenerated++;

  // Step 3: Check existing positions for sell signals
  const positions = db.getAgentPositions(agentId);
  for (const pos of positions) {
    const matchingToken = tokens.find(t => t.baseToken?.address === pos.token_address);
    if (matchingToken) {
      const currentPrice = parseFloat(matchingToken.priceUsd || '0');
      if (currentPrice > 0) {
        const pnl = (currentPrice - pos.entry_price) * pos.quantity;
        const pnlPct = ((currentPrice - pos.entry_price) / pos.entry_price) * 100;
        db.updatePosition(pos.id, { current_price: currentPrice, unrealized_pnl: pnl, unrealized_pnl_pct: pnlPct });

        const posData = { ...pos, current_price: currentPrice, unrealized_pnl: pnl, unrealized_pnl_pct: pnlPct };

        // Trailing stop management
        const posRegime = detectMarketRegime(matchingToken);
        const adaptiveStops = calculateAdaptiveStopLevels(pos.entry_price, 70, posRegime, agentConfig);

        let trailingTriggered = false;
        if (adaptiveStops.trailingStopPct && pnlPct > 5) {
          const tsState = updateTrailingStop(pos.id, currentPrice, pos.entry_price, adaptiveStops.trailingStopPct, adaptiveStops.partialTakeProfitPct);

          if (currentPrice <= tsState.trailingStopPrice) {
            trailingTriggered = true;
            const freshAgent = db.getAgent(agentId)!;
            const sellTrade = simulateSell(freshAgent, pos, matchingToken, `Trailing stop hit (HWM: $${tsState.highWaterMark.toFixed(6)})`);
            if (sellTrade) {
              result.sellsExecuted++;
              clearTrailingStop(pos.id);
            }
            continue;
          }

          // Partial exit at partial TP level
          if (!tsState.partialExitDone && tsState.partialTakeProfitPct && pnlPct >= tsState.partialTakeProfitPct * 100) {
            tsState.partialExitDone = true;
            const freshAgent = db.getAgent(agentId)!;
            const partialTrade = simulatePartialSell(freshAgent, pos, matchingToken, `Partial TP at +${pnlPct.toFixed(1)}%`, 50);
            if (partialTrade) {
              result.sellsExecuted++;
              db.updatePosition(pos.id, { stop_loss: pos.entry_price });
            }
            continue;
          }
        }

        // Regular exit analysis
        if (!trailingTriggered) {
          const sellSignal = strategy.shouldSell(posData, matchingToken, agentConfig);
          const enhancedExit: EnhancedExitSignal = enhancedExitAnalysis(posData, matchingToken, agentConfig);
          const shouldSell = sellSignal.sell || enhancedExit.shouldExit;
          const exitReason = sellSignal.sell ? sellSignal.reason : enhancedExit.reason;
          const exitPercent = enhancedExit.exitPercent > 0 && enhancedExit.exitPercent < 100 && !sellSignal.sell ? enhancedExit.exitPercent : 100;

          if (shouldSell) {
            const freshAgent = db.getAgent(agentId)!;
            if (exitPercent < 100) {
              const partialTrade = simulatePartialSell(freshAgent, pos, matchingToken, exitReason, exitPercent);
              if (partialTrade) result.sellsExecuted++;
            } else {
              const sellTrade = simulateSell(freshAgent, pos, matchingToken, exitReason);
              if (sellTrade) {
                result.sellsExecuted++;
                clearTrailingStop(pos.id);
              }
            }
          }
        }
      }
    }
  }

  // Step 4: Buy signals for top candidates
  const currentPositions = db.getAgentPositions(agentId);
  const positionTokens = new Set(currentPositions.map(p => p.token_address));
  const freshAgent = db.getAgent(agentId)!;
  const maxPositions = freshAgent.risk_tolerance === 'aggressive' ? 5 : freshAgent.risk_tolerance === 'conservative' ? 2 : 3;

  for (const candidate of topCandidates) {
    if (currentPositions.length >= maxPositions) break;
    if (positionTokens.has(candidate.token.baseToken?.address)) continue;
    if (freshAgent.current_balance < 5) break;

    const secScan = quickSecurityScan(candidate.token);
    const buySignal = strategy.shouldBuy(candidate.token, secScan, agentConfig);

    if (buySignal.buy && buySignal.confidence > 40) {
      if (isTokenBlocked(candidate.token.baseToken.address)) continue;

      const enhancedSignal: EnhancedEntrySignal = enhancedEntryAnalysis(
        candidate.token, secScan, agentConfig, buySignal.confidence, buySignal.suggestedAmount
      );

      if (!enhancedSignal.shouldEnter) continue;

      const latestAgent = db.getAgent(agentId)!;
      const buyResult = simulateBuy(
        latestAgent, candidate.token, enhancedSignal.adjustedAmount,
        buySignal.reason, secScan.overallScore,
        enhancedSignal.stopLevels.stopLoss, enhancedSignal.stopLevels.takeProfit
      );
      if (buyResult) {
        result.buysExecuted++;
        positionTokens.add(candidate.token.baseToken?.address);
        db.createThought({
          agent_id: agentId, thought_type: 'execution',
          content: `Bought ${candidate.token.baseToken?.symbol} — $${enhancedSignal.adjustedAmount.toFixed(2)} | Regime: ${enhancedSignal.regime.regime}`,
          confidence: enhancedSignal.confidence,
        });
        result.thoughtsGenerated++;
      }
    }
  }

  result.duration = Date.now() - start;
  db.createThought({
    agent_id: agentId, thought_type: 'observation',
    content: `Cycle complete in ${(result.duration/1000).toFixed(1)}s — ${result.buysExecuted} buys, ${result.sellsExecuted} sells, ${result.tokensAnalyzed} analyzed`,
  });
  result.thoughtsGenerated++;

  return result;
}

export function getAgentStatus(agentId: string) {
  const agent = db.getAgent(agentId);
  if (!agent) return null;
  const positions = db.getAgentPositions(agentId);
  const recentThoughts = db.getAgentThoughts(agentId, 5);
  return { agent, positions, recentThoughts, openPositionCount: positions.length };
}
