#!/usr/bin/env node

import { createInterface } from 'readline';
import { writeFileSync, existsSync } from 'fs';

const rl = createInterface({ input: process.stdin, output: process.stdout });
const ask = (q) => new Promise((res) => rl.question(q, res));

console.log('\n🧠 Second Brain Template — Setup\n');
console.log('This wizard creates your .env.local file.\n');

async function main() {
  if (existsSync('.env.local')) {
    const overwrite = await ask('.env.local already exists. Overwrite? (y/N): ');
    if (overwrite.toLowerCase() !== 'y') {
      console.log('Setup cancelled.');
      rl.close();
      return;
    }
  }

  console.log('\nNo environment variables required for the base template!');
  console.log('The app uses local JSON files for tasks and pins,');
  console.log('and local markdown files in content/ for documents.\n');

  const port = await ask('Dev server port (default: 3333): ');

  let env = '# Second Brain Template\n';
  env += `# Dev server port: ${port || '3333'}\n`;

  writeFileSync('.env.local', env);

  console.log('\n✅ .env.local created!');
  console.log('\nNext steps:');
  console.log('  npm install');
  console.log('  npm run dev');
  console.log(`\nOpen http://localhost:${port || '3333'} in your browser.`);
  console.log('\nAdd markdown files to content/notes/ to populate your knowledge base.');
  console.log('Use the PARA folders: projects/, areas/, resources/, archive/\n');

  rl.close();
}

main().catch((e) => { console.error(e); rl.close(); });
