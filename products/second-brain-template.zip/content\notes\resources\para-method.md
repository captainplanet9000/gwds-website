# The PARA Method

PARA stands for Projects, Areas, Resources, and Archive.

## Projects
Short-term efforts with a clear goal and deadline.

## Areas
Long-term responsibilities with standards to maintain.

## Resources
Topics of ongoing interest — reference material.

## Archive
Completed or inactive items from the other three categories.
