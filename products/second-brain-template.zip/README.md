# 🧠 Second Brain Template

A PARA-organized personal knowledge management system built with Next.js 15, React 19, and Tailwind CSS 4.

Zero external dependencies for data storage — everything runs on local JSON and Markdown files. No database setup required.

![Dark Theme](https://img.shields.io/badge/theme-dark-1a1a2e) ![Next.js 15](https://img.shields.io/badge/Next.js-15-black) ![React 19](https://img.shields.io/badge/React-19-61dafb) ![Tailwind 4](https://img.shields.io/badge/Tailwind-4-38bdf8)

## Features

### 📄 PARA Document System
Organize your knowledge using the **Projects, Areas, Resources, Archive** method. Write in Markdown with full syntax highlighting, frontmatter support, and a tree-based sidebar navigation.

### 📋 Kanban Task Board
Drag-and-drop task management with four columns: Backlog → In Progress → Review → Done. Priority levels, tags, and inline editing.

### 📌 Pinboard
Quick-capture sticky notes with color coding, tags, pin-to-top, and archive functionality. Think of it as your digital corkboard.

### 🔍 Full-Text Search
Instant search across all documents, tasks, and pins. Keyboard shortcut (⌘K / Ctrl+K) for quick access.

### ⏳ Activity Timeline
Chronological feed of all activity — document edits, task changes, journal entries — grouped by day.

### 🚀 Projects Overview
PARA category breakdown with document counts, word counts, and quick navigation to each category's documents.

### 📱 Mobile Responsive
Hamburger menu navigation, stacked layouts, and touch-friendly interactions on every screen.

## Quick Start

```bash
# Install dependencies
npm install

# Run setup wizard (optional)
node setup.mjs

# Start dev server
npm run dev
```

Open [http://localhost:3333](http://localhost:3333) in your browser.

## Project Structure

```
second-brain-template/
├── content/
│   ├── notes/
│   │   ├── projects/     # Active projects with deadlines
│   │   ├── areas/        # Ongoing responsibilities
│   │   ├── resources/    # Reference material
│   │   └── archive/      # Completed/inactive items
│   ├── memory/           # Journal entries (YYYY-MM-DD.md)
│   └── MEMORY.md         # Long-term memory file
├── data/
│   ├── tasks.json        # Kanban board data
│   └── pins.json         # Pinboard data
├── src/
│   ├── app/              # Next.js App Router pages
│   │   ├── api/          # API routes (tasks, pins, documents, search, timeline)
│   │   ├── tasks/        # Kanban board page
│   │   ├── documents/    # Document viewer/editor
│   │   ├── pinboard/     # Quick capture pins
│   │   ├── search/       # Full-text search
│   │   ├── timeline/     # Activity feed
│   │   └── projects/     # PARA overview
│   ├── components/
│   │   └── Nav.tsx       # Top navigation bar
│   └── lib/
│       └── documents.ts  # Document reading/parsing utilities
├── package.json
├── setup.mjs             # Interactive setup wizard
└── README.md
```

## Adding Content

### Documents
Drop `.md` files into `content/notes/` and its PARA subdirectories. They'll appear automatically in the sidebar and search results.

```markdown
---
title: My Document Title
---

# My Document

Content goes here...
```

### Journal Entries
Create files named `YYYY-MM-DD.md` in `content/memory/` for journal entries. They show up in the Timeline and Documents views.

### Tasks
Create tasks through the UI — they're stored in `data/tasks.json`. Drag cards between columns to update status.

### Pins
Quick-capture ideas through the Pinboard UI. Color-code them, add tags, pin important ones to the top.

## Tech Stack

- **Next.js 15** — App Router, Server Components, API Routes
- **React 19** — Latest React with server components
- **Tailwind CSS 4** — Utility-first CSS with oklch color tokens
- **gray-matter** — Markdown frontmatter parsing
- **highlight.js** — Code syntax highlighting
- **TypeScript** — Full type safety

## Customization

### Theming
Edit CSS custom properties in `src/app/globals.css`. The design uses oklch color space for perceptually uniform colors.

### Adding Pages
Create new routes in `src/app/`. The navigation links are defined in `src/components/Nav.tsx`.

### Data Storage
The template uses local files by default. To switch to a database (e.g., Supabase), modify the API routes in `src/app/api/`.

## License

Commercial single-developer license. See [LICENSE.md](./LICENSE.md) for details.
