# Example Project

This is a sample project document. Replace it with your own.

## Goals
- Define project scope
- Set milestones
- Track deliverables

## Status
Currently in planning phase.
