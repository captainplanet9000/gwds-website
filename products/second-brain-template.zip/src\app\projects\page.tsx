'use client';

import { useEffect, useState, useMemo } from 'react';
import Link from 'next/link';

interface DocMeta { title: string; slug: string; category: string; categoryLabel: string; modified: string; wordCount: number; }

const PARA = [
  { key: 'projects', icon: '🚀', label: 'Projects', desc: 'Active work with deadlines and deliverables' },
  { key: 'areas', icon: '🔄', label: 'Areas', desc: 'Ongoing responsibilities to maintain' },
  { key: 'resources', icon: '📚', label: 'Resources', desc: 'Reference material and knowledge' },
  { key: 'archive', icon: '📦', label: 'Archive', desc: 'Completed or inactive items' },
];

export default function ProjectsPage() {
  const [docs, setDocs] = useState<DocMeta[]>([]);
  const [selected, setSelected] = useState<string | null>(null);

  useEffect(() => { fetch('/api/documents').then(r => r.json()).then(setDocs); }, []);

  const getCount = (cat: string) => docs.filter(d => d.category === cat).length;
  const getWordCount = (cat: string) => docs.filter(d => d.category === cat).reduce((s, d) => s + d.wordCount, 0);
  const getDocs = (cat: string) => docs.filter(d => d.category === cat).sort((a, b) => new Date(b.modified).getTime() - new Date(a.modified).getTime());

  const cleanName = (s: string) => s.replace(/-/g, ' ').replace(/\b\w/g, c => c.toUpperCase());
  const fmtDate = (iso: string) => new Date(iso).toLocaleDateString('en-US', { month: 'short', day: 'numeric' });

  return (
    <div className="page-container" style={{ maxWidth: 1100 }}>
      <div className="dash-hero">
        <h1>🚀 Projects & Knowledge</h1>
        <p>Your PARA-organized knowledge base</p>
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(220px, 1fr))', gap: 14, marginBottom: 32 }}>
        {PARA.map(p => (
          <div key={p.key} className={`cat-card ${selected === p.key ? 'active' : ''}`}
            onClick={() => setSelected(selected === p.key ? null : p.key)}
            style={selected === p.key ? { borderColor: 'var(--accent)' } : {}}>
            <div className="cat-icon">{p.icon}</div>
            <div className="cat-label">{p.label}</div>
            <div className="cat-count" style={{ fontSize: '0.78rem' }}>{p.desc}</div>
            <div style={{ display: 'flex', gap: 6, marginTop: 6, flexWrap: 'wrap' }}>
              <span className={`badge badge-${p.key}`}>{getCount(p.key)} docs</span>
              <span className="badge badge-notes">{(getWordCount(p.key) / 1000).toFixed(1)}k words</span>
            </div>
          </div>
        ))}
      </div>

      {selected && (
        <div>
          <div className="section-heading">{PARA.find(p => p.key === selected)?.icon} {PARA.find(p => p.key === selected)?.label}</div>
          {getDocs(selected).length === 0 ? (
            <div style={{ color: 'var(--text-tertiary)', fontSize: '0.85rem', padding: 16 }}>
              No documents yet. <Link href="/documents" style={{ color: 'var(--accent)' }}>Create one →</Link>
            </div>
          ) : (
            <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
              {getDocs(selected).map(d => (
                <Link key={d.slug} href={`/documents?doc=${encodeURIComponent(d.slug)}`} style={{
                  display: 'flex', justifyContent: 'space-between', alignItems: 'center',
                  padding: '12px 14px', background: 'var(--bg-surface)', border: '1px solid var(--border-subtle)',
                  borderRadius: 'var(--radius-md)', textDecoration: 'none', transition: 'all 0.15s',
                }}>
                  <span style={{ fontWeight: 500, color: 'var(--text-primary)' }}>{cleanName(d.title)}</span>
                  <div style={{ display: 'flex', gap: 8, alignItems: 'center' }}>
                    <span style={{ fontSize: '0.75rem', color: 'var(--text-tertiary)' }}>{d.wordCount} words</span>
                    <span style={{ fontSize: '0.75rem', color: 'var(--text-tertiary)' }}>{fmtDate(d.modified)}</span>
                  </div>
                </Link>
              ))}
            </div>
          )}
        </div>
      )}
    </div>
  );
}
