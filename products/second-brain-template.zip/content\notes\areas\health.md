# Health & Fitness

Ongoing area of responsibility.

## Habits
- Morning workout
- Daily water intake
- Sleep tracking
