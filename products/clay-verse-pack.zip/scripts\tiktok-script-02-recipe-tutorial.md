# TikTok Script #2: "Miniature Clay Cooking Tutorial"

**Duration:** 60 seconds  
**Style:** Smooth Polymer or Fingerprint Clay  
**Format:** Vertical 9:16  
**Audio:** Satisfying cooking ASMR sounds or "chef's kiss" trending audio

---

## Shot Breakdown

### 0-8 sec: TITLE & INGREDIENTS
- **Visual:** Overhead shot of miniature kitchen counter with ingredients laid out
- **Animation:** Ingredients appear one by one (stop-motion placement)
- **Text Overlay:** "How to make TINY pancakes 🥞"
- **Ingredients:** Flour bag (paper), eggs, milk bottle, butter, mixing bowl

### 8-15 sec: CRACK THE EGGS
- **Visual:** Clay hands crack tiny egg (real quail egg or resin prop)
- **Animation:** Egg cracks, yolk drops into bowl (glossy yellow clay/resin)
- **Text Overlay:** None (let ASMR speak)

### 15-22 sec: ADD FLOUR
- **Visual:** Flour "pours" from bag (white powder or baby powder)
- **Animation:** Cloud of flour puffs up slightly
- **Text Overlay:** "add flour (eyeball it)"

### 22-30 sec: MIX IT UP
- **Visual:** Tiny whisk spins in bowl, batter forms
- **Animation:** Whisk rotates, mixture swirls (white clay with yellow streaks)
- **Text Overlay:** "mix until smooth-ish"

### 30-40 sec: HEAT THE PAN
- **Visual:** Miniature stovetop, tiny pan on burner
- **Animation:** Butter melts (yellow clay → glossy puddle), slight steam effect
- **Text Overlay:** "medium heat!"

### 40-48 sec: POUR THE BATTER
- **Visual:** Batter pours from tiny pitcher into pan
- **Animation:** Batter spreads into circle, bubbles appear on surface
- **Text Overlay:** "bubbles = flip time"

### 48-55 sec: THE FLIP
- **Visual:** Spatula slides under pancake, flips it in air
- **Animation:** Slow-motion flip (shoot at higher frame rate)
- **Text Overlay:** "🤞🏼🤞🏼🤞🏼"

### 55-58 sec: STACK & SERVE
- **Visual:** Three pancakes stacked, butter pat on top, syrup drizzle
- **Animation:** Syrup (resin or honey) oozes down sides
- **Text Overlay:** "*chef's kiss*"

### 58-60 sec: END CARD
- **Visual:** "Try this recipe!" or "Follow for more tiny food"
- **Animation:** Pancake stack rotates

---

## Production Notes

- **Total Frames:** ~400-500 frames
- **Rig Requirements:** Overhead locked camera, excellent lighting for food appeal
- **Props Needed:** Kitchen set, mixing bowls, whisk, pan, spatula, ingredients
- **Special FX:** Practical steam (cotton on wire), syrup (clear resin or real honey)

## Material Choices

- **Pancakes:** Tan/beige polymer clay, painted with brown edges for "cooked" look
- **Eggs:** Yellow resin for yolk, clear resin for white
- **Milk:** White paint or glue
- **Butter:** Glossy yellow clay or real butter (melts under lights — commit to speed)
- **Syrup:** Honey, corn syrup, or UV resin (doesn't dry)

## AI Generation Strategy

This one is trickier for pure AI video gen — food needs to look tactile and real. Best approach:
1. Build practical miniature food props
2. Photograph each step
3. Use img2vid for transition moments (pour, mix, flip)
4. Combine with straight photos held for 1-2 seconds
5. Heavy sound design to sell the ASMR

## Engagement Hooks

- ASMR/satisfying content (huge TikTok niche)
- Miniature content (dedicated fanbase)
- Recipe format (familiar structure)
- "Try this!" CTA (encourages duets/stitches)

## Variations

- **Tiny Pizza:** Rolling dough, adding toppings, oven bake
- **Mini Sushi:** Rolling mats, rice placement, precision cuts
- **Small Cake:** Mixing, baking, frosting, decorating
- **Itsy-Bitsy Burger:** Grilling patty, assembly, first bite

---

**Estimated Production Time:** 6-8 hours (traditional) | 2-3 hours (AI-assisted hybrid)  
**Virality Potential:** 🔥🔥🔥 High (satisfying + niche crossover)
