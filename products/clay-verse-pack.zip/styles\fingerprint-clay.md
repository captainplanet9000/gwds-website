# Fingerprint Clay Style

## Aesthetic Overview
The classic handmade look — visible fingerprints, thumb smoothing marks, and slight imperfections that prove a human sculpted this. Warm, nostalgic, tactile. Think Gumby, early Wallace & Gromit, vintage children's television.

## Material Specs
- **Clay Type:** Soft plasticine (Van Aken, Newplast) or oil-based modeling clay
- **Finish:** Matte, slightly powdery surface
- **Texture Density:** High — obvious finger ridges, especially on larger flat surfaces
- **Color Palette:** Desaturated primaries, earth tones, slightly muddy mixes

## Visual Characteristics
- **Surface Quality:** Unpolished, showing tool marks and finger pressure
- **Edges:** Soft, rounded (not crisp geometric)
- **Blending:** Visible seams where colors meet, marbled transitions
- **Imperfections:** Embrace dust specs, tiny cracks, compression marks

## Lighting Recommendations
- **Key Light:** Soft, warm (3000-3500K) to enhance clay warmth
- **Avoid:** Harsh direct light that reveals too much texture detail (can look dirty)
- **Ideal Setup:** Diffused tungsten bulbs, bounced off white cards
- **Shadows:** Gentle, not dramatic — this style is cozy, not moody

## Camera & Framing
- **Focal Length:** 35-50mm (natural perspective, not too distorted)
- **Depth of Field:** Medium — some background blur but not extreme
- **Frame Rate Feel:** 12-18 fps stop-motion cadence
- **Movement:** Simple, linear camera moves (no complex rigs)

## Color Grading
- **Temperature:** Warm (push 200-400K warmer in post)
- **Saturation:** -10 to -20% (avoid overly vibrant, go nostalgic)
- **Contrast:** Medium-low (soft blacks, not crushed)
- **Film Look:** Add slight grain or Super 8 texture overlay

## AI Prompt Keywords
"fingerprint texture clay, handmade plasticine, visible thumb marks, soft matte finish, warm nostalgic lighting, stop-motion animation style, Gumby aesthetic, tactile imperfect sculpture"

## Best Use Cases
- Character-focused animation
- Nostalgic storytelling
- Children's content
- Low-fi indie projects
- ASMR satisfying textures

## Reference Works
- Wallace & Gromit (early shorts)
- Gumby (1950s-60s)
- Pingu (1990s)
- Morph (Aardman, 1977)

---

**Pro Tip:** When generating, emphasize "visible fingerprints" and "handmade texture" in your prompt. If the AI makes it too smooth, add "imperfect surface, sculpting marks, amateur craft aesthetic."
