# Runway Gen-3 Settings for Claymation

Optimized settings for generating stop-motion clay animation with Runway Gen-3 Alpha and Turbo.

---

## General Settings

### Model Choice
- **Gen-3 Alpha:** Best for high-quality, cinematic results (10 sec clips)
- **Gen-3 Turbo:** Faster, cheaper, good for iteration and tests (5-10 sec clips)
- **Recommendation:** Use Turbo for testing prompts, Alpha for final renders

### Resolution
- **1280x768 (16:9)** — Horizontal/YouTube format
- **768x1280 (9:16)** — Vertical/TikTok format ✅ Recommended
- **1280x1280 (1:1)** — Square/Instagram feed

---

## Prompt Engineering for Clay

### Core Prompt Structure
```
[Action/Scene] + [Clay Style] + [Lighting] + [Camera Movement] + [Frame Rate Feel]
```

### Example Prompt
```
A cheerful clay character walks across a miniature city, fingerprint texture visible on plasticine surface, warm tungsten lighting from above, camera tracks smoothly left to right, 12fps stop-motion animation style
```

### Essential Keywords
- **Material:** "plasticine clay," "polymer clay," "stop-motion," "handmade sculpture"
- **Texture:** "fingerprint marks," "matte finish," "visible sculpting," "imperfect surface"
- **Movement:** "12fps cadence," "frame-by-frame animation," "slight jitter," "stop-motion timing"
- **Lighting:** "soft tungsten," "diffused overhead," "gentle shadows," "warm practical lights"

### Avoid These (They Break Clay Look)
- "Realistic," "photorealistic," "live-action"
- "Smooth motion," "60fps," "motion blur" (unless intentional)
- "CGI," "3D render" (unless you want that hybrid look)

---

## Text-to-Video Settings

### Duration
- **5 seconds** — Good for action beats, transitions
- **10 seconds** — Best for complete scenes with setup and payoff
- **Recommendation:** Generate multiple 5-sec clips, stitch in editing

### Motion Control
- **Camera Motion:** Low to Medium (2-5/10)
  - Too high = floaty, unrealistic camera moves
  - Clay stop-motion uses locked or simple dolly shots
- **Subject Motion:** Medium (4-6/10)
  - Matches the deliberate, frame-by-frame feel
  - Avoid High (creates morphing, loses clay structure)

### Seed
- **Random** for exploration
- **Fixed** when you find a look you like (iterate on that seed)

---

## Image-to-Video Settings (Recommended Workflow)

### Why Img2Vid for Clay?
Text-to-video can be unpredictable. Starting from a reference image gives you:
- Consistent character design
- Controlled environment/set
- Better clay texture retention

### Input Image Prep
1. Photograph your actual clay setup (or generate perfect first frame in Midjourney/DALL-E)
2. Ensure proper stop-motion lighting (avoid harsh shadows)
3. Resolution: At least 1280px on long edge
4. Composition: Leave room for motion (don't crop tight)

### Img2Vid Prompt
Keep it simple — describe the **motion only**, not the scene (image already has that):
```
Character takes three steps forward, slight body bounce with each step, 12fps stop-motion animation
```

### Motion Strength
- **Low (1-3):** Subtle movements, breathing, idle animation
- **Medium (4-6):** Walking, object interaction, deliberate actions ✅ Recommended
- **High (7-9):** Fast action, chase scenes, explosions

---

## Advanced Techniques

### Achieving Stop-Motion Jitter
Runway's motion is often TOO smooth. To add stop-motion feel:
1. Generate at highest quality
2. Export at 24fps
3. In post (After Effects/Premiere):
   - Apply Posterize Time effect → 12fps
   - Slight frame blending OFF (keep it crisp)

### Clay Texture Preservation
If generated clay looks too smooth/CGI:
1. Add "visible fingerprints, handmade texture, imperfect surface" to prompt
2. Use img2vid starting from a photo of REAL clay
3. In post: Add film grain or texture overlay (10-15% opacity)

### Lighting Consistency
For multi-shot sequences:
1. Describe exact light setup in every prompt:
   - "Soft tungsten key light 45° camera left, white bounce fill camera right"
2. Use same seed across related shots
3. Color grade in post for final matching

---

## Workflow Example: 60-Second TikTok

1. **Storyboard:** 6-8 distinct shots
2. **Generate:** Each shot as 5-10 sec clip (Runway)
3. **Iterate:** Regenerate any shots that don't match (try different seeds)
4. **Edit:** Import to CapCut/Premiere, trim to beats
5. **Post-Process:**
   - Color grade for consistency
   - Add posterize time effect (12fps feel)
   - Slight film grain overlay
   - Text overlays and trending audio
6. **Export:** 1080x1920, 30fps (TikTok optimal)

---

## Troubleshooting

### Problem: "Clay looks like CGI, not handmade"
- **Solution:** Add "rough texture, fingerprint marks, matte finish, amateur craft" to prompt
- Use img2vid from photo of real clay

### Problem: "Motion is too floaty/unrealistic"
- **Solution:** Lower motion strength to 3-5, add "12fps stop-motion timing" to prompt

### Problem: "Character morphs or loses structure"
- **Solution:** Use img2vid instead of text-to-video, reduce motion strength

### Problem: "Lighting changes mid-clip"
- **Solution:** Be VERY specific about lighting in prompt, lock seed

---

## Cost Optimization

- **Turbo for iterations:** $0.25 per 5sec vs $1.25 for Alpha
- **Batch prompts:** Test 5 variations at once, pick the best
- **Img2Vid over Text:** More predictable = fewer failed generations

---

## Best Practices Summary

✅ Use img2vid workflow for consistency  
✅ Keep motion strength 4-6 for clay feel  
✅ Specify "12fps stop-motion" in every prompt  
✅ Describe lighting explicitly  
✅ Generate short clips, edit together  
✅ Add posterize time effect in post  

❌ Don't use "realistic" or "photorealistic"  
❌ Don't max out motion strength  
❌ Don't expect 60-sec single shots (stitch multiple)  

---

**Pro Tip:** Save your best prompts + seeds in a spreadsheet. When you find a winning combo, reuse it across projects with slight variations.
