# TikTok Script #1: "Clay Character Morning Routine"

**Duration:** 60 seconds  
**Style:** Pastel Whimsy or Fingerprint Clay  
**Format:** Vertical 9:16  
**Audio:** Upbeat morning routine trending audio or lofi instrumental

---

## Shot Breakdown

### 0-5 sec: WAKE UP
- **Visual:** Clay alarm clock rings (bells wiggle). Clay character in bed, eyes closed.
- **Animation:** Eyes pop open (swap face), character sits up with slight squash/stretch
- **Text Overlay:** "me waking up for no reason at 6am"

### 5-12 sec: STRETCH
- **Visual:** Character stands, arms stretch overhead (wire armature visible flex)
- **Animation:** Big exaggerated yawn, body compresses then extends
- **Text Overlay:** None (let action speak)

### 12-22 sec: BREAKFAST
- **Visual:** Miniature kitchen. Character pours cereal (tiny beads), milk (white paint), eats with tiny spoon
- **Animation:** Spoon to mouth, chewing motion, satisfied expression
- **Text Overlay:** "gotta fuel up"

### 22-32 sec: COFFEE
- **Visual:** Tiny coffee maker brews (brown liquid drips), character holds mug with both hands
- **Animation:** Steam rises (cotton wisps on wire), character sips, eyes light up
- **Text Overlay:** "okay NOW i'm awake"

### 32-42 sec: GET DRESSED
- **Visual:** Quick cuts of character swapping outfits (replaceable clay pieces)
- **Animation:** Fast 3-frame swaps — pajamas → casual → formal → back to casual
- **Text Overlay:** "choosing an outfit is hard"

### 42-50 sec: BRUSH TEETH
- **Visual:** Bathroom miniature set. Toothbrush (actual tiny brush), clay character brushes
- **Animation:** Vigorous horizontal brushing motion, foam on mouth (white clay)
- **Text Overlay:** None

### 50-58 sec: OUT THE DOOR
- **Visual:** Character walks to miniature door, grabs tiny bag/briefcase
- **Animation:** Wave goodbye to camera, door closes
- **Text Overlay:** "time to conquer the day ✨"

### 58-60 sec: END CARD
- **Visual:** Logo or "follow for more clay content!"
- **Animation:** Simple rotate or bounce

---

## Production Notes

- **Total Frames:** ~300-400 (shooting on 2s or 3s)
- **Rig Requirements:** Overhead camera locked off, move character/props between frames
- **Props Needed:** Bed, alarm clock, kitchen table, cereal box, coffee pot, mug, bathroom mirror, door
- **Character Rigging:** Wire armature or replaceable parts for outfit changes

## AI Generation Strategy

If using AI video gen instead of pure stop-motion:
1. Create 6-8 separate clips (one per scene)
2. Use img2vid starting from photos of your clay setups
3. Stitch together in editing with quick cuts
4. Add text overlays and trending audio in CapCut/Premiere

## Engagement Hooks

- Relatable morning struggle content
- Satisfying miniature details (ASMR appeal)
- Character personality shines through animation
- Trending audio increases discoverability

## Variations

- **Weekend Version:** Character hits snooze, goes back to sleep
- **Coffee Addict Version:** Multiple cups of coffee, increasingly frantic energy
- **Work-from-Home Version:** Gets dressed waist-up only, pajama pants remain

---

**Estimated Production Time:** 4-6 hours (traditional stop-motion) | 1-2 hours (AI-assisted)
