# Clay Verse Animation Pack

**Premium claymation prompts and workflows for AI video generation**

Transform your ideas into tactile, handcrafted-looking animations with this comprehensive claymation asset pack. Perfect for AI video tools like Runway Gen-3, Kling AI, and Pika.

## What's Inside

- **10 Production-Ready Prompts** — Detailed scene descriptions for character animation, environments, and action sequences
- **5 Style Reference Cards** — Aesthetic specs for different clay techniques (fingerprint, smooth polymer, rustic, neon-glaze, pastel)
- **3 TikTok Scripts** — 60-second claymation content templates ready to produce
- **AI Tool Settings** — Optimized configs for Runway Gen-3, Kling AI, and ComfyUI workflows

## How to Use

1. **Choose a prompt** from the `/prompts` folder that matches your scene
2. **Select a style** from `/styles` to define the aesthetic
3. **Apply recommended settings** from `/settings` for your chosen AI tool
4. **Generate and iterate** — adjust motion strength, camera movement, and timing to taste

## Prompt Structure

Each prompt file includes:
- **Scene Description** — What's happening in the shot
- **Style Notes** — Clay texture, lighting, and material details
- **Camera Direction** — Movement, framing, and focal length
- **Mood & Lighting** — Atmosphere and color temperature
- **Recommended Motion Settings** — Speed and smoothness guidance

## Tool Compatibility

- **Runway Gen-3 Alpha/Turbo** ✅
- **Kling AI v1.5** ✅
- **Pika 1.5** ✅
- **ComfyUI (img2vid workflows)** ✅
- **Luma Dream Machine** ✅ (basic compatibility)

## License

**Commercial Use:** ✅ Allowed  
**Attribution:** Not required (but appreciated!)  
**Resale of prompts:** ❌ Not permitted  
**Generated videos:** Yours to use, sell, and distribute freely

## Tips for Best Results

- Start with **medium motion strength** (4-6/10) for clay — too high creates unrealistic morphing
- Use **shorter clips** (3-5 seconds) and stitch together for more control
- **Upscale in post** — AI video generators work better at lower res, then upscale
- Add **film grain or texture overlays** in editing to enhance the handmade feel
- Combine with **practical stop-motion reference footage** for img2vid workflows

## Support

Questions? Need help dialing in your settings? Email support@gammawaves.studio

---

**Clay Verse Animation Pack v1.0**  
© 2026 Gamma Waves Design Studio  
Made with 🐾 by GWDS
