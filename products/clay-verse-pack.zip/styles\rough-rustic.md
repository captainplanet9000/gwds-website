# Rough Rustic Style

## Aesthetic Overview
Earthy, handmade, deliberately crude. This style embraces imperfection — visible seams, rough edges, mixed-media elements. Looks like it was made in a garage with love and limited resources. Think early Tim Burton, indie horror, folk art animation.

## Material Specs
- **Clay Type:** Cheap plasticine, air-dry clay (even with cracks), mixed with found objects
- **Finish:** Completely matte, dusty, unrefined
- **Texture Density:** Extreme — lumpy, bumpy, every thumbprint visible
- **Color Palette:** Muted, muddy, desaturated earth tones with pops of weird color

## Visual Characteristics
- **Surface Quality:** Rough, unpolished, "wabi-sabi" aesthetic
- **Edges:** Jagged, uneven, organic chaos
- **Blending:** Non-existent — visible color blocks, harsh transitions
- **Mixed Media:** Clay + twigs + fabric scraps + wire + found trash

## Lighting Recommendations
- **Key Light:** Single practical bulb, bare tungsten, harsh shadows
- **Atmosphere:** Moody, gothic, slightly ominous even in daytime scenes
- **Ideal Setup:** One cheap work lamp, maybe a candle for motivation
- **Shadows:** Deep, dramatic, low-budget horror movie vibes

## Camera & Framing
- **Focal Length:** Wide (24-28mm) for distortion, or tight macro for uncomfortable detail
- **Depth of Field:** Deep (everything in focus, nowhere to hide)
- **Frame Rate Feel:** Irregular — 8-15 fps, embrace the jutter
- **Movement:** Handheld shake, wobbly tripod, low-tech tracking

## Color Grading
- **Temperature:** Cool to neutral (slight green or blue cast)
- **Saturation:** -30 to -40% (grim, desaturated)
- **Contrast:** High (crushed blacks, blown highlights okay)
- **Film Look:** 16mm grain, damaged film emulation, VHS glitch

## AI Prompt Keywords
"rough handmade clay, crude stop-motion, imperfect sculpting, folk art animation, gothic atmosphere, mixed media miniatures, unpolished texture, indie horror aesthetic, Jan Svankmajer style"

## Best Use Cases
- Horror/unsettling content
- Art house animation
- Music videos (experimental, metal, industrial)
- Anti-corporate indie projects
- Deliberately "off" humor (Adult Swim vibes)

## Reference Works
- The Nightmare Before Christmas (early Burton)
- Jan Svankmajer films (Alice, Conspirators of Pleasure)
- Lee Hardcastle's claymation gore
- PES music videos (but darker)
- Tool music videos (stop-motion segments)

## Technical Notes
- Lean into "amateur" and "DIY" language in prompts
- Add "unsettling" or "slightly disturbing" to push the vibe
- Reference Jan Svankmajer explicitly — AI models know his texture
- Combine with "gothic" or "macabre" for mood reinforcement

---

**Pro Tip:** This style works great when you want something memorable and weird. It's anti-Instagram, anti-polish. If you're making content that needs to stand out in an ocean of slick AI videos, this is your weapon.
