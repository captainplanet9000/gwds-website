# Pastel Whimsy Style

## Aesthetic Overview
Soft, dreamy, kawaii-influenced claymation. Gentle colors, rounded shapes, cozy vibes. Think Sanrio meets Wes Anderson. Perfect for feel-good content, kids' media, wholesome storytelling. Maximum coziness.

## Material Specs
- **Clay Type:** Soft pastel-colored polymer clay or fondant (cake decorating material)
- **Finish:** Soft matte or slight pearl sheen (not fully glossy)
- **Texture Density:** Low — smooth surfaces with intentional fabric/knit textures
- **Color Palette:** Baby pink, mint green, lavender, peach, cream, sky blue

## Visual Characteristics
- **Surface Quality:** Pillowy, soft-focus edges, gentle forms
- **Edges:** Rounded, no sharp corners, huggable shapes
- **Blending:** Seamless pastel gradients, watercolor-like transitions
- **Props:** Miniature felt elements, tiny pom-poms, craft store aesthetic

## Lighting Recommendations
- **Key Light:** Extremely soft, overcast daylight feel (6000K)
- **Atmosphere:** Bright, airy, no harsh shadows anywhere
- **Ideal Setup:** Large diffusion panels, fill cards everywhere, wraparound light
- **Shadows:** Barely visible, just enough for depth

## Camera & Framing
- **Focal Length:** 50mm standard or 85mm portrait (gentle compression)
- **Depth of Field:** Shallow to medium (dreamy bokeh in background)
- **Frame Rate Feel:** Smooth 24fps, no jitter (calming motion)
- **Movement:** Slow, gentle drifts — no sudden moves

## Color Grading
- **Temperature:** Slightly warm (100-200K lift) for cozy feel
- **Saturation:** Normal but shifted toward pastels (crushing heavy colors)
- **Contrast:** Low (milky blacks, soft highlights)
- **Film Look:** Fujifilm velvia softness, or digital clean with bloom

## AI Prompt Keywords
"pastel clay animation, soft kawaii aesthetic, gentle whimsical stop-motion, baby pink and mint colors, cozy miniature world, rounded shapes, Wes Anderson symmetry, dreamy soft lighting"

## Best Use Cases
- Children's content (preschool age)
- ASMR satisfying videos
- Self-care/wellness content
- Kawaii culture content
- Brand mascots (cute products)
- Wholesome storytelling

## Reference Works
- Isle of Dogs (Wes Anderson) — pastel color palette
- Rilakkuma and Kaoru (Netflix)
- Sanrio character design
- Cake decorating videos (aesthetic overlap)
- Lofi Girl aesthetic (but 3D)

## Set Design Notes
- Use craft felt, yarn, tiny knitted elements
- Incorporate miniature food (donuts, cupcakes, boba tea)
- Soft textiles as backgrounds (fleece blankets, felt sheets)
- Tiny succulent plants, kawaii stationery as props

## Lighting Recipe
1. Key: Large softbox overhead, 90% power
2. Fill: White bounce cards on 3 sides
3. Subtle rim: Soft backlight with diffusion
4. Background: Overexposed 1-2 stops (hazy glow)

---

**Pro Tip:** This style sells merch. If you're building a character or brand, pastel whimsy is the most commercially viable aesthetic in the pack. It tests well with audiences 5-35 years old.
