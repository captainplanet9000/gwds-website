# Kling AI Settings for Claymation

Optimized settings for generating stop-motion clay animation with Kling AI v1.5 and v1.6.

---

## General Settings

### Model Version
- **Kling v1.5:** Standard model, good quality, widely available
- **Kling v1.6:** Improved motion coherence, better at complex scenes
- **Recommendation:** Use v1.6 if available (better at maintaining clay structure)

### Mode Selection
- **Standard Mode:** 5-second clips, balanced quality/speed
- **Pro Mode:** 10-second clips, higher quality, slower generation ✅ Recommended for finals
- **Recommendation:** Standard for testing, Pro for final renders

### Aspect Ratio
- **16:9 (1280x720)** — Horizontal YouTube
- **9:16 (720x1280)** — Vertical TikTok/Reels ✅ Best for social
- **1:1 (1024x1024)** — Square Instagram feed

---

## Text-to-Video Settings

### Prompt Structure for Clay
Kling responds well to structured prompts:

```
[Subject] + [Action] + [Material Detail] + [Style] + [Camera] + [Lighting]
```

### Example Prompt
```
A small clay character with round head and stubby legs walks across a handmade miniature city set. Plasticine clay with visible fingerprint texture, matte surface finish. Stop-motion animation style, 12 frames per second cadence. Camera slowly tracks from left to right at eye level. Warm soft lighting from overhead tungsten bulb, gentle shadows.
```

### Key Prompt Elements

**Material Specification:**
- "Plasticine clay," "polymer clay," "Sculpey"
- "Fingerprint texture," "handmade surface"
- "Matte finish," "slightly rough"

**Style Anchors:**
- "Stop-motion animation"
- "Claymation style"
- "Aardman aesthetic" (Kling knows Wallace & Gromit)
- "12fps animation cadence"

**Negative Prompts (Important!):**
- realistic skin, photorealistic, live action, CGI render, smooth motion, motion blur, 60fps

---

## Image-to-Video Settings

### Why Img2Vid with Kling?
Kling's img2vid is STRONG — often better than text-to-video for clay because:
- Preserves exact character design
- Maintains clay texture from reference
- More predictable motion

### Input Image Guidelines
1. **Resolution:** 1024px minimum on long edge
2. **Composition:** Center subject, leave 20% padding for motion
3. **Lighting:** Match your desired final lighting (Kling preserves it)
4. **Quality:** Sharp, well-lit photo (no blur, no grain)

### Motion Prompt (Img2Vid)
Describe ONLY the motion, not the scene:

```
Character takes four steps forward with bouncy walk cycle, body squashes slightly with each step, stop-motion animation timing
```

Keep it under 100 characters for best results.

---

## Creativity & Relevance Sliders

### Creativity (0-100)
Controls how much Kling "interprets" vs "follows literally"

- **0-30:** Very literal, minimal hallucination ✅ Best for clay (prevents morphing)
- **30-60:** Balanced, some artistic liberty
- **60-100:** High interpretation (can break clay structure)

**Recommendation:** Keep at 20-40 for claymation

### Relevance (0-100)
How closely output matches the prompt

- **70-100:** Strict adherence ✅ Recommended (maintains clay look)
- **40-70:** Some deviation
- **0-40:** Loose interpretation (risky)

**Recommendation:** Set to 80-90 for consistent results

---

## Motion Settings

### Camera Movement
Kling has specific camera controls:

- **Static:** Locked camera, subject moves
- **Pan:** Left/right horizontal camera motion
- **Tilt:** Up/down vertical camera motion
- **Dolly:** Forward/backward tracking
- **Crane:** Combined vertical and forward motion

**For Clay Animation:**
- Use **Static** or **Dolly** (matches stop-motion conventions)
- Avoid complex multi-axis moves (breaks the handmade feel)

### Movement Speed
- **Slow:** 1-3/10 — Subtle motion, breathing, idle ✅ Good for establishing shots
- **Medium:** 4-6/10 — Walking, object interaction ✅ Best for most clay scenes
- **Fast:** 7-10 — Running, action, chase (can cause morphing — use carefully)

---

## Advanced Techniques

### Stop-Motion Jitter Effect
Kling's motion is smooth by default. To add stop-motion feel:

1. Generate at Pro quality
2. In post-processing:
   - Import to After Effects or DaVinci Resolve
   - Apply **Posterize Time** effect → 12fps or 15fps
   - Disable frame blending (keep crisp frame transitions)
   - Optional: Add 1-2% random shake for "handmade camera" feel

### Clay Texture Enhancement
If output looks too smooth:

**In Prompt:**
- Add: "rough handmade texture, visible sculpting marks, amateur craft quality"
- Increase detail: "extreme close-up shows fingerprint ridges in clay surface"

**In Post:**
- Add film grain overlay (10-20% opacity)
- Slight texture map overlay (burlap or canvas texture at 5-10%)

### Multi-Shot Sequences
For longer content (30-60 seconds):

1. **Shot List:** Break into 5-8 distinct clips
2. **Consistency Settings:**
   - Use same Creativity/Relevance values
   - Reference same lighting setup in each prompt
   - Keep character description identical
3. **Generate All Clips:** Before editing (so you can regenerate matches)
4. **Edit Together:** Use quick cuts (0.5-1 sec per shot max)

---

## Workflow: TikTok Claymation (60 sec)

### Preparation
1. Storyboard 6-8 key moments
2. Write detailed prompts for each (save in .txt files)
3. Decide: text-to-video or img2vid?
   - If consistent character needed → img2vid
   - If each shot is different → text-to-video

### Generation
1. Set to Pro Mode, 9:16 aspect ratio
2. Creativity: 30, Relevance: 85
3. Generate first shot → review → adjust if needed
4. Generate remaining shots with same settings
5. Regenerate any that don't match (try different seeds)

### Post-Production
1. Import clips to CapCut or Premiere Pro
2. Trim each clip to 5-8 seconds (cut out slow start/end)
3. Apply consistent color grade (LUT or manual)
4. Add posterize time effect (12fps) to all clips
5. Layer text overlays synchronized to beats
6. Add trending audio (check TikTok library)
7. Export: 1080x1920, 30fps, high bitrate

---

## Troubleshooting

### Issue: "Character morphs or melts during motion"
**Fix:**
- Lower Creativity slider to 20-30
- Reduce movement speed to 3-5
- Use img2vid instead of text-to-video
- Add "solid stable structure, no deformation" to prompt

### Issue: "Lighting changes mid-clip"
**Fix:**
- Be extremely specific about lighting in prompt:
  - "Single tungsten key light from camera left at 45 degrees, constant throughout shot, no flickering"
- Set Relevance to 90+

### Issue: "Clay looks like CGI/3D render"
**Fix:**
- Add negative prompt: "CGI, 3D render, computer graphics, smooth plastic"
- Add to prompt: "practical handmade clay, visible fingerprints, matte surface, amateur craft"
- Use img2vid from actual clay photo

### Issue: "Motion too smooth, doesn't look like stop-motion"
**Fix:**
- Don't fix in Kling (it's inherently smooth)
- Fix in post with posterize time effect
- Optional: Add subtle frame position jitter in After Effects (1-2px random)

---

## Cost Optimization

- **Standard Mode:** ~$0.30 per 5sec clip
- **Pro Mode:** ~$0.80 per 10sec clip
- **Strategy:**
  - Use Standard for concept testing (3-5 variations)
  - Switch to Pro for final selected shots
  - Img2vid is same cost but more predictable (fewer wasted gens)

---

## Best Practices Summary

✅ Use img2vid for character consistency  
✅ Keep Creativity 20-40, Relevance 80-90  
✅ Specify "stop-motion" and "claymation" in every prompt  
✅ Use Static or Dolly camera moves  
✅ Generate Pro mode for finals  
✅ Add posterize time effect in post  

❌ Don't use high Creativity (causes morphing)  
❌ Don't use complex camera moves  
❌ Don't expect stop-motion jitter from AI (add in post)  
❌ Don't skip negative prompts  

---

## Kling vs Runway Quick Comparison

| Feature | Kling | Runway |
|---------|-------|--------|
| Texture retention | Better | Good |
| Motion smoothness | Very smooth | Smooth |
| Prompt following | Stricter | More creative |
| Cost (10sec) | ~$0.80 | ~$1.25 |
| Best for | Consistent characters | Varied scenes |

**Recommendation:** Use both! Kling for character shots, Runway for environment/establishing.

---

**Pro Tip:** Kling has a "reference image" feature separate from img2vid — you can provide a style reference image while using text-to-video. Use a photo of real clay as style ref for better texture.
