# Neon Glaze Style

## Aesthetic Overview
Futuristic, glossy, hyper-saturated clay with reflective surfaces and neon accent lighting. Looks like claymation shot in a cyberpunk nightclub. Shiny glazed ceramics meet vaporwave colors. Not realistic — stylized and bold.

## Material Specs
- **Clay Type:** Polymer clay with high-gloss varnish, or ceramic with colored glazes
- **Finish:** Wet-look ultra-glossy, mirror reflections
- **Texture Density:** Smooth base with strategic specular highlights
- **Color Palette:** Neon pinks, cyans, purples, electric blues, acid greens + black

## Visual Characteristics
- **Surface Quality:** Glass-like reflections, wet appearance
- **Edges:** Sharp and clean (like injection-molded plastic toys)
- **Blending:** High contrast color blocking, no muddy transitions
- **Glow:** Practical neon lights or LED strips integrated into set

## Lighting Recommendations
- **Key Light:** Colored gels (magenta, cyan, green) — never white light
- **Atmosphere:** Noir shadows + neon highlights, high contrast
- **Ideal Setup:** RGB LED strips, colored practicals, blacklight optional
- **Shadows:** Deep and saturated (colored shadows, not neutral gray)

## Camera & Framing
- **Focal Length:** 35mm for music video energy, or 85mm for portrait glamour shots
- **Depth of Field:** Shallow (f/1.4-2.8 feel) — bokeh city lights in background
- **Frame Rate Feel:** 24fps smooth or 60fps (hyper-real slow-mo)
- **Movement:** Dynamic — whip pans, crash zooms, Fincher-style slow push-ins

## Color Grading
- **Temperature:** Cool (heavy blue/cyan bias) with warm neon accents
- **Saturation:** +30 to +50% (go bold or go home)
- **Contrast:** Very High (true blacks, clipped highlights for glow)
- **Film Look:** Digital, clean, zero grain — or VHS glitch for vaporwave

## AI Prompt Keywords
"glossy neon clay, cyberpunk stop-motion, reflective ceramic glaze, vaporwave colors, neon lighting, futuristic miniature set, wet-look finish, bold color blocking, Blade Runner aesthetic"

## Best Use Cases
- Music videos (electronic, synthwave, pop)
- Fashion/beauty content
- Tech product launches
- Nightlife/club content
- Retro-futurism branding

## Reference Works
- Tron aesthetic (but claymation)
- Vaporwave art (but 3D physical)
- Blade Runner's neon streets
- Drive (2011) color palette
- Adult Swim bumpers (some)

## Technical Notes
- Push "neon," "glossy," and "reflective" hard in prompts
- Specify colors explicitly ("hot pink neon, electric cyan, deep purple")
- Add "cyberpunk" or "vaporwave" for style anchoring
- Works best with darker backgrounds to make colors pop

## Lighting Recipe
1. Key: Cyan gel, camera left, hard source
2. Rim: Magenta gel, behind subject, edge light
3. Practical: Small RGB LED strip in-shot (pink or green)
4. Background: Deep blue or pure black

---

**Pro Tip:** This style is LOUD. Use it when you want maximum visual impact in a short time (perfect for TikTok/Reels). It's the opposite of subtle — that's the point.
