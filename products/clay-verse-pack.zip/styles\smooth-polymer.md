# Smooth Polymer Style

## Aesthetic Overview
Polished, professional claymation with ultra-smooth surfaces. This is modern stop-motion at its finest — characters look production-ready, clean edges, deliberate lighting. Think Laika Studios (Kubo, Coraline), Shaun the Sheep, modern Aardman.

## Material Specs
- **Clay Type:** Polymer clay (Sculpey, Fimo) baked for stability, or high-grade plasticine meticulously smoothed
- **Finish:** Satin to semi-gloss, seamless surface
- **Texture Density:** Minimal — only intentional textures (fabric, hair, specific materials)
- **Color Palette:** Rich, saturated, carefully color-matched

## Visual Characteristics
- **Surface Quality:** Immaculate — no visible fingerprints, even skin tones
- **Edges:** Crisp where intended (architectural), soft where organic
- **Blending:** Seamless gradients, professional paint jobs
- **Details:** High precision — tiny props, realistic miniatures, perfect scaling

## Lighting Recommendations
- **Key Light:** Controlled studio lighting, often 3-point setups
- **Sophistication:** Motivated lighting (visible sources make sense in-world)
- **Ideal Setup:** LED panels with diffusion, precise flag/barn door control
- **Shadows:** Deliberate, used for mood and depth

## Camera & Framing
- **Focal Length:** Variable — wide for establishing, macro for detail shots
- **Depth of Field:** Often shallow to mimic cinema cameras (1.8-2.8 equivalent)
- **Frame Rate Feel:** 24 fps equivalent (smooth, filmic)
- **Movement:** Complex rigs allowed — sliders, jibs, motion control

## Color Grading
- **Temperature:** Varies per scene mood (cool for night, warm for day)
- **Saturation:** Normal to +10% (rich, saturated without being garish)
- **Contrast:** Medium-high (cinematic blacks, controlled highlights)
- **Film Look:** Digital intermediate grade, log color space workflow

## AI Prompt Keywords
"smooth polymer clay animation, professional stop-motion, Laika Studios quality, seamless surface finish, cinematic lighting, detailed miniature set, modern claymation, pristine sculpting"

## Best Use Cases
- Commercial work (ads, music videos)
- High-budget narrative shorts
- Feature film look-dev
- Portfolio hero pieces
- Client presentations

## Reference Works
- Kubo and the Two Strings (Laika)
- Coraline (Laika)
- Shaun the Sheep Movie (Aardman)
- Isle of Dogs (Wes Anderson)
- The Boxtrolls (Laika)

## Technical Notes
- This style requires multiple generations and refinement
- Use "professional stop-motion" and "studio production quality" in prompts
- Reference specific studios (Laika, Aardman modern) for AI training recognition
- Combine with "cinematic lighting" and "detailed miniature environment"

---

**Pro Tip:** To achieve this look with AI tools, use img2vid workflows starting from a high-quality 3D render or pristine photograph of clay. Pure text-to-video struggles with this level of polish — give it a perfect reference frame.
