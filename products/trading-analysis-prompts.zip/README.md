# Trading Analysis Prompts

**165+ prompts for crypto, DeFi, and market analysis.**

Stop making trades based on gut feelings. This pack gives you structured prompts for technical analysis, fundamental research, sentiment tracking, risk management, and trade planning. Paste them into your AI tool, fill in the specifics, and get analysis that would take hours to do manually.

---

## What's Inside

| File | Prompts | What It Covers |
|------|---------|----------------|
| `prompts/technical-analysis.md` | 30 | Chart patterns, indicators, S/R levels, multi-timeframe analysis |
| `prompts/fundamental-analysis.md` | 20 | Tokenomics, team evaluation, metrics, on-chain data |
| `prompts/market-sentiment.md` | 20 | Social sentiment, news analysis, fear/greed interpretation |
| `prompts/risk-management.md` | 25 | Position sizing, portfolio review, risk assessment, drawdown analysis |
| `prompts/trade-planning.md` | 20 | Trade plans, entry/exit criteria, journaling, reviews |
| `prompts/defi-research.md` | 20 | Protocol analysis, yield farming, liquidity, smart contract risk |
| `prompts/macro-analysis.md` | 15 | Macro economics, Fed policy, correlations, global events |
| `prompts/trading-psychology.md` | 15 | Bias detection, emotional management, discipline systems |
| **Total** | **165+** | |

## Who This Is For

- Active crypto/DeFi traders who use AI tools for research
- Portfolio managers who need structured analysis frameworks
- Trading journal enthusiasts who want better self-review
- Anyone who wants to think more systematically about markets

## How to Use

1. **Pick your analysis need** — Open the relevant file
2. **Copy the prompt** — System prompt goes in your AI's system instruction
3. **Fill in the brackets** — Add your specific token, timeframe, data
4. **Run and verify** — AI gives you structured analysis, you verify the data and make your own decision

### Important Disclaimers

- These prompts help you THINK about markets, not predict them
- AI analysis is only as good as the data you feed it
- Always verify AI-generated analysis against real data
- Nothing here is financial advice — it's analytical frameworks
- Past performance doesn't predict future results (seriously)

## Prompt Format

Every prompt follows this structure:

```
**System Prompt:**
You are a [specialized analyst role]...

**User Prompt:**
[Specific analysis instruction with [BRACKETED] fields]

**Example Output:**
[What quality analysis looks like]
```

## License

Personal and commercial use. See `LICENSE.md` for details.

---

*Built by Gamma Waves Design Studio — [gwds.co](https://gwds.co)*
