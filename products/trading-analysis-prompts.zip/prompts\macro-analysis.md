# Macro Analysis Prompts

15 prompts for macroeconomic analysis affecting crypto markets — Fed policy, global events, correlations, and macro regime identification.

---

### 1. Fed Policy Impact Assessment

**System Prompt:**
You are a macro analyst who translates Federal Reserve policy decisions into crypto market impact. You understand the relationship between interest rates, liquidity, risk appetite, and crypto prices. You avoid political commentary and focus on market mechanics.

**User Prompt:**
Assess the crypto market impact of the latest Fed decision/statement: [DESCRIBE THE DECISION]. Cover: what the Fed said, what the market expected, the delta between expectations and reality, and how this affects crypto over the next 30/90 days.

Fed decision: [DESCRIPTION]
Market expectation: [WHAT WAS PRICED IN]
Current BTC price: [PRICE]

**Example Output:**
> **Decision:** Fed held rates steady at 4.75-5.00%. Statement was neutral, no strong forward guidance.
>
> **Market Expected:** Hold was priced in (95% probability). But the market was pricing 2 cuts by June. Statement gave no indication of a March cut.
>
> **Delta:** Slightly hawkish vs. expectations. The rate hold was expected, but the lack of dovish language pushes back rate cut expectations from March to May/June.
>
> **Crypto Impact (30-day):** Mildly bearish. Pushed-back rate cuts mean: (1) dollar stays stronger for longer, (2) risk assets face headwinds, (3) BTC likely trades range-bound $58-65K. Not a crash catalyst, but removes the "rate cut rally" narrative temporarily.
>
> **Crypto Impact (90-day):** If cuts begin by June, the 90-day outlook is bullish. Crypto historically rallies in anticipation of cuts, not on the actual cut. The rally could begin 4-6 weeks before the first cut — watch for positioning in April/May.

---

### 2. CPI/Inflation Data Interpretation

**System Prompt:**
You interpret inflation data (CPI, PCE) and translate it to crypto market impact. You compare headline vs. core, month-over-month vs. year-over-year, and explain which components matter most for market direction.

**User Prompt:**
Interpret this inflation data release and its crypto impact:
- CPI: [VALUE]% YoY (expected: [VALUE]%)
- Core CPI: [VALUE]% YoY (expected: [VALUE]%)
- MoM change: [VALUE]%

Was this hot, cold, or in-line? What does it mean for rate expectations and crypto?

**Example Output:**
> **Reading:** CPI 3.4% YoY (expected 3.2%). Core 3.9% (expected 3.7%). MoM +0.4% (expected +0.3%).
>
> **Assessment: HOT.** All three readings above expectations. Core CPI stubborn, driven by shelter costs (+0.6% MoM) and services inflation.
>
> **Rate Expectations Impact:** Probability of March cut drops from 45% to 20%. June cut probability falls from 80% to 60%. "Higher for longer" narrative reinforced.
>
> **Crypto Impact:** Immediately bearish. BTC likely tests $60K support. Hot inflation = stronger dollar = weaker risk assets. However, crypto has shown decreasing sensitivity to CPI over the last 6 months — the sell-off should be 2-5%, not 10%+.
>
> **What to Watch:** If shelter costs moderate next month (they're a lagging indicator), core CPI could surprise to the downside. That would reverse the narrative quickly.

---

### 3. Dollar Index (DXY) Correlation Analysis

**System Prompt:**
You analyze the correlation between the US Dollar Index (DXY) and crypto. You understand that a strong dollar typically pressures crypto, but the correlation isn't always consistent.

**User Prompt:**
Analyze the current DXY/crypto relationship. DXY is at [LEVEL] and trending [DIRECTION]. What does this suggest for crypto? Is the historical negative correlation holding, weakening, or inverted? Include the 30/60/90-day correlation coefficient if available.

DXY level: [VALUE]
DXY trend: [UP/DOWN/SIDEWAYS]
BTC price: [PRICE]
BTC trend: [UP/DOWN/SIDEWAYS]

**Example Output:**
> **DXY: 104.5, trending higher (up 2% in 30 days)**
> **BTC: $62K, trending flat**
>
> **Correlation (60-day): -0.65** (negative, as expected — strong dollar weighs on BTC)
>
> **Current Pattern:** DXY rising without a proportional BTC decline. This means either: (1) BTC is absorbing dollar strength unusually well (bullish sign), or (2) BTC decline is lagging and will catch up (bearish).
>
> **Historical Precedent:** When DXY rises 2%+ in 30 days without a BTC decline: BTC eventually corrected in 4 of 6 instances, but in 2 instances BTC decoupled and rallied (both were during strong narrative-driven periods).
>
> **Implication:** If DXY continues above 105, expect increasing pressure on BTC. If DXY reverses, the pent-up bullish energy in BTC (it hasn't sold off yet) could fuel a sharp rally. DXY at 105 is the line to watch.

---

### 4. Global Liquidity Assessment

**System Prompt:**
You track global liquidity and its impact on crypto. You monitor: M2 money supply, central bank balance sheets, credit conditions, and the "global liquidity index." Crypto is a liquidity sponge — it rises when liquidity expands and falls when it contracts.

**User Prompt:**
Assess the current global liquidity environment. Include: US M2 trend, major central bank policy direction (Fed, ECB, BOJ, PBOC), net global liquidity change, and what this means for crypto over the next 3-6 months.

**Example Output:**
> **Global Liquidity Assessment:**
>
> **US M2:** $20.8T, up 2.1% YoY. First sustained increase after 18 months of contraction. This is the most important single metric for crypto — M2 expansion historically correlates with BTC rallies with a 2-3 month lag.
>
> **Fed Balance Sheet:** Still in QT mode, reducing at $60B/month. Headwind, but slowing (was $95B/month).
>
> **ECB:** Holding rates, expected to cut before the Fed. Mildly expansionary.
> **BOJ:** Still accommodative. Yen carry trade intact — supports global risk appetite.
> **PBOC:** Easing credit conditions. $500B in new stimulus announced.
>
> **Net Assessment:** Global liquidity is EXPANDING for the first time in 2 years. Three of four major central banks are easing or holding. Only the Fed is still tightening, and they're expected to pivot by mid-year.
>
> **Crypto Implication:** This is the macro setup for a sustained rally. M2 expansion + approaching rate cuts + global easing = favorable liquidity conditions. The 2-3 month lag from M2 turning positive puts the crypto acceleration timeline at Q2 2026.

---

### 5. Yield Curve Interpretation

**System Prompt:**
You interpret the US Treasury yield curve and its implications for risk assets including crypto. You track: 2y/10y spread, 3m/10y spread, and real yields.

**User Prompt:**
Interpret the current yield curve shape and what it means for crypto. 2-year yield: [VALUE]%. 10-year yield: [VALUE]%. 2y/10y spread: [VALUE]. Is the curve inverted, normalizing, or steepening? Historical implications.

2Y: [VALUE]%
10Y: [VALUE]%
Spread: [VALUE]

**Example Output:**
> **2Y: 4.60%. 10Y: 4.25%. Spread: -0.35% (inverted)**
>
> **Status:** Yield curve has been inverted for 18 months. It's now less inverted than 6 months ago (-0.35% vs. -1.00%). The curve is normalizing (un-inverting).
>
> **What This Means:** The initial inversion predicted a recession (historically reliable signal). The normalization typically occurs as the recession approaches or the Fed pivots. The curve un-inverting is NOT the all-clear — it often steepens right before economic pain arrives.
>
> **Crypto Implication:** Paradoxically, the early stages of curve normalization can be bullish for crypto because it signals rate cuts are coming. However, if the economy actually enters recession, risk assets (including crypto) sell off initially before the liquidity response (QE, rate cuts) creates the next leg up.
>
> **Watch:** If the 2y/10y spread turns positive, expect volatility. The transition period is usually messy.

---

### 6-10. Specific Macro Prompts

### 6. Employment Data Impact
**User Prompt:** NFP (Non-Farm Payrolls) came in at [NUMBER] vs. [EXPECTED]. Unemployment rate: [%]. What does this mean for Fed policy and crypto? Is "bad news good news" (weak jobs = more cuts = bullish) or "bad news is bad news" (recession fears)?

**Example Output:** "NFP: 125K vs. 200K expected. Unemployment 4.1%. This is 'bad news is good news' territory. The labor market is cooling enough to justify rate cuts but not collapsing enough to signal recession. Rate cut probability for June jumped from 60% to 78%. Crypto should react positively within 24-48 hours."

### 7. Geopolitical Risk Assessment
**User Prompt:** A major geopolitical event is occurring: [EVENT]. Assess the crypto market impact through: safe-haven narrative (does BTC benefit?), risk-off sentiment (does everything sell?), and historical precedent for similar events.

**Example Output:** "Geopolitical escalation in [region]. Historical pattern: initial sell-off across all risk assets (BTC -5-10%), followed by recovery within 1-2 weeks as flight-to-safety buying resumes. BTC's safe-haven narrative strengthens during prolonged geopolitical tension but weakens during acute crisis moments. Reduce leverage, increase stablecoin allocation, prepare to buy the dip if it's a 1-week event."

### 8. Real Interest Rate Analysis
**User Prompt:** Calculate the real interest rate (Fed Funds rate minus inflation) and interpret its crypto impact. When real rates are deeply negative, risk assets thrive. When positive, they face headwinds.

**Example Output:** "Fed Funds: 5.0%. CPI: 3.4%. Real rate: +1.6% (positive). Positive real rates create opportunity cost for holding non-yielding assets like BTC. However, if CPI trends toward 2.5% while the Fed cuts to 4%, real rates narrow to +1.5% → still positive but improving. Crypto historically rallies when real rates are declining, even if still positive. The direction matters more than the level."

### 9. Risk Appetite Indicator Dashboard
**User Prompt:** Assess the current risk appetite environment using: VIX level, high-yield credit spreads, equity market trends, and crypto market cap relative to equities. Are we in risk-on, risk-off, or transition?

**Example Output:** "VIX: 14 (low — risk-on). HY spreads: 350bp (tight — risk-on). S&P: at ATH (risk-on). Crypto/equity ratio: recovering (risk-on). All risk indicators are green. This is a full risk-on environment. The risk: complacency. When everything is risk-on, the correction when it comes is sharp. Enjoy the ride but keep stops tight."

### 10. Treasury Yield vs. DeFi Yield
**User Prompt:** Compare current US Treasury yields ([%]) to DeFi stablecoin yields. When Treasury yields exceed DeFi yields, capital flows out of crypto. When DeFi yields exceed Treasuries, capital flows in. Where are we now?

**Example Output:** "10Y Treasury: 4.25%. DeFi stablecoin yields: Aave USDC 5.2%, Compound USDC 4.8%, Maker DSR 5.0%. DeFi yields are slightly above Treasury yields — the spread has been positive for the first time in 12 months. This is meaningful: it reverses the capital outflow that occurred when Treasuries offered 5%+ with zero risk. Capital should gradually return to DeFi as the yield premium sustains."

---

### 11-15. Macro Framework Prompts

### 11. Market Regime Identification
**User Prompt:** Based on current macro data (growth, inflation, monetary policy), identify the current market regime: goldilocks, reflation, stagflation, or deflation. What does each regime mean for crypto? Which regime are we in?

**Example Output:** "Current regime: REFLATION. Growth is moderate, inflation is sticky-but-declining, and monetary policy is shifting from tightening to easing. Reflation is historically the best regime for crypto — positive growth means risk appetite, and easing policy means liquidity expansion. This is the regime that powered BTC from $10K to $60K in 2020-2021."

### 12. Central Bank Divergence Analysis
**User Prompt:** Map the current monetary policy stance of the 5 major central banks (Fed, ECB, BOJ, BOE, PBOC). Identify divergences and how they affect currency flows and crypto.

### 13. Commodity Correlation Check
**User Prompt:** Analyze BTC's current correlation with gold, oil, and the S&P 500. Which asset is BTC tracking most closely? Has the correlation shifted recently? What does this tell us about BTC's current identity (risk asset vs. safe haven)?

### 14. Macro Event Calendar Strategy
**User Prompt:** Here are the major macro events for [MONTH]: [LIST]. For each, assess: expected market impact, how to position crypto exposure before and after, and whether to reduce or increase exposure.

### 15. Long-Term Macro Thesis for Crypto
**User Prompt:** Build a macro thesis for crypto over the next [1-2 YEARS]. Base it on: fiscal deficits, monetary policy trajectory, institutional adoption trends, and global liquidity cycles. Bull case, base case, and bear case with price targets.

**Example Output:**
> **Bull Case (30% probability):** Global coordinated easing, M2 expansion accelerates, BTC ETF inflows exceed expectations, institutional allocation reaches 2% of portfolios. BTC: $150K-$200K.
>
> **Base Case (50% probability):** Gradual rate cuts, moderate liquidity expansion, steady institutional adoption. Normal cycle dynamics. BTC: $100K-$130K.
>
> **Bear Case (20% probability):** Recession triggers risk-off selloff, regulatory crackdown, geopolitical shock. BTC: $40K-$60K before recovery.
>
> **Key Variables:** The biggest swing factor is liquidity. If M2 expansion continues above 5% YoY, the bull case becomes dominant. If M2 contracts again, bear case activates.

---

*15 macro analysis prompts. Markets don't exist in a vacuum. Neither should your analysis.*
