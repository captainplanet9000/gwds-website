# Risk Management Prompts

25 prompts for position sizing, portfolio review, risk assessment, drawdown analysis, and protecting your capital.

---

### 1. Position Size Calculator

**System Prompt:**
You are a risk management specialist for crypto traders. You calculate position sizes based on account size, risk tolerance, and stop-loss distance. You never recommend risking more than 2% of capital on a single trade. You show your math.

**User Prompt:**
Calculate the optimal position size for this trade:
- Account size: $[AMOUNT]
- Risk per trade: [1-2%]
- Entry price: $[PRICE]
- Stop-loss price: $[PRICE]
- Target price: $[PRICE]

Show: dollar risk, position size, R:R ratio, and whether this trade meets a minimum 2:1 R:R.

**Example Output:**
> **Calculation:**
> - Account: $50,000
> - Risk per trade: 1.5% = $750 max loss
> - Entry: $3,200 | Stop: $3,050 | Target: $3,600
> - Stop distance: $150 per unit (4.7%)
> - Position size: $750 / $150 = 5 units
> - Position value: 5 × $3,200 = $16,000 (32% of account)
> - R:R: ($3,600-$3,200) / ($3,200-$3,050) = $400/$150 = **2.67:1** ✅
>
> **Verdict:** Trade meets minimum 2:1 R:R. Position size is reasonable at 32% of account with a 1.5% risk. Proceed if technical setup confirms.

---

### 2. Portfolio Risk Assessment

**System Prompt:**
You are a portfolio risk analyst for crypto holdings. You assess: concentration risk, correlation risk, sector exposure, and overall portfolio vulnerability to specific scenarios. You're conservative and flag anything that could cause >20% portfolio drawdown.

**User Prompt:**
Assess the risk profile of this portfolio:
[LIST POSITIONS WITH ALLOCATION %]
Total portfolio value: $[AMOUNT]

Analyze: concentration risk, correlation between holdings, sector exposure, and vulnerability to a 30% BTC correction.

**Example Output:**
> **Portfolio:**
> - BTC: 40% ($20K)
> - ETH: 25% ($12.5K)
> - SOL: 15% ($7.5K)
> - LINK: 10% ($5K)
> - USDC: 10% ($5K)
>
> **Concentration Risk: MODERATE.** BTC + ETH = 65%. These are correlated at 0.85+. In a downturn, 65% of your portfolio moves in the same direction.
>
> **Correlation Risk: HIGH.** All four crypto assets have >0.7 correlation to BTC. Your 90% crypto allocation effectively behaves like a leveraged BTC position with extra volatility from alts.
>
> **BTC -30% Scenario:**
> - BTC: -30% → $14K loss → $14K remaining
> - ETH: likely -35-40% → $7.5K-$8.1K remaining
> - SOL: likely -40-50% → $3.75K-$4.5K remaining
> - LINK: likely -40-45% → $2.75K-$3K remaining
> - USDC: $5K (safe)
> - **Estimated portfolio after BTC -30%: ~$33K (-34%)**
>
> **Recommendation:** Consider increasing USDC/stables to 20-25% if you can't stomach a 34% drawdown. Or add non-correlated positions (gold exposure, yield-bearing stables).

---

### 3. Risk-Reward Scenario Analysis

**System Prompt:**
You model trade scenarios with probability-weighted outcomes. You calculate expected value by assigning probabilities to bull, base, and bear cases.

**User Prompt:**
Model three scenarios for [TOKEN] position:
- Entry: $[PRICE]
- Bull case target: $[PRICE] (probability: [%])
- Base case target: $[PRICE] (probability: [%])
- Bear case (stop): $[PRICE] (probability: [%])
- Position size: $[AMOUNT]

Calculate the expected value and whether this trade has positive expectancy.

**Example Output:**
> **Bull case:** $3,200 → $3,800 = +$600/unit (25% probability)
> **Base case:** $3,200 → $3,400 = +$200/unit (45% probability)
> **Bear case:** $3,200 → $3,000 = -$200/unit (30% probability)
>
> **Expected Value per unit:**
> (0.25 × $600) + (0.45 × $200) + (0.30 × -$200) = $150 + $90 - $60 = **+$180/unit**
>
> **EV on $10K position (3.125 units):** +$562.50
>
> **Assessment:** Positive expected value (+5.6% EV on position). This is a mathematically sound trade. The key risk: the 30% bear case probability isn't extreme, but a -6.25% loss on your portfolio is within tolerance.

---

### 4. Maximum Drawdown Analysis

**System Prompt:**
You analyze trading history to calculate maximum drawdown, drawdown duration, and recovery patterns. You help traders understand their risk exposure based on real performance.

**User Prompt:**
Analyze this trading history for maximum drawdown:
[LIST OF TRADES WITH P&L OR EQUITY CURVE DATA]
Starting capital: $[AMOUNT]

Calculate: max drawdown (%), longest drawdown period, average recovery time, and current drawdown from peak.

**Example Output:**
> **Equity Curve Analysis:**
> - Peak equity: $62,000 (reached Feb 15)
> - Trough equity: $48,500 (reached Feb 28)
> - Current equity: $52,000
>
> **Maximum Drawdown: -21.8%** ($62K → $48.5K)
> **Drawdown Duration:** 13 days (and counting — not yet recovered)
> **Current Status:** Recovering. Currently -16.1% from peak.
>
> **Historical Pattern:** This is the deepest drawdown in the sample. Previous worst: -14%. Average drawdown: -8%.
>
> **Warning:** A 21.8% drawdown requires a 27.8% gain to recover. If this drawdown frequency increases, the strategy may need adjustment. Review the losing trades from Feb 15-28 for pattern recognition.

---

### 5. Correlation Matrix Builder

**System Prompt:**
You build and interpret correlation matrices for crypto portfolios. You identify hidden correlations and suggest diversification improvements.

**User Prompt:**
Build a correlation matrix for these assets over the last [PERIOD]: [LIST ASSETS]. Identify: which pairs are most correlated (>0.8), which are least correlated (<0.3), and any negative correlations. Suggest portfolio adjustments for better diversification.

Assets: [LIST]
Period: [30/60/90 DAYS]

**Example Output:**
> **Correlation Matrix (60-day):**
>
> |      | BTC  | ETH  | SOL  | LINK | GOLD | USD  |
> |------|------|------|------|------|------|------|
> | BTC  | 1.00 | 0.87 | 0.82 | 0.79 | 0.15 | -0.25|
> | ETH  |      | 1.00 | 0.85 | 0.83 | 0.12 | -0.22|
> | SOL  |      |      | 1.00 | 0.76 | 0.08 | -0.20|
> | LINK |      |      |      | 1.00 | 0.10 | -0.18|
>
> **High Correlation Pairs (>0.8):** BTC/ETH (0.87), ETH/SOL (0.85), ETH/LINK (0.83), BTC/SOL (0.82)
>
> **Diversification Gaps:** All crypto assets are highly correlated. Adding GOLD (0.08-0.15 correlation) or USD stables would genuinely diversify. Currently the portfolio has ~4 correlated bets, not 4 diversified positions.

---

### 6. Stop-Loss Strategy Optimizer

**System Prompt:**
You optimize stop-loss placement based on technical levels, ATR, and the trader's risk tolerance. You balance between stops that are too tight (frequent stop-outs) and too wide (excessive loss per trade).

**User Prompt:**
Recommend a stop-loss strategy for [TOKEN] on [TIMEFRAME]. Consider: ATR-based stops, support-level stops, percentage-based stops, and trailing stops. Current price: [PRICE]. ATR: [VALUE]. Nearest support: [PRICE].

Token: [TOKEN]
Timeframe: [TIMEFRAME]
Current price: [PRICE]
14-period ATR: [VALUE]
Nearest support: [PRICE]

**Example Output:**
> **Option 1: ATR-Based (2x ATR)**
> Stop: $3,200 - (2 × $180) = $2,840. Risk: 11.25%. Wide but statistically sound — gives the trade room to breathe. Best for: swing trades held for days.
>
> **Option 2: Support-Level Based**
> Stop: $3,050 (below nearest support with $50 buffer). Risk: 4.7%. Tighter, more capital efficient. Best for: trades with clear structural levels.
>
> **Option 3: Percentage-Based (5%)**
> Stop: $3,040. Risk: 5%. Simple and consistent. Doesn't account for market structure but easy to manage.
>
> **Recommendation:** Use Option 2 (support-based) for this setup. The support at $3,100 has been tested 5 times — placing the stop at $3,050 gives buffer while keeping risk manageable. If stopped out, the thesis is invalidated anyway.

---

### 7-12. Portfolio Management Prompts

### 7. Rebalancing Analysis
**User Prompt:** My portfolio targets are [LIST TARGETS]. Current allocations are [LIST ACTUAL]. Calculate the trades needed to rebalance and the tax implications of rebalancing (assumes [SHORT/LONG-TERM] capital gains).

**Example Output:** "BTC: 40% target, 52% actual → sell $6K of BTC. ETH: 30% target, 22% actual → buy $4K ETH. SOL: 15% target, 18% actual → sell $1.5K SOL. Stables: 15% target, 8% actual → net $3.5K moves to stables. Tax note: selling $7.5K worth of assets — if all at a gain, estimated tax liability at 15% LTCG: ~$1,125."

### 8. Leverage Risk Calculator
**User Prompt:** I want to open a [X]x leveraged position on [TOKEN]. Account size: $[AMOUNT]. Calculate: liquidation price, margin required, maximum adverse move before liquidation, and whether this leverage level is appropriate for the current volatility.

**Example Output:** "5x long on ETH at $3,200. Margin: $2,000 for a $10,000 position. Liquidation: approximately $2,620 (depends on exchange margin model). That's 18% below entry. Current ATR suggests 5.6% daily swings — you could be liquidated by normal volatility within 3 days. Recommendation: reduce to 2-3x or use a hard stop well above liquidation."

### 9. Black Swan Preparation
**User Prompt:** Model a black swan event for my portfolio. If [TOKEN] drops 50% in 24 hours (exchange hack, regulatory ban, or similar), what happens to my portfolio? What protection measures should I have in place?

**Example Output:** "Portfolio impact of a 50% ETH crash: ETH position ($12.5K) → $6.25K. Correlated assets (SOL, LINK) likely drop 30-40% in sympathy. Total portfolio estimate: $50K → ~$30K (-40%). Protection measures: (1) Put options if available, (2) Stablecoin allocation of 20%+ as crash insurance, (3) Emergency stop-losses set on all positions, (4) Hardware wallet for long-term holds (exchange risk)."

### 10. Risk Per Day Calculator
**User Prompt:** I have [NUMBER] open positions. Calculate my total risk exposure if all stop-losses are hit simultaneously. Is my aggregate risk within acceptable limits (max 5% of total portfolio)?

**Example Output:** "Position 1: $750 at risk. Position 2: $500 at risk. Position 3: $600 at risk. Total risk if all stops hit: $1,850. Portfolio: $50,000. Aggregate risk: 3.7%. Within the 5% maximum. However, note that a correlated crash could trigger all stops simultaneously — these aren't independent risks."

### 11. Win Rate & Expectancy Tracker
**User Prompt:** Based on my last [NUMBER] trades, calculate: win rate, average win, average loss, profit factor, and trading expectancy. Assess whether my strategy has positive expectancy.

**Example Output:** "50 trades. Win rate: 56% (28W / 22L). Avg win: $420. Avg loss: $280. Profit factor: (28 × $420) / (22 × $280) = $11,760 / $6,160 = 1.91. Expectancy per trade: (0.56 × $420) - (0.44 × $280) = $235.20 - $123.20 = +$112. POSITIVE EXPECTANCY. Strategy is profitable over a large sample. Key: maintain discipline and don't change parameters during losing streaks."

### 12. Monthly Risk Budget
**User Prompt:** Create a monthly risk budget for a $[AMOUNT] trading account. Allocate risk across: active trades, new positions, swing positions, and emergency reserve. Maximum monthly loss tolerance: [%].

**Example Output:** "Monthly budget for $50K account, 10% max monthly loss ($5K): Active trades (3 max): $2,500 risk allocation (50% of budget). New position exploration: $1,000 risk allocation (20%). Swing holds: $1,000 risk allocation (20%). Emergency reserve (unallocated): $500 (10%). Rules: if monthly loss reaches $3,500 (70% of budget), reduce position sizes by 50%. If $5K loss reached, stop trading for the remainder of the month."

---

### 13-19. Advanced Risk Prompts

### 13. Kelly Criterion Position Sizing
**User Prompt:** Apply the Kelly Criterion to determine optimal position size given: win probability [%], average win size, and average loss size. Also calculate the half-Kelly recommendation (more conservative).

**Example Output:** "Kelly % = (0.56 × 1.5 - 0.44) / 1.5 = 0.267 = 26.7% of capital. Half-Kelly (recommended): 13.35% of capital per trade. For a $50K account: max $6,675 per position. Full Kelly is mathematically optimal but the volatility is brutal — half-Kelly gives 75% of the growth with half the drawdowns."

### 14. Tail Risk Assessment
**User Prompt:** Assess the tail risk (probability of extreme events) for [TOKEN/PORTFOLIO]. Model the impact of a 3-sigma and 5-sigma move. What historical events caused similar moves?

**Example Output:** "ETH daily return standard deviation: 4.2%. 3-sigma move: ±12.6% in one day. Probability: ~0.3% per day (about once per year). 5-sigma move: ±21% in one day. Probability: ~0.00006% (should almost never happen). Historical: ETH has had 3-sigma+ days 8 times in 2024 — more frequent than theory predicts. Crypto has fat tails — use 2x the theoretical probability for risk planning."

### 15. Drawdown Recovery Calculator
**User Prompt:** I'm currently in a [%] drawdown. Calculate: the gain needed to recover, estimated recovery time based on my historical monthly returns, and whether I should adjust strategy during recovery.

**Example Output:** "Current drawdown: -25%. Gain needed to recover: +33.3%. At your historical average of +8%/month: recovery time ≈ 4 months. At reduced performance during drawdown recovery (typical: 60% of normal): ≈ 7 months. Strategy adjustment: DO NOT increase risk to 'make it back faster.' This is the #1 mistake traders make during drawdowns. Maintain or reduce position sizes until you recover 50% of the drawdown."

### 16. Stress Test: Multi-Scenario
**User Prompt:** Stress test my portfolio against: (1) BTC drops 40%, (2) stablecoin depeg event, (3) major exchange goes insolvent, (4) regulatory crackdown. For each: estimate portfolio impact and mitigation strategy.

### 17. Hedging Strategy Generator
**User Prompt:** I'm long $[AMOUNT] of [TOKEN]. Design a hedging strategy using: options, shorts, or correlated assets. Target: protect against >15% downside while maintaining upside exposure.

### 18. Risk-Adjusted Return Comparison
**User Prompt:** Compare the risk-adjusted returns of [STRATEGY A] vs [STRATEGY B] using Sharpe ratio, Sortino ratio, and max drawdown. Which is superior on a risk-adjusted basis?

### 19. Liquidation Cascade Risk
**User Prompt:** Assess the liquidation cascade risk for [TOKEN] at current leverage levels. If price drops to [PRICE], how many liquidations are estimated? Could this cascade cause a deeper drop?

---

### 20-25. Quick Risk Prompts

### 20. Pre-Trade Checklist
**User Prompt:** Run a pre-trade risk checklist for: [TOKEN] [LONG/SHORT] at [PRICE]. Check: position size within limits, R:R above 2:1, stop-loss defined, no overlapping correlated positions, and aggregate risk within budget.

**Example Output:** "✅ Position size: $8K (16% of portfolio — within 25% max). ✅ R:R: 2.5:1. ✅ Stop at $3,050. ⚠️ Existing long ETH position is 0.85 correlated — combined crypto long exposure = 48% of portfolio. ❌ Aggregate risk with all stops hit: 6.2% — exceeds 5% maximum. Recommendation: reduce either this position or the ETH position by 20% to bring aggregate risk to 5%."

### 21. Risk Event Calendar
**User Prompt:** List upcoming risk events for the next [PERIOD] that could impact my [TOKEN] positions. Include: token unlocks, economic data releases, regulatory deadlines, and protocol upgrades.

### 22. Counterparty Risk Assessment
**User Prompt:** Assess the counterparty risk of holding funds on [EXCHANGE]. Consider: proof of reserves, regulatory status, insurance fund size, and historical incidents.

### 23. Dollar-Cost Average vs. Lump Sum Risk
**User Prompt:** I want to deploy $[AMOUNT] into [TOKEN]. Compare the risk profile of DCA over [PERIOD] vs. lump sum entry. Which approach has historically performed better for this asset class?

### 24. Exit Strategy Framework
**User Prompt:** Design an exit strategy for a profitable [TOKEN] position currently up [%]. Include: partial profit targets, trailing stop mechanism, and criteria for full exit.

**Example Output:** "Position up 40%. Exit plan: Sell 25% at current price (lock in some profit). Set trailing stop at 15% below peak for remaining 75%. If price reaches +60%, sell another 25%. Final 50% rides with a 10% trailing stop. Full exit: if price breaks below the 50-day MA on daily close, exit everything regardless of profit."

### 25. Annual Risk Review
**User Prompt:** Conduct an annual risk review for my trading. Analyze: largest single-trade loss, maximum drawdown, number of times risk limits were exceeded, correlation between losses (clustered or distributed), and recommendations for next year's risk parameters.

**Example Output:** "Annual Review: Largest loss: -$3,200 (March BTC flash crash). Max drawdown: -18% (March-April). Risk limits exceeded: 4 times (all during March — emotional trading during crash). Loss clustering: 70% of annual losses occurred in a 3-week period — suggesting emotional decision-making during volatility. Recommendation for next year: (1) Auto-reduce position sizes by 50% when portfolio drawdown exceeds -10%, (2) Implement a 24-hour cooling period after any loss exceeding 2%, (3) Increase stablecoin allocation to 25% during high-volatility periods."

---

*25 risk management prompts. Protect your capital first. Profits follow.*
