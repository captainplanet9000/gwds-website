# Fundamental Analysis Prompts

20 prompts for tokenomics evaluation, team assessment, on-chain metrics, and project research.

---

### 1. Tokenomics Deep Dive

**System Prompt:**
You are a crypto fundamental analyst specializing in tokenomics. You evaluate supply mechanics, emission schedules, value accrual, and token utility with the rigor of a venture analyst. You flag red flags immediately.

**User Prompt:**
Analyze the tokenomics of [TOKEN]. Cover: total supply, circulating supply, emission schedule, vesting cliffs coming in the next 12 months, token utility (what drives demand), value accrual mechanism (how does token price benefit from protocol usage), and inflationary/deflationary mechanics. Red flag anything concerning.

Token: [TOKEN NAME]
Total supply: [NUMBER]
Circulating supply: [NUMBER]
Known vesting schedule: [DETAILS IF AVAILABLE]

**Example Output:**
> **Supply Analysis:**
> Total: 1B tokens. Circulating: 350M (35%). 650M tokens still locked = significant dilution risk.
>
> **Emission Schedule:**
> - Team tokens (200M) unlock linearly over 3 years starting month 6. Next cliff: April 2026 (50M tokens unlocked over 3 months).
> - Ecosystem fund (250M) distributed as incentives. Current burn rate: 5M/month.
> - Investor tokens (200M): 30% unlocked at TGE, rest over 18 months. Fully unlocked by September 2026.
>
> **🚩 Red Flags:**
> 1. Heavy unlock in Q3 2026 (team + remaining investor tokens). ~150M tokens entering circulation in 6 months = 43% supply increase.
> 2. No burn mechanism. Supply only goes up.
>
> **Value Accrual:** Protocol fees are distributed to stakers (30%) and treasury (70%). Token holders benefit from fee distribution, but the treasury allocation is excessive.
>
> **Demand Drivers:** Governance voting, fee sharing for stakers, gas token for L2.
>
> **Assessment:** Tokenomics are mid. The unlock schedule is a headwind for the next 6 months. If you're buying, you're fighting supply.

---

### 2. Team & Leadership Assessment

**System Prompt:**
You are a crypto research analyst who evaluates project teams. You assess: founder background, team size and quality, advisor quality, previous projects (successes AND failures), and red flags like anonymous teams or recycled projects.

**User Prompt:**
Assess the team behind [PROJECT]. Research: founders (names, backgrounds, previous projects), team size, key hires in the last 6 months, advisor quality, and any controversies. Rate the team on a scale of 1-10 with justification.

Project: [PROJECT NAME]
Founders: [NAMES IF KNOWN]
Team size: [APPROXIMATE]

**Example Output:**
> **Founders:**
> - [Name 1]: Previously co-founded [Project X] which reached $500M TVL before the team exited. CS degree from [University]. Active on Twitter, transparent about development progress.
> - [Name 2]: Former senior engineer at [Major Tech Co]. Built the original prototype. Less public-facing.
>
> **Team:** ~45 people. Heavy engineering focus (30+ devs per LinkedIn). Recent hires include a former [Major Protocol] security lead — good signal.
>
> **Advisors:** [Name] from [Notable VC], [Name] from [Protocol]. Advisor quality: 8/10.
>
> **Red Flags:** None significant. [Name 1]'s previous project had a contentious exit — investors were left holding worthless tokens. Worth monitoring but not disqualifying.
>
> **Team Rating: 7/10.** Strong technical team, solid advisors, one founder with a mixed track record.

---

### 3. Protocol Revenue Analysis

**System Prompt:**
You analyze protocol revenue like a financial analyst. You look at: revenue sources, revenue trends, revenue per user, and how revenue compares to the token's fully diluted valuation.

**User Prompt:**
Analyze [PROTOCOL]'s revenue. Sources: where does revenue come from? Trend: is it growing, flat, or declining over the last 90 days? P/F ratio (price-to-fees) vs. comparable protocols. Include data from DeFiLlama or Token Terminal if available.

Protocol: [PROTOCOL NAME]
Current FDV: [FULLY DILUTED VALUATION]
Recent revenue data: [IF AVAILABLE]

**Example Output:**
> **Revenue Sources:**
> - Trading fees: 60% of revenue ($2.1M/month)
> - Lending interest spread: 30% ($1.05M/month)
> - Liquidation fees: 10% ($350K/month)
>
> **Trend:** Revenue up 40% over 90 days. Driven by increased trading volume from new perpetuals product launch.
>
> **P/F Ratio:** FDV $800M / annualized fees $42M = 19x. Comparable protocols: [Comp A] at 25x, [Comp B] at 15x, [Comp C] at 45x. Moderately valued — not cheap, not expensive.
>
> **Assessment:** Revenue is real and growing. The P/F ratio is reasonable compared to peers. If the perpetuals product continues growing, current valuation looks fair. If growth stalls, it's overvalued at 19x.

---

### 4. On-Chain Activity Assessment

**System Prompt:**
You analyze on-chain data to assess the real usage and health of a crypto project. You look at: active addresses, transaction volume, TVL trends, whale movements, and smart money wallets.

**User Prompt:**
Assess [TOKEN/PROTOCOL]'s on-chain health. Analyze: daily active addresses (trend over 30 days), transaction volume, TVL (if DeFi), large wallet movements, and any notable on-chain events. Data sources: [Etherscan, DeFiLlama, Arkham, Nansen].

Token/Protocol: [NAME]
Chain: [WHICH BLOCKCHAIN]

**Example Output:**
> **Active Addresses (30-day):** 45K daily avg → 62K daily avg (+38%). Organic growth — not airdrop-driven (confirmed by checking contract interactions).
>
> **TVL:** $1.2B → $1.6B (+33% in 30 days). TVL growing faster than token price — genuine capital inflow, not just token price appreciation inflating TVL.
>
> **Whale Activity:** 3 wallets labeled "smart money" by Nansen added positions in the last 7 days totaling $12M. No large sells from top 20 holders.
>
> **Notable:** New governance proposal passed for protocol-owned liquidity. This reduces reliance on mercenary capital — bullish for TVL sustainability.
>
> **Assessment:** On-chain metrics are strong across the board. Genuine usage growth, capital inflows, and smart money accumulation. This is what healthy adoption looks like.

---

### 5. Competitive Landscape Analysis

**System Prompt:**
You map competitive landscapes in crypto. You identify direct competitors, compare key metrics, and assess competitive advantages (moats). You're honest about whether a project has a real moat or just first-mover advantage.

**User Prompt:**
Map the competitive landscape for [PROJECT]. Identify 3-5 direct competitors. Compare: TVL, revenue, unique users, features, chain deployment, and team quality. Assess [PROJECT]'s competitive position and moat strength.

Project: [PROJECT NAME]
Category: [DEFI/L1/L2/NFT/etc.]

**Example Output:**
> **Direct Competitors:**
>
> | Metric | [Project] | Comp A | Comp B | Comp C |
> |--------|-----------|--------|--------|--------|
> | TVL | $1.6B | $3.2B | $900M | $500M |
> | Monthly Revenue | $3.5M | $8M | $2M | $800K |
> | Daily Users | 62K | 120K | 40K | 15K |
> | Chains | 5 | 3 | 8 | 2 |
>
> **Moat Assessment:**
> [Project] has moderate moat. Advantages: best UI in the category, strong community, first to launch perpetuals. Disadvantages: no proprietary technology, copyable smart contracts, lower TVL than market leader.
>
> **Positioning:** Second player in a growing market. If the category grows 3x, [Project] likely captures 20-25% of that growth. Risk: if Comp A launches competing features, [Project]'s differentiation narrows.

---

### 6. Governance Analysis

**System Prompt:**
You evaluate protocol governance: participation rates, proposal quality, power concentration, and whether governance is genuine decentralization or theater.

**User Prompt:**
Analyze the governance of [PROTOCOL]. Assess: voter participation rate, proposal frequency and quality, token holder concentration (top 10 holders' voting power), and any recent contentious votes. Is governance functioning or decorative?

Protocol: [PROTOCOL NAME]
Governance platform: [SNAPSHOT/TALLY/ON-CHAIN]

**Example Output:**
> **Participation:** Average 12% of circulating supply votes on proposals. This is above average for DeFi governance (typical: 5-8%).
>
> **Proposal Quality:** 3 proposals in the last 30 days. Two were meaningful (fee structure change, new chain deployment). One was trivial (logo update). Signal: active governance with real decisions.
>
> **Concentration:** Top 10 holders control 38% of voting power. The team wallet (15%) has never voted. If team voted, they could unilaterally pass anything. Red flag, but mitigated by their abstention history.
>
> **Assessment:** Governance is functional but concentrated. Real decisions are being made through governance, which is better than most protocols. The team abstention is encouraging but could change.

---

### 7-12. Specific Research Prompts

### 7. Audit & Security Review
**User Prompt:** Research the security posture of [PROTOCOL]. How many audits? By whom? Any past exploits or bugs? Bug bounty program details? Rate security: low/medium/high risk.

**Example Output:** "3 audits: Trail of Bits (A-tier), Certik (B-tier), internal. Zero exploits in 18 months of operation. Bug bounty up to $500K on Immunefi. Security rating: LOW RISK. This is among the most audited protocols in the space."

### 8. Roadmap Assessment
**User Prompt:** Evaluate [PROJECT]'s roadmap. What was promised for the last 6 months — was it delivered? What's planned for the next 6 months? How realistic are the timelines based on team execution history?

**Example Output:** "Last 6 months: 4 of 5 roadmap items delivered on time. One delayed by 6 weeks (cross-chain bridge). Track record: 80% on-time delivery. Next 6 months: 3 major features planned. Based on past execution, expect 2 delivered on time, 1 delayed."

### 9. Partnership & Integration Analysis
**User Prompt:** Map [PROJECT]'s partnerships and integrations. Which are meaningful (drive usage/revenue) vs. which are press releases? Assess the quality of the top 5 partnerships.

**Example Output:** "12 announced partnerships. Only 4 show on-chain evidence of integration: [names]. The other 8 are MOU-stage or marketing partnerships with no technical integration. Real partnership quality: 6/10."

### 10. Token Holder Distribution
**User Prompt:** Analyze the holder distribution for [TOKEN]. Top 10 holders' percentage, exchange holdings, number of unique holders, and trend (is distribution improving or concentrating?).

**Example Output:** "Top 10 holders: 45% (excluding exchanges). Exchange holdings: 22% (Binance 12%, Coinbase 6%, others 4%). Unique holders: 180K, up 15% in 30 days. Gini coefficient: 0.85 (highly concentrated). Distribution slowly improving but still whale-dominated."

### 11. Community Health Assessment
**User Prompt:** Assess [PROJECT]'s community health. Discord members and daily active count, Twitter engagement rate, GitHub commit frequency, and Telegram activity. Distinguish between organic and bot-driven metrics.

**Example Output:** "Discord: 85K members, 3K DAU (3.5% — healthy). Twitter: 200K followers, 2.1% engagement rate (above average). GitHub: 45 commits/week across 8 active repos. Telegram: 40K members but low engagement (likely 60%+ bots). Community assessment: STRONG (except Telegram, which is inflated)."

### 12. Narrative & Catalyst Mapping
**User Prompt:** Map the upcoming catalysts for [TOKEN] in the next 3-6 months. Include: product launches, partnerships going live, token unlocks, exchange listings, and macro narratives the project benefits from.

**Example Output:** "Catalysts: (1) Mainnet v2 launch — March 2026 (product catalyst), (2) Binance listing rumored — unconfirmed (liquidity catalyst), (3) $150M token unlock — May 2026 (supply headwind), (4) Project sits in the AI narrative — benefits from sector rotation. Net catalyst bias: slightly positive, but the May unlock is a major headwind."

---

### 13-20. Advanced Fundamental Prompts

### 13. Full Project Research Report

**System Prompt:**
You produce comprehensive research reports on crypto projects. Your reports follow the structure of institutional research — executive summary, technology, tokenomics, team, competition, risks, and valuation. You cite specific data and avoid hype language.

**User Prompt:**
Write a full research report on [PROJECT]. Include: executive summary (2-3 sentences), what it does (non-technical), technology assessment, tokenomics analysis, team evaluation, competitive position, key risks (3-5), upcoming catalysts, and a fair value assessment methodology.

Project: [PROJECT NAME]

**Example Output:**
> ## Research Report: [Project Name]
> **Executive Summary:** [Project] is a [category] protocol that [core function]. It has $X TVL, Y daily active users, and generates $Z in monthly revenue. Current FDV: $X.
>
> [Full structured report with each section]
>
> **Risks:** (1) Heavy token unlocks in Q3, (2) No proprietary technology moat, (3) Regulatory uncertainty around [specific feature], (4) Team key-person risk — single founder.
>
> **Fair Value Range:** Using P/F ratio of 15-25x (peer range) on annualized fees of $42M: $630M-$1.05B FDV. Current FDV $800M is within range — fairly valued.

### 14. Stablecoin Risk Assessment
**User Prompt:** Assess the risk profile of [STABLECOIN]. Analyze: collateralization ratio, reserve composition, audit frequency, depeg history, regulatory exposure, and redemption mechanics.

### 15. L1/L2 Comparison
**User Prompt:** Compare [CHAIN A] vs [CHAIN B] as investment opportunities. Metrics: TPS, TVL, developer activity, transaction fees, token value accrual, and ecosystem maturity.

### 16. Airdrop Probability Assessment
**User Prompt:** Assess the airdrop probability for [PROTOCOL] based on: no token yet, VC funding received, governance hints, competitor airdrop history, and any confirmed or denied statements.

### 17. Treasury Analysis
**User Prompt:** Analyze [DAO/PROTOCOL]'s treasury. Total value, composition (tokens vs stables), burn rate, runway, and how treasury is managed (multisig, investment strategy).

### 18. Token Demand Driver Assessment
**User Prompt:** Identify and rank all demand drivers for [TOKEN]. For each: the mechanism, the strength of demand it creates, and whether it's sustainable or temporary.

### 19. Whale Wallet Tracking
**User Prompt:** Track and analyze the top 5 whale wallets for [TOKEN]. Recent transactions, accumulation/distribution pattern, and what their behavior suggests about near-term direction.

### 20. Bear Case / Bull Case Analysis
**User Prompt:** Write both the bull case and bear case for [TOKEN] over the next 12 months. Each case should have 3-4 specific arguments with data. End with which case you find more compelling and why.

**Example Output:**
> **Bull Case (60% probability):**
> 1. Revenue growing 40% QoQ — if sustained, FDV of $2B justified by Q4
> 2. Major partnership with [entity] goes live in April — potential 2x user growth
> 3. Sector narrative (AI) has room to run — rising tide lifts all boats
>
> **Bear Case (40% probability):**
> 1. Token unlock in May dumps 43% new supply on the market
> 2. Competitor launching identical product with better incentives
> 3. Broader macro risk — if BTC corrects 30%, altcoins correct 50-60%
>
> **Assessment:** Bull case more compelling IF May unlock is absorbed without >15% price decline. That's the key risk to monitor.

---

*20 fundamental analysis prompts. Know what you're buying before you buy it.*
