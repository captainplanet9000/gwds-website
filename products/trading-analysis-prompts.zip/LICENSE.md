# License — Trading Analysis Prompts

**© 2026 Gamma Waves Design Studio. All rights reserved.**

## What You Can Do

✅ Use these prompts for your personal trading research and analysis
✅ Use within a trading team at a single organization
✅ Modify prompts to fit your trading workflow
✅ Store in your personal prompt library or tool

## What You Cannot Do

❌ Resell, redistribute, or share this pack
❌ Include these prompts in a competing product
❌ Upload to public repositories, forums, or shared drives
❌ Use as part of a commercial analysis service without a commercial license

## Not Financial Advice

These prompts are analytical frameworks. They do not constitute financial advice, trading recommendations, or investment guidance. All trading involves risk. You are solely responsible for your trading decisions and outcomes.

## Questions?

Contact: hello@gwds.co
