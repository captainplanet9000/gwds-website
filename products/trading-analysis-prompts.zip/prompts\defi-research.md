# DeFi Research Prompts

20 prompts for protocol analysis, yield farming evaluation, liquidity analysis, and smart contract risk assessment.

---

### 1. Protocol Deep Dive

**System Prompt:**
You are a DeFi research analyst who evaluates protocols like a venture investor. You assess: product-market fit, revenue model, competitive advantage, risk factors, and growth potential. You reference real metrics from DeFiLlama, Dune, and protocol dashboards.

**User Prompt:**
Conduct a deep dive on [PROTOCOL]. Cover: what it does (1 sentence), how it makes money, TVL and trend, daily users, revenue, competitive position, key risks, and your assessment of whether it's worth allocating capital to.

Protocol: [NAME]
Category: [DEX/LENDING/DERIVATIVES/YIELD/BRIDGE]
Chain(s): [WHICH CHAINS]
Current TVL: [AMOUNT]

**Example Output:**
> ## Protocol Deep Dive: [Protocol Name]
>
> **What it does:** Decentralized perpetual futures exchange with up to 50x leverage, no KYC.
>
> **Revenue model:** 0.1% trading fee on all trades. 70% to LPs, 30% to protocol treasury. Current daily volume: $500M → $500K daily revenue to protocol.
>
> **TVL:** $800M. Up 60% in 90 days. Growth is organic — no new incentive programs in the last 2 months.
>
> **Daily Users:** 12K unique addresses. Up from 8K 30 days ago (+50%).
>
> **Competitive Position:** #2 in on-chain perps by volume. #1 is 3x larger but losing market share. Advantage: better UX, lower fees, multi-chain deployment.
>
> **Key Risks:**
> 1. Smart contract risk — handling $800M with 2 audits (decent, not great)
> 2. Regulatory risk — perps without KYC is a target
> 3. LP risk — impermanent loss during high volatility events
>
> **Assessment:** Strong fundamentals, growing usage, real revenue. The P/F ratio is reasonable. Worth a position if you can accept the smart contract and regulatory risks. Size accordingly — no more than 5% of portfolio.

---

### 2. Yield Farming Strategy Evaluation

**System Prompt:**
You evaluate yield farming opportunities with a focus on real yield vs. inflation yield. You calculate the actual return after considering: impermanent loss, token emission dilution, gas costs, and the sustainability of the APR.

**User Prompt:**
Evaluate this yield farming opportunity:
- Protocol: [NAME]
- Pool: [PAIR]
- Advertised APR: [%]
- TVL of pool: [AMOUNT]
- Reward token: [TOKEN]
- Reward token trend: [RISING/FALLING/STABLE]

Calculate: real yield (after emissions dilution), impermanent loss risk, break-even timeframe, and your recommendation.

**Example Output:**
> **Advertised APR: 45%**
>
> **Yield Breakdown:**
> - Trading fees: 8% APR (real yield — sustainable)
> - Token emissions: 37% APR (inflationary — depends on token price)
>
> **Impermanent Loss Risk:** Pool is ETH/USDC. If ETH moves ±20%, IL ≈ 0.5-1%. At 8% real yield, you're covered even with moderate IL. If ETH moves ±50%, IL ≈ 2-5.7%. Net yield could turn negative on the fee portion alone.
>
> **Emission Sustainability:** Reward token is down 40% in 90 days. The 37% emission APR was 65% APR 90 days ago. It's declining because the reward token is losing value. Projected APR in 30 days if trend continues: ~28%.
>
> **Break-Even:** At 8% real yield, you break even on gas costs ($50 in/out) in approximately 45 days on a $10K deposit.
>
> **Recommendation:** The 8% real yield is solid. The emission yield is bonus but don't count on it. Enter with the mindset that you're earning 8% + whatever the reward token does. Sell reward tokens immediately unless you have a thesis on the reward token itself.

---

### 3. Liquidity Pool Risk Assessment

**System Prompt:**
You assess LP risks including: impermanent loss scenarios, smart contract risk, rug pull indicators, and liquidity concentration. You're blunt about risk — no sugarcoating.

**User Prompt:**
Assess the risk of providing liquidity to [POOL] on [PROTOCOL]. Pool details: [PAIR], TVL: [AMOUNT], top LP holders' share: [%]. Analyze: impermanent loss at various price movements, smart contract risk, concentration risk, and any rug indicators.

Pool: [PAIR]
Protocol: [NAME]
TVL: [AMOUNT]

**Example Output:**
> **Impermanent Loss Model (ETH/TOKEN pool, assuming TOKEN is volatile):**
> - TOKEN ±25%: IL ≈ 0.6% ($60 on $10K)
> - TOKEN ±50%: IL ≈ 2.0% ($200 on $10K)
> - TOKEN ±75%: IL ≈ 3.8% ($380 on $10K)
> - TOKEN to zero: IL = ~50% (you hold a worthless token and reduced ETH)
>
> **Smart Contract Risk: MEDIUM.** One audit by [Firm]. No exploits in 8 months. But the audit was for v1 — current version is v2 with unaudited additions.
>
> **Concentration Risk: HIGH.** Top 3 LPs hold 65% of the pool. If one withdraws, the remaining LPs face increased slippage risk and reduced fee income.
>
> **Rug Indicators:**
> - ✅ Multisig admin (3 of 5) — good
> - ⚠️ Timelock is only 12 hours — prefer 48h+
> - ✅ No mint function in token contract
> - ⚠️ Contract is upgradeable — admin can change logic
>
> **Risk Rating: MEDIUM-HIGH.** The upgradeable contract and short timelock are concerns. Position size accordingly — don't put more than you can afford to lose.

---

### 4. Bridge Risk Assessment

**System Prompt:**
You evaluate cross-chain bridge risk. Bridges are historically the highest-risk component in DeFi. You assess: security model, TVL at risk, audit history, past incidents, and team reputation.

**User Prompt:**
Assess the risk of using [BRIDGE] to move [AMOUNT] of [TOKEN] from [CHAIN A] to [CHAIN B]. Consider: security model (multisig, light client, ZK proof), past exploits, TVL, and whether the risk is worth it vs. alternatives.

Bridge: [NAME]
Amount: [HOW MUCH]
Route: [FROM → TO]

**Example Output:**
> **Security Model:** Multisig validation (5 of 9 validators). This is the weakest bridge security model — a compromised quorum can steal all funds.
>
> **TVL at Risk:** $300M. If this bridge is exploited, losses could be total.
>
> **Audit History:** 3 audits. Zero exploits in 14 months. Bug bounty: $1M on Immunefi.
>
> **Past Incidents:** None for this bridge. However, bridges with similar multisig models have been exploited multiple times (Ronin: $625M, Wormhole: $325M).
>
> **Alternatives:** [Alt Bridge 1] uses light client validation (more secure). [Alt Bridge 2] uses ZK proofs (most secure). Both take longer (20 min vs. 5 min).
>
> **Recommendation:** For $[AMOUNT], use [Alt Bridge 2] with ZK proofs despite the longer wait. The 15-minute time difference isn't worth the security tradeoff. If speed is critical for a time-sensitive trade, use the multisig bridge but only for amounts you can afford to lose entirely.

---

### 5. DeFi Protocol Comparison

**System Prompt:**
You compare DeFi protocols within the same category. You use real metrics and avoid brand loyalty. The best protocol for one user may not be the best for another.

**User Prompt:**
Compare [PROTOCOL A] vs [PROTOCOL B] vs [PROTOCOL C] for [USE CASE]. Metrics: TVL, fees, security, user experience, chain availability, and token economics. Include a recommendation matrix.

Protocols: [LIST]
Use case: [LENDING/TRADING/YIELD/BRIDGING]

**Example Output:**
> | Metric | Protocol A | Protocol B | Protocol C |
> |--------|-----------|-----------|-----------|
> | TVL | $2.1B | $800M | $3.5B |
> | Trading Fees | 0.05% | 0.1% | 0.04% |
> | Audits | 5 | 2 | 7 |
> | Chains | 8 | 3 | 5 |
> | Token APR (staking) | 12% | 25% | 8% |
> | UX Rating | 8/10 | 6/10 | 9/10 |
>
> **For lowest fees:** Protocol C
> **For highest yield:** Protocol B (but higher risk — fewer audits, smaller TVL)
> **For best security:** Protocol C (most audits, largest TVL)
> **For multi-chain:** Protocol A (8 chains)
>
> **Overall pick:** Protocol C for most users. Protocol A if you need a specific chain.

---

### 6-12. Specific DeFi Analysis Prompts

### 6. Lending Protocol Risk
**User Prompt:** Assess the risk of depositing [TOKEN] as collateral and borrowing [TOKEN] on [LENDING PROTOCOL]. Include: liquidation threshold, health factor calculation, oracle risk, and what a 30% market drop does to my position.

**Example Output:** "Depositing $10K ETH (LTV 80%) to borrow $6K USDC. Health factor: 1.33. A 30% ETH drop puts health factor at 0.93 — LIQUIDATED. Safe borrowing at 50% LTV: borrow $5K, health factor 1.6, can survive a 37% drop. Never borrow at max LTV unless you're actively monitoring."

### 7. Staking vs. LP vs. Lending Comparison
**User Prompt:** I have $[AMOUNT] of [TOKEN]. Compare the risk-adjusted returns of: single-side staking, providing LP, and lending it out. Which generates the best risk-adjusted return?

### 8. Flash Loan Attack Risk
**User Prompt:** Assess [PROTOCOL]'s vulnerability to flash loan attacks. Does it use TWAP oracles? Are there price manipulation vectors? Has it been tested in high-volatility events?

### 9. Governance Attack Vector Analysis
**User Prompt:** Assess the governance attack surface of [PROTOCOL]. What's the minimum token amount to pass a malicious proposal? Is there a timelock? Could a whale or coordinated group force through a harmful change?

### 10. Real Yield Calculator
**User Prompt:** Calculate the real yield (protocol revenue distributed to token holders) of [PROTOCOL]. Compare: total protocol revenue, amount distributed to stakers, staking participation rate, and effective yield vs. inflation from new token emissions.

**Example Output:** "Protocol revenue: $5M/month. Distributed to stakers: 30% = $1.5M/month. Staked supply: $500M. Real yield: 3.6% APR. Token emissions: 5% annual inflation = -5% dilution. Net yield for non-stakers: -5%. Net yield for stakers: 3.6% - 5% = -1.4%. You need the token to appreciate >1.4% to break even. The 'yield' is subsidized by inflation, not by protocol revenue."

### 11. TVL Quality Assessment
**User Prompt:** Assess the quality of [PROTOCOL]'s TVL. How much is incentivized (mercenary capital) vs. organic? What happens to TVL when incentives end? Historical TVL retention rate after incentive programs.

### 12. Airdrop Farming Risk/Reward
**User Prompt:** Evaluate the risk/reward of farming a potential airdrop from [PROTOCOL]. Estimated airdrop value based on comparable projects, capital required, time commitment, risk of capital loss, and opportunity cost.

**Example Output:** "Comparable airdrops (similar TVL, funding): $2K-$8K per wallet. Capital required: $5K-$10K deployed for 3+ months. Risk: smart contract risk on unaudited protocol + opportunity cost of locked capital. Expected value: $3K-5K (conservative estimate). Risk-adjusted: worth it if the capital deployed is <5% of your portfolio and the protocol has at least one audit."

---

### 13-20. Advanced DeFi Prompts

### 13. MEV Risk Assessment
**User Prompt:** Assess MEV (Maximal Extractable Value) risk for [TRADE TYPE] on [CHAIN]. How much value might be extracted? What protections exist (private mempools, MEV protection services)?

### 14. Stablecoin Depeg Risk Matrix
**User Prompt:** Create a risk matrix for stablecoins I hold: [LIST]. Rate each on: collateral quality, regulatory risk, depeg history, and smart contract risk. Which should I use for DeFi and which for storage?

### 15. DeFi Insurance Evaluation
**User Prompt:** Evaluate whether DeFi insurance is worth buying for [POSITION] on [PROTOCOL]. Cost of coverage vs. risk of loss vs. coverage limitations. Providers: [Nexus Mutual, InsurAce, etc.].

### 16. Concentrated Liquidity Strategy
**User Prompt:** Design a concentrated liquidity strategy for [PAIR] on [DEX]. Include: price range, expected APR, rebalancing triggers, and impermanent loss at range boundaries.

### 17. DeFi Yield Strategy Comparison
**User Prompt:** Compare these 3 yield strategies for $[AMOUNT] of [TOKEN]: [Strategy 1], [Strategy 2], [Strategy 3]. Risk-adjusted return, complexity, gas costs, and time investment.

### 18. Protocol Upgrade Risk
**User Prompt:** [PROTOCOL] is upgrading to [VERSION]. Assess the risks: has the new version been audited? Testnet performance? Migration risks? Should I withdraw during the upgrade?

### 19. Chain-Specific DeFi Ecosystem Review
**User Prompt:** Review the DeFi ecosystem on [CHAIN]. Map the top protocols by category (DEX, lending, derivatives, yield). Identify gaps and opportunities. Which protocols are most trusted?

### 20. DeFi Portfolio Construction
**User Prompt:** Design a DeFi-native portfolio strategy with $[AMOUNT]. Goals: [YIELD TARGET]% APR, maximum [RISK LEVEL] risk. Allocate across: stablecoin yield, blue-chip LP, single-side staking, and one higher-risk/higher-reward position.

**Example Output:**
> **$50K DeFi Portfolio — Target 12% APR, Moderate Risk**
>
> **40% ($20K) — Stablecoin Yield**
> USDC on Aave (Ethereum): 5% APR. Battle-tested, 7 audits, $10B TVL. Lowest risk.
>
> **25% ($12.5K) — Blue-Chip LP**
> ETH/USDC on Uniswap v3 (tight range): 8-15% APR from fees. IL risk managed by range selection.
>
> **20% ($10K) — Single-Side Staking**
> ETH staking via Lido: 3.5% APR + potential restaking yield. Liquid (can exit via stETH sale).
>
> **15% ($7.5K) — Higher Risk/Reward**
> [Protocol] perpetuals LP: 25-40% APR. Newer protocol, fewer audits, but strong growth metrics.
>
> **Blended Expected APR: 10-14%**
> **Max Drawdown Estimate: -15-20%** (during a major market crash)

---

*20 DeFi research prompts. Understand the protocol before you deposit.*
