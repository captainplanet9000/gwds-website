# Trade Planning Prompts

20 prompts for creating trade plans, defining entry/exit criteria, trade journaling, and performance reviews.

---

### 1. Complete Trade Plan Template

**System Prompt:**
You are a trading coach who helps traders create structured trade plans before entering any position. Your plans include every detail needed to execute the trade without emotional decision-making. If the plan doesn't have a clear edge, you say so.

**User Prompt:**
Create a complete trade plan for [TOKEN] [LONG/SHORT]. Include: thesis (why this trade), entry criteria (specific conditions), entry price/zone, position size, stop-loss (with reasoning), target 1 and target 2, R:R ratio, timeframe, and invalidation criteria. Also include: what you'll do if the trade goes against you and what you'll do if it hits target 1.

Token: [TOKEN]
Direction: [LONG/SHORT]
Account size: [AMOUNT]
Risk tolerance: [% PER TRADE]
Current price: [PRICE]
Key technical levels: [SUPPORT/RESISTANCE]

**Example Output:**
> ## Trade Plan: ETH Long
>
> **Thesis:** ETH forming ascending triangle on daily with bullish volume divergence. Weekly trend bullish. Breakout above $3,400 targets measured move to $4,000.
>
> **Entry Criteria:** Daily close above $3,400 WITH volume > 20-day average. No entry on a wick above — need a close.
>
> **Entry Zone:** $3,400-$3,450 (post-breakout confirmation)
> **Position Size:** 4 units ($13,600 / 27% of $50K portfolio)
> **Risk per trade:** 1.5% = $750
>
> **Stop-Loss:** $3,220 (below the ascending triangle trendline). Distance from entry: $180/unit.
> Position size check: $750 / $180 = 4.17 units → rounded to 4 units. Risk = $720. ✅
>
> **Target 1:** $3,800 (measured move 60%) — take 50% off
> **Target 2:** $4,000 (measured move 100%) — exit remaining 50%
> **R:R (to T1):** $400/$180 = 2.22:1 ✅
> **R:R (to T2):** $600/$180 = 3.33:1 ✅
>
> **Timeframe:** Swing trade — expecting 5-15 days to play out.
>
> **If trade goes against me:** Stop is hard. No moving it. If stopped, reassess but don't re-enter the same day.
>
> **If T1 hit:** Take 50% profit. Move stop on remaining to breakeven ($3,400). Let the rest ride to T2.
>
> **Invalidation:** If price breaks down below $3,100 before reaching entry, the ascending triangle is broken and the thesis is dead. No trade.

---

### 2. Entry Criteria Checklist

**System Prompt:**
You help traders define specific, objective entry criteria that remove emotional decision-making. Every criterion must be binary (yes/no) — no subjective judgment calls.

**User Prompt:**
Create an entry criteria checklist for [TRADE TYPE] trades on [TOKEN/MARKET]. Include 5-7 criteria that must ALL be met before entering. Each criterion must be objectively measurable.

Trade type: [BREAKOUT/PULLBACK/REVERSAL/TREND-FOLLOWING]
Token: [TOKEN]
Timeframe: [YOUR TIMEFRAME]

**Example Output:**
> ## Entry Checklist: Breakout Trades (Daily Timeframe)
>
> All boxes must be checked before entering:
>
> ☐ **Price closed above resistance** — not wicked, CLOSED
> ☐ **Volume on breakout candle > 1.5x 20-day average** — measured, not estimated
> ☐ **RSI between 50-70** — not already overbought
> ☐ **Weekly trend is bullish** (price above 20W MA)
> ☐ **No major news event in next 24 hours** (FOMC, CPI, etc.)
> ☐ **R:R minimum 2:1** to first target
> ☐ **Aggregate portfolio risk with this trade < 5%**
>
> **If even one box is unchecked:** NO TRADE. Wait for setup to fully form.

---

### 3. Exit Strategy Builder

**System Prompt:**
You design structured exit strategies that maximize gains while protecting profits. You create rules for partial exits, trailing stops, and full exits. No exits should require real-time emotional decisions.

**User Prompt:**
Design an exit strategy for a [TOKEN] position entered at [PRICE]. Define: partial exit points (with percentage to close), trailing stop mechanism, full exit criteria, and time-based exit (if the trade doesn't move in [DAYS]).

Token: [TOKEN]
Entry: [PRICE]
Position size: [AMOUNT]
Account size: [TOTAL]

**Example Output:**
> ## Exit Strategy
>
> **Partial Exits:**
> - At +10% ($3,520): close 25% of position. Move stop to breakeven.
> - At +15% ($3,680): close another 25%. Trail stop to +5% ($3,360).
> - At +25% ($4,000): close final 50%. Trade complete.
>
> **Trailing Stop (for remaining position after first partial):**
> After T1 hit: trail stop at 2x ATR below the most recent swing high. Currently that would be ~$200 below. Adjust daily.
>
> **Full Exit Triggers:**
> - Hard stop at -5.6% ($3,020) — no exceptions
> - Daily close below 20 MA after position is profitable = exit all
> - Extreme funding rate (>0.1%) = exit 50% regardless of price
>
> **Time-Based Exit:** If trade hasn't moved +5% in the direction of the thesis within 7 trading days, close at market. Dead money is a risk too.

---

### 4. Trade Journal Entry

**System Prompt:**
You are a trade journaling assistant. You help traders document trades with all relevant information for future review. The journal captures: what happened, why you entered/exited, what you did right, and what you'd change.

**User Prompt:**
Create a trade journal entry for this trade:
- Token: [TOKEN]
- Direction: [LONG/SHORT]
- Entry: [PRICE] on [DATE]
- Exit: [PRICE] on [DATE]
- P&L: [AMOUNT]
- Original thesis: [WHY YOU TOOK THE TRADE]

Analyze: did the thesis play out? Was the execution good? What would you do differently? Rate the trade quality 1-10 (separate from P&L).

**Example Output:**
> ## Trade Journal: ETH Long — Feb 15-22, 2026
>
> **Setup:** Ascending triangle breakout on daily
> **Entry:** $3,410 on Feb 15 (1 candle after confirmed breakout)
> **Stop:** $3,220 (placed correctly below trendline)
> **Exit:** $3,680 on Feb 22 (hit T1, took 50%. Remaining stopped at breakeven on pullback)
> **P&L:** +$540 (net on 4 units — $270 from T1, $0 from remainder)
>
> **Did thesis play out?** Partially. The breakout worked, price hit T1, but failed to reach T2 and reversed.
>
> **Execution review:**
> ✅ Entry was clean — waited for confirmation
> ✅ Stop was properly placed and never moved
> ✅ Took partial at T1 as planned
> ⚠️ Could have taken more off at T1 given weakening volume
> ❌ Didn't adjust trailing stop fast enough on remaining position
>
> **What I'd change:** Take 60-75% off at T1 when volume is declining into the move. The breakout was real but momentum was fading — I should have respected the volume divergence.
>
> **Trade Quality: 7/10.** Good plan, good entry, good partial. Lost some profit on the remaining position due to slow stop adjustment. Profitable trade with room for improvement in execution.

---

### 5. Weekly Performance Review

**System Prompt:**
You conduct structured weekly trading reviews. You analyze all trades from the week, identify patterns in wins and losses, assess whether the trader followed their rules, and provide specific improvement actions.

**User Prompt:**
Conduct a weekly trading review for these trades from [WEEK]:
[LIST ALL TRADES WITH ENTRY/EXIT/P&L]
Total P&L: [AMOUNT]
Win rate this week: [%]

Analyze: best trade and why, worst trade and why, rules followed/broken, patterns in outcomes, and one specific action item for next week.

**Example Output:**
> ## Weekly Review: Feb 17-21, 2026
>
> **Summary:** 7 trades. 4 wins, 3 losses. Win rate: 57%. Net P&L: +$1,280. Profit factor: 2.1.
>
> **Best trade:** ETH breakout long (+$540). Why: clear thesis, patient entry, disciplined execution.
>
> **Worst trade:** SOL long (-$420). Why: entered on FOMO after seeing it pump 8%. No breakout confirmation. Violated entry checklist (RSI was already 74 at entry).
>
> **Rules assessment:**
> - Entry checklist followed: 5 of 7 trades ✅ (2 trades entered without full checklist — both were losers)
> - Stop-losses respected: 7 of 7 ✅
> - Position sizing: 6 of 7 ✅ (one trade was 0.5% oversized)
>
> **Pattern identified:** Both losing trades this week were entered without completing the entry checklist. When checklist was followed: 4W/1L (80%). When ignored: 0W/2L (0%).
>
> **Action item for next week:** Physical checklist on desk. No trade executes until every box is checked. Laminate it.

---

### 6-10. Planning Framework Prompts

### 6. Monthly Trading Plan
**User Prompt:** Create a monthly trading plan for [MONTH]. Include: market outlook, assets I'll focus on, maximum number of trades, risk budget for the month, key dates to avoid trading around, and specific goals.

**Example Output:** "March 2026 plan: Focus on ETH and SOL setups. Max 15 trades. Monthly risk budget: 8% of portfolio ($4K). Avoid trading March 18-19 (FOMC). Goal: maintain 2:1 avg R:R and follow entry checklist on 100% of trades."

### 7. Pre-Market Analysis Template
**User Prompt:** Create a daily pre-market analysis template I can fill in every morning. Include: overnight developments, key levels for today, open position status, economic calendar events, and today's plan (trade or wait).

**Example Output:** Template with fields for: BTC overnight range, key S/R for the day, funding rate, any overnight news, open position updates (stop adjustments needed?), economic events, and a binary decision: "Today I will trade / Today I will observe."

### 8. Trade Idea Scoring System
**User Prompt:** Create a scoring system for evaluating trade ideas before execution. Categories: technical setup quality, fundamental support, risk/reward, market conditions, and conviction level. Minimum score to take a trade.

**Example Output:** "Score each 1-5: Technical setup (5=textbook, 1=forcing it), Fundamental backdrop (5=strong catalyst, 1=no fundamental reason), R:R (5=3:1+, 1=below 1:1), Market conditions (5=trending/clear, 1=choppy/uncertain), Conviction (5=high confidence, 1=gambling). Minimum score to trade: 18/25. Score below 15: hard pass."

### 9. Scaling Plan Builder
**User Prompt:** Build a scaling plan for entering [TOKEN] position. Instead of all-in at one price, define 3-4 entry levels, percentage at each level, and conditions for adding to the position.

**Example Output:** "Entry 1: 30% at $3,200 (current support test). Entry 2: 30% at $3,050 (200 MA + Fib 0.382). Entry 3: 40% at $2,900 (major support + Fib 0.5). Average entry if all filled: $3,035. Only add at Entry 2 and 3 if thesis remains intact (no break of market structure)."

### 10. Take-Profit Optimization
**User Prompt:** Analyze my last [NUMBER] trades. On profitable trades, did I exit too early, too late, or at the right time? Calculate: average MAE (Maximum Adverse Excursion) and MFE (Maximum Favorable Excursion) to optimize my profit-taking.

**Example Output:** "Analysis of 30 winning trades: Average exit captured 62% of the maximum favorable excursion (MFE). In 18 of 30 trades, price went at least 30% further than your exit. You're leaving money on the table. Recommendation: switch from fixed targets to trailing stops after reaching +50% of your initial target. This historically captures 15-25% more per trade."

---

### 11-15. Journal & Review Prompts

### 11. Trade Journal Debrief
**User Prompt:** I just closed a trade. Debrief me: was the trade consistent with my plan? Did I follow my rules? What emotion was I feeling when I entered and exited? Was this an A, B, or C-grade trade (regardless of P&L)?

### 12. Losing Streak Analysis
**User Prompt:** I've had [NUMBER] consecutive losing trades. Analyze the sequence: were the losses random (normal variance) or is there a pattern (same mistake repeated)? Should I adjust my approach or stay the course?

**Example Output:** "5 consecutive losses. Analysis: 3 of 5 were stopped out within normal ATR range (normal variance). 2 of 5 were entries against the larger trend (repeating mistake). The losing streak is 60% bad luck, 40% bad process. Action: keep trading but ONLY in the direction of the daily trend. No counter-trend entries until confidence rebuilds."

### 13. Emotional State Log
**User Prompt:** Create a pre-trade emotional check-in template. Before each trade, rate: stress level, FOMO intensity, revenge trading urge, confidence level, and sleep quality. If any reading is in the red zone, the trade is blocked.

**Example Output:** "Pre-trade check: Stress (1-5): __, FOMO (1-5): __, Revenge urge (1-5): __, Confidence (1-5): __, Sleep (hours): __. RED ZONE (no trading): Stress >4, FOMO >3, Revenge >2, Confidence <2, or Sleep <5 hours. If any metric is red, close the charts. Come back tomorrow."

### 14. Quarterly Strategy Review
**User Prompt:** Conduct a quarterly review of my trading strategy. Analyze: total P&L, win rate trend, average R:R achieved vs. planned, maximum drawdown, rule compliance %, and whether the strategy still has edge.

### 15. Trade Mistake Taxonomy
**User Prompt:** Categorize my last [NUMBER] losing trades by mistake type: (1) bad entry, (2) moved stop, (3) no stop, (4) FOMO entry, (5) revenge trade, (6) correct trade that lost (normal), (7) other. Which category is costing me the most?

**Example Output:** "20 losing trades: Bad entry (5) = $1,800 in losses. Moved stop (3) = $2,100. No stop (1) = $1,500. FOMO (4) = $1,600. Revenge (2) = $900. Normal losses (5) = $1,200. BIGGEST COST: moved stops ($2,100). This one behavior cost more than any other mistake category. Fix this ONE thing and your results improve by 25%."

---

### 16-20. Quick Planning Prompts

### 16. Trade Thesis Generator
**User Prompt:** Generate a structured trade thesis for [TOKEN] based on [ANALYSIS TYPE]. The thesis must be falsifiable — include the specific condition that would prove it wrong.

### 17. Opportunity Cost Analysis
**User Prompt:** I'm considering [TRADE A] vs [TRADE B]. Compare: R:R, probability of success, timeframe, capital required, and opportunity cost. Which is the better allocation of my capital?

### 18. End-of-Day Review Template
**User Prompt:** Create a 5-minute end-of-day review template. Include: trades taken (or why none taken), rules followed/broken, P&L, emotional state, and one observation about today's market.

### 19. Strategy Backtesting Prompt
**User Prompt:** Design a backtest framework for [STRATEGY] over the last [PERIOD]. Define: entry rules, exit rules, position sizing, and what metrics to track. How many trades should the sample include for statistical significance?

### 20. Trading Rules Document
**User Prompt:** Help me create a personal trading rules document. Based on my described trading style [DESCRIPTION], define: maximum positions, risk per trade, daily loss limit, maximum correlation exposure, and mandatory cooling-off rules.

**Example Output:**
> ## My Trading Rules (Non-Negotiable)
>
> 1. **Max risk per trade:** 1.5% of portfolio
> 2. **Max open positions:** 4
> 3. **Max correlated exposure:** 3 positions in same direction
> 4. **Daily loss limit:** 3% — if hit, close charts for 24 hours
> 5. **Weekly loss limit:** 5% — if hit, trade at 50% size next week
> 6. **Monthly loss limit:** 10% — if hit, stop trading for rest of month
> 7. **Every trade needs a written plan before execution**
> 8. **No trading during first and last 15 min of session (fakeouts)**
> 9. **No trading on <5 hours of sleep**
> 10. **Journal every trade within 1 hour of closing**

---

*20 trade planning prompts. Plan the trade. Trade the plan.*
