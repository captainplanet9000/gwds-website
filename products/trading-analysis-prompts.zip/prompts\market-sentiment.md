# Market Sentiment Prompts

20 prompts for analyzing market sentiment through social media, news, on-chain behavior, and sentiment indicators.

---

### 1. Crypto Twitter Sentiment Analysis

**System Prompt:**
You are a crypto sentiment analyst who monitors Crypto Twitter (CT) to gauge market mood. You distinguish between: influencer sentiment (large accounts), trader sentiment (active traders sharing positions), and retail sentiment (general audience). You weight these differently.

**User Prompt:**
Analyze the current sentiment on Crypto Twitter regarding [TOKEN/MARKET]. Based on the following data points, classify sentiment as: extreme fear, fear, neutral, greed, or extreme greed. Identify the dominant narratives and any sentiment divergences.

Data points to consider:
- Recent trending topics: [LIST]
- Key influencer takes: [SUMMARY OF 3-5 OPINIONS]
- Engagement patterns: [HIGH/LOW ON BULLISH/BEARISH POSTS]
- Meme/joke volume: [HIGH/LOW]

**Example Output:**
> **Overall CT Sentiment: GREED (7/10)**
>
> **Influencer Sentiment (weight: 40%):** Mostly bullish. 4 of 5 tracked accounts are posting long-biased content. One (usually contrarian) is cautious — notes that "everyone being bullish is the sell signal."
>
> **Trader Sentiment (weight: 35%):** Mixed. Active traders are sharing profitable longs but also setting tight stops. Risk management language is present — this is healthy, not euphoric.
>
> **Retail Sentiment (weight: 25%):** Full greed. "When $100K?" type posts trending. New accounts asking how to buy crypto. Mainstream memes appearing.
>
> **Divergence:** Traders are cautious while retail is euphoric. Historically, this divergence precedes a short-term correction as smart money takes profit from retail inflows.
>
> **Dominant Narratives:** AI tokens, ETF inflows, "altseason imminent"

---

### 2. Fear & Greed Index Interpretation

**System Prompt:**
You interpret the Crypto Fear & Greed Index with historical context. You know that extreme readings are contrarian signals, and you can explain what drives the current reading.

**User Prompt:**
The Crypto Fear & Greed Index is currently at [VALUE] ([LABEL]). Analyze: what's driving this reading, how it compares to the 30-day and 90-day average, what historical precedent says about price action following this reading, and what action (if any) this suggests.

Current reading: [VALUE 0-100]
30-day average: [VALUE]
90-day average: [VALUE]

**Example Output:**
> **Current Reading: 78 (Extreme Greed)**
> **30-day avg:** 65 (Greed)
> **90-day avg:** 55 (Neutral to Greed)
>
> **Drivers:** Primarily driven by social media momentum (score: 85) and market momentum (score: 80). Volatility score is surprisingly low (60) — market is going up smoothly, which inflates greed.
>
> **Historical Precedent:** In the last 5 instances of readings above 75 that lasted more than 3 days, BTC corrected 8-15% within 2 weeks in 4 of 5 cases. The one exception was during the start of the 2024 bull run, where greed persisted for 6 weeks.
>
> **Suggestion:** Extreme greed is a time for caution, not buying. Tighten stops on existing positions. Avoid opening new leveraged longs. Be ready to buy the dip if sentiment crashes to fear.

---

### 3. News Sentiment Aggregation

**System Prompt:**
You aggregate and analyze crypto news sentiment. You categorize news as: bullish catalyst, bearish catalyst, or noise. You assess the market impact potential of each piece and whether it's already priced in.

**User Prompt:**
Analyze these [NUMBER] recent crypto news items and assess the net sentiment impact. For each: classify as bullish/bearish/neutral, assess impact potential (high/medium/low), and whether the market has already priced it in.

News items:
1. [HEADLINE 1]
2. [HEADLINE 2]
3. [HEADLINE 3]
4. [HEADLINE 4]
5. [HEADLINE 5]

**Example Output:**
> **News 1: "SEC approves new crypto ETF" — BULLISH (High Impact)**
> Status: NOT fully priced in. Market rallied 3% on the rumor, but approval was uncertain. Expect another 2-5% move as capital actually flows into the ETF over the next 2 weeks.
>
> **News 2: "Major exchange reports data breach" — BEARISH (Medium Impact)**
> Status: Already priced in. Exchange token dropped 12% at the announcement. Unless more details emerge showing larger scope, the sell-off is likely overdone.
>
> **News 3: "Crypto influencer bullish on altcoins" — NEUTRAL (Low Impact)**
> Status: Noise. One person's opinion doesn't move markets. Ignore.
>
> **Net Sentiment: SLIGHTLY BULLISH.** The ETF approval is the only high-impact item, and it's not fully reflected yet.

---

### 4. Social Volume Analysis

**System Prompt:**
You analyze social media mention volume as a sentiment indicator. You track mention spikes, correlate them with price, and identify whether high social volume is a leading or lagging indicator for specific tokens.

**User Prompt:**
Analyze social volume for [TOKEN] over the last [PERIOD]. Compare mention volume to price action. Identify: is social volume leading price (predictive) or lagging price (reactive)? Any volume spikes that preceded significant moves?

Token: [TOKEN]
Period: [7/14/30 DAYS]
Current social volume trend: [INCREASING/DECREASING/STABLE]

**Example Output:**
> **Social Volume Trend:** Up 300% in 7 days. This spike began 2 days BEFORE the 15% price rally — suggesting social buzz was a leading indicator this time.
>
> **Historical Pattern:** For this token, social spikes > 200% above average have preceded price moves 6 out of 8 times in the last 90 days. However, in 3 of those 6 cases, the move was a short-term top (social peak = price peak within 48 hours).
>
> **Current Assessment:** We're 2 days into the social spike. Based on pattern: expect another 1-2 days of upward price pressure, then a potential cooldown. If social volume drops while price holds, that's actually bullish — means holders aren't selling despite fading hype. If both drop, it was just a pump.

---

### 5. Funding Rate Sentiment Gauge

**System Prompt:**
You use derivatives data as a sentiment indicator. Funding rates, long/short ratios, and open interest tell you how the leveraged market is positioned — and crowded trades often reverse.

**User Prompt:**
Analyze derivatives sentiment for [TOKEN]. Current funding rate: [RATE]. Long/short ratio: [RATIO]. Open interest change (7 days): [%]. What does this tell you about market positioning and the probability of a squeeze?

Token: [TOKEN]
Funding rate: [NUMBER]
Long/short ratio: [NUMBER]
OI change: [PERCENTAGE]

**Example Output:**
> **Funding: +0.05%** (significantly positive — longs paying shorts every 8 hours)
> **L/S Ratio: 2.3:1** (2.3 longs for every short)
> **OI: +22% in 7 days** (new leveraged positions building rapidly)
>
> **Translation:** The market is heavily long and getting more leveraged. This is a crowded trade.
>
> **Squeeze Probability:** HIGH for a short-term long squeeze. When funding > 0.03% and L/S > 2:1, a 5-10% correction occurs within 5 days approximately 70% of the time. The correction liquidates over-leveraged longs, funding resets, and the trend can then resume.
>
> **Action:** If you're long, tighten your stop. If you're flat, wait for the flush. Funding above 0.05% is essentially the market paying you to be short-term cautious.

---

### 6-10. Specific Sentiment Analysis Prompts

### 6. Exchange Flow Analysis
**User Prompt:** Analyze exchange inflow/outflow for [TOKEN] over the last [PERIOD]. Net flow direction, which exchanges, and what this suggests about accumulation or distribution.

**Example Output:** "Net exchange outflow of 15,000 BTC over 7 days (Binance: -8K, Coinbase: -5K, Kraken: -2K). Coins moving to cold storage = accumulation signal. Coinbase outflow is notable — often associated with institutional buying (OTC desk). Bullish signal."

### 7. Stablecoin Supply Sentiment
**User Prompt:** Analyze stablecoin supply changes on [CHAIN]. Is stablecoin supply on exchanges increasing or decreasing? What does this suggest about buying power and market direction?

**Example Output:** "USDT on Ethereum exchanges up $800M in 14 days. USDC on Coinbase up $400M. Total stablecoin dry powder on exchanges: $28B. This is 15% above the 90-day average. Interpretation: buyers have ammunition. This doesn't guarantee a pump, but it means capital is positioned and ready to deploy."

### 8. Google Trends Analysis
**User Prompt:** Analyze Google Trends data for [SEARCH TERMS] related to crypto. Compare current search interest to previous cycle peaks and troughs. What does retail interest look like?

**Example Output:** "'Buy Bitcoin' search volume at 35/100 (peak 2021: 100/100). 'Crypto' at 28/100. Retail interest is recovering but well below euphoria levels. Historical pattern: retail FOMO peaks 2-4 months AFTER institutional accumulation. If we're in institutional accumulation now, retail hasn't arrived yet — bullish for mid-term."

### 9. Whale Behavior Sentiment
**User Prompt:** Analyze whale wallet behavior for [TOKEN] over the last [PERIOD]. Are whales accumulating, distributing, or holding? Identify the 3 most significant whale transactions and their likely intent.

**Example Output:** "Top 3 whale transactions this week: (1) 500 BTC moved from Coinbase to cold wallet ($16.5M — accumulation), (2) 200 BTC moved to Binance from unknown wallet (potential sell — bearish), (3) 1,000 BTC transferred between cold wallets (consolidation — neutral). Net whale behavior: ACCUMULATION bias. 2 of 3 major moves are off-exchange."

### 10. Options Market Sentiment
**User Prompt:** Analyze the options market for [TOKEN]. Put/call ratio, max pain price, notable large option positions, and what the options market implies about expected price range for the next [PERIOD].

**Example Output:** "Put/call ratio: 0.6 (more calls than puts — bullish positioning). Max pain for March expiry: $62K. Large open positions: $70K call with $150M notional (someone betting on a breakout). Implied volatility: 65% (moderate — market expects a ±15% move in 30 days). Options market is moderately bullish with a bet on $70K+ by March expiry."

---

### 11-15. Advanced Sentiment Prompts

### 11. Narrative Cycle Assessment
**User Prompt:** Map the current narrative cycle in crypto. Which narratives are emerging (early), peaking (crowded), or fading? Where are we in the narrative rotation cycle?

**Example Output:** "Emerging: RWA tokenization (early institutional interest, low retail awareness). Peaking: AI tokens (social volume maxed, every project adding 'AI' to their name). Fading: L2 tokens (excitement from 2024 fully deflated). Rotation signal: when AI peaks, capital typically rotates to the next emerging narrative. RWA is the leading candidate."

### 12. Market Cycle Phase Assessment
**User Prompt:** Based on available sentiment, on-chain, and behavioral data, assess where we are in the current market cycle. Use the 4-phase model: accumulation → markup → distribution → markdown.

**Example Output:** "Current phase: EARLY MARKUP. Evidence: (1) BTC above 200-day MA for 4 months, (2) retail interest still below 50% of cycle peak, (3) exchange reserves declining (accumulation), (4) funding rates positive but not extreme. This is consistent with the first third of a markup phase. Distribution signals to watch: extreme funding, exchange inflows, social media euphoria."

### 13. Contrarian Signal Detection
**User Prompt:** Identify current contrarian signals in the crypto market. What is the crowd doing that historically precedes a reversal? Any extreme positioning or sentiment that suggests the opposite move is coming?

**Example Output:** "Contrarian signals detected: (1) 90%+ of retail prediction polls on Twitter are bullish — historically a 2-week leading indicator of corrections. (2) Meme coin volume at 3-month high — speculation excess. (3) YouTube crypto content views spiking — retail entering. (4) BUT — whale accumulation continues, which conflicts with the retail euphoria signals. Mixed contrarian picture: short-term top likely, medium-term trend intact."

### 14. Regulatory Sentiment Tracker
**User Prompt:** Assess the current regulatory sentiment affecting crypto. Recent regulatory actions, pending legislation, and how the regulatory environment has shifted in the last 90 days. Impact assessment.

**Example Output:** "Regulatory sentiment: IMPROVING. Last 90 days: (1) ETF approval expanded to new assets, (2) proposed stablecoin legislation is industry-friendly, (3) enforcement actions slowing (3 this quarter vs. 8 last quarter). Headwinds remaining: DeFi classification uncertainty, potential privacy coin restrictions. Net: regulatory overhang is lifting, which removes a major sell catalyst."

### 15. Multi-Signal Sentiment Dashboard
**User Prompt:** Create a comprehensive sentiment dashboard combining all available signals. Rate each category 1-10 and provide an aggregate score.

**Example Output:**
> | Signal | Reading | Score (1-10) | Bias |
> |--------|---------|-------------|------|
> | Fear/Greed Index | 72 | 7 | Greedy |
> | Funding Rates | +0.03% | 6 | Slightly crowded long |
> | Exchange Flows | Net outflow | 8 | Accumulation |
> | Social Volume | Above average | 6 | Elevated interest |
> | Whale Behavior | Accumulating | 8 | Bullish |
> | Google Trends | Below midpoint | 7 | Retail not euphoric |
> | Options Market | 0.6 P/C ratio | 7 | Bullish positioning |
>
> **Aggregate: 7.0/10 — BULLISH with caution.** Most signals align bullish, but funding rates and social volume suggest short-term froth. The ideal scenario: a 5-8% pullback that resets funding before continuation.

---

### 16-20. Quick Sentiment Prompts

### 16. Sentiment Divergence Alert
**User Prompt:** Identify any divergences between sentiment indicators and price for [TOKEN]. Is sentiment more bullish or bearish than price action suggests?

### 17. Influencer Consensus Tracker
**User Prompt:** Summarize the positions/opinions of [5 SPECIFIC INFLUENCERS] on [TOKEN/MARKET]. Is there consensus or disagreement? When influencers agree unanimously, what has historically happened?

### 18. Community Mood Assessment
**User Prompt:** Assess the mood in [PROJECT]'s community (Discord/Telegram). Are holders confident, anxious, or euphoric? Any concerning patterns like "paper hands" shaming or "diamond hands" copium?

### 19. News Cycle Position
**User Prompt:** Where are we in the current crypto news cycle? Is coverage positive, negative, or mixed across mainstream media, crypto media, and social? How does media tone compare to actual market performance?

### 20. Event-Based Sentiment Forecast
**User Prompt:** A major event is coming: [EVENT]. Based on historical precedent, model how sentiment is likely to shift before, during, and after the event. Include "buy the rumor, sell the news" analysis.

**Example Output:** "Pattern for [similar events]: Sentiment peaks 1-3 days before the event. Price typically runs 10-20% in the 2 weeks prior. On event day: initial reaction matches expectations, then reverses within 48 hours (sell the news). Suggested approach: reduce position 30% into the event, rebuy on post-event dip if fundamentals unchanged."

---

*20 sentiment analysis prompts. Read the crowd before joining it.*
