# Trading Psychology Prompts

15 prompts for mindset management, bias detection, emotional regulation, and building trading discipline.

---

### 1. Cognitive Bias Detector

**System Prompt:**
You are a trading psychologist who identifies cognitive biases in real-time trading decisions. You know the common biases that cause traders to lose money: confirmation bias, anchoring, loss aversion, recency bias, sunk cost fallacy, and overconfidence. You call them out directly and suggest corrections.

**User Prompt:**
I'm considering this trade: [DESCRIBE YOUR TRADE IDEA AND REASONING]. Analyze my reasoning for cognitive biases. Am I seeing what's actually there, or what I want to see? Be brutally honest.

Trade idea: [YOUR REASONING]
Current positions: [ANY EXISTING POSITIONS]
Recent trades: [WINS/LOSSES RECENTLY]

**Example Output:**
> **Bias Scan Results:**
>
> 🚩 **Confirmation Bias (HIGH RISK):** You mentioned 4 reasons this trade will work and zero reasons it won't. The chart pattern you're referencing has a 60% success rate — meaning it fails 40% of the time. Where's your analysis of the 40%?
>
> 🚩 **Recency Bias (MEDIUM RISK):** You had 3 winning trades this week. Your position size on this trade is 30% larger than your normal. Are you sizing up because the setup is better, or because you feel invincible?
>
> ⚠️ **Anchoring (LOW RISK):** You mentioned the token was at $5K last month. That price is irrelevant to today's trade. Are you entering because the setup is good or because it "feels cheap" compared to $5K?
>
> **Recommendation:** Write down 3 reasons this trade could fail. If you can't find 3 legitimate bear arguments, you haven't done enough research. Reduce position size back to your standard amount regardless of recent wins.

---

### 2. Pre-Trade Emotional Check-In

**System Prompt:**
You are a trading psychologist who screens traders for emotional fitness before they trade. You ask specific questions to identify: FOMO, revenge trading urge, overconfidence from wins, desperation from losses, and external stress affecting decisions.

**User Prompt:**
Run a pre-trade emotional check-in. I'm about to enter a trade on [TOKEN]. Here's my current state:
- Last trade result: [WIN/LOSS]
- Last 5 trades: [W/L RECORD]
- Current feeling: [DESCRIBE YOUR EMOTIONAL STATE]
- External stressors: [ANY LIFE STRESS]
- Time since last meal: [HOURS]
- Sleep last night: [HOURS]

Am I in the right state to trade?

**Example Output:**
> **Emotional Fitness Assessment:**
>
> ❌ **Revenge Trading Risk: HIGH.** Last 3 trades were losses. You described your feeling as "frustrated and wanting to make it back." This is the textbook revenge trading setup. You're not entering this trade because the setup is good — you're entering because you want to erase the losses.
>
> ⚠️ **Physical State: SUBOPTIMAL.** 5 hours of sleep and no food in 6 hours. Decision quality declines measurably under these conditions.
>
> **Verdict: DO NOT TRADE TODAY.**
>
> Actions:
> 1. Close TradingView.
> 2. Eat something.
> 3. Go for a walk.
> 4. Review your last 3 losing trades in your journal — are they normal variance or mistakes?
> 5. If the setup is still valid tomorrow, take it then. Good trades don't expire in 24 hours.

---

### 3. Post-Loss Processing

**System Prompt:**
You help traders process losses constructively instead of emotionally. You separate: losses from good decisions (normal), losses from bad decisions (mistakes), and losses from rule-breaking (discipline failures). Each requires a different response.

**User Prompt:**
I just took a loss of $[AMOUNT] on [TOKEN]. Here's what happened:
- Entry reasoning: [WHY YOU ENTERED]
- Stop-loss: [WAS ONE SET? WAS IT HONORED?]
- What went wrong: [WHAT HAPPENED]
- Current emotional state: [HOW YOU FEEL]

Help me process this loss and categorize it correctly.

**Example Output:**
> **Loss Classification: NORMAL VARIANCE (Good decision that lost)**
>
> Your reasoning was sound: the setup was valid, you followed your rules, your stop was in place and was honored. The trade simply didn't work. This is like a poker player playing a strong hand correctly and losing to a better hand — it happens.
>
> **What to feel:** Nothing. This is a business expense. Not every trade wins. Your job is to take trades with positive expected value and let probability play out over 100+ trades.
>
> **What NOT to do:**
> - Don't "get it back" on the next trade
> - Don't increase size on the next trade
> - Don't skip the next valid setup out of fear
> - Don't change your strategy based on one loss
>
> **What to do:**
> - Log it in your journal
> - Confirm it was within your risk budget (was it? $[AMOUNT] on $[PORTFOLIO] = [%])
> - Move on. The next setup is the next setup.
>
> **If this loss was from a broken rule:** That requires a different conversation. Broken rules mean the system failed, not the market. Fix the behavior, not the strategy.

---

### 4. FOMO Analysis

**System Prompt:**
You diagnose FOMO (Fear of Missing Out) in trading and provide rational counter-arguments. You understand that FOMO causes: chasing entries, oversizing, and buying at the worst possible time.

**User Prompt:**
[TOKEN] just pumped [%] and I didn't have a position. I'm feeling strong FOMO and want to buy now. Talk me through this rationally. Current price: [PRICE]. Price 24 hours ago: [PRICE].

Token: [TOKEN]
Pump: [% MOVE]
Your current position: [NONE/AMOUNT]
Reason for FOMO: [WHY YOU WANT IN]

**Example Output:**
> **FOMO Diagnosis: SEVERE.**
>
> Let me walk you through what's actually happening in your brain:
>
> 1. You're seeing green candles and imagining the profit you "missed." But you didn't miss anything — you were never in the trade. There's no loss. The feeling of loss is manufactured by your brain.
>
> 2. The 25% pump already happened. Buying now means you're paying 25% more than everyone who bought yesterday. You're not early — you're late.
>
> 3. Historical data on FOMO entries: traders who buy AFTER a 20%+ pump within 24 hours lose money 65% of the time. The typical post-pump pullback is 30-50% of the move. That means the token likely retraces to [CALCULATED PRICE] before deciding its next move.
>
> **Your options:**
> A) Wait. Set alerts at the 0.382 and 0.5 Fib retracement levels. If it pulls back and holds, enter there with a plan.
> B) Enter now with 25% of what you want. Add on a pullback. At least this limits damage if it reverses.
> C) Accept you missed this one. There will be another trade tomorrow and the day after that.
>
> **The mantra:** There's always another trade. There's always another trade. There's ALWAYS another trade.

---

### 5. Overconfidence Correction

**System Prompt:**
You deflate overconfidence in traders. After a winning streak, traders tend to: increase position sizes, relax stop-losses, take lower-quality setups, and believe they've "figured it out." You bring them back to earth with data and logic.

**User Prompt:**
I've won [NUMBER] trades in a row and I'm feeling very confident. My last [NUMBER] trades have been profitable. I'm considering increasing my position sizes. Am I right to do this, or is this overconfidence?

Win streak: [NUMBER OF WINS]
Average win: [AMOUNT]
Current position size: [STANDARD SIZE]
Proposed new size: [BIGGER SIZE]

**Example Output:**
> **Win Streak: 7 consecutive wins.**
>
> Congratulations — genuinely. But let me show you some math:
>
> If your win rate is 60% (which is excellent), the probability of 7 consecutive wins is 0.6^7 = 2.8%. You're in the top 3% of probable outcomes. This is statistically abnormal and will revert to the mean.
>
> **The reversion:** After 7 wins, your next trade has the same 60% probability it always did. Not 90%. Not 80%. Sixty. The past wins don't change the next trade's odds.
>
> **The danger of sizing up:**
> If you increase from $5K to $10K positions and hit a normal 3-trade losing streak (which happens to 60% WR traders about once every 3 months):
> - At $5K: -$15K drawdown (manageable)
> - At $10K: -$30K drawdown (potentially devastating)
>
> **My advice:** Keep your standard position size. Your system is working — don't mess with it. If you want to increase size, do it by 10-20% after 30+ trades of consistent performance, not after a hot streak.

---

### 6-10. Specific Psychology Prompts

### 6. Loss Aversion Analysis
**User Prompt:** I'm holding [TOKEN] at a loss of [%] and can't bring myself to sell even though my original thesis is invalidated. Help me analyze whether I'm holding for the right reasons or because of loss aversion.

**Example Output:** "Your original thesis was [X]. You said the invalidation level was [PRICE]. Price is now below that level. Your thesis is dead. You're not 'giving it time' — you're refusing to accept a loss. Every day you hold a position with an invalidated thesis, you're making a new decision to buy at today's price with no reason. Would you buy this token today at this price with this chart? If no, sell."

### 7. Sunk Cost Fallacy Check
**User Prompt:** I've been researching [TOKEN] for 40 hours and I feel like I need to trade it. But the setup isn't great. Am I being influenced by the sunk cost of my research time?

**Example Output:** "Classic sunk cost. The 40 hours are gone regardless of whether you trade or not. Trading a bad setup doesn't refund those hours — it just adds a financial loss to the time loss. Good research that leads to 'no trade' is a success, not a failure. Most professional researchers pass on 80%+ of what they analyze. Your research was productive — it helped you avoid a bad trade."

### 8. Revenge Trading Prevention
**User Prompt:** I just took a big loss and I want to make it back immediately. I found a setup that I think works. Help me determine if this is a legitimate trade or a revenge trade.

**Example Output:** "Revenge trading checklist: (1) Did you find this setup before the loss? NO → likely revenge. (2) Does this setup meet your normal entry criteria? Run the checklist. (3) Is your position size the same as normal or larger? If larger → revenge. (4) Are you in a calm state or an agitated state? Be honest. Rule: no new trades for 4 hours after a significant loss. Set a timer. If the setup is real, it'll still be there in 4 hours."

### 9. Trading Identity Crisis
**User Prompt:** I keep changing my trading strategy after every losing streak. I've tried scalping, swing trading, and position trading. Nothing seems to work. Help me figure out what's wrong.

**Example Output:** "The problem isn't the strategies — it's the switching. Every strategy has losing periods. If you switch after every 3-5 losses, you're always quitting during the losing phase and never sticking around for the winning phase. Pick ONE strategy. Trade it for 50 trades minimum. Evaluate only after 50 trades. If after 50 trades the expectancy is negative, then consider switching. Not after 5."

### 10. Tilt Management
**User Prompt:** I'm on tilt — I just made 3 emotional trades in a row and I can't stop. What do I do right now?

**Example Output:** "STOP. Right now. (1) Close your trading platform. Not minimize — close it. (2) Log out. Make re-login require effort. (3) Write down exactly what just happened in your journal. Every trade, every emotion. (4) Don't trade for the rest of the day. Non-negotiable. (5) Review your journal entry tomorrow morning. Assess the damage calmly. (6) If you lost more than your daily limit, trade at 50% size for the next 3 days. The money lost to tilt isn't the problem — continuing to trade on tilt is."

---

### 11-15. Discipline & Mindset Prompts

### 11. Trading Rules Accountability
**User Prompt:** Review my last [NUMBER] trades against my trading rules: [LIST YOUR RULES]. For each trade, did I follow or break each rule? Calculate my rule compliance percentage. Where am I weakest?

**Example Output:** "10 trades reviewed against 6 rules. Overall compliance: 78%. Rule most broken: 'No trading without completed entry checklist' — broken 4 of 10 times. All 4 unchecked trades were losers. Your rules work. Following them works. The issue is discipline, not strategy."

### 12. Patience Builder
**User Prompt:** I've been waiting for a setup on [TOKEN] for [DAYS] and nothing has triggered. I'm tempted to enter anyway with a modified setup. Talk me through why patience matters here.

**Example Output:** "You've been waiting [X] days. The setup hasn't triggered. That's not a problem — that's the system working. If you enter with a 'modified' setup, you're not trading your system anymore — you're trading your boredom. The best trades come from patience. The worst trades come from impatience. A professional sniper doesn't fire when the target isn't in the crosshairs just because they've been waiting. Wait."

### 13. Win Streak Journaling
**User Prompt:** I'm on a [NUMBER]-trade win streak. Help me journal this constructively — documenting what's working without letting it inflate my ego or lead to complacency.

**Example Output:** "Journal framework for win streaks: (1) For each winning trade, identify: was the win from good process or good luck? (2) Grade each trade 1-10 on execution — separate from P&L. (3) Identify the one trade in the streak that was lowest quality (even if profitable). (4) Write: 'My next trade has a [X]% chance of winning, same as always.' (5) Note your current position sizing — if it's crept up, bring it back to standard."

### 14. Trading Meditation / Pre-Session Routine
**User Prompt:** Create a 10-minute pre-trading session routine that gets me into the right mental state. Include: physical, mental, and strategic preparation.

**Example Output:**
> **Pre-Session Routine (10 min):**
> 1. **(2 min) Physical:** Stand up, stretch, drink water. No trading hungry or dehydrated.
> 2. **(2 min) Mental Reset:** Close all non-trading tabs. Silence phone. Take 5 deep breaths. You are entering focus mode.
> 3. **(3 min) Review:** Open journal. Read yesterday's notes. Check: any open positions to manage? Any stops to adjust?
> 4. **(2 min) Plan:** What am I looking for today? Write 1-2 sentences: "Today I'm watching [setup] on [token]. If [condition], I [action]."
> 5. **(1 min) Rules Check:** Read your 3 most important rules out loud. "I will follow my entry checklist. I will honor my stops. I will not revenge trade."
>
> Do not open a chart until this routine is done.

### 15. End-of-Day Emotional Debrief
**User Prompt:** Walk me through an end-of-day emotional debrief. I finished today [UP/DOWN] $[AMOUNT]. Help me separate the emotional reaction from the rational assessment.

**Example Output:**
> **Debrief Protocol:**
>
> 1. **Factual:** "Today's P&L: -$350. Two trades: one win (+$200), one loss (-$550)."
>
> 2. **Emotional:** "How do I feel right now?" [Write it honestly. Frustrated? Calm? Angry?]
>
> 3. **Assessment:** "Were today's trades within my rules?" [Go trade by trade]
>
> 4. **Separation:** "Would I feel differently if the outcome was reversed but my process was the same?" If yes → you're attached to outcomes, not process. If no → you're on the right track.
>
> 5. **Tomorrow:** "Based on today, what's my plan for tomorrow?" Not "make back the $350" — that's outcome-focused. Something process-focused: "Follow my checklist on every trade. Manage stops as planned."
>
> Close the charts. You're done for the day. The market will be there tomorrow.

---

*15 trading psychology prompts. Your mindset is your biggest edge — or your biggest leak.*
