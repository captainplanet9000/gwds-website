# Technical Analysis Prompts

30 prompts for chart analysis, indicators, pattern recognition, and multi-timeframe analysis.

---

### 1. Multi-Timeframe Trend Analysis

**System Prompt:**
You are a technical analyst specializing in crypto markets. You analyze price action across multiple timeframes to identify trend alignment. You reference specific candle patterns, support/resistance levels, and moving average relationships. You're precise with numbers and honest about uncertainty.

**User Prompt:**
Perform a multi-timeframe trend analysis for [TOKEN/PAIR] across the weekly, daily, 4H, and 1H charts. For each timeframe, identify: the current trend direction, key support/resistance levels, and the dominant pattern. Then assess whether the timeframes are aligned (confluent) or conflicting. Current price: [PRICE].

Token: [TOKEN/PAIR]
Current price: [PRICE]
Data source: [WHERE YOU'RE LOOKING — TradingView, etc.]

**Example Output:**
> **Weekly:** Bullish — price above 20W and 50W MA. Support at $2,850, resistance at $3,400. Higher highs and higher lows intact since October.
>
> **Daily:** Consolidating — sideways range between $3,100-$3,300 for 12 days. 20D MA flattening. Volume declining in the range.
>
> **4H:** Bearish short-term — lower highs forming since $3,300 rejection. RSI at 42, trending down. Support at $3,100 tested twice.
>
> **1H:** Neutral — choppy price action within the 4H range. No clear pattern.
>
> **Confluence Assessment:** MIXED. Weekly bullish, daily consolidating, 4H bearish, 1H neutral. The weekly trend suggests dips are buying opportunities, but the 4H is warning of a potential breakdown from the daily range. Key level: $3,100 — a daily close below invalidates the bullish thesis. Watch for volume expansion at range boundaries.

---

### 2. Support/Resistance Level Mapping

**System Prompt:**
You are a price action analyst who maps support and resistance levels using historical price data. You distinguish between: level strength (how many times tested), level recency, and whether the level has flipped (former resistance becoming support or vice versa).

**User Prompt:**
Map the key support and resistance levels for [TOKEN] on the [TIMEFRAME] chart. For each level, indicate: the price, number of touches, last time it was tested, and whether it's been flipped. Rank them by strength. Current price: [PRICE].

Token: [TOKEN]
Timeframe: [DAILY/4H/1H]
Current price: [PRICE]

**Example Output:**
> **Resistance Levels (above current price):**
> 1. $3,400 — STRONG (4 touches, last tested 5 days ago, never broken on daily close)
> 2. $3,550 — MODERATE (2 touches, last tested 3 weeks ago)
> 3. $3,800 — WEAK (1 touch, all-time high from Jan, untested since)
>
> **Support Levels (below current price):**
> 1. $3,100 — STRONG (5 touches, last tested yesterday, former resistance flipped to support in November)
> 2. $2,850 — STRONG (3 touches, 50D MA confluence, last tested 2 weeks ago)
> 3. $2,600 — MODERATE (2 touches, monthly level)
>
> **Key Observation:** $3,100 is the pivot. Holding above = bullish continuation likely. Breaking below on volume = targets $2,850 as first support.

---

### 3. Chart Pattern Identification

**System Prompt:**
You are a chart pattern specialist who identifies and validates classical chart patterns. You assess: pattern completeness, measured move target, invalidation level, and reliability statistics for the pattern type.

**User Prompt:**
Identify any classical chart patterns forming on [TOKEN]'s [TIMEFRAME] chart. For each pattern found: name it, describe its boundaries, give the measured move target, the invalidation level, and the historical success rate of this pattern type. Current price: [PRICE].

Token: [TOKEN]
Timeframe: [TIMEFRAME]
Current price: [PRICE]

**Example Output:**
> **Pattern Identified: Ascending Triangle**
>
> Boundaries:
> - Flat resistance: $3,400 (horizontal top)
> - Rising support: trendline from $2,800 to $3,200 over 6 weeks (higher lows)
> - Currently in the 75% completion zone of the triangle
>
> Measured Move: Pattern height ($600) added to breakout point = $4,000 target on upside breakout.
>
> Invalidation: Break below the rising trendline (currently ~$3,150) on volume.
>
> Historical Note: Ascending triangles break upward ~68% of the time. Volume confirmation is critical — a breakout without volume expansion has a much higher failure rate.

---

### 4. Moving Average Analysis

**System Prompt:**
You are a technical analyst who uses moving averages for trend analysis and signal generation. You analyze MA relationships (golden cross, death cross, MA ribbon), price-to-MA distance, and MA slope for momentum assessment.

**User Prompt:**
Analyze the moving average structure for [TOKEN] on the [TIMEFRAME] chart. Include: 20, 50, 100, and 200 period MAs. For each: current value, slope direction, and price relationship. Identify any MA crosses or convergences forming. Current price: [PRICE].

Token: [TOKEN]
Timeframe: [TIMEFRAME]
Current price: [PRICE]

**Example Output:**
> **MA Values and Slope:**
> - 20 MA: $3,180 (flat/slightly declining) — price below
> - 50 MA: $3,050 (rising) — price above
> - 100 MA: $2,900 (rising steadily) — price above
> - 200 MA: $2,650 (rising) — price well above
>
> **MA Relationships:**
> - 20 crossing below 50: NOT YET, but converging. Watch for bearish cross in 2-3 days if price stays below $3,200.
> - 50 well above 100: bullish structure intact
> - All MAs above 200: longer-term trend still bullish
>
> **Assessment:** Short-term momentum weakening (price below 20MA, 20MA flattening), but medium-term bullish structure intact. The 50MA at $3,050 is the line in the sand — losing it would shift the medium-term picture bearish.

---

### 5. RSI Divergence Scanner

**System Prompt:**
You identify RSI divergences — both bullish and bearish, regular and hidden. You explain the significance of each divergence type and assess its reliability based on timeframe and confluence.

**User Prompt:**
Scan [TOKEN]'s [TIMEFRAME] chart for RSI divergences. Identify any regular bullish, regular bearish, hidden bullish, or hidden bearish divergences. For each: describe the price points, RSI readings, and what the divergence suggests. Current RSI: [VALUE].

Token: [TOKEN]
Timeframe: [TIMEFRAME]
Current RSI: [VALUE]

**Example Output:**
> **Divergence Found: Regular Bearish Divergence (Daily)**
>
> Price made a higher high: $3,400 on Feb 20 → $3,380 on Feb 28 (marginally lower, but still in the upper range)
> RSI made a definitively lower high: 72 → 61
>
> This suggests momentum is fading even as price holds near highs. Regular bearish divergences precede pullbacks ~60% of the time on the daily timeframe.
>
> **Confluence check:** Volume also declining on the second push — confirms weakening buying pressure.
>
> **Warning:** RSI divergences can persist for extended periods, especially in strong trends. This is a caution signal, not a sell signal by itself. Wait for price confirmation (break of support or bearish candle pattern).

---

### 6. Volume Profile Analysis

**System Prompt:**
You analyze volume profiles to identify high-volume nodes (HVN), low-volume nodes (LVN), point of control (POC), and value area (VA). You explain what each level means for future price action.

**User Prompt:**
Analyze the volume profile for [TOKEN] over the last [PERIOD]. Identify the POC, value area high/low, any significant HVNs and LVNs. Explain what these levels mean for upcoming price action. Current price: [PRICE].

Token: [TOKEN]
Period: [TIMEFRAME RANGE]
Current price: [PRICE]

**Example Output:**
> **Volume Profile (Last 30 Days):**
> - POC (Point of Control): $3,200 — heaviest traded price. Acts as a magnet.
> - Value Area High (VAH): $3,350 — upper bound of 70% volume. Resistance.
> - Value Area Low (VAL): $3,050 — lower bound. Support.
> - HVN at $3,000: heavy accumulation zone. Strong support if reached.
> - LVN between $3,350-$3,400: thin volume. Price moves fast through this zone.
>
> **Implication:** Current price at $3,180 is near the POC — expect chop. A break above $3,350 enters the LVN and could move quickly to $3,400+. A break below $3,050 has strong support at the $3,000 HVN.

---

### 7. Fibonacci Level Analysis

**System Prompt:**
You apply Fibonacci retracement and extension levels to swing highs and lows. You identify which Fib levels cluster with other technical levels for confluence.

**User Prompt:**
Apply Fibonacci retracement levels to [TOKEN]'s recent swing from [LOW PRICE] to [HIGH PRICE]. Identify which Fib levels cluster with other support/resistance, MAs, or psychological numbers. Assess which level is the most likely reaction zone.

Token: [TOKEN]
Swing low: [PRICE]
Swing high: [PRICE]
Current price: [PRICE]

**Example Output:**
> **Fibonacci Levels (from $2,400 swing low to $3,400 swing high):**
> - 0.236: $3,164
> - 0.382: $3,018 ← clusters with 50 MA ($3,050) and psychological $3,000
> - 0.500: $2,900 ← clusters with 100 MA ($2,900)
> - 0.618: $2,782
> - 0.786: $2,615
>
> **Highest Confluence Zone:** $2,900-$3,050 range. Three levels converge: 0.382 Fib, 0.500 Fib, 50 MA, 100 MA, and the $3,000 psychological level. If price reaches this zone, expect a strong reaction.

---

### 8-15. Indicator-Specific Prompts

### 8. MACD Analysis
**User Prompt:** Analyze the MACD (12,26,9) for [TOKEN] on [TIMEFRAME]. Current histogram value, signal line relationship, and any divergences from price. Is momentum expanding or contracting?

**Example Output:** "MACD histogram contracting from +45 toward zero. Signal line cross imminent in 2-3 candles if trend continues. Price holding steady while MACD declines = bearish momentum divergence."

### 9. Bollinger Band Analysis
**User Prompt:** Analyze Bollinger Bands (20,2) for [TOKEN]. Current band width, price position within bands, and any squeeze or expansion signals. Current price: [PRICE].

**Example Output:** "Band width at 3-month low = squeeze forming. Price at upper band. Historical pattern: squeezes at this level resolved with 8%+ moves in either direction within 5 days. Directional bias from other indicators needed."

### 10. Ichimoku Cloud Analysis
**User Prompt:** Analyze the Ichimoku Cloud for [TOKEN] on [TIMEFRAME]. Cover: price vs. cloud, Tenkan/Kijun relationship, Chikou Span position, and future cloud shape.

**Example Output:** "Price above the cloud (bullish). Tenkan above Kijun (bullish momentum). Chikou above price from 26 periods ago (confirmed bullish). Future cloud is green and expanding. All 5 signals aligned bullish — strong trend."

### 11. Stochastic RSI Analysis
**User Prompt:** Analyze StochRSI for [TOKEN] on [TIMEFRAME]. Current reading, overbought/oversold status, and any crossover signals. Compare with regular RSI.

**Example Output:** "StochRSI: 0.92 (overbought zone). Regular RSI: 68 (elevated but not overbought). StochRSI reaches overbought before RSI — early warning of potential pullback. Watch for StochRSI K/D bearish crossover."

### 12. ADX Trend Strength
**User Prompt:** Analyze the ADX/DMI for [TOKEN] on [TIMEFRAME]. ADX value, +DI/-DI relationship, and whether the current trend is strong, weak, or transitioning.

**Example Output:** "ADX: 32 (strong trend confirmed). +DI: 28, -DI: 14 (+DI dominant = bullish trend). ADX rising from 20 to 32 over 10 days = trend strengthening. As long as ADX stays above 25, trend-following strategies favored over mean reversion."

### 13. OBV (On-Balance Volume) Analysis
**User Prompt:** Analyze OBV for [TOKEN] on [TIMEFRAME]. Is OBV confirming or diverging from price? Identify any notable OBV breakouts preceding price moves.

**Example Output:** "OBV making new highs while price is still below its previous high — bullish OBV divergence. This often precedes a price breakout by 3-7 days. Smart money accumulating before the crowd."

### 14. VWAP Analysis
**User Prompt:** Analyze the relationship between [TOKEN]'s price and VWAP on [TIMEFRAME]. Is price above or below VWAP? How has it interacted with VWAP in the last [NUMBER] sessions?

**Example Output:** "Price reclaimed VWAP 4 hours ago and is holding above. VWAP at $3,150 is acting as dynamic support. In the last 10 sessions, price has respected VWAP as support/resistance in 7 of them — making it a high-reliability level for this asset."

### 15. Average True Range (ATR) for Volatility
**User Prompt:** Calculate and interpret the ATR for [TOKEN] on [TIMEFRAME]. Current ATR value, whether volatility is expanding or contracting, and implications for stop-loss placement and position sizing.

**Example Output:** "14-period ATR: $180 (5.6% of current price). ATR expanding from $120 three weeks ago — volatility increasing. For a 2-ATR stop: $360 risk per unit. If risking 1% of a $50K portfolio: position size = $500 / $360 = 1.38 units max."

---

### 16-22. Pattern & Structure Prompts

### 16. Order Block Identification
**User Prompt:** Identify recent bullish and bearish order blocks for [TOKEN] on [TIMEFRAME]. For each: the price zone, the candle(s) that formed it, and whether it's been mitigated.

**Example Output:** "Bullish OB at $3,000-$3,040 (daily). Formed Feb 12 — large green candle with volume 3x average. Not yet mitigated. First retest of this zone should see a reaction. Bearish OB at $3,380-$3,400 — formed Feb 20, the rejection candle."

### 17. Fair Value Gap (FVG) Analysis
**User Prompt:** Identify unfilled Fair Value Gaps for [TOKEN] on [TIMEFRAME]. For each: the gap range, when it formed, and the probability of a fill based on historical behavior.

**Example Output:** "Bullish FVG between $3,080-$3,120 (formed Feb 25 during the sharp move up). Historical fill rate for FVGs on ETH daily: ~72% within 10 days. This gap is a magnet — if price pulls back, expect a bounce in this zone."

### 18. Market Structure Analysis
**User Prompt:** Analyze the market structure for [TOKEN] on [TIMEFRAME]. Map recent swing highs and lows. Identify any BOS (Break of Structure) or CHoCH (Change of Character). Current bias: bullish or bearish?

**Example Output:** "Last 4 swing points: HL ($2,800) → HH ($3,200) → HL ($3,000) → HH ($3,400). Bullish structure intact. CHoCH would occur on a break below $3,000 (last higher low). No BOS or CHoCH yet — trend is healthy."

### 19. Trendline Analysis
**User Prompt:** Identify the most significant trendlines for [TOKEN] on [TIMEFRAME]. For each: number of touches, angle, and the price level where the trendline intersects the current date.

**Example Output:** "Ascending trendline from $2,400 (Dec 1) to $3,000 (Feb 15) — 3 touches, intersects today at ~$3,150. This is the bull market trendline. Breaking below it would be the first major warning sign."

### 20. Candle Pattern Recognition
**User Prompt:** Review the last 10 candles on [TOKEN]'s [TIMEFRAME] chart. Identify any significant single-candle or multi-candle patterns. Assess their reliability at the current price level.

**Example Output:** "Last 3 candles form a 'Three Inside Down' bearish reversal pattern at resistance ($3,400). This pattern has a 65% bearish resolution rate. Confirmation: a red candle closing below $3,300 tomorrow. Invalidation: a close above $3,400."

### 21. Wyckoff Phase Identification
**User Prompt:** Assess whether [TOKEN]'s current price action on [TIMEFRAME] fits a Wyckoff phase. If so: which phase (accumulation, markup, distribution, markdown), what event we're at, and what comes next.

**Example Output:** "Current action resembles Wyckoff Accumulation Phase C — the 'Spring' or shakeout phase. The dip below $3,100 on Feb 26 with immediate recovery and volume surge fits the Spring pattern. If correct, Phase D (markup) begins soon. Confirmation: higher lows above the Spring low with increasing volume."

### 22. Elliott Wave Count
**User Prompt:** Propose an Elliott Wave count for [TOKEN] on [TIMEFRAME]. Identify which wave we're currently in, the expected targets for current and next waves, and the invalidation level.

**Example Output:** "Proposed count: we're in Wave 3 of a larger Wave (3). Wave 1: $2,000→$2,800. Wave 2: $2,800→$2,400. Wave 3 in progress: $2,400→target $3,600-$3,800 (1.618 extension). Invalidation: a move below $2,400 (Wave 2 low) would invalidate this count."

---

### 23-30. Multi-Asset & Correlation Prompts

### 23. Cross-Asset Correlation Analysis
**User Prompt:** Analyze the correlation between [TOKEN A] and [TOKEN B/ASSET] over the last [PERIOD]. Is the correlation strengthening, weakening, or diverging? What does this mean for trading [TOKEN A]?

**Example Output:** "BTC/ETH 30-day correlation: 0.87 (high positive). However, 7-day correlation dropped to 0.72 — ETH is starting to decouple. Historically, when ETH's correlation to BTC drops below 0.75, ETH tends to outperform BTC by 8-12% in the following 2 weeks."

### 24. Relative Strength Comparison
**User Prompt:** Compare [TOKEN]'s relative performance against [BENCHMARK] over [PERIOD]. Is [TOKEN] outperforming or underperforming? Is the relative strength trend improving or deteriorating?

**Example Output:** "SOL/BTC ratio: trending up from 0.0015 to 0.0022 over 30 days (+47%). SOL is significantly outperforming BTC. The ratio is above its 20-period MA and accelerating. As long as SOL/BTC holds above 0.0019 (20MA), relative strength favors SOL over BTC."

### 25. Sector Rotation Analysis
**User Prompt:** Analyze the current sector rotation in crypto. Which sectors (L1, L2, DeFi, AI, meme, RWA) are showing relative strength vs. BTC? Which are lagging? What does the rotation pattern suggest?

**Example Output:** "Current rotation: AI tokens outperforming (sector +18% vs BTC +5% in 14 days). L2 tokens neutral. DeFi underperforming. Meme coins sharply lagging. This pattern typically occurs in mid-cycle — money flows from majors to narratives. Watch for DeFi rotation as the next leg."

### 26. Liquidation Level Analysis
**User Prompt:** Analyze the known liquidation levels for [TOKEN]. Where are the major liquidation clusters above and below current price? How might these act as magnets for price?

**Example Output:** "Major liquidation clusters: $3,500 (estimated $200M in short liquidations), $2,900 (estimated $150M in long liquidations). Current price $3,200. Price tends to gravitate toward the nearest large liquidation cluster. The $3,500 cluster is closer and larger — slight upward bias from liquidation hunting."

### 27. Open Interest Analysis
**User Prompt:** Analyze the open interest trend for [TOKEN] perpetual futures. Is OI increasing or decreasing? What does the OI/price relationship suggest about positioning?

**Example Output:** "OI up 15% over 7 days while price flat = new positions being built without moving price. This is coiling energy. When combined with funding rate at +0.01% (slightly long-biased), it suggests a leveraged squeeze in either direction is building. The resolution will be violent."

### 28. Funding Rate Interpretation
**User Prompt:** Analyze the current funding rates for [TOKEN] across major exchanges. Are rates elevated, negative, or neutral? What does this suggest about market positioning and potential for a squeeze?

**Example Output:** "Funding rates: Binance +0.03%, Bybit +0.04%, OKX +0.035%. All elevated positive = market is long-heavy. Historical pattern: when funding stays above +0.03% for 3+ days, a short-term correction of 3-5% occurs ~65% of the time to flush over-leveraged longs."

### 29. Heatmap Analysis
**User Prompt:** Describe the current crypto market heatmap. Which assets are strongest (green) and weakest (red) over [PERIOD]? Identify any notable outliers and what might be driving them.

**Example Output:** "24H heatmap: BTC +1.2%, ETH +2.1%, SOL +5.4% (outlier green). AI sector deep green (FET +12%, RNDR +8%). DeFi sector mixed. Meme sector red (DOGE -3%, SHIB -4%). Narrative driver: AI sector pumping on [specific news/catalyst]. Rotation into high-beta plays suggests risk-on sentiment."

### 30. Complete Technical Setup Report

**System Prompt:**
You are a senior technical analyst producing a comprehensive setup report. You combine multiple analysis methods into one cohesive view. You clearly state bias, conviction level, and invalidation.

**User Prompt:**
Produce a complete technical analysis report for [TOKEN] at [CURRENT PRICE]. Include: trend analysis (multi-TF), key levels, active patterns, indicator readings (RSI, MACD, volume), and a trade setup if one exists. State your bias and conviction (low/medium/high).

Token: [TOKEN]
Current price: [PRICE]
Your portfolio context: [YOUR POSITION IF ANY]

**Example Output:**
> ## Technical Setup Report: [TOKEN]
>
> **Bias: Bullish (Medium Conviction)**
>
> **Trend:** Weekly bullish, Daily consolidating, 4H neutral
> **Key Levels:** Support $3,100, $2,900. Resistance $3,400, $3,550.
> **Active Pattern:** Ascending triangle on daily (68% bullish breakout probability)
> **RSI:** 55 (neutral, room in both directions)
> **MACD:** Histogram contracting, approaching zero line
> **Volume:** Below average — waiting for catalyst
>
> **Setup:** Long on daily close above $3,400 with volume confirmation.
> Target 1: $3,800 (measured move). Target 2: $4,000 (psychological + Fib extension).
> Stop: $3,250 (below the triangle trendline).
> R:R = 1:2.5 minimum.
>
> **Invalidation:** Daily close below $3,100 flips bias to bearish.

---

*30 technical analysis prompts. Analyze before you trade.*
