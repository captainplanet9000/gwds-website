/**
 * Trade Logger
 *
 * Handles all Supabase writes for the agent system:
 * - Trade opens and closes
 * - Decision logging
 * - Coordination scratchpad for multi-agent awareness
 * - Performance metric updates
 */

import type { SupabaseClient } from "@supabase/supabase-js";
import type { AgentConfig, AgentPosition, AgentTrade, Decision, AgentPerformance } from "./engine";

// ─── Types ───────────────────────────────────────────────────────────────────

interface ScratchpadMessage {
  action: string;
  symbol: string;
  side?: string;
  size?: number;
  entryPrice?: number;
  stopLoss?: number;
  takeProfit?: number;
  pnl?: number;
  reason?: string;
}

// ─── Trade Logger ────────────────────────────────────────────────────────────

export class TradeLogger {
  private supabase: SupabaseClient;
  private agentId: string;
  private writeQueue: Array<() => Promise<void>> = [];
  private flushing = false;

  constructor(supabase: SupabaseClient, agentId: string) {
    this.supabase = supabase;
    this.agentId = agentId;
  }

  /**
   * Log a trade open to agent_trades.
   */
  async logTradeOpen(position: AgentPosition): Promise<void> {
    this.enqueue(async () => {
      const { error } = await this.supabase.from("agent_trades").insert({
        id: position.id,
        agent_id: this.agentId,
        symbol: position.symbol,
        side: position.side,
        size: position.size,
        entry_price: position.entryPrice,
        stop_loss: position.stopLoss,
        take_profit: position.takeProfit,
        status: "open",
        created_at: position.openedAt,
      });

      if (error) {
        console.error(`[TradeLogger] Failed to log trade open: ${error.message}`);
      }
    });
  }

  /**
   * Log a trade close: update the existing row with exit data.
   */
  async logTradeClose(trade: AgentTrade): Promise<void> {
    this.enqueue(async () => {
      const { error } = await this.supabase
        .from("agent_trades")
        .update({
          exit_price: trade.exitPrice,
          pnl: trade.pnl,
          fees: trade.fees,
          status: "closed",
          closed_at: trade.closedAt,
          close_reason: trade.reason,
        })
        .eq("id", trade.id);

      // If update finds nothing (trade opened before logger), insert full record
      if (error) {
        const { error: insertError } = await this.supabase.from("agent_trades").insert({
          id: trade.id,
          agent_id: this.agentId,
          symbol: trade.symbol,
          side: trade.side,
          size: trade.size,
          entry_price: trade.entryPrice,
          exit_price: trade.exitPrice,
          pnl: trade.pnl,
          fees: trade.fees,
          status: "closed",
          created_at: trade.openedAt,
          closed_at: trade.closedAt,
          close_reason: trade.reason,
        });

        if (insertError) {
          console.error(`[TradeLogger] Failed to log trade close: ${insertError.message}`);
        }
      }
    });
  }

  /**
   * Log a decision (every cycle, whether trade was executed or not).
   */
  async logDecision(decision: Decision): Promise<void> {
    this.enqueue(async () => {
      const { error } = await this.supabase.from("agent_decisions").insert({
        id: decision.id,
        agent_id: this.agentId,
        symbol: decision.symbol,
        decision: decision.finalAction,
        strategy_signal: decision.strategySignal.signal,
        strategy_confidence: decision.strategySignal.confidence,
        ai_override: decision.aiOverride
          ? {
              action: decision.aiOverride.action,
              confidence: decision.aiOverride.confidence,
              reasoning: decision.aiOverride.reasoning,
              suggestedAction: decision.aiOverride.suggestedAction,
            }
          : null,
        risk_check: {
          allowed: decision.riskCheck.allowed,
          reason: decision.riskCheck.reason,
          positionSize: decision.riskCheck.positionSize,
          riskRewardRatio: decision.riskCheck.riskRewardRatio,
        },
        reasoning: decision.reasoning,
        executed: decision.executed,
        market_data: {
          stopLoss: decision.strategySignal.stopLoss,
          takeProfit: decision.strategySignal.takeProfit,
          strategyReason: decision.strategySignal.reason,
        },
        created_at: decision.timestamp,
      });

      if (error) {
        console.error(`[TradeLogger] Failed to log decision: ${error.message}`);
      }
    });
  }

  /**
   * Broadcast state to coordination_scratchpad so other agents can see it.
   */
  async broadcastToScratchpad(
    agentId: string,
    agentName: string,
    message: ScratchpadMessage,
  ): Promise<void> {
    this.enqueue(async () => {
      // Prune old entries (keep last 100 per agent)
      const { data: existing } = await this.supabase
        .from("coordination_scratchpad")
        .select("id")
        .eq("agent_id", agentId)
        .order("created_at", { ascending: true });

      if (existing && existing.length > 100) {
        const toDelete = existing.slice(0, existing.length - 100).map((r) => r.id);
        await this.supabase
          .from("coordination_scratchpad")
          .delete()
          .in("id", toDelete);
      }

      // Insert new entry
      const { error } = await this.supabase.from("coordination_scratchpad").insert({
        agent_id: agentId,
        agent_name: agentName,
        message_type: message.action,
        payload: message,
        created_at: new Date().toISOString(),
      });

      if (error) {
        console.error(`[TradeLogger] Scratchpad write failed: ${error.message}`);
      }
    });
  }

  /**
   * Update the agent's performance JSON and status in the agents table.
   */
  async updateAgentState(
    config: AgentConfig,
    performance: AgentPerformance,
    status: string,
  ): Promise<void> {
    this.enqueue(async () => {
      const { error } = await this.supabase
        .from("agents")
        .update({
          performance_json: {
            totalPnl: performance.totalPnl,
            winRate: performance.winRate,
            tradeCount: performance.tradeCount,
            winCount: performance.winCount,
            lossCount: performance.lossCount,
            avgWin: performance.avgWin,
            avgLoss: performance.avgLoss,
            profitFactor: performance.profitFactor,
            maxDrawdown: performance.maxDrawdown,
            sharpeRatio: performance.sharpeRatio,
            dailyPnl: performance.dailyPnl,
            bestTrade: performance.bestTrade,
            worstTrade: performance.worstTrade,
          },
          status: status === "running" ? "active" : status,
          updated_at: new Date().toISOString(),
        })
        .eq("id", config.id);

      if (error) {
        console.error(`[TradeLogger] Failed to update agent state: ${error.message}`);
      }
    });
  }

  /**
   * Fetch recent scratchpad entries from other agents (for coordination).
   */
  async getRecentScratchpad(
    excludeAgentId: string,
    limit: number = 20,
  ): Promise<Array<{ agentName: string; messageType: string; payload: unknown; createdAt: string }>> {
    const { data, error } = await this.supabase
      .from("coordination_scratchpad")
      .select("agent_name, message_type, payload, created_at")
      .neq("agent_id", excludeAgentId)
      .order("created_at", { ascending: false })
      .limit(limit);

    if (error) {
      console.error(`[TradeLogger] Scratchpad read failed: ${error.message}`);
      return [];
    }

    return (data ?? []).map((row) => ({
      agentName: row.agent_name,
      messageType: row.message_type,
      payload: row.payload,
      createdAt: row.created_at,
    }));
  }

  /**
   * Get trade history for an agent from Supabase.
   */
  async getTradeHistory(
    limit: number = 50,
  ): Promise<Array<{
    symbol: string;
    side: string;
    entryPrice: number;
    exitPrice: number | null;
    pnl: number | null;
    status: string;
    createdAt: string;
  }>> {
    const { data, error } = await this.supabase
      .from("agent_trades")
      .select("symbol, side, entry_price, exit_price, pnl, status, created_at")
      .eq("agent_id", this.agentId)
      .order("created_at", { ascending: false })
      .limit(limit);

    if (error) {
      console.error(`[TradeLogger] Trade history read failed: ${error.message}`);
      return [];
    }

    return (data ?? []).map((row) => ({
      symbol: row.symbol,
      side: row.side,
      entryPrice: row.entry_price,
      exitPrice: row.exit_price,
      pnl: row.pnl,
      status: row.status,
      createdAt: row.created_at,
    }));
  }

  // ─── Internal Queue ──────────────────────────────────────────────────────

  /**
   * Enqueue a write operation. Writes are batched and executed sequentially
   * to prevent overwhelming Supabase with concurrent requests.
   */
  private enqueue(fn: () => Promise<void>): void {
    this.writeQueue.push(fn);
    if (!this.flushing) {
      this.flush();
    }
  }

  /**
   * Process the write queue sequentially.
   */
  private async flush(): Promise<void> {
    if (this.flushing) return;
    this.flushing = true;

    while (this.writeQueue.length > 0) {
      const fn = this.writeQueue.shift()!;
      try {
        await fn();
      } catch (err) {
        console.error(`[TradeLogger] Queue flush error: ${(err as Error).message}`);
      }
    }

    this.flushing = false;
  }
}
