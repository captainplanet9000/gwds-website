'use client'

import { useState, useEffect, useCallback } from 'react'
import { Card, CardHeader, CardContent } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Separator } from '@/components/ui/separator'
import { fetchAPI, formatUSD, formatPnL, formatPercent, pnlColor, formatNumber } from '@/lib/utils'
import { Shield, AlertTriangle, TrendingDown, Activity } from 'lucide-react'

/* ─── Types ─────────────────────────────────────────────────────── */

interface RiskPosition {
  coin: string
  side: string
  size: number
  leverage: number
  entryPrice: number
  markPrice: number
  liquidationPrice: number | null
  distanceToLiq: number
  pnl: number
  exposure: number
  riskLevel: 'low' | 'medium' | 'high' | 'critical'
}

interface RiskData {
  riskScore: number
  totalExposure: number
  marginRatio: number
  maxDrawdown: number
  sharpeRatio: number
  positions: RiskPosition[]
  accountValue: number
  marginUsed: number
  volatilityRegime: 'low' | 'normal' | 'high' | 'extreme'
}

/* ─── Skeleton ──────────────────────────────────────────────────── */

function Skeleton({ className = '' }: { className?: string }) {
  return <div className={`skeleton ${className}`} />
}

/* ─── Risk Score Gauge ──────────────────────────────────────────── */

function RiskGauge({ score }: { score: number }) {
  const clamp = Math.max(0, Math.min(100, score))
  const angle = (clamp / 100) * 180 - 90 // -90 to 90 degrees
  let color = '#22c55e'
  let label = 'Low Risk'
  if (clamp >= 75) { color = '#ef4444'; label = 'Critical' }
  else if (clamp >= 50) { color = '#eab308'; label = 'Elevated' }
  else if (clamp >= 25) { color = '#3b82f6'; label = 'Moderate' }

  return (
    <div className="flex flex-col items-center">
      <svg viewBox="0 0 200 120" className="w-48 h-auto">
        {/* Background arc */}
        <path d="M 20 100 A 80 80 0 0 1 180 100" fill="none" stroke="#2a2a3e" strokeWidth="12" strokeLinecap="round" />
        {/* Colored arc */}
        <path
          d="M 20 100 A 80 80 0 0 1 180 100"
          fill="none"
          stroke={color}
          strokeWidth="12"
          strokeLinecap="round"
          strokeDasharray={`${(clamp / 100) * 251.2} 251.2`}
          className="transition-all duration-1000 ease-out"
        />
        {/* Needle */}
        <line
          x1="100"
          y1="100"
          x2={100 + 60 * Math.cos((angle * Math.PI) / 180)}
          y2={100 - 60 * Math.sin((angle * Math.PI) / 180)}
          stroke={color}
          strokeWidth="2.5"
          strokeLinecap="round"
          className="transition-all duration-1000 ease-out"
        />
        <circle cx="100" cy="100" r="5" fill={color} />
        {/* Score */}
        <text x="100" y="85" textAnchor="middle" fill="#f1f5f9" fontSize="28" fontWeight="700" fontFamily="'JetBrains Mono', monospace">
          {clamp}
        </text>
      </svg>
      <p className="text-sm font-medium mt-1" style={{ color }}>{label}</p>
      <p className="text-[10px] text-text-muted">Risk Score (0-100)</p>
    </div>
  )
}

/* ─── Volatility Regime Card ────────────────────────────────────── */

function VolatilityCard({ regime }: { regime: string }) {
  const config: Record<string, { color: string; bg: string; icon: React.ReactNode; desc: string }> = {
    low: { color: 'text-accent-green', bg: 'bg-accent-green/10', icon: <Activity className="w-5 h-5" />, desc: 'Markets calm. Normal position sizing.' },
    normal: { color: 'text-accent-blue', bg: 'bg-accent-blue/10', icon: <Activity className="w-5 h-5" />, desc: 'Standard volatility. Regular risk parameters.' },
    high: { color: 'text-accent-yellow', bg: 'bg-accent-yellow/10', icon: <AlertTriangle className="w-5 h-5" />, desc: 'Elevated volatility. Consider reducing exposure.' },
    extreme: { color: 'text-accent-red', bg: 'bg-accent-red/10', icon: <TrendingDown className="w-5 h-5" />, desc: 'Extreme conditions. Reduce positions immediately.' },
  }
  const c = config[regime] || config.normal

  return (
    <Card>
      <CardContent className="p-5">
        <div className="flex items-center gap-3 mb-3">
          <div className={`w-10 h-10 rounded-xl ${c.bg} ${c.color} flex items-center justify-center`}>
            {c.icon}
          </div>
          <div>
            <p className="text-xs text-text-muted uppercase tracking-wider">Volatility Regime</p>
            <p className={`text-lg font-semibold capitalize ${c.color}`}>{regime}</p>
          </div>
        </div>
        <p className="text-xs text-text-secondary">{c.desc}</p>
      </CardContent>
    </Card>
  )
}

/* ─── Position Sizing Calculator ────────────────────────────────── */

function PositionCalc() {
  const [equity, setEquity] = useState('10000')
  const [riskPct, setRiskPct] = useState('2')
  const [stopDist, setStopDist] = useState('3')

  const equityNum = parseFloat(equity || '0')
  const riskNum = parseFloat(riskPct || '0')
  const stopNum = parseFloat(stopDist || '0')
  const riskAmount = equityNum * (riskNum / 100)
  const positionSize = stopNum > 0 ? riskAmount / (stopNum / 100) : 0

  return (
    <Card>
      <CardHeader>
        <h3 className="text-sm font-semibold text-text-primary">Position Size Calculator</h3>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="grid grid-cols-3 gap-3">
          <div>
            <Label className="text-xs mb-1.5 block">Equity ($)</Label>
            <Input type="number" value={equity} onChange={e => setEquity(e.target.value)} />
          </div>
          <div>
            <Label className="text-xs mb-1.5 block">Risk %</Label>
            <Input type="number" value={riskPct} onChange={e => setRiskPct(e.target.value)} />
          </div>
          <div>
            <Label className="text-xs mb-1.5 block">Stop Distance %</Label>
            <Input type="number" value={stopDist} onChange={e => setStopDist(e.target.value)} />
          </div>
        </div>
        <Separator />
        <div className="grid grid-cols-2 gap-4">
          <div>
            <p className="text-[10px] text-text-muted uppercase tracking-wider">Risk Amount</p>
            <p className="text-lg font-bold font-mono text-accent-red">{formatUSD(riskAmount)}</p>
          </div>
          <div>
            <p className="text-[10px] text-text-muted uppercase tracking-wider">Recommended Size</p>
            <p className="text-lg font-bold font-mono text-accent-purple">{formatUSD(positionSize)}</p>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}

/* ─── Page ──────────────────────────────────────────────────────── */

export default function RiskPage() {
  const [risk, setRisk] = useState<RiskData | null>(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState('')

  const load = useCallback(async () => {
    setLoading(true)
    setError('')
    try {
      const data = await fetchAPI<RiskData>('/api/risk')
      setRisk(data)
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Failed to load risk data')
    } finally {
      setLoading(false)
    }
  }, [])

  useEffect(() => { load() }, [load])

  const riskLevelColor: Record<string, string> = {
    low: 'text-accent-green',
    medium: 'text-accent-blue',
    high: 'text-accent-yellow',
    critical: 'text-accent-red',
  }

  if (error) {
    return (
      <div className="flex flex-col items-center justify-center py-20 gap-4">
        <div className="w-12 h-12 rounded-full bg-accent-red/10 flex items-center justify-center">
          <Shield className="w-6 h-6 text-accent-red" />
        </div>
        <p className="text-text-secondary text-sm">{error}</p>
        <Button onClick={load} variant="outline" size="sm">Retry</Button>
      </div>
    )
  }

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Risk Overview */}
      <div className="grid lg:grid-cols-[280px_1fr] gap-6">
        {/* Gauge */}
        <Card className="flex items-center justify-center py-6">
          {loading ? <Skeleton className="w-48 h-32" /> : <RiskGauge score={risk?.riskScore || 0} />}
        </Card>

        {/* Metrics Grid */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
          <Card className="p-4">
            <p className="text-[10px] text-text-muted uppercase tracking-wider mb-1">Total Exposure</p>
            {loading ? <Skeleton className="h-7 w-24" /> : (
              <p className="text-xl font-bold font-mono text-text-primary">{formatUSD(risk?.totalExposure || 0)}</p>
            )}
          </Card>
          <Card className="p-4">
            <p className="text-[10px] text-text-muted uppercase tracking-wider mb-1">Margin Ratio</p>
            {loading ? <Skeleton className="h-7 w-20" /> : (
              <p className={`text-xl font-bold font-mono ${(risk?.marginRatio || 0) > 50 ? 'text-accent-red' : 'text-text-primary'}`}>
                {formatNumber(risk?.marginRatio || 0, 1)}%
              </p>
            )}
          </Card>
          <Card className="p-4">
            <p className="text-[10px] text-text-muted uppercase tracking-wider mb-1">Max Drawdown</p>
            {loading ? <Skeleton className="h-7 w-20" /> : (
              <p className="text-xl font-bold font-mono text-accent-red">{formatUSD(risk?.maxDrawdown || 0)}</p>
            )}
          </Card>
          <Card className="p-4">
            <p className="text-[10px] text-text-muted uppercase tracking-wider mb-1">Sharpe Ratio</p>
            {loading ? <Skeleton className="h-7 w-16" /> : (
              <p className="text-xl font-bold font-mono text-text-primary">{formatNumber(risk?.sharpeRatio || 0, 2)}</p>
            )}
          </Card>
        </div>
      </div>

      <div className="grid lg:grid-cols-2 gap-6">
        {/* Volatility Regime */}
        {loading ? (
          <Card className="p-5"><Skeleton className="h-20 w-full" /></Card>
        ) : (
          <VolatilityCard regime={risk?.volatilityRegime || 'normal'} />
        )}

        {/* Position Calculator */}
        <PositionCalc />
      </div>

      {/* Per-Position Risk Table */}
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <h2 className="text-sm font-semibold text-text-primary flex items-center gap-2">
              <Shield className="w-4 h-4 text-accent-purple" />
              Position Risk Analysis
            </h2>
            <span className="text-xs text-text-muted">{risk?.positions?.length || 0} positions</span>
          </div>
        </CardHeader>
        <div className="overflow-x-auto">
          <table className="w-full text-xs">
            <thead>
              <tr className="text-text-muted border-b border-dashboard-border">
                <th className="text-left px-5 py-2.5 font-medium">Coin</th>
                <th className="text-left px-2 py-2.5 font-medium">Side</th>
                <th className="text-right px-2 py-2.5 font-medium">Leverage</th>
                <th className="text-right px-2 py-2.5 font-medium">Exposure</th>
                <th className="text-right px-2 py-2.5 font-medium">Liq. Price</th>
                <th className="text-right px-2 py-2.5 font-medium">Dist. to Liq</th>
                <th className="text-right px-2 py-2.5 font-medium">PnL</th>
                <th className="text-right px-5 py-2.5 font-medium">Risk</th>
              </tr>
            </thead>
            <tbody>
              {loading ? (
                Array.from({ length: 4 }).map((_, i) => (
                  <tr key={i} className="border-b border-dashboard-border/50">
                    {Array.from({ length: 8 }).map((_, j) => (
                      <td key={j} className="px-5 py-3"><Skeleton className="h-4 w-14" /></td>
                    ))}
                  </tr>
                ))
              ) : !risk?.positions?.length ? (
                <tr><td colSpan={8} className="px-5 py-8 text-center text-text-muted">No open positions</td></tr>
              ) : (
                risk.positions.map((p, i) => (
                  <tr key={i} className="border-b border-dashboard-border/50 hover:bg-dashboard-hover/50 transition-colors">
                    <td className="px-5 py-3 font-medium text-text-primary">{p.coin}</td>
                    <td className="px-2 py-3">
                      <Badge variant={p.side === 'long' ? 'long' : 'short'}>{p.side}</Badge>
                    </td>
                    <td className="px-2 py-3 text-right font-mono text-text-secondary">{p.leverage}×</td>
                    <td className="px-2 py-3 text-right font-mono text-text-secondary">{formatUSD(p.exposure)}</td>
                    <td className="px-2 py-3 text-right font-mono text-text-secondary">
                      {p.liquidationPrice ? formatUSD(p.liquidationPrice) : '—'}
                    </td>
                    <td className="px-2 py-3 text-right font-mono text-text-secondary">
                      {p.distanceToLiq < 100 ? `${formatNumber(p.distanceToLiq, 1)}%` : '—'}
                    </td>
                    <td className={`px-2 py-3 text-right font-mono font-medium ${pnlColor(p.pnl)}`}>
                      {formatPnL(p.pnl)}
                    </td>
                    <td className="px-5 py-3 text-right">
                      <Badge variant={p.riskLevel === 'low' ? 'active' : p.riskLevel === 'critical' ? 'error' : p.riskLevel === 'high' ? 'loss' : 'info'}>
                        {p.riskLevel}
                      </Badge>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </Card>
    </div>
  )
}
