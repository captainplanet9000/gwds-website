'use client'

import { useState, useEffect, useCallback } from 'react'
import { TradingChart, type OHLCVData } from '@/components/charts/TradingChart'
import { Card, CardHeader, CardContent } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Badge } from '@/components/ui/badge'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Tabs, TabsList, TabsTrigger, TabsContent } from '@/components/ui/tabs'
import { fetchAPI, formatUSD, formatPnL, formatNumber, pnlColor, formatPercent, timeAgo } from '@/lib/utils'

/* ─── Types ─────────────────────────────────────────────────────── */

interface MarketPrice {
  symbol: string
  price: number
  change24h: number
  volume24h: number
}

interface Position {
  coin: string
  side: 'long' | 'short'
  size: number
  entryPrice: number
  markPrice: number
  pnl: number
  leverage: number
}

interface WalletData {
  accountValue: number
  freeCollateral: number
  positions: Position[]
}

const SYMBOLS = ['BTC', 'ETH', 'SOL', 'HYPE', 'SUI', 'DOGE', 'ARB', 'OP', 'AVAX', 'LINK', 'WIF', 'PEPE']
const INTERVALS = [
  { label: '1m', value: '1m' },
  { label: '5m', value: '5m' },
  { label: '15m', value: '15m' },
  { label: '1H', value: '1h' },
  { label: '4H', value: '4h' },
  { label: '1D', value: '1d' },
]

/* ─── Skeleton ──────────────────────────────────────────────────── */

function Skeleton({ className = '' }: { className?: string }) {
  return <div className={`skeleton ${className}`} />
}

/* ─── Price Ticker ──────────────────────────────────────────────── */

function PriceTicker({ prices }: { prices: MarketPrice[] }) {
  const top = prices.slice(0, 12)
  return (
    <div className="flex items-center gap-6 overflow-x-auto py-2 px-4 bg-dashboard-surface/50 border-b border-dashboard-border scrollbar-none">
      {top.map(p => (
        <div key={p.symbol} className="flex items-center gap-2 flex-shrink-0">
          <span className="text-xs font-medium text-text-primary">{p.symbol}</span>
          <span className="text-xs font-mono text-text-secondary">{formatUSD(p.price)}</span>
          <span className={`text-[10px] font-mono ${p.change24h >= 0 ? 'text-accent-green' : 'text-accent-red'}`}>
            {formatPercent(p.change24h)}
          </span>
        </div>
      ))}
    </div>
  )
}

/* ─── Order Panel ───────────────────────────────────────────────── */

function OrderPanel({ symbol, currentPrice, freeCollateral }: { symbol: string; currentPrice: number; freeCollateral: number }) {
  const [side, setSide] = useState<'buy' | 'sell'>('buy')
  const [orderType, setOrderType] = useState<'market' | 'limit'>('market')
  const [size, setSize] = useState('')
  const [price, setPrice] = useState('')
  const [stopLoss, setStopLoss] = useState('')
  const [takeProfit, setTakeProfit] = useState('')
  const [submitting, setSubmitting] = useState(false)
  const [result, setResult] = useState<{ type: 'success' | 'error'; message: string } | null>(null)

  const estimatedValue = parseFloat(size || '0') * (orderType === 'limit' ? parseFloat(price || '0') : currentPrice)

  async function handleSubmit() {
    setSubmitting(true)
    setResult(null)
    try {
      const body: Record<string, unknown> = {
        symbol,
        side,
        size: parseFloat(size),
        type: orderType,
      }
      if (orderType === 'limit') body.price = parseFloat(price)
      if (stopLoss) body.stopLoss = parseFloat(stopLoss)
      if (takeProfit) body.takeProfit = parseFloat(takeProfit)

      const res = await fetchAPI<{ status: string; error?: string }>('/api/orders', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(body),
      })

      if (res.error) throw new Error(res.error)
      setResult({ type: 'success', message: `${side.toUpperCase()} ${size} ${symbol} — Order placed` })
      setSize('')
      setPrice('')
      setStopLoss('')
      setTakeProfit('')
    } catch (e) {
      setResult({ type: 'error', message: e instanceof Error ? e.message : 'Order failed' })
    } finally {
      setSubmitting(false)
    }
  }

  return (
    <Card className="h-full">
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <h3 className="text-sm font-semibold text-text-primary">Order Entry</h3>
          <span className="text-xs text-text-muted font-mono">{symbol}/USD</span>
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* Buy / Sell */}
        <div className="grid grid-cols-2 gap-2">
          <button
            onClick={() => setSide('buy')}
            className={`py-2.5 rounded-lg text-sm font-semibold transition-all ${side === 'buy' ? 'bg-accent-green text-white shadow-lg shadow-accent-green/20' : 'bg-dashboard-card text-text-muted hover:text-text-secondary border border-dashboard-border'}`}
          >
            Buy / Long
          </button>
          <button
            onClick={() => setSide('sell')}
            className={`py-2.5 rounded-lg text-sm font-semibold transition-all ${side === 'sell' ? 'bg-accent-red text-white shadow-lg shadow-accent-red/20' : 'bg-dashboard-card text-text-muted hover:text-text-secondary border border-dashboard-border'}`}
          >
            Sell / Short
          </button>
        </div>

        {/* Order Type */}
        <Tabs value={orderType} onValueChange={v => setOrderType(v as 'market' | 'limit')}>
          <TabsList className="w-full">
            <TabsTrigger value="market" className="flex-1">Market</TabsTrigger>
            <TabsTrigger value="limit" className="flex-1">Limit</TabsTrigger>
          </TabsList>
        </Tabs>

        {/* Price (limit only) */}
        {orderType === 'limit' && (
          <div>
            <Label className="text-xs mb-1.5 block">Limit Price</Label>
            <Input
              type="number"
              placeholder={formatUSD(currentPrice)}
              value={price}
              onChange={e => setPrice(e.target.value)}
              step="0.01"
            />
          </div>
        )}

        {/* Size */}
        <div>
          <div className="flex items-center justify-between mb-1.5">
            <Label className="text-xs">Size ({symbol})</Label>
            <span className="text-[10px] text-text-muted font-mono">Avail: {formatUSD(freeCollateral)}</span>
          </div>
          <Input
            type="number"
            placeholder="0.00"
            value={size}
            onChange={e => setSize(e.target.value)}
            step="0.001"
          />
          {estimatedValue > 0 && (
            <p className="text-[10px] text-text-muted mt-1 font-mono">≈ {formatUSD(estimatedValue)}</p>
          )}
        </div>

        {/* Quick size buttons */}
        <div className="grid grid-cols-4 gap-1.5">
          {[10, 25, 50, 100].map(pct => (
            <button
              key={pct}
              onClick={() => {
                if (currentPrice > 0) {
                  const usdSize = freeCollateral * (pct / 100)
                  setSize((usdSize / currentPrice).toFixed(6))
                }
              }}
              className="py-1 rounded text-[10px] font-medium bg-dashboard-card border border-dashboard-border text-text-muted hover:text-text-secondary hover:border-text-muted transition-colors"
            >
              {pct}%
            </button>
          ))}
        </div>

        {/* SL / TP */}
        <div className="grid grid-cols-2 gap-3">
          <div>
            <Label className="text-xs mb-1.5 block">Stop Loss</Label>
            <Input
              type="number"
              placeholder="Optional"
              value={stopLoss}
              onChange={e => setStopLoss(e.target.value)}
              step="0.01"
              className="text-accent-red"
            />
          </div>
          <div>
            <Label className="text-xs mb-1.5 block">Take Profit</Label>
            <Input
              type="number"
              placeholder="Optional"
              value={takeProfit}
              onChange={e => setTakeProfit(e.target.value)}
              step="0.01"
              className="text-accent-green"
            />
          </div>
        </div>

        {/* Submit */}
        <Button
          onClick={handleSubmit}
          disabled={submitting || !size || parseFloat(size) <= 0}
          variant={side === 'buy' ? 'success' : 'destructive'}
          className="w-full h-11 text-sm font-bold"
        >
          {submitting ? 'Placing...' : `${side === 'buy' ? 'Buy' : 'Sell'} ${symbol}`}
        </Button>

        {/* Result */}
        {result && (
          <div className={`p-2.5 rounded-lg text-xs font-medium ${result.type === 'success' ? 'bg-accent-green/10 text-accent-green border border-accent-green/20' : 'bg-accent-red/10 text-accent-red border border-accent-red/20'}`}>
            {result.message}
          </div>
        )}
      </CardContent>
    </Card>
  )
}

/* ─── Page ──────────────────────────────────────────────────────── */

export default function TradingPage() {
  const [symbol, setSymbol] = useState('BTC')
  const [interval, setInterval] = useState('1h')
  const [candles, setCandles] = useState<OHLCVData[]>([])
  const [prices, setPrices] = useState<MarketPrice[]>([])
  const [wallet, setWallet] = useState<WalletData | null>(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState('')

  const currentPrice = prices.find(p => p.symbol === symbol)?.price || 0

  const loadData = useCallback(async () => {
    setLoading(true)
    setError('')
    try {
      const [c, p, w] = await Promise.all([
        fetchAPI<OHLCVData[]>(`/api/market/candles/${symbol}?interval=${interval}&lookback=300`),
        fetchAPI<MarketPrice[]>('/api/market/prices'),
        fetchAPI<WalletData>('/api/wallet/sync'),
      ])
      setCandles(c)
      setPrices(p)
      setWallet(w)
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Failed to load data')
    } finally {
      setLoading(false)
    }
  }, [symbol, interval])

  useEffect(() => { loadData() }, [loadData])

  // Auto-refresh prices every 10s
  useEffect(() => {
    const id = window.setInterval(async () => {
      try {
        const p = await fetchAPI<MarketPrice[]>('/api/market/prices')
        setPrices(p)
      } catch { /* silent */ }
    }, 10000)
    return () => clearInterval(id)
  }, [])

  if (error) {
    return (
      <div className="flex flex-col items-center justify-center py-20 gap-4">
        <div className="w-12 h-12 rounded-full bg-accent-red/10 flex items-center justify-center">
          <svg className="w-6 h-6 text-accent-red" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/></svg>
        </div>
        <p className="text-text-secondary text-sm">{error}</p>
        <Button onClick={loadData} variant="outline" size="sm">Retry</Button>
      </div>
    )
  }

  return (
    <div className="space-y-0 -m-4 lg:-m-6 animate-fade-in">
      {/* Price Ticker */}
      <PriceTicker prices={prices} />

      <div className="p-4 lg:p-6 space-y-4">
        {/* Chart + Order Entry */}
        <div className="grid lg:grid-cols-[1fr_320px] gap-4">
          {/* Chart Section */}
          <Card className="overflow-hidden">
            <div className="flex items-center justify-between px-4 py-3 border-b border-dashboard-border">
              <div className="flex items-center gap-3">
                <Select value={symbol} onValueChange={setSymbol}>
                  <SelectTrigger className="w-[120px] h-8 text-xs">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {SYMBOLS.map(s => (
                      <SelectItem key={s} value={s}>{s}/USD</SelectItem>
                    ))}
                  </SelectContent>
                </Select>

                {currentPrice > 0 && (
                  <div className="flex items-center gap-2">
                    <span className="text-lg font-bold font-mono text-text-primary">{formatUSD(currentPrice)}</span>
                    {prices.find(p => p.symbol === symbol) && (
                      <span className={`text-xs font-mono ${pnlColor(prices.find(p => p.symbol === symbol)!.change24h)}`}>
                        {formatPercent(prices.find(p => p.symbol === symbol)!.change24h)}
                      </span>
                    )}
                  </div>
                )}
              </div>

              {/* Interval selector */}
              <div className="flex items-center gap-1">
                {INTERVALS.map(i => (
                  <button
                    key={i.value}
                    onClick={() => setInterval(i.value)}
                    className={`px-2.5 py-1 rounded text-xs font-medium transition-colors ${interval === i.value ? 'bg-accent-purple/20 text-accent-purple' : 'text-text-muted hover:text-text-secondary hover:bg-dashboard-hover'}`}
                  >
                    {i.label}
                  </button>
                ))}
              </div>
            </div>

            {loading ? (
              <Skeleton className="h-[500px] w-full rounded-none" />
            ) : (
              <TradingChart symbol={`${symbol}/USD`} data={candles} height={500} />
            )}
          </Card>

          {/* Order Entry */}
          <OrderPanel
            symbol={symbol}
            currentPrice={currentPrice}
            freeCollateral={wallet?.freeCollateral || 0}
          />
        </div>

        {/* Open Positions */}
        <Card>
          <CardHeader>
            <div className="flex items-center justify-between">
              <h2 className="text-sm font-semibold text-text-primary">Open Positions</h2>
              <span className="text-xs text-text-muted">{wallet?.positions?.length || 0} active</span>
            </div>
          </CardHeader>
          <div className="overflow-x-auto">
            <table className="w-full text-xs">
              <thead>
                <tr className="text-text-muted border-b border-dashboard-border">
                  <th className="text-left px-5 py-2.5 font-medium">Symbol</th>
                  <th className="text-left px-2 py-2.5 font-medium">Side</th>
                  <th className="text-right px-2 py-2.5 font-medium">Size</th>
                  <th className="text-right px-2 py-2.5 font-medium">Entry</th>
                  <th className="text-right px-2 py-2.5 font-medium">Mark</th>
                  <th className="text-right px-2 py-2.5 font-medium">Lev</th>
                  <th className="text-right px-5 py-2.5 font-medium">PnL</th>
                </tr>
              </thead>
              <tbody>
                {loading ? (
                  Array.from({ length: 3 }).map((_, i) => (
                    <tr key={i} className="border-b border-dashboard-border/50">
                      {Array.from({ length: 7 }).map((_, j) => (
                        <td key={j} className="px-5 py-3"><Skeleton className="h-4 w-14" /></td>
                      ))}
                    </tr>
                  ))
                ) : !wallet?.positions?.length ? (
                  <tr><td colSpan={7} className="px-5 py-8 text-center text-text-muted">No open positions</td></tr>
                ) : (
                  wallet.positions.map((p, i) => (
                    <tr key={i} className="border-b border-dashboard-border/50 hover:bg-dashboard-hover/50 transition-colors">
                      <td className="px-5 py-3 font-medium text-text-primary">{p.coin}</td>
                      <td className="px-2 py-3">
                        <Badge variant={p.side === 'long' ? 'long' : 'short'}>{p.side}</Badge>
                      </td>
                      <td className="px-2 py-3 text-right font-mono text-text-secondary">{formatNumber(p.size, 4)}</td>
                      <td className="px-2 py-3 text-right font-mono text-text-secondary">{formatUSD(p.entryPrice)}</td>
                      <td className="px-2 py-3 text-right font-mono text-text-secondary">{formatUSD(p.markPrice)}</td>
                      <td className="px-2 py-3 text-right font-mono text-text-secondary">{p.leverage}×</td>
                      <td className={`px-5 py-3 text-right font-mono font-medium ${pnlColor(p.pnl)}`}>{formatPnL(p.pnl)}</td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </Card>
      </div>
    </div>
  )
}
