'use client'

import { useState, useEffect } from 'react'
import { usePathname } from 'next/navigation'
import Link from 'next/link'
import { fetchAPI, formatUSD, shortAddress } from '@/lib/utils'

const NAV_ITEMS = [
  { label: 'Overview', href: '/dashboard', icon: 'grid' },
  { label: 'Live Trading', href: '/dashboard/trading', icon: 'zap' },
  { label: 'Agents', href: '/dashboard/agents', icon: 'bot' },
  { label: 'Risk & Vol', href: '/dashboard/risk', icon: 'shield' },
  { label: 'Performance', href: '/dashboard/performance', icon: 'trending' },
  { label: 'Settings', href: '/dashboard/settings', icon: 'gear' },
]

function NavIcon({ icon, className = '' }: { icon: string; className?: string }) {
  const c = `w-5 h-5 ${className}`
  switch (icon) {
    case 'grid': return <svg className={c} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5"><rect x="3" y="3" width="7" height="7" rx="1.5"/><rect x="14" y="3" width="7" height="7" rx="1.5"/><rect x="3" y="14" width="7" height="7" rx="1.5"/><rect x="14" y="14" width="7" height="7" rx="1.5"/></svg>
    case 'zap': return <svg className={c} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5"><polygon points="13 2 3 14 12 14 11 22 21 10 12 10 13 2"/></svg>
    case 'bot': return <svg className={c} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5"><rect x="3" y="8" width="18" height="12" rx="2"/><circle cx="9" cy="14" r="1.5" fill="currentColor"/><circle cx="15" cy="14" r="1.5" fill="currentColor"/><path d="M12 2v4"/><circle cx="12" cy="2" r="1.5"/></svg>
    case 'shield': return <svg className={c} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5"><path d="M12 2l8 4v6c0 5.25-3.5 9.74-8 11-4.5-1.26-8-5.75-8-11V6l8-4z"/></svg>
    case 'trending': return <svg className={c} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5"><polyline points="23 6 13.5 15.5 8.5 10.5 1 18"/><polyline points="17 6 23 6 23 12"/></svg>
    case 'gear': return <svg className={c} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5"><circle cx="12" cy="12" r="3"/><path d="M12 1v2m0 18v2M4.22 4.22l1.42 1.42m12.72 12.72l1.42 1.42M1 12h2m18 0h2M4.22 19.78l1.42-1.42M18.36 5.64l1.42-1.42"/></svg>
    default: return null
  }
}

export default function DashboardLayout({ children }: { children: React.ReactNode }) {
  const pathname = usePathname()
  const [collapsed, setCollapsed] = useState(false)
  const [mobileOpen, setMobileOpen] = useState(false)
  const [wallet, setWallet] = useState<{ accountValue: number; address: string } | null>(null)

  useEffect(() => {
    fetchAPI<{ accountValue: number }>('/api/wallet/sync')
      .then(d => setWallet({ accountValue: d.accountValue, address: process.env.NEXT_PUBLIC_MAIN_WALLET_ADDRESS || '' }))
      .catch(() => {})
  }, [])

  const isActive = (href: string) => {
    if (href === '/dashboard') return pathname === '/dashboard'
    return pathname.startsWith(href)
  }

  return (
    <div className="flex min-h-screen bg-dashboard-bg">
      {/* Mobile overlay */}
      {mobileOpen && (
        <div className="fixed inset-0 bg-black/60 z-40 lg:hidden" onClick={() => setMobileOpen(false)} />
      )}

      {/* Sidebar */}
      <aside className={`fixed lg:static inset-y-0 left-0 z-50 flex flex-col bg-dashboard-surface border-r border-dashboard-border transition-all duration-300 ${collapsed ? 'w-[68px]' : 'w-[240px]'} ${mobileOpen ? 'translate-x-0' : '-translate-x-full lg:translate-x-0'}`}>
        {/* Logo */}
        <div className={`flex items-center gap-3 px-4 h-16 border-b border-dashboard-border ${collapsed ? 'justify-center' : ''}`}>
          <div className="w-8 h-8 rounded-lg bg-accent-purple/20 flex items-center justify-center flex-shrink-0">
            <svg className="w-5 h-5 text-accent-purple" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><polyline points="22 7 13.5 15.5 8.5 10.5 2 17"/><polyline points="16 7 22 7 22 13"/></svg>
          </div>
          {!collapsed && (
            <div className="overflow-hidden">
              <h1 className="text-sm font-bold text-text-primary whitespace-nowrap">Trading Dashboard</h1>
              <p className="text-[10px] text-accent-purple font-semibold tracking-wider uppercase">Pro</p>
            </div>
          )}
        </div>

        {/* Nav */}
        <nav className="flex-1 py-4 px-2 space-y-1">
          {NAV_ITEMS.map(item => (
            <Link
              key={item.href}
              href={item.href}
              onClick={() => setMobileOpen(false)}
              className={`flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-all duration-150 group ${isActive(item.href) ? 'bg-accent-purple/10 text-accent-purple' : 'text-text-secondary hover:text-text-primary hover:bg-dashboard-hover'} ${collapsed ? 'justify-center' : ''}`}
            >
              <NavIcon icon={item.icon} className={isActive(item.href) ? 'text-accent-purple' : 'text-text-muted group-hover:text-text-secondary'} />
              {!collapsed && <span>{item.label}</span>}
              {isActive(item.href) && !collapsed && <div className="ml-auto w-1.5 h-1.5 rounded-full bg-accent-purple" />}
            </Link>
          ))}
        </nav>

        {/* Collapse toggle */}
        <button
          onClick={() => setCollapsed(!collapsed)}
          className="hidden lg:flex items-center justify-center h-12 border-t border-dashboard-border text-text-muted hover:text-text-primary transition-colors"
        >
          <svg className={`w-4 h-4 transition-transform ${collapsed ? 'rotate-180' : ''}`} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><polyline points="15 18 9 12 15 6"/></svg>
        </button>
      </aside>

      {/* Main content */}
      <div className="flex-1 flex flex-col min-w-0">
        {/* Top bar */}
        <header className="h-16 flex items-center justify-between px-4 lg:px-6 border-b border-dashboard-border bg-dashboard-surface/80 backdrop-blur-sm sticky top-0 z-30">
          <button
            onClick={() => setMobileOpen(true)}
            className="lg:hidden p-2 -ml-2 text-text-secondary hover:text-text-primary"
          >
            <svg className="w-5 h-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><line x1="3" y1="6" x2="21" y2="6"/><line x1="3" y1="12" x2="21" y2="12"/><line x1="3" y1="18" x2="21" y2="18"/></svg>
          </button>

          <div className="hidden lg:block" />

          <div className="flex items-center gap-4">
            {wallet ? (
              <div className="flex items-center gap-3">
                <div className="text-right">
                  <p className="text-xs text-text-muted">Account Value</p>
                  <p className="text-sm font-semibold text-text-primary font-mono">{formatUSD(wallet.accountValue)}</p>
                </div>
                <div className="h-8 w-px bg-dashboard-border" />
                <div className="flex items-center gap-2 px-3 py-1.5 rounded-lg bg-accent-green/10 border border-accent-green/20">
                  <div className="w-2 h-2 rounded-full bg-accent-green animate-pulse" />
                  <span className="text-xs font-mono text-accent-green">{shortAddress(wallet.address)}</span>
                </div>
              </div>
            ) : (
              <div className="flex items-center gap-2 px-3 py-1.5 rounded-lg bg-dashboard-card border border-dashboard-border">
                <div className="w-2 h-2 rounded-full bg-text-muted" />
                <span className="text-xs text-text-muted">Not connected</span>
              </div>
            )}
          </div>
        </header>

        {/* Page content */}
        <main className="flex-1 p-4 lg:p-6 overflow-auto">
          {children}
        </main>
      </div>
    </div>
  )
}
