import { NextRequest, NextResponse } from 'next/server'

// In production, settings would be stored in Supabase or a config file.
// For the template, we use env vars + defaults.
const defaultSettings = {
  connection: {
    hyperliquidConnected: !!process.env.NEXT_PUBLIC_MAIN_WALLET_ADDRESS,
    supabaseConnected: !!process.env.NEXT_PUBLIC_SUPABASE_URL,
    openrouterConnected: !!process.env.OPENROUTER_API_KEY,
    network: process.env.NEXT_PUBLIC_HYPERLIQUID_NETWORK || 'mainnet',
  },
  trading: {
    defaultLeverage: 5,
    maxPositionPct: 25,
    riskPerTradePct: 2,
    defaultSlippageBps: 50,
  },
  agents: {
    defaultStrategy: 'vwap-mean-reversion',
    autoTrade: false,
    maxConcurrentPositions: 5,
    aiAnalysis: false,
  },
  advanced: {
    network: process.env.NEXT_PUBLIC_HYPERLIQUID_NETWORK || 'mainnet',
    dataRetentionDays: 90,
  },
}

export async function GET() {
  return NextResponse.json(defaultSettings)
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    // In production, persist to DB. For template, just echo back merged settings.
    const merged = { ...defaultSettings, ...body }
    return NextResponse.json(merged)
  } catch (error) {
    console.error('Settings error:', error)
    return NextResponse.json({ error: 'Failed to save settings' }, { status: 500 })
  }
}
