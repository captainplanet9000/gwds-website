'use client'

import { useEffect, useRef, useCallback } from 'react'
import { createChart, type IChartApi, type ISeriesApi, ColorType, CrosshairMode } from 'lightweight-charts'

export interface OHLCVData {
  time: string // 'YYYY-MM-DD' or Unix timestamp
  open: number
  high: number
  low: number
  close: number
  volume?: number
}

interface TradingChartProps {
  symbol: string
  data: OHLCVData[]
  height?: number
  className?: string
}

export function TradingChart({ symbol, data, height = 500, className = '' }: TradingChartProps) {
  const containerRef = useRef<HTMLDivElement>(null)
  const chartRef = useRef<IChartApi | null>(null)
  const candleSeriesRef = useRef<ISeriesApi<'Candlestick'> | null>(null)
  const volumeSeriesRef = useRef<ISeriesApi<'Histogram'> | null>(null)

  const initChart = useCallback(() => {
    if (!containerRef.current) return

    // Clean up existing chart
    if (chartRef.current) {
      chartRef.current.remove()
      chartRef.current = null
    }

    const chart = createChart(containerRef.current, {
      width: containerRef.current.clientWidth,
      height,
      layout: {
        background: { type: ColorType.Solid, color: 'transparent' },
        textColor: '#64748b',
        fontFamily: "'JetBrains Mono', monospace",
        fontSize: 11,
      },
      grid: {
        vertLines: { color: 'rgba(42, 42, 62, 0.5)' },
        horzLines: { color: 'rgba(42, 42, 62, 0.5)' },
      },
      crosshair: {
        mode: CrosshairMode.Normal,
        vertLine: {
          color: 'rgba(139, 92, 246, 0.3)',
          width: 1,
          style: 3,
          labelBackgroundColor: '#8b5cf6',
        },
        horzLine: {
          color: 'rgba(139, 92, 246, 0.3)',
          width: 1,
          style: 3,
          labelBackgroundColor: '#8b5cf6',
        },
      },
      timeScale: {
        borderColor: '#2a2a3e',
        timeVisible: true,
        secondsVisible: false,
        rightOffset: 5,
        barSpacing: 8,
      },
      rightPriceScale: {
        borderColor: '#2a2a3e',
        scaleMargins: { top: 0.1, bottom: 0.25 },
      },
      handleScroll: { vertTouchDrag: false },
    })

    const candleSeries = chart.addCandlestickSeries({
      upColor: '#22c55e',
      downColor: '#ef4444',
      borderUpColor: '#22c55e',
      borderDownColor: '#ef4444',
      wickUpColor: '#22c55e',
      wickDownColor: '#ef4444',
    })

    const volumeSeries = chart.addHistogramSeries({
      priceFormat: { type: 'volume' },
      priceScaleId: 'volume',
    })

    chart.priceScale('volume').applyOptions({
      scaleMargins: { top: 0.8, bottom: 0 },
    })

    chartRef.current = chart
    candleSeriesRef.current = candleSeries
    volumeSeriesRef.current = volumeSeries

    return chart
  }, [height])

  // Initialize chart
  useEffect(() => {
    initChart()
    return () => {
      if (chartRef.current) {
        chartRef.current.remove()
        chartRef.current = null
      }
    }
  }, [initChart])

  // Update data
  useEffect(() => {
    if (!candleSeriesRef.current || !volumeSeriesRef.current || !data.length) return

    const candleData = data.map(d => ({
      time: d.time as string,
      open: d.open,
      high: d.high,
      low: d.low,
      close: d.close,
    }))

    const volumeData = data.map(d => ({
      time: d.time as string,
      value: d.volume || 0,
      color: d.close >= d.open ? 'rgba(34, 197, 94, 0.3)' : 'rgba(239, 68, 68, 0.3)',
    }))

    candleSeriesRef.current.setData(candleData as never[])
    volumeSeriesRef.current.setData(volumeData as never[])
    chartRef.current?.timeScale().fitContent()
  }, [data])

  // Resize handler
  useEffect(() => {
    const container = containerRef.current
    if (!container || !chartRef.current) return

    const observer = new ResizeObserver(entries => {
      for (const entry of entries) {
        const { width } = entry.contentRect
        chartRef.current?.applyOptions({ width })
      }
    })

    observer.observe(container)
    return () => observer.disconnect()
  }, [])

  return (
    <div className={`relative ${className}`}>
      {/* Symbol badge overlay */}
      <div className="absolute top-3 left-3 z-10 flex items-center gap-2">
        <span className="px-2.5 py-1 rounded-md bg-dashboard-card/90 border border-dashboard-border text-sm font-semibold text-text-primary font-mono backdrop-blur-sm">
          {symbol}
        </span>
      </div>
      {data.length === 0 && (
        <div className="absolute inset-0 flex items-center justify-center z-10">
          <p className="text-text-muted text-sm">Loading chart data...</p>
        </div>
      )}
      <div ref={containerRef} style={{ height }} />
    </div>
  )
}
