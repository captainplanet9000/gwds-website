'use client'

import { useState, useEffect, useCallback, useMemo } from 'react'
import { Card, CardHeader, CardContent } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { EquityChart, type EquityPoint } from '@/components/charts/EquityChart'
import { PnLBarChart, type PnLDay } from '@/components/charts/PnLBarChart'
import { WinRateChart } from '@/components/charts/WinRateChart'
import { fetchAPI, formatUSD, formatPnL, pnlColor, formatNumber, formatPercent } from '@/lib/utils'
import { BarChart3, TrendingUp, TrendingDown, Trophy, Skull } from 'lucide-react'

/* ─── Types ─────────────────────────────────────────────────────── */

interface Trade {
  id: string
  agentId: string
  coin: string
  side: string
  size: number
  price: number
  exitPrice: number | null
  pnl: number
  status: string
  created_at: string
  closed_at: string | null
}

interface AgentSummary {
  id: string
  name: string
  strategy: string
  pnl: number
  tradeCount: number
  winRate: number
}

/* ─── Skeleton ──────────────────────────────────────────────────── */

function Skeleton({ className = '' }: { className?: string }) {
  return <div className={`skeleton ${className}`} />
}

/* ─── Page ──────────────────────────────────────────────────────── */

export default function PerformancePage() {
  const [trades, setTrades] = useState<Trade[]>([])
  const [agents, setAgents] = useState<AgentSummary[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState('')

  const load = useCallback(async () => {
    setLoading(true)
    setError('')
    try {
      const [t, a] = await Promise.all([
        fetchAPI<Trade[]>('/api/trades?limit=500'),
        fetchAPI<AgentSummary[]>('/api/agents'),
      ])
      setTrades(t)
      setAgents(a)
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Failed to load')
    } finally {
      setLoading(false)
    }
  }, [])

  useEffect(() => { load() }, [load])

  // Computed analytics
  const analytics = useMemo(() => {
    const closedTrades = trades.filter(t => t.status === 'closed' && t.pnl !== null)
    const wins = closedTrades.filter(t => t.pnl > 0)
    const losses = closedTrades.filter(t => t.pnl <= 0)

    const totalPnl = closedTrades.reduce((s, t) => s + t.pnl, 0)
    const winRate = closedTrades.length > 0 ? (wins.length / closedTrades.length) * 100 : 0
    const avgWin = wins.length > 0 ? wins.reduce((s, t) => s + t.pnl, 0) / wins.length : 0
    const avgLoss = losses.length > 0 ? losses.reduce((s, t) => s + t.pnl, 0) / losses.length : 0
    const profitFactor = Math.abs(avgLoss) > 0 ? (avgWin * wins.length) / Math.abs(avgLoss * losses.length) : 0

    const bestTrade = closedTrades.reduce((best, t) => t.pnl > (best?.pnl || -Infinity) ? t : best, closedTrades[0])
    const worstTrade = closedTrades.reduce((worst, t) => t.pnl < (worst?.pnl || Infinity) ? t : worst, closedTrades[0])

    return { totalPnl, winRate, avgWin, avgLoss, profitFactor, wins: wins.length, losses: losses.length, bestTrade, worstTrade, totalTrades: closedTrades.length }
  }, [trades])

  // Daily PnL for bar chart
  const dailyPnl = useMemo<PnLDay[]>(() => {
    const byDay: Record<string, number> = {}
    trades.filter(t => t.status === 'closed').forEach(t => {
      const day = (t.closed_at || t.created_at).split('T')[0]
      byDay[day] = (byDay[day] || 0) + t.pnl
    })
    return Object.entries(byDay)
      .sort(([a], [b]) => a.localeCompare(b))
      .slice(-30)
      .map(([date, pnl]) => ({ date, pnl }))
  }, [trades])

  // Equity curve
  const equityCurve = useMemo<EquityPoint[]>(() => {
    const sorted = trades.filter(t => t.status === 'closed').sort((a, b) => new Date(a.created_at).getTime() - new Date(b.created_at).getTime())
    let cumulative = 10000
    return sorted.map(t => {
      cumulative += t.pnl
      return { date: t.created_at.split('T')[0], value: cumulative }
    })
  }, [trades])

  // Performance by symbol
  const bySymbol = useMemo(() => {
    const map: Record<string, { pnl: number; count: number; wins: number }> = {}
    trades.filter(t => t.status === 'closed').forEach(t => {
      if (!map[t.coin]) map[t.coin] = { pnl: 0, count: 0, wins: 0 }
      map[t.coin].pnl += t.pnl
      map[t.coin].count++
      if (t.pnl > 0) map[t.coin].wins++
    })
    return Object.entries(map)
      .map(([symbol, d]) => ({ symbol, ...d, winRate: d.count > 0 ? (d.wins / d.count) * 100 : 0 }))
      .sort((a, b) => b.pnl - a.pnl)
  }, [trades])

  if (error) {
    return (
      <div className="flex flex-col items-center justify-center py-20 gap-4">
        <div className="w-12 h-12 rounded-full bg-accent-red/10 flex items-center justify-center">
          <BarChart3 className="w-6 h-6 text-accent-red" />
        </div>
        <p className="text-text-secondary text-sm">{error}</p>
        <Button onClick={load} variant="outline" size="sm">Retry</Button>
      </div>
    )
  }

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Summary Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-5 gap-4">
        <Card className="p-4" glow>
          <p className="text-[10px] text-text-muted uppercase tracking-wider mb-1">Total PnL</p>
          {loading ? <Skeleton className="h-7 w-24" /> : (
            <p className={`text-xl font-bold font-mono ${pnlColor(analytics.totalPnl)}`}>{formatPnL(analytics.totalPnl)}</p>
          )}
        </Card>
        <Card className="p-4">
          <p className="text-[10px] text-text-muted uppercase tracking-wider mb-1">Win Rate</p>
          {loading ? <Skeleton className="h-7 w-16" /> : (
            <p className={`text-xl font-bold font-mono ${analytics.winRate >= 50 ? 'text-accent-green' : 'text-accent-red'}`}>
              {analytics.winRate.toFixed(1)}%
            </p>
          )}
        </Card>
        <Card className="p-4">
          <p className="text-[10px] text-text-muted uppercase tracking-wider mb-1">Avg Win</p>
          {loading ? <Skeleton className="h-7 w-20" /> : (
            <p className="text-xl font-bold font-mono text-accent-green">{formatPnL(analytics.avgWin)}</p>
          )}
        </Card>
        <Card className="p-4">
          <p className="text-[10px] text-text-muted uppercase tracking-wider mb-1">Avg Loss</p>
          {loading ? <Skeleton className="h-7 w-20" /> : (
            <p className="text-xl font-bold font-mono text-accent-red">{formatPnL(analytics.avgLoss)}</p>
          )}
        </Card>
        <Card className="p-4">
          <p className="text-[10px] text-text-muted uppercase tracking-wider mb-1">Profit Factor</p>
          {loading ? <Skeleton className="h-7 w-16" /> : (
            <p className={`text-xl font-bold font-mono ${analytics.profitFactor >= 1.5 ? 'text-accent-green' : analytics.profitFactor >= 1 ? 'text-accent-blue' : 'text-accent-red'}`}>
              {formatNumber(analytics.profitFactor, 2)}
            </p>
          )}
        </Card>
      </div>

      {/* Charts Row */}
      <div className="grid lg:grid-cols-[1fr_220px] gap-6">
        {/* Daily PnL */}
        <Card>
          <CardHeader>
            <h2 className="text-sm font-semibold text-text-primary">Daily PnL (Last 30 Days)</h2>
          </CardHeader>
          <CardContent className="p-2">
            {loading ? <Skeleton className="h-[280px] w-full" /> : (
              <PnLBarChart data={dailyPnl} />
            )}
          </CardContent>
        </Card>

        {/* Win Rate Donut */}
        <Card className="flex flex-col items-center justify-center py-6">
          {loading ? (
            <Skeleton className="w-[180px] h-[180px] rounded-full" />
          ) : (
            <>
              <WinRateChart wins={analytics.wins} losses={analytics.losses} />
              <div className="flex items-center gap-4 mt-4">
                <div className="flex items-center gap-1.5">
                  <div className="w-2.5 h-2.5 rounded-full bg-accent-green" />
                  <span className="text-xs text-text-muted">{analytics.wins}W</span>
                </div>
                <div className="flex items-center gap-1.5">
                  <div className="w-2.5 h-2.5 rounded-full bg-accent-red" />
                  <span className="text-xs text-text-muted">{analytics.losses}L</span>
                </div>
              </div>
            </>
          )}
        </Card>
      </div>

      {/* Equity Curve */}
      <Card>
        <CardHeader>
          <h2 className="text-sm font-semibold text-text-primary">Equity Curve</h2>
        </CardHeader>
        <CardContent className="p-2">
          {loading ? <Skeleton className="h-[280px] w-full" /> : (
            <EquityChart data={equityCurve} />
          )}
        </CardContent>
      </Card>

      <div className="grid lg:grid-cols-2 gap-6">
        {/* By Strategy */}
        <Card>
          <CardHeader>
            <h2 className="text-sm font-semibold text-text-primary">Performance by Agent</h2>
          </CardHeader>
          <div className="overflow-x-auto">
            <table className="w-full text-xs">
              <thead>
                <tr className="text-text-muted border-b border-dashboard-border">
                  <th className="text-left px-5 py-2.5 font-medium">Agent</th>
                  <th className="text-left px-2 py-2.5 font-medium">Strategy</th>
                  <th className="text-right px-2 py-2.5 font-medium">Trades</th>
                  <th className="text-right px-2 py-2.5 font-medium">Win Rate</th>
                  <th className="text-right px-5 py-2.5 font-medium">PnL</th>
                </tr>
              </thead>
              <tbody>
                {loading ? (
                  Array.from({ length: 3 }).map((_, i) => (
                    <tr key={i} className="border-b border-dashboard-border/50">
                      {Array.from({ length: 5 }).map((_, j) => <td key={j} className="px-5 py-3"><Skeleton className="h-4 w-16" /></td>)}
                    </tr>
                  ))
                ) : agents.length === 0 ? (
                  <tr><td colSpan={5} className="px-5 py-8 text-center text-text-muted">No agents</td></tr>
                ) : (
                  agents.map(a => (
                    <tr key={a.id} className="border-b border-dashboard-border/50 hover:bg-dashboard-hover/50 transition-colors">
                      <td className="px-5 py-3 font-medium text-text-primary">{a.name}</td>
                      <td className="px-2 py-3"><Badge variant="purple">{a.strategy}</Badge></td>
                      <td className="px-2 py-3 text-right font-mono text-text-secondary">{a.tradeCount}</td>
                      <td className="px-2 py-3 text-right font-mono text-text-secondary">{a.winRate.toFixed(0)}%</td>
                      <td className={`px-5 py-3 text-right font-mono font-medium ${pnlColor(a.pnl)}`}>{formatPnL(a.pnl)}</td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </Card>

        {/* By Symbol */}
        <Card>
          <CardHeader>
            <h2 className="text-sm font-semibold text-text-primary">Performance by Symbol</h2>
          </CardHeader>
          <div className="overflow-x-auto">
            <table className="w-full text-xs">
              <thead>
                <tr className="text-text-muted border-b border-dashboard-border">
                  <th className="text-left px-5 py-2.5 font-medium">Symbol</th>
                  <th className="text-right px-2 py-2.5 font-medium">Trades</th>
                  <th className="text-right px-2 py-2.5 font-medium">Win Rate</th>
                  <th className="text-right px-5 py-2.5 font-medium">PnL</th>
                </tr>
              </thead>
              <tbody>
                {loading ? (
                  Array.from({ length: 5 }).map((_, i) => (
                    <tr key={i} className="border-b border-dashboard-border/50">
                      {Array.from({ length: 4 }).map((_, j) => <td key={j} className="px-5 py-3"><Skeleton className="h-4 w-16" /></td>)}
                    </tr>
                  ))
                ) : bySymbol.length === 0 ? (
                  <tr><td colSpan={4} className="px-5 py-8 text-center text-text-muted">No trades</td></tr>
                ) : (
                  bySymbol.map(s => (
                    <tr key={s.symbol} className="border-b border-dashboard-border/50 hover:bg-dashboard-hover/50 transition-colors">
                      <td className="px-5 py-3 font-medium text-text-primary">{s.symbol}</td>
                      <td className="px-2 py-3 text-right font-mono text-text-secondary">{s.count}</td>
                      <td className="px-2 py-3 text-right font-mono text-text-secondary">{s.winRate.toFixed(0)}%</td>
                      <td className={`px-5 py-3 text-right font-mono font-medium ${pnlColor(s.pnl)}`}>{formatPnL(s.pnl)}</td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </Card>
      </div>

      {/* Best & Worst Trades */}
      <div className="grid lg:grid-cols-2 gap-6">
        <Card>
          <CardContent className="p-5">
            <div className="flex items-center gap-3 mb-3">
              <div className="w-10 h-10 rounded-xl bg-accent-green/10 flex items-center justify-center">
                <Trophy className="w-5 h-5 text-accent-green" />
              </div>
              <div>
                <p className="text-xs text-text-muted">Best Trade</p>
                {loading ? <Skeleton className="h-5 w-32" /> : analytics.bestTrade ? (
                  <p className="text-lg font-bold font-mono text-accent-green">{formatPnL(analytics.bestTrade.pnl)}</p>
                ) : <p className="text-sm text-text-muted">—</p>}
              </div>
            </div>
            {analytics.bestTrade && !loading && (
              <p className="text-xs text-text-secondary">
                {analytics.bestTrade.coin} {analytics.bestTrade.side} — {analytics.bestTrade.size} @ {formatUSD(analytics.bestTrade.price)}
              </p>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-5">
            <div className="flex items-center gap-3 mb-3">
              <div className="w-10 h-10 rounded-xl bg-accent-red/10 flex items-center justify-center">
                <Skull className="w-5 h-5 text-accent-red" />
              </div>
              <div>
                <p className="text-xs text-text-muted">Worst Trade</p>
                {loading ? <Skeleton className="h-5 w-32" /> : analytics.worstTrade ? (
                  <p className="text-lg font-bold font-mono text-accent-red">{formatPnL(analytics.worstTrade.pnl)}</p>
                ) : <p className="text-sm text-text-muted">—</p>}
              </div>
            </div>
            {analytics.worstTrade && !loading && (
              <p className="text-xs text-text-secondary">
                {analytics.worstTrade.coin} {analytics.worstTrade.side} — {analytics.worstTrade.size} @ {formatUSD(analytics.worstTrade.price)}
              </p>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
