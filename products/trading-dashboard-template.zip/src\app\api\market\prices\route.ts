import { NextResponse } from 'next/server'
import { getAllPrices } from '@/lib/hyperliquid/client'

export const revalidate = 10

export async function GET() {
  try {
    const assets = await getAllPrices()

    const prices = assets.map(a => ({
      symbol: a.coin,
      price: parseFloat(a.midPx || a.markPx || '0'),
      markPrice: parseFloat(a.markPx || '0'),
      change24h: a.prevDayPx
        ? ((parseFloat(a.markPx) - parseFloat(a.prevDayPx)) / parseFloat(a.prevDayPx)) * 100
        : 0,
      volume24h: parseFloat(a.dayNtlVlm || '0'),
      funding: parseFloat(a.funding || '0'),
      openInterest: parseFloat(a.openInterest || '0'),
    }))

    return NextResponse.json(prices, {
      headers: { 'Cache-Control': 's-maxage=10, stale-while-revalidate=30' },
    })
  } catch (error) {
    console.error('Market prices error:', error)
    return NextResponse.json(
      { error: 'Failed to fetch market data' },
      { status: 500 }
    )
  }
}
