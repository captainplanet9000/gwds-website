/**
 * Hyperliquid REST API Client
 *
 * Provides typed access to the Hyperliquid info and exchange endpoints.
 * Uses ethers.js for EIP-712 signing on order placement.
 *
 * Docs: https://hyperliquid.gitbook.io/hyperliquid-docs/for-developers/api
 */

import { ethers } from "ethers";
import { getNetworkConfig } from "./network-config";

// ─── Types ───────────────────────────────────────────────────────────────────

export interface Balance {
  coin: string;
  total: string;
  available: string;
  unrealizedPnl: string;
}

export interface Position {
  coin: string;
  szi: string; // signed size (negative = short)
  entryPx: string;
  positionValue: string;
  unrealizedPnl: string;
  returnOnEquity: string;
  leverage: { type: string; value: number };
  liquidationPx: string | null;
}

export interface AssetPrice {
  coin: string;
  markPx: string;
  midPx: string;
  prevDayPx: string;
  dayNtlVlm: string;
  funding: string;
  openInterest: string;
}

export interface OrderResult {
  status: "ok" | "error";
  response?: {
    type: string;
    data?: { statuses: Array<{ resting?: { oid: number } }> };
  };
  error?: string;
}

export interface CancelResult {
  status: "ok" | "error";
  error?: string;
}

// ─── Helpers ─────────────────────────────────────────────────────────────────

const config = getNetworkConfig();

/**
 * POST to the Hyperliquid info endpoint.
 */
async function infoRequest<T>(body: Record<string, unknown>): Promise<T> {
  const res = await fetch(config.infoUrl, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body),
  });
  if (!res.ok) {
    throw new Error(`Hyperliquid info error ${res.status}: ${await res.text()}`);
  }
  return res.json() as Promise<T>;
}

/**
 * Build and sign an exchange action using EIP-712.
 * The private key is read from API_WALLET_PRIVATE_KEY.
 */
async function signedExchangeRequest(
  action: Record<string, unknown>,
  nonce: number,
  vaultAddress?: string,
): Promise<OrderResult> {
  const privateKey = process.env.API_WALLET_PRIVATE_KEY;
  if (!privateKey) {
    throw new Error(
      "API_WALLET_PRIVATE_KEY is not set. Cannot sign exchange requests.",
    );
  }

  const wallet = new ethers.Wallet(privateKey);

  // Hyperliquid EIP-712 domain
  const domain = {
    name: "Exchange",
    version: "1",
    chainId: 1337,
    verifyingContract: "0x0000000000000000000000000000000000000000" as `0x${string}`,
  };

  const types = {
    Agent: [
      { name: "source", type: "string" },
      { name: "connectionId", type: "bytes32" },
    ],
  };

  // The connection ID is a hash of the action
  const actionHash = ethers.keccak256(
    ethers.toUtf8Bytes(JSON.stringify(action) + nonce.toString()),
  );

  const value = {
    source: config.network === "mainnet" ? "a" : "b",
    connectionId: actionHash,
  };

  const signature = await wallet.signTypedData(domain, types, value);

  const payload: Record<string, unknown> = {
    action,
    nonce,
    signature,
  };

  if (vaultAddress) {
    payload.vaultAddress = vaultAddress;
  }

  const res = await fetch(config.exchangeUrl, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(payload),
  });

  if (!res.ok) {
    const text = await res.text();
    return { status: "error", error: `HTTP ${res.status}: ${text}` };
  }

  const data = await res.json();
  return { status: "ok", response: data };
}

// ─── Public API ──────────────────────────────────────────────────────────────

/**
 * Get account balances (USDC equity, available margin, etc.)
 * @param walletAddress - Defaults to NEXT_PUBLIC_MAIN_WALLET_ADDRESS
 */
export async function getBalance(
  walletAddress?: string,
): Promise<{ accountValue: string; totalMarginUsed: string; balances: Balance[] }> {
  const user = walletAddress ?? process.env.NEXT_PUBLIC_MAIN_WALLET_ADDRESS;
  if (!user) throw new Error("No wallet address configured.");

  const data = await infoRequest<{
    marginSummary: { accountValue: string; totalMarginUsed: string };
    assetPositions: Array<{
      position: { coin: string };
    }>;
    crossMarginSummary: { accountValue: string; totalMarginUsed: string };
  }>({
    type: "clearinghouseState",
    user,
  });

  return {
    accountValue: data.marginSummary?.accountValue ?? data.crossMarginSummary?.accountValue ?? "0",
    totalMarginUsed: data.marginSummary?.totalMarginUsed ?? data.crossMarginSummary?.totalMarginUsed ?? "0",
    balances: [],
  };
}

/**
 * Get all open positions for a wallet.
 * @param walletAddress - Defaults to NEXT_PUBLIC_MAIN_WALLET_ADDRESS
 */
export async function getPositions(walletAddress?: string): Promise<Position[]> {
  const user = walletAddress ?? process.env.NEXT_PUBLIC_MAIN_WALLET_ADDRESS;
  if (!user) throw new Error("No wallet address configured.");

  const data = await infoRequest<{
    assetPositions: Array<{
      position: Position;
    }>;
  }>({
    type: "clearinghouseState",
    user,
  });

  return (data.assetPositions ?? []).map((ap) => ap.position);
}

/**
 * Get live prices for all perpetual assets.
 */
export async function getAllPrices(): Promise<AssetPrice[]> {
  const data = await infoRequest<AssetPrice[]>({
    type: "metaAndAssetCtxs",
  });

  // metaAndAssetCtxs returns [meta, assetCtxs[]]
  if (Array.isArray(data) && data.length === 2) {
    const assetCtxs = data[1] as unknown as AssetPrice[];
    const meta = data[0] as unknown as { universe: Array<{ name: string }> };
    return assetCtxs.map((ctx, i) => ({
      ...ctx,
      coin: meta.universe[i]?.name ?? `UNKNOWN-${i}`,
    }));
  }

  return [];
}

/**
 * Place a limit order on Hyperliquid.
 * @param coin - Asset symbol (e.g. "ETH")
 * @param isBuy - true for long, false for short
 * @param size - Position size in contracts
 * @param price - Limit price
 * @param reduceOnly - If true, only reduces existing position
 */
export async function placeLimitOrder(
  coin: string,
  isBuy: boolean,
  size: number,
  price: number,
  reduceOnly = false,
): Promise<OrderResult> {
  const nonce = Date.now();

  const action = {
    type: "order",
    orders: [
      {
        a: getAssetIndex(coin),
        b: isBuy,
        p: price.toString(),
        s: size.toString(),
        r: reduceOnly,
        t: { limit: { tif: "Gtc" } },
      },
    ],
    grouping: "na",
  };

  return signedExchangeRequest(action, nonce);
}

/**
 * Place a market order on Hyperliquid.
 * Uses aggressive limit pricing (slippage tolerance built in).
 * @param coin - Asset symbol (e.g. "ETH")
 * @param isBuy - true for long, false for short
 * @param size - Position size in contracts
 * @param slippageBps - Slippage tolerance in basis points (default: 50 = 0.5%)
 */
export async function placeMarketOrder(
  coin: string,
  isBuy: boolean,
  size: number,
  slippageBps = 50,
): Promise<OrderResult> {
  // Fetch current price first
  const prices = await getAllPrices();
  const asset = prices.find(
    (p) => p.coin.toUpperCase() === coin.toUpperCase(),
  );
  if (!asset) {
    return { status: "error", error: `Asset ${coin} not found` };
  }

  const currentPrice = parseFloat(asset.markPx);
  const slippage = currentPrice * (slippageBps / 10000);
  const limitPrice = isBuy
    ? currentPrice + slippage
    : currentPrice - slippage;

  const nonce = Date.now();

  const action = {
    type: "order",
    orders: [
      {
        a: getAssetIndex(coin),
        b: isBuy,
        p: roundPrice(limitPrice, coin),
        s: size.toString(),
        r: false,
        t: { limit: { tif: "Ioc" } },
      },
    ],
    grouping: "na",
  };

  return signedExchangeRequest(action, nonce);
}

/**
 * Cancel an open order.
 * @param coin - Asset symbol
 * @param orderId - The order ID to cancel
 */
export async function cancelOrder(
  coin: string,
  orderId: number,
): Promise<CancelResult> {
  const nonce = Date.now();

  const action = {
    type: "cancel",
    cancels: [
      {
        a: getAssetIndex(coin),
        o: orderId,
      },
    ],
  };

  const result = await signedExchangeRequest(action, nonce);
  return { status: result.status, error: result.error };
}

// ─── Internal Helpers ────────────────────────────────────────────────────────

/**
 * Rough asset index lookup. In production, fetch from meta endpoint and cache.
 * Common assets are hardcoded for convenience.
 */
const COMMON_ASSETS: Record<string, number> = {
  BTC: 0,
  ETH: 1,
  SOL: 2,
  DOGE: 3,
  ARB: 4,
  SUI: 5,
  OP: 6,
  AVAX: 7,
  MATIC: 8,
  LINK: 9,
  WIF: 10,
  PEPE: 11,
};

function getAssetIndex(coin: string): number {
  const idx = COMMON_ASSETS[coin.toUpperCase()];
  if (idx === undefined) {
    // Fall back to 0 — in production, resolve dynamically from /info meta
    console.warn(
      `Asset index for ${coin} not found in COMMON_ASSETS. Using 0. Fetch meta to resolve.`,
    );
    return 0;
  }
  return idx;
}

/**
 * Round price to Hyperliquid's required precision.
 */
function roundPrice(price: number, _coin: string): string {
  if (price >= 10000) return price.toFixed(1);
  if (price >= 100) return price.toFixed(2);
  if (price >= 1) return price.toFixed(3);
  if (price >= 0.01) return price.toFixed(5);
  return price.toFixed(6);
}
