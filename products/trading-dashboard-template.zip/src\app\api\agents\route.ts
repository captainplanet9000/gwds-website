import { NextRequest, NextResponse } from 'next/server'
import { getSupabaseAdmin, type Agent } from '@/lib/supabase'

export async function GET() {
  try {
    const supabase = getSupabaseAdmin()
    const { data, error } = await supabase
      .from('agents')
      .select('*')
      .order('created_at', { ascending: false })

    if (error) throw error

    const agents = (data as Agent[]).map(a => ({
      id: a.id,
      name: a.name,
      strategy: a.strategy,
      status: a.status,
      allocatedBalance: a.allocated_balance,
      pnl: (a.performance_json as Record<string, number>)?.total_pnl || 0,
      tradeCount: (a.performance_json as Record<string, number>)?.trade_count || 0,
      winRate: (a.performance_json as Record<string, number>)?.win_rate || 0,
      config: a.config,
      createdAt: a.created_at,
    }))

    return NextResponse.json(agents)
  } catch (error) {
    console.error('Agents GET error:', error)
    return NextResponse.json({ error: 'Failed to fetch agents' }, { status: 500 })
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { name, strategy, symbols, allocation, maxPositionPct, stopLossPct, takeProfitPct, aiAnalysis } = body

    if (!name || !strategy || !allocation) {
      return NextResponse.json({ error: 'Missing required fields: name, strategy, allocation' }, { status: 400 })
    }

    const supabase = getSupabaseAdmin()
    const { data, error } = await supabase
      .from('agents')
      .insert({
        name,
        strategy,
        allocated_balance: allocation,
        status: 'paused',
        config: {
          symbols: symbols || ['BTC', 'ETH'],
          max_position_pct: maxPositionPct || 25,
          stop_loss_pct: stopLossPct || 5,
          take_profit_pct: takeProfitPct || 10,
          ai_analysis: aiAnalysis || false,
        },
        performance_json: {
          total_pnl: 0,
          trade_count: 0,
          win_rate: 0,
          best_trade: 0,
          worst_trade: 0,
        },
      })
      .select()
      .single()

    if (error) throw error

    return NextResponse.json(data, { status: 201 })
  } catch (error) {
    console.error('Agents POST error:', error)
    return NextResponse.json({ error: 'Failed to create agent' }, { status: 500 })
  }
}
