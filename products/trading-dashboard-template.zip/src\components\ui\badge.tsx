import { cva, type VariantProps } from "class-variance-authority"

const badgeVariants = cva(
  "inline-flex items-center rounded-md px-2 py-0.5 text-[10px] font-semibold uppercase tracking-wider transition-colors",
  {
    variants: {
      variant: {
        default: "bg-dashboard-card border border-dashboard-border text-text-secondary",
        long: "bg-accent-green/10 text-accent-green border border-accent-green/20",
        short: "bg-accent-red/10 text-accent-red border border-accent-red/20",
        active: "bg-accent-green/10 text-accent-green border border-accent-green/20",
        paused: "bg-accent-yellow/10 text-accent-yellow border border-accent-yellow/20",
        stopped: "bg-text-muted/10 text-text-muted border border-text-muted/20",
        error: "bg-accent-red/10 text-accent-red border border-accent-red/20",
        profit: "bg-accent-green/10 text-accent-green",
        loss: "bg-accent-red/10 text-accent-red",
        info: "bg-accent-blue/10 text-accent-blue border border-accent-blue/20",
        purple: "bg-accent-purple/10 text-accent-purple border border-accent-purple/20",
      },
    },
    defaultVariants: {
      variant: "default",
    },
  }
)

export interface BadgeProps
  extends React.HTMLAttributes<HTMLSpanElement>,
    VariantProps<typeof badgeVariants> {}

export function Badge({ className = "", variant, ...props }: BadgeProps) {
  return <span className={`${badgeVariants({ variant })} ${className}`} {...props} />
}
