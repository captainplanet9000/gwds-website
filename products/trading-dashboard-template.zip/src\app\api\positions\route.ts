import { NextResponse } from 'next/server'
import { getPositions } from '@/lib/hyperliquid/client'

export async function GET() {
  try {
    const positions = await getPositions()

    const parsed = positions
      .filter(p => parseFloat(p.szi) !== 0)
      .map(p => {
        const size = parseFloat(p.szi)
        const entryPrice = parseFloat(p.entryPx)
        const posValue = parseFloat(p.positionValue)
        return {
          coin: p.coin,
          side: size > 0 ? 'long' : 'short',
          size: Math.abs(size),
          entryPrice,
          markPrice: posValue / Math.abs(size) || entryPrice,
          pnl: parseFloat(p.unrealizedPnl),
          leverage: p.leverage.value,
        }
      })

    return NextResponse.json(parsed)
  } catch (error) {
    console.error('Positions error:', error)
    return NextResponse.json({ error: 'Failed to fetch positions' }, { status: 500 })
  }
}
