/**
 * Built-In Trading Strategies
 *
 * Three production-ready strategies that work out of the box.
 * Each takes candle data and returns a trading signal with risk levels.
 *
 * Create your own by implementing the StrategyFunction type.
 */

// ─── Types ───────────────────────────────────────────────────────────────────

export interface Candle {
  timestamp: number;
  open: number;
  high: number;
  low: number;
  close: number;
  volume: number;
}

export interface StrategySignal {
  signal: "buy" | "sell" | "hold";
  confidence: number; // 0 to 1
  stopLoss: number;
  takeProfit: number;
  reason?: string;
}

export type StrategyFunction = (candles: Candle[]) => StrategySignal;

// ─── Helpers ─────────────────────────────────────────────────────────────────

/** Simple Moving Average over the last `period` candles. */
function sma(candles: Candle[], period: number): number {
  if (candles.length < period) return candles[candles.length - 1]?.close ?? 0;
  const slice = candles.slice(-period);
  return slice.reduce((sum, c) => sum + c.close, 0) / period;
}

/** Exponential Moving Average. */
function ema(candles: Candle[], period: number): number {
  if (candles.length === 0) return 0;
  const k = 2 / (period + 1);
  let emaValue = candles[0].close;
  for (let i = 1; i < candles.length; i++) {
    emaValue = candles[i].close * k + emaValue * (1 - k);
  }
  return emaValue;
}

/** Standard deviation of closing prices over the last `period` candles. */
function stdDev(candles: Candle[], period: number): number {
  if (candles.length < period) return 0;
  const slice = candles.slice(-period);
  const mean = slice.reduce((sum, c) => sum + c.close, 0) / period;
  const variance =
    slice.reduce((sum, c) => sum + (c.close - mean) ** 2, 0) / period;
  return Math.sqrt(variance);
}

/** Approximate VWAP from candle data. */
function vwap(candles: Candle[]): number {
  let cumulativeTPV = 0;
  let cumulativeVolume = 0;
  for (const c of candles) {
    const typicalPrice = (c.high + c.low + c.close) / 3;
    cumulativeTPV += typicalPrice * c.volume;
    cumulativeVolume += c.volume;
  }
  return cumulativeVolume > 0 ? cumulativeTPV / cumulativeVolume : 0;
}

// ─── Strategies ──────────────────────────────────────────────────────────────

/**
 * VWAP Mean Reversion
 *
 * Buys when price drops significantly below VWAP (oversold).
 * Sells when price rises significantly above VWAP (overbought).
 * Best on range-bound or mean-reverting assets.
 */
export const vwapMeanReversion: StrategyFunction = (candles) => {
  if (candles.length < 20) {
    return { signal: "hold", confidence: 0, stopLoss: 0, takeProfit: 0, reason: "Insufficient data" };
  }

  const currentPrice = candles[candles.length - 1].close;
  const currentVwap = vwap(candles.slice(-50));
  const deviation = (currentPrice - currentVwap) / currentVwap;
  const atr = calculateATR(candles, 14);

  // Buy if price is >1.5% below VWAP
  if (deviation < -0.015) {
    const confidence = Math.min(Math.abs(deviation) / 0.04, 1);
    return {
      signal: "buy",
      confidence,
      stopLoss: currentPrice - atr * 2,
      takeProfit: currentVwap, // Target: reversion to VWAP
      reason: `Price ${(deviation * 100).toFixed(2)}% below VWAP`,
    };
  }

  // Sell if price is >1.5% above VWAP
  if (deviation > 0.015) {
    const confidence = Math.min(deviation / 0.04, 1);
    return {
      signal: "sell",
      confidence,
      stopLoss: currentPrice + atr * 2,
      takeProfit: currentVwap,
      reason: `Price ${(deviation * 100).toFixed(2)}% above VWAP`,
    };
  }

  return {
    signal: "hold",
    confidence: 0.3,
    stopLoss: currentPrice - atr * 2,
    takeProfit: currentPrice + atr * 2,
    reason: "Price near VWAP — no edge",
  };
};

/**
 * Momentum (EMA Crossover)
 *
 * Goes long when fast EMA crosses above slow EMA (bullish momentum).
 * Goes short when fast EMA crosses below slow EMA (bearish momentum).
 * Works best in trending markets.
 */
export const momentumEMA: StrategyFunction = (candles) => {
  if (candles.length < 30) {
    return { signal: "hold", confidence: 0, stopLoss: 0, takeProfit: 0, reason: "Insufficient data" };
  }

  const currentPrice = candles[candles.length - 1].close;
  const fastEMA = ema(candles, 9);
  const slowEMA = ema(candles, 21);
  const atr = calculateATR(candles, 14);

  // Previous candle EMAs for crossover detection
  const prevCandles = candles.slice(0, -1);
  const prevFastEMA = ema(prevCandles, 9);
  const prevSlowEMA = ema(prevCandles, 21);

  const crossedUp = prevFastEMA <= prevSlowEMA && fastEMA > slowEMA;
  const crossedDown = prevFastEMA >= prevSlowEMA && fastEMA < slowEMA;

  // Momentum strength: how far apart the EMAs are
  const spread = Math.abs(fastEMA - slowEMA) / currentPrice;
  const confidence = Math.min(spread / 0.005, 1);

  if (crossedUp) {
    return {
      signal: "buy",
      confidence: Math.max(confidence, 0.6),
      stopLoss: currentPrice - atr * 1.5,
      takeProfit: currentPrice + atr * 3,
      reason: `EMA 9/21 bullish crossover`,
    };
  }

  if (crossedDown) {
    return {
      signal: "sell",
      confidence: Math.max(confidence, 0.6),
      stopLoss: currentPrice + atr * 1.5,
      takeProfit: currentPrice - atr * 3,
      reason: `EMA 9/21 bearish crossover`,
    };
  }

  // If already in a trend (no crossover but EMA alignment)
  if (fastEMA > slowEMA && spread > 0.002) {
    return {
      signal: "buy",
      confidence: confidence * 0.5,
      stopLoss: currentPrice - atr * 2,
      takeProfit: currentPrice + atr * 2,
      reason: "Bullish EMA alignment, trend continuation",
    };
  }

  if (fastEMA < slowEMA && spread > 0.002) {
    return {
      signal: "sell",
      confidence: confidence * 0.5,
      stopLoss: currentPrice + atr * 2,
      takeProfit: currentPrice - atr * 2,
      reason: "Bearish EMA alignment, trend continuation",
    };
  }

  return {
    signal: "hold",
    confidence: 0.2,
    stopLoss: currentPrice - atr * 2,
    takeProfit: currentPrice + atr * 2,
    reason: "No clear momentum signal",
  };
};

/**
 * Breakout (Bollinger Bands)
 *
 * Buys on upper band breakout (strong bullish pressure).
 * Sells on lower band breakdown (strong bearish pressure).
 * Uses band width for volatility confirmation.
 */
export const bollingerBreakout: StrategyFunction = (candles) => {
  if (candles.length < 25) {
    return { signal: "hold", confidence: 0, stopLoss: 0, takeProfit: 0, reason: "Insufficient data" };
  }

  const period = 20;
  const multiplier = 2;
  const currentPrice = candles[candles.length - 1].close;
  const prevPrice = candles[candles.length - 2].close;
  const middle = sma(candles, period);
  const sd = stdDev(candles, period);
  const upperBand = middle + multiplier * sd;
  const lowerBand = middle - multiplier * sd;
  const atr = calculateATR(candles, 14);

  // Band width for volatility context (narrow bands = breakout more significant)
  const bandWidth = (upperBand - lowerBand) / middle;

  // Upper breakout: price closes above upper band
  if (currentPrice > upperBand && prevPrice <= upperBand) {
    const confidence = Math.min(bandWidth < 0.04 ? 0.9 : 0.6, 1);
    return {
      signal: "buy",
      confidence,
      stopLoss: middle, // Stop at middle band
      takeProfit: currentPrice + (currentPrice - middle), // Mirror distance above
      reason: `Upper Bollinger breakout (width: ${(bandWidth * 100).toFixed(1)}%)`,
    };
  }

  // Lower breakdown: price closes below lower band
  if (currentPrice < lowerBand && prevPrice >= lowerBand) {
    const confidence = Math.min(bandWidth < 0.04 ? 0.9 : 0.6, 1);
    return {
      signal: "sell",
      confidence,
      stopLoss: middle,
      takeProfit: currentPrice - (middle - currentPrice),
      reason: `Lower Bollinger breakdown (width: ${(bandWidth * 100).toFixed(1)}%)`,
    };
  }

  return {
    signal: "hold",
    confidence: 0.2,
    stopLoss: currentPrice - atr * 2,
    takeProfit: currentPrice + atr * 2,
    reason: `Price within bands (${((currentPrice - lowerBand) / (upperBand - lowerBand) * 100).toFixed(0)}% position)`,
  };
};

// ─── Utility ─────────────────────────────────────────────────────────────────

/** Average True Range for stop/target calculations. */
function calculateATR(candles: Candle[], period: number): number {
  if (candles.length < period + 1) return candles[candles.length - 1]?.close * 0.02;

  let atrSum = 0;
  for (let i = candles.length - period; i < candles.length; i++) {
    const high = candles[i].high;
    const low = candles[i].low;
    const prevClose = candles[i - 1].close;
    const tr = Math.max(high - low, Math.abs(high - prevClose), Math.abs(low - prevClose));
    atrSum += tr;
  }
  return atrSum / period;
}

/** Registry of built-in strategies by name. */
export const STRATEGIES: Record<string, StrategyFunction> = {
  "vwap-mean-reversion": vwapMeanReversion,
  "momentum-ema": momentumEMA,
  "bollinger-breakout": bollingerBreakout,
};

/**
 * Look up a strategy by name. Returns undefined if not found.
 */
export function getStrategy(name: string): StrategyFunction | undefined {
  return STRATEGIES[name];
}
