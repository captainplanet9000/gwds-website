'use client'

import { useState, useEffect, useCallback } from 'react'
import { Card, CardHeader, CardContent } from '@/components/ui/card'
import { fetchAPI, formatUSD, formatPnL, formatPercent, pnlColor, timeAgo, formatNumber } from '@/lib/utils'

/* ---------- types ---------- */
interface WalletData { accountValue: number; margin: number; withdrawable: number; pnl24h: number; pnl24hPct: number }
interface Position { coin: string; side: string; size: number; entryPrice: number; markPrice: number; pnl: number; leverage: number }
interface Agent { id: string; name: string; strategy: string; status: string; pnl: number }
interface Trade { id: string; coin: string; side: string; size: number; price: number; pnl: number; created_at: string }

/* ---------- skeleton ---------- */
function Skeleton({ className = '' }: { className?: string }) {
  return <div className={`skeleton ${className}`} />
}

function StatCard({ label, value, sub, loading }: { label: string; value: string; sub?: string; loading: boolean }) {
  return (
    <Card className="p-4">
      <p className="text-xs text-text-muted uppercase tracking-wider mb-1">{label}</p>
      {loading ? <Skeleton className="h-7 w-28 mb-1" /> : <p className="text-xl font-bold font-mono text-text-primary">{value}</p>}
      {sub && !loading && <p className="text-xs text-text-secondary mt-0.5">{sub}</p>}
    </Card>
  )
}

/* ---------- equity chart ---------- */
function EquityChart({ data }: { data: number[] }) {
  if (!data.length) return null
  const min = Math.min(...data)
  const max = Math.max(...data)
  const range = max - min || 1
  const w = 600
  const h = 160
  const points = data.map((v, i) => `${(i / (data.length - 1)) * w},${h - ((v - min) / range) * (h - 20) - 10}`).join(' ')
  const areaPoints = `0,${h} ${points} ${w},${h}`
  const rising = data[data.length - 1] >= data[0]
  const color = rising ? '#22c55e' : '#ef4444'

  return (
    <svg viewBox={`0 0 ${w} ${h}`} className="w-full h-40" preserveAspectRatio="none">
      <defs>
        <linearGradient id="eqGrad" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor={color} stopOpacity="0.15" />
          <stop offset="100%" stopColor={color} stopOpacity="0" />
        </linearGradient>
      </defs>
      <polygon points={areaPoints} fill="url(#eqGrad)" />
      <polyline points={points} fill="none" stroke={color} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  )
}

export default function DashboardOverview() {
  const [wallet, setWallet] = useState<WalletData | null>(null)
  const [positions, setPositions] = useState<Position[]>([])
  const [agents, setAgents] = useState<Agent[]>([])
  const [trades, setTrades] = useState<Trade[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState('')

  const load = useCallback(async () => {
    setLoading(true)
    setError('')
    try {
      const [w, p, a, t] = await Promise.all([
        fetchAPI<WalletData>('/api/wallet/sync'),
        fetchAPI<Position[]>('/api/positions'),
        fetchAPI<Agent[]>('/api/agents'),
        fetchAPI<Trade[]>('/api/trades?limit=20'),
      ])
      setWallet(w)
      setPositions(p)
      setAgents(a)
      setTrades(t)
    } catch (e: unknown) {
      setError(e instanceof Error ? e.message : 'Failed to load data')
    } finally {
      setLoading(false)
    }
  }, [])

  useEffect(() => { load() }, [load])

  // Generate mock equity curve from trades
  const equityCurve = trades.length > 0
    ? trades.slice().reverse().reduce<number[]>((acc, t) => {
        const last = acc.length ? acc[acc.length - 1] : (wallet?.accountValue || 10000)
        acc.push(last + t.pnl)
        return acc
      }, [])
    : Array.from({ length: 30 }, (_, i) => 10000 + Math.sin(i / 3) * 500 + i * 50)

  if (error) {
    return (
      <div className="flex flex-col items-center justify-center py-20 gap-4">
        <div className="w-12 h-12 rounded-full bg-accent-red/10 flex items-center justify-center">
          <svg className="w-6 h-6 text-accent-red" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/></svg>
        </div>
        <p className="text-text-secondary text-sm">{error}</p>
        <button onClick={load} className="px-4 py-2 rounded-lg bg-accent-purple/20 text-accent-purple text-sm hover:bg-accent-purple/30 transition-colors">Retry</button>
      </div>
    )
  }

  const totalPnl = positions.reduce((s, p) => s + p.pnl, 0)
  const stats24h = {
    trades: trades.filter(t => Date.now() - new Date(t.created_at).getTime() < 86400000).length,
    winRate: trades.length ? (trades.filter(t => t.pnl > 0).length / trades.length * 100) : 0,
    grossPnl: trades.reduce((s, t) => s + t.pnl, 0),
    fees: trades.length * 0.35,
  }

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Stats Row */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <Card className="p-5" glow>
          <p className="text-xs text-text-muted uppercase tracking-wider mb-1">Account Value</p>
          {loading ? <Skeleton className="h-8 w-32" /> : (
            <>
              <p className="text-2xl font-bold font-mono text-text-primary">{formatUSD(wallet?.accountValue || 0)}</p>
              <p className={`text-xs mt-1 font-mono ${pnlColor(wallet?.pnl24h || 0)}`}>
                {formatPnL(wallet?.pnl24h || 0)} ({formatPercent(wallet?.pnl24hPct || 0)})
              </p>
            </>
          )}
        </Card>
        <StatCard label="Unrealized PnL" value={formatPnL(totalPnl)} loading={loading} />
        <StatCard label="Open Positions" value={String(positions.length)} sub={`${formatUSD(positions.reduce((s, p) => s + Math.abs(p.size * p.markPrice), 0))} exposure`} loading={loading} />
        <StatCard label="Active Agents" value={String(agents.filter(a => a.status === 'active').length)} sub={`${agents.length} total`} loading={loading} />
      </div>

      {/* Equity Curve */}
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <h2 className="text-sm font-semibold text-text-primary">Equity Curve</h2>
            <span className={`text-xs font-mono ${pnlColor(totalPnl)}`}>{formatPnL(totalPnl)}</span>
          </div>
        </CardHeader>
        <CardContent className="p-0 px-2 pb-2">
          {loading ? <Skeleton className="h-40 w-full rounded-none" /> : <EquityChart data={equityCurve} />}
        </CardContent>
      </Card>

      <div className="grid lg:grid-cols-2 gap-6">
        {/* Positions */}
        <Card>
          <CardHeader>
            <h2 className="text-sm font-semibold text-text-primary">Open Positions</h2>
          </CardHeader>
          <div className="overflow-x-auto">
            <table className="w-full text-xs">
              <thead>
                <tr className="text-text-muted border-b border-dashboard-border">
                  <th className="text-left px-5 py-2.5 font-medium">Coin</th>
                  <th className="text-left px-2 py-2.5 font-medium">Side</th>
                  <th className="text-right px-2 py-2.5 font-medium">Size</th>
                  <th className="text-right px-2 py-2.5 font-medium">Entry</th>
                  <th className="text-right px-2 py-2.5 font-medium">Mark</th>
                  <th className="text-right px-5 py-2.5 font-medium">PnL</th>
                </tr>
              </thead>
              <tbody>
                {loading ? (
                  Array.from({ length: 4 }).map((_, i) => (
                    <tr key={i} className="border-b border-dashboard-border/50">
                      {Array.from({ length: 6 }).map((_, j) => <td key={j} className="px-5 py-3"><Skeleton className="h-4 w-16" /></td>)}
                    </tr>
                  ))
                ) : positions.length === 0 ? (
                  <tr><td colSpan={6} className="px-5 py-8 text-center text-text-muted">No open positions</td></tr>
                ) : (
                  positions.map((p, i) => (
                    <tr key={i} className="border-b border-dashboard-border/50 hover:bg-dashboard-hover/50 transition-colors">
                      <td className="px-5 py-3 font-medium text-text-primary">{p.coin}</td>
                      <td className="px-2 py-3">
                        <span className={`px-1.5 py-0.5 rounded text-[10px] font-semibold uppercase ${p.side === 'long' ? 'bg-accent-green/10 text-accent-green' : 'bg-accent-red/10 text-accent-red'}`}>
                          {p.side}
                        </span>
                      </td>
                      <td className="px-2 py-3 text-right font-mono text-text-secondary">{formatNumber(p.size, 4)}</td>
                      <td className="px-2 py-3 text-right font-mono text-text-secondary">{formatUSD(p.entryPrice)}</td>
                      <td className="px-2 py-3 text-right font-mono text-text-secondary">{formatUSD(p.markPrice)}</td>
                      <td className={`px-5 py-3 text-right font-mono font-medium ${pnlColor(p.pnl)}`}>{formatPnL(p.pnl)}</td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </Card>

        {/* Active Agents */}
        <Card>
          <CardHeader>
            <h2 className="text-sm font-semibold text-text-primary">Active Agents</h2>
          </CardHeader>
          <CardContent className="space-y-3">
            {loading ? (
              Array.from({ length: 3 }).map((_, i) => (
                <div key={i} className="flex items-center gap-3 p-3 rounded-lg bg-dashboard-card">
                  <Skeleton className="w-8 h-8 rounded-lg" />
                  <div className="flex-1"><Skeleton className="h-4 w-24 mb-1" /><Skeleton className="h-3 w-16" /></div>
                  <Skeleton className="h-4 w-16" />
                </div>
              ))
            ) : agents.length === 0 ? (
              <p className="text-center text-text-muted text-sm py-6">No agents configured</p>
            ) : (
              agents.map(a => (
                <div key={a.id} className="flex items-center gap-3 p-3 rounded-lg bg-dashboard-card border border-dashboard-border/50 hover:border-dashboard-border transition-colors">
                  <div className={`w-8 h-8 rounded-lg flex items-center justify-center text-xs font-bold ${a.status === 'active' ? 'bg-accent-purple/20 text-accent-purple' : 'bg-dashboard-hover text-text-muted'}`}>
                    {a.name.slice(0, 2).toUpperCase()}
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium text-text-primary truncate">{a.name}</p>
                    <p className="text-xs text-text-muted">{a.strategy}</p>
                  </div>
                  <div className={`w-2 h-2 rounded-full ${a.status === 'active' ? 'bg-accent-green' : 'bg-text-muted'}`} />
                  <span className={`text-sm font-mono font-medium ${pnlColor(a.pnl)}`}>{formatPnL(a.pnl)}</span>
                </div>
              ))
            )}
          </CardContent>
        </Card>
      </div>

      <div className="grid lg:grid-cols-3 gap-6">
        {/* Recent Trades */}
        <Card className="lg:col-span-2">
          <CardHeader>
            <h2 className="text-sm font-semibold text-text-primary">Recent Trades</h2>
          </CardHeader>
          <div className="overflow-x-auto">
            <table className="w-full text-xs">
              <thead>
                <tr className="text-text-muted border-b border-dashboard-border">
                  <th className="text-left px-5 py-2.5 font-medium">Coin</th>
                  <th className="text-left px-2 py-2.5 font-medium">Side</th>
                  <th className="text-right px-2 py-2.5 font-medium">Size</th>
                  <th className="text-right px-2 py-2.5 font-medium">Price</th>
                  <th className="text-right px-2 py-2.5 font-medium">PnL</th>
                  <th className="text-right px-5 py-2.5 font-medium">Time</th>
                </tr>
              </thead>
              <tbody>
                {loading ? (
                  Array.from({ length: 5 }).map((_, i) => (
                    <tr key={i} className="border-b border-dashboard-border/50">
                      {Array.from({ length: 6 }).map((_, j) => <td key={j} className="px-5 py-3"><Skeleton className="h-4 w-14" /></td>)}
                    </tr>
                  ))
                ) : trades.length === 0 ? (
                  <tr><td colSpan={6} className="px-5 py-8 text-center text-text-muted">No trades yet</td></tr>
                ) : (
                  trades.slice(0, 10).map(t => (
                    <tr key={t.id} className="border-b border-dashboard-border/50 hover:bg-dashboard-hover/50 transition-colors">
                      <td className="px-5 py-3 font-medium text-text-primary">{t.coin}</td>
                      <td className="px-2 py-3">
                        <span className={`px-1.5 py-0.5 rounded text-[10px] font-semibold uppercase ${t.side === 'buy' ? 'bg-accent-green/10 text-accent-green' : 'bg-accent-red/10 text-accent-red'}`}>{t.side}</span>
                      </td>
                      <td className="px-2 py-3 text-right font-mono text-text-secondary">{formatNumber(t.size, 4)}</td>
                      <td className="px-2 py-3 text-right font-mono text-text-secondary">{formatUSD(t.price)}</td>
                      <td className={`px-2 py-3 text-right font-mono font-medium ${pnlColor(t.pnl)}`}>{formatPnL(t.pnl)}</td>
                      <td className="px-5 py-3 text-right text-text-muted">{timeAgo(t.created_at)}</td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </Card>

        {/* 24h Stats */}
        <Card>
          <CardHeader>
            <h2 className="text-sm font-semibold text-text-primary">24h Statistics</h2>
          </CardHeader>
          <CardContent className="space-y-4">
            {loading ? (
              Array.from({ length: 4 }).map((_, i) => (
                <div key={i} className="flex justify-between"><Skeleton className="h-4 w-20" /><Skeleton className="h-4 w-16" /></div>
              ))
            ) : (
              <>
                <div className="flex justify-between items-center">
                  <span className="text-text-muted text-sm">Total Trades</span>
                  <span className="font-mono font-medium text-text-primary">{stats24h.trades}</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-text-muted text-sm">Win Rate</span>
                  <span className={`font-mono font-medium ${stats24h.winRate >= 50 ? 'text-accent-green' : 'text-accent-red'}`}>
                    {stats24h.winRate.toFixed(1)}%
                  </span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-text-muted text-sm">Gross PnL</span>
                  <span className={`font-mono font-medium ${pnlColor(stats24h.grossPnl)}`}>{formatPnL(stats24h.grossPnl)}</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-text-muted text-sm">Est. Fees</span>
                  <span className="font-mono text-text-secondary">-{formatUSD(stats24h.fees)}</span>
                </div>
                <div className="pt-3 mt-3 border-t border-dashboard-border flex justify-between items-center">
                  <span className="text-text-secondary text-sm font-medium">Net PnL</span>
                  <span className={`font-mono font-semibold ${pnlColor(stats24h.grossPnl - stats24h.fees)}`}>
                    {formatPnL(stats24h.grossPnl - stats24h.fees)}
                  </span>
                </div>
              </>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
