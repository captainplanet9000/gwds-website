'use client'

import { PieChart, Pie, Cell, ResponsiveContainer } from 'recharts'

interface WinRateChartProps {
  wins: number
  losses: number
  size?: number
  className?: string
}

export function WinRateChart({ wins, losses, size = 180, className = '' }: WinRateChartProps) {
  const total = wins + losses
  const winRate = total > 0 ? (wins / total) * 100 : 0

  const data = [
    { name: 'Wins', value: wins || 0 },
    { name: 'Losses', value: losses || 0 },
  ]

  if (total === 0) {
    data[0].value = 1
    data[1].value = 0
  }

  const COLORS = ['#22c55e', '#ef4444']

  return (
    <div className={`relative ${className}`} style={{ width: size, height: size }}>
      <ResponsiveContainer width="100%" height="100%">
        <PieChart>
          <Pie
            data={data}
            cx="50%"
            cy="50%"
            innerRadius={size * 0.32}
            outerRadius={size * 0.44}
            paddingAngle={3}
            dataKey="value"
            stroke="none"
          >
            {data.map((_, i) => (
              <Cell key={i} fill={total === 0 ? '#2a2a3e' : COLORS[i]} />
            ))}
          </Pie>
        </PieChart>
      </ResponsiveContainer>
      {/* Center label */}
      <div className="absolute inset-0 flex flex-col items-center justify-center">
        <span className="text-2xl font-bold font-mono text-text-primary">{winRate.toFixed(0)}%</span>
        <span className="text-[10px] text-text-muted uppercase tracking-wider">Win Rate</span>
      </div>
    </div>
  )
}
