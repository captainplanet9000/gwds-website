# Trading Dashboard Pro — Commercial License

**Version 1.0 — Effective March 2026**

Copyright © 2026 Gamma Waves Design Studio (GWDS). All rights reserved.

---

## Grant of License

Gamma Waves Design Studio ("Licensor") grants you ("Licensee") a non-exclusive, non-transferable, worldwide license to use Trading Dashboard Pro ("Software") subject to the following terms.

## Permitted Use

- **Single Developer.** This license covers one (1) individual developer. The Licensee may use the Software on unlimited personal devices.
- **Single Production Deployment.** The Licensee may deploy the Software to one (1) production environment (domain, server, or service instance).
- **Modification.** The Licensee may modify, extend, and customize the source code for their own use within the permitted deployment.
- **Internal Use.** The Licensee may use the Software for personal trading, internal business operations, or client projects where the Software is part of a larger custom solution (not sold as a standalone product).

## Restrictions

- **No Redistribution.** The Licensee may not distribute, sublicense, sell, lease, or otherwise make the Software (or any derivative work) available to third parties as a standalone product or template.
- **No Resale.** The Licensee may not resell the Software or create competing products derived primarily from the Software.
- **No Sharing.** The Licensee may not share source code access with other developers outside their direct employment. Additional developers require additional licenses.
- **No Open Source.** The Licensee may not publish the Software or substantial portions of it under any open-source license.

## Updates

The purchase price includes access to updates released within twelve (12) months of the original purchase date. Access to updates beyond this period requires a renewal or new purchase.

## Intellectual Property

The Software, including all source code, documentation, designs, and associated materials, remains the intellectual property of Gamma Waves Design Studio. This license grants usage rights only — no ownership transfer occurs.

## Warranty Disclaimer

THE SOFTWARE IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, OR NON-INFRINGEMENT.

**TRADING RISK:** The Software facilitates trading on decentralized exchanges using real funds. The Licensor is not responsible for any financial losses incurred through the use of the Software. Trading involves substantial risk of loss. Past performance does not guarantee future results.

## Limitation of Liability

IN NO EVENT SHALL THE LICENSOR BE LIABLE FOR ANY INDIRECT, INCIDENTAL, SPECIAL, CONSEQUENTIAL, OR PUNITIVE DAMAGES, OR ANY LOSS OF PROFITS, REVENUE, DATA, OR USE, ARISING OUT OF OR RELATED TO THE USE OF THE SOFTWARE, REGARDLESS OF THE THEORY OF LIABILITY.

The Licensor's total liability under this license shall not exceed the amount paid by the Licensee for the Software.

## Termination

This license terminates automatically if the Licensee violates any of its terms. Upon termination, the Licensee must destroy all copies of the Software in their possession.

## Governing Law

This license is governed by the laws of the State of California, United States, without regard to its conflict of laws provisions.

---

**Gamma Waves Design Studio**
gammawavesdesign@gmail.com
https://gwds-website.vercel.app
