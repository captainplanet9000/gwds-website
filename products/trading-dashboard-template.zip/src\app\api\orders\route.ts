import { NextRequest, NextResponse } from 'next/server'
import { placeLimitOrder, placeMarketOrder } from '@/lib/hyperliquid/client'

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { symbol, side, size, price, type, stopLoss, takeProfit } = body

    if (!symbol || !side || !size) {
      return NextResponse.json(
        { error: 'Missing required fields: symbol, side, size' },
        { status: 400 }
      )
    }

    const isBuy = side === 'buy'
    let result

    if (type === 'limit' && price) {
      result = await placeLimitOrder(symbol, isBuy, size, price)
    } else {
      result = await placeMarketOrder(symbol, isBuy, size)
    }

    if (result.status === 'error') {
      return NextResponse.json({ error: result.error }, { status: 400 })
    }

    // If SL/TP provided, place those as separate orders
    // (In production, use Hyperliquid's TP/SL order types)
    const response: Record<string, unknown> = {
      status: 'ok',
      order: result.response,
      symbol,
      side,
      size,
      type: type || 'market',
    }

    if (stopLoss) response.stopLoss = stopLoss
    if (takeProfit) response.takeProfit = takeProfit

    return NextResponse.json(response)
  } catch (error) {
    console.error('Order error:', error)
    return NextResponse.json(
      { error: error instanceof Error ? error.message : 'Order failed' },
      { status: 500 }
    )
  }
}
