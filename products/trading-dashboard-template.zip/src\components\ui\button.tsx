import * as React from "react"
import { Slot } from "@radix-ui/react-slot"
import { cva, type VariantProps } from "class-variance-authority"

const buttonVariants = cva(
  "inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-lg text-sm font-medium transition-all duration-150 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent-purple/50 focus-visible:ring-offset-2 focus-visible:ring-offset-dashboard-bg disabled:pointer-events-none disabled:opacity-50 [&_svg]:pointer-events-none [&_svg]:size-4 [&_svg]:shrink-0 cursor-pointer",
  {
    variants: {
      variant: {
        default: "bg-accent-purple text-white hover:bg-accent-purple-dark shadow-lg shadow-accent-purple/20",
        destructive: "bg-accent-red text-white hover:bg-accent-red/80 shadow-lg shadow-accent-red/20",
        outline: "border border-dashboard-border bg-transparent text-text-primary hover:bg-dashboard-hover hover:border-text-muted",
        secondary: "bg-dashboard-card text-text-primary border border-dashboard-border hover:bg-dashboard-hover",
        ghost: "text-text-secondary hover:text-text-primary hover:bg-dashboard-hover",
        link: "text-accent-purple underline-offset-4 hover:underline",
        success: "bg-accent-green text-white hover:bg-accent-green/80 shadow-lg shadow-accent-green/20",
      },
      size: {
        default: "h-10 px-4 py-2",
        sm: "h-8 rounded-md px-3 text-xs",
        lg: "h-12 rounded-xl px-8 text-base",
        icon: "h-10 w-10",
      },
    },
    defaultVariants: {
      variant: "default",
      size: "default",
    },
  }
)

export interface ButtonProps
  extends React.ButtonHTMLAttributes<HTMLButtonElement>,
    VariantProps<typeof buttonVariants> {
  asChild?: boolean
}

const Button = React.forwardRef<HTMLButtonElement, ButtonProps>(
  ({ className = "", variant, size, asChild = false, ...props }, ref) => {
    const Comp = asChild ? Slot : "button"
    return (
      <Comp
        className={`${buttonVariants({ variant, size })} ${className}`}
        ref={ref}
        {...props}
      />
    )
  }
)
Button.displayName = "Button"

export { Button, buttonVariants }
