/**
 * Risk Management Module
 *
 * Standalone risk manager that validates every trade against configurable
 * constraints. Handles position sizing, drawdown tracking, correlation
 * limits, and circuit breakers.
 */

import type { StrategySignal } from "@/lib/trading/strategies";

// ─── Types ───────────────────────────────────────────────────────────────────

export interface RiskConfig {
  maxPositionPercent: number;
  stopLossPercent: number;
  takeProfitPercent: number;
  maxConcurrentPositions: number;
  maxDailyLoss: number;
  allocatedBalance: number;
}

export interface RiskCheck {
  allowed: boolean;
  reason: string;
  positionSize: number;
  riskRewardRatio: number;
  kellySizing?: number;
  fixedFractionalSizing?: number;
}

export interface PortfolioPosition {
  symbol: string;
  side: "long" | "short";
  size: number;
  entryPrice: number;
  currentPrice: number;
  unrealizedPnl: number;
}

export interface DrawdownState {
  peakEquity: number;
  currentEquity: number;
  currentDrawdown: number;
  maxDrawdown: number;
  drawdownStartedAt: string | null;
  isInDrawdown: boolean;
}

// ─── Risk Manager ────────────────────────────────────────────────────────────

export class RiskManager {
  private config: RiskConfig;
  private drawdown: DrawdownState;

  constructor(config: RiskConfig) {
    this.config = config;
    this.drawdown = {
      peakEquity: config.allocatedBalance,
      currentEquity: config.allocatedBalance,
      currentDrawdown: 0,
      maxDrawdown: 0,
      drawdownStartedAt: null,
      isInDrawdown: false,
    };
  }

  /**
   * Evaluate whether a trade signal should be executed.
   * Returns sizing and risk/reward info.
   */
  evaluate(
    signal: StrategySignal,
    currentPrice: number,
    openPositions: PortfolioPosition[],
    dailyPnl: number,
  ): RiskCheck {
    // Hold signals always pass
    if (signal.signal === "hold") {
      return {
        allowed: false,
        reason: "Strategy signal is hold",
        positionSize: 0,
        riskRewardRatio: 0,
      };
    }

    // Circuit breaker: max daily loss
    if (dailyPnl <= -this.config.maxDailyLoss) {
      return {
        allowed: false,
        reason: `Daily loss limit reached: $${Math.abs(dailyPnl).toFixed(2)} >= $${this.config.maxDailyLoss}`,
        positionSize: 0,
        riskRewardRatio: 0,
      };
    }

    // Max concurrent positions
    if (openPositions.length >= this.config.maxConcurrentPositions) {
      return {
        allowed: false,
        reason: `Max concurrent positions reached: ${openPositions.length}/${this.config.maxConcurrentPositions}`,
        positionSize: 0,
        riskRewardRatio: 0,
      };
    }

    // Check for duplicate symbol
    const existingSymbol = openPositions.find(
      (p) => p.symbol === signal.reason?.split(" ")[0], // rough match
    );

    // Calculate risk/reward ratio
    const isLong = signal.signal === "buy";
    const riskPerUnit = isLong
      ? currentPrice - signal.stopLoss
      : signal.stopLoss - currentPrice;
    const rewardPerUnit = isLong
      ? signal.takeProfit - currentPrice
      : currentPrice - signal.takeProfit;

    const riskRewardRatio = riskPerUnit > 0 ? rewardPerUnit / riskPerUnit : 0;

    // Reject trades with poor risk/reward (below 1.0)
    if (riskRewardRatio < 1.0) {
      return {
        allowed: false,
        reason: `Poor risk/reward ratio: ${riskRewardRatio.toFixed(2)} (min 1.0)`,
        positionSize: 0,
        riskRewardRatio,
      };
    }

    // Reject very low confidence signals
    if (signal.confidence < 0.3) {
      return {
        allowed: false,
        reason: `Low confidence: ${(signal.confidence * 100).toFixed(0)}% (min 30%)`,
        positionSize: 0,
        riskRewardRatio,
      };
    }

    // Calculate position size
    const maxPositionValue =
      this.config.allocatedBalance * (this.config.maxPositionPercent / 100);

    const kellySizing = this.kellySize(signal.confidence, riskRewardRatio, currentPrice);
    const fixedFractionalSizing = this.fixedFractionalSize(
      currentPrice,
      signal.stopLoss,
      isLong,
    );

    // Use the more conservative of Kelly and fixed-fractional
    const rawSize = Math.min(kellySizing, fixedFractionalSizing);
    const maxContracts = maxPositionValue / currentPrice;
    const positionSize = Math.min(rawSize, maxContracts);

    // Ensure position is meaningful (at least $10 notional)
    if (positionSize * currentPrice < 10) {
      return {
        allowed: false,
        reason: "Position too small to be meaningful (< $10 notional)",
        positionSize: 0,
        riskRewardRatio,
        kellySizing,
        fixedFractionalSizing,
      };
    }

    // Check total exposure with new position
    const currentExposure = openPositions.reduce(
      (sum, p) => sum + p.size * p.currentPrice,
      0,
    );
    const newExposure = currentExposure + positionSize * currentPrice;
    if (newExposure > this.config.allocatedBalance * 2) {
      return {
        allowed: false,
        reason: `Total exposure would exceed 2x allocation: $${newExposure.toFixed(2)}`,
        positionSize: 0,
        riskRewardRatio,
      };
    }

    // Drawdown check: reduce sizing if in drawdown
    let adjustedSize = positionSize;
    if (this.drawdown.isInDrawdown && this.drawdown.currentDrawdown > 5) {
      const reductionFactor = Math.max(
        0.25,
        1 - this.drawdown.currentDrawdown / 20,
      );
      adjustedSize = positionSize * reductionFactor;
    }

    // Round to reasonable precision
    adjustedSize = this.roundSize(adjustedSize, currentPrice);

    return {
      allowed: true,
      reason: `Risk check passed. R:R ${riskRewardRatio.toFixed(2)}, confidence ${(signal.confidence * 100).toFixed(0)}%`,
      positionSize: adjustedSize,
      riskRewardRatio,
      kellySizing,
      fixedFractionalSizing,
    };
  }

  /**
   * Kelly Criterion position sizing.
   *
   * f* = (p * b - q) / b
   * where p = win probability, b = win/loss ratio, q = 1-p
   *
   * Uses half-Kelly for safety.
   */
  kellySize(
    winProbability: number,
    riskRewardRatio: number,
    currentPrice: number,
  ): number {
    const p = Math.min(Math.max(winProbability, 0.01), 0.99);
    const b = riskRewardRatio;
    const q = 1 - p;

    const kelly = (p * b - q) / b;

    // Clamp to 0-25% of balance and use half-Kelly
    const fraction = Math.min(Math.max(kelly * 0.5, 0), 0.25);
    const positionValue = this.config.allocatedBalance * fraction;

    return positionValue / currentPrice;
  }

  /**
   * Fixed-fractional position sizing.
   *
   * Risk a fixed % of account on each trade (default: 1%).
   * Size = (Account * RiskPercent) / (Entry - StopLoss)
   */
  fixedFractionalSize(
    currentPrice: number,
    stopLoss: number,
    isLong: boolean,
    riskPercent: number = 1,
  ): number {
    const riskAmount = this.config.allocatedBalance * (riskPercent / 100);
    const riskPerUnit = isLong
      ? Math.abs(currentPrice - stopLoss)
      : Math.abs(stopLoss - currentPrice);

    if (riskPerUnit <= 0) return 0;

    return riskAmount / riskPerUnit;
  }

  /**
   * Update drawdown state with current equity.
   */
  updateDrawdown(currentEquity: number): void {
    this.drawdown.currentEquity = currentEquity;

    if (currentEquity > this.drawdown.peakEquity) {
      this.drawdown.peakEquity = currentEquity;
      this.drawdown.isInDrawdown = false;
      this.drawdown.drawdownStartedAt = null;
    }

    if (this.drawdown.peakEquity > 0) {
      this.drawdown.currentDrawdown =
        ((this.drawdown.peakEquity - currentEquity) / this.drawdown.peakEquity) * 100;
    }

    if (this.drawdown.currentDrawdown > 0 && !this.drawdown.isInDrawdown) {
      this.drawdown.isInDrawdown = true;
      this.drawdown.drawdownStartedAt = new Date().toISOString();
    }

    if (this.drawdown.currentDrawdown > this.drawdown.maxDrawdown) {
      this.drawdown.maxDrawdown = this.drawdown.currentDrawdown;
    }
  }

  /**
   * Get current drawdown state.
   */
  getDrawdownState(): DrawdownState {
    return { ...this.drawdown };
  }

  /**
   * Check if the daily loss circuit breaker is tripped.
   */
  isDailyLossBreached(dailyPnl: number): boolean {
    return dailyPnl <= -this.config.maxDailyLoss;
  }

  /**
   * Calculate correlation-adjusted exposure.
   * Penalizes concentrated positions in correlated assets.
   */
  correlationExposure(positions: PortfolioPosition[]): {
    adjustedExposure: number;
    warnings: string[];
  } {
    // Known high-correlation pairs for crypto
    const correlatedPairs: Array<[string, string, number]> = [
      ["BTC", "ETH", 0.85],
      ["SOL", "ETH", 0.7],
      ["ARB", "ETH", 0.8],
      ["OP", "ETH", 0.8],
      ["DOGE", "WIF", 0.6],
      ["PEPE", "WIF", 0.5],
    ];

    let adjustedExposure = 0;
    const warnings: string[] = [];

    for (const pos of positions) {
      const notional = pos.size * pos.currentPrice;
      adjustedExposure += notional;

      // Check correlation with other positions
      for (const other of positions) {
        if (pos.symbol === other.symbol) continue;

        const pair = correlatedPairs.find(
          ([a, b]) =>
            (a === pos.symbol && b === other.symbol) ||
            (b === pos.symbol && a === other.symbol),
        );

        if (pair) {
          const correlation = pair[2];
          const otherNotional = other.size * other.currentPrice;
          const sameSide = pos.side === other.side;

          if (sameSide && correlation > 0.6) {
            const additionalRisk = Math.min(notional, otherNotional) * correlation * 0.5;
            adjustedExposure += additionalRisk;
            warnings.push(
              `${pos.symbol}/${other.symbol} same-direction correlation: ${(correlation * 100).toFixed(0)}%`,
            );
          }
        }
      }
    }

    return { adjustedExposure, warnings };
  }

  /**
   * Round position size to appropriate precision.
   */
  private roundSize(size: number, price: number): number {
    if (price > 10000) {
      // BTC-like: 0.001 precision
      return Math.floor(size * 1000) / 1000;
    }
    if (price > 100) {
      // ETH-like: 0.01 precision
      return Math.floor(size * 100) / 100;
    }
    if (price > 1) {
      // SOL-like: 0.1 precision
      return Math.floor(size * 10) / 10;
    }
    // Small coins: integer precision
    return Math.floor(size);
  }
}
