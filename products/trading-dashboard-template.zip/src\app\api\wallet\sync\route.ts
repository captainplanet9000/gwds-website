import { NextResponse } from 'next/server'
import { getBalance, getPositions } from '@/lib/hyperliquid/client'

export async function GET() {
  try {
    const [balance, positions] = await Promise.all([
      getBalance(),
      getPositions(),
    ])

    const accountValue = parseFloat(balance.accountValue)
    const marginUsed = parseFloat(balance.totalMarginUsed)
    const withdrawable = accountValue - marginUsed

    const parsed = positions
      .filter(p => parseFloat(p.szi) !== 0)
      .map(p => {
        const size = parseFloat(p.szi)
        const entryPrice = parseFloat(p.entryPx)
        const posValue = parseFloat(p.positionValue)
        const pnl = parseFloat(p.unrealizedPnl)
        const roe = parseFloat(p.returnOnEquity)
        const liqPx = p.liquidationPx ? parseFloat(p.liquidationPx) : null

        return {
          coin: p.coin,
          side: size > 0 ? 'long' as const : 'short' as const,
          size: Math.abs(size),
          entryPrice,
          markPrice: posValue / Math.abs(size) || entryPrice,
          positionValue: posValue,
          pnl,
          roe,
          leverage: p.leverage.value,
          leverageType: p.leverage.type,
          liquidationPrice: liqPx,
        }
      })

    const totalPnl = parsed.reduce((s, p) => s + p.pnl, 0)

    return NextResponse.json({
      accountValue,
      margin: marginUsed,
      withdrawable,
      freeCollateral: withdrawable,
      totalUnrealizedPnl: totalPnl,
      pnl24h: totalPnl,
      pnl24hPct: accountValue > 0 ? (totalPnl / accountValue) * 100 : 0,
      positions: parsed,
      address: process.env.NEXT_PUBLIC_MAIN_WALLET_ADDRESS || '',
      network: process.env.NEXT_PUBLIC_HYPERLIQUID_NETWORK || 'mainnet',
    })
  } catch (error) {
    console.error('Wallet sync error:', error)
    return NextResponse.json(
      { error: 'Failed to sync wallet' },
      { status: 500 }
    )
  }
}
