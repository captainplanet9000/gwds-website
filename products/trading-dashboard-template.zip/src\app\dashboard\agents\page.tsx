'use client'

import { useState, useEffect, useCallback } from 'react'
import { Card, CardHeader, CardContent } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Switch } from '@/components/ui/switch'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter, DialogTrigger } from '@/components/ui/dialog'
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuSeparator, DropdownMenuTrigger } from '@/components/ui/dropdown-menu'
import { fetchAPI, formatUSD, formatPnL, pnlColor, timeAgo, formatPercent } from '@/lib/utils'
import { Plus, MoreVertical, Eye, Pencil, Trash2, Bot, Zap } from 'lucide-react'

/* ─── Types ─────────────────────────────────────────────────────── */

interface AgentData {
  id: string
  name: string
  strategy: string
  status: 'active' | 'paused' | 'stopped' | 'error'
  allocatedBalance: number
  pnl: number
  tradeCount: number
  winRate: number
  config: {
    symbols?: string[]
    max_position_pct?: number
    stop_loss_pct?: number
    take_profit_pct?: number
    ai_analysis?: boolean
  }
  createdAt: string
}

interface WalletData {
  accountValue: number
  freeCollateral: number
}

const STRATEGIES = [
  { value: 'vwap-mean-reversion', label: 'VWAP Mean Reversion', desc: 'Buys oversold, sells overbought relative to VWAP' },
  { value: 'momentum-ema', label: 'EMA Momentum', desc: 'Trades EMA 9/21 crossover signals' },
  { value: 'bollinger-breakout', label: 'BB Breakout', desc: 'Trades Bollinger Band breakouts' },
  { value: 'custom', label: 'Custom Strategy', desc: 'Define your own entry/exit logic' },
]

const AVAILABLE_SYMBOLS = ['BTC', 'ETH', 'SOL', 'HYPE', 'SUI', 'DOGE', 'ARB', 'OP', 'AVAX', 'LINK', 'WIF', 'PEPE']

/* ─── Skeleton ──────────────────────────────────────────────────── */

function Skeleton({ className = '' }: { className?: string }) {
  return <div className={`skeleton ${className}`} />
}

/* ─── Create Agent Dialog ───────────────────────────────────────── */

function CreateAgentDialog({ onCreated }: { onCreated: () => void }) {
  const [open, setOpen] = useState(false)
  const [name, setName] = useState('')
  const [strategy, setStrategy] = useState('vwap-mean-reversion')
  const [selectedSymbols, setSelectedSymbols] = useState<string[]>(['BTC', 'ETH'])
  const [allocation, setAllocation] = useState('')
  const [maxPosition, setMaxPosition] = useState('25')
  const [stopLoss, setStopLoss] = useState('5')
  const [takeProfit, setTakeProfit] = useState('10')
  const [aiAnalysis, setAiAnalysis] = useState(false)
  const [deploying, setDeploying] = useState(false)

  function toggleSymbol(sym: string) {
    setSelectedSymbols(prev =>
      prev.includes(sym) ? prev.filter(s => s !== sym) : [...prev, sym]
    )
  }

  async function handleDeploy() {
    setDeploying(true)
    try {
      await fetchAPI('/api/agents', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          name,
          strategy,
          symbols: selectedSymbols,
          allocation: parseFloat(allocation),
          maxPositionPct: parseFloat(maxPosition),
          stopLossPct: parseFloat(stopLoss),
          takeProfitPct: parseFloat(takeProfit),
          aiAnalysis,
        }),
      })
      setOpen(false)
      resetForm()
      onCreated()
    } catch { /* toast error */ } finally {
      setDeploying(false)
    }
  }

  function resetForm() {
    setName('')
    setStrategy('vwap-mean-reversion')
    setSelectedSymbols(['BTC', 'ETH'])
    setAllocation('')
    setMaxPosition('25')
    setStopLoss('5')
    setTakeProfit('10')
    setAiAnalysis(false)
  }

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button className="gap-2">
          <Plus className="w-4 h-4" />
          Create Agent
        </Button>
      </DialogTrigger>
      <DialogContent className="max-w-xl">
        <DialogHeader>
          <DialogTitle>Deploy New Agent</DialogTitle>
          <DialogDescription>Configure an autonomous trading agent with your risk parameters.</DialogDescription>
        </DialogHeader>

        <div className="space-y-5">
          {/* Name */}
          <div>
            <Label className="text-xs mb-1.5 block">Agent Name</Label>
            <Input placeholder="e.g. BTC Scalper Alpha" value={name} onChange={e => setName(e.target.value)} />
          </div>

          {/* Strategy */}
          <div>
            <Label className="text-xs mb-1.5 block">Strategy</Label>
            <Select value={strategy} onValueChange={setStrategy}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {STRATEGIES.map(s => (
                  <SelectItem key={s.value} value={s.value}>{s.label}</SelectItem>
                ))}
              </SelectContent>
            </Select>
            <p className="text-[10px] text-text-muted mt-1">
              {STRATEGIES.find(s => s.value === strategy)?.desc}
            </p>
          </div>

          {/* Symbols */}
          <div>
            <Label className="text-xs mb-1.5 block">Trading Pairs</Label>
            <div className="flex flex-wrap gap-1.5">
              {AVAILABLE_SYMBOLS.map(sym => (
                <button
                  key={sym}
                  onClick={() => toggleSymbol(sym)}
                  className={`px-2.5 py-1 rounded-md text-xs font-medium transition-all ${selectedSymbols.includes(sym) ? 'bg-accent-purple/20 text-accent-purple border border-accent-purple/30' : 'bg-dashboard-card border border-dashboard-border text-text-muted hover:text-text-secondary'}`}
                >
                  {sym}
                </button>
              ))}
            </div>
          </div>

          {/* Allocation */}
          <div>
            <Label className="text-xs mb-1.5 block">Allocation (USD)</Label>
            <Input type="number" placeholder="1000" value={allocation} onChange={e => setAllocation(e.target.value)} />
          </div>

          {/* Risk Limits */}
          <div className="grid grid-cols-3 gap-3">
            <div>
              <Label className="text-xs mb-1.5 block">Max Position %</Label>
              <Input type="number" value={maxPosition} onChange={e => setMaxPosition(e.target.value)} />
            </div>
            <div>
              <Label className="text-xs mb-1.5 block">Stop Loss %</Label>
              <Input type="number" value={stopLoss} onChange={e => setStopLoss(e.target.value)} />
            </div>
            <div>
              <Label className="text-xs mb-1.5 block">Take Profit %</Label>
              <Input type="number" value={takeProfit} onChange={e => setTakeProfit(e.target.value)} />
            </div>
          </div>

          {/* AI Analysis */}
          <div className="flex items-center justify-between p-3 rounded-lg bg-dashboard-card border border-dashboard-border">
            <div>
              <p className="text-sm font-medium text-text-primary flex items-center gap-2">
                <Zap className="w-4 h-4 text-accent-purple" />
                AI Analysis
              </p>
              <p className="text-[10px] text-text-muted mt-0.5">Uses OpenRouter for LLM-powered trade reasoning</p>
            </div>
            <Switch checked={aiAnalysis} onCheckedChange={setAiAnalysis} />
          </div>
        </div>

        <DialogFooter>
          <Button variant="ghost" onClick={() => setOpen(false)}>Cancel</Button>
          <Button
            onClick={handleDeploy}
            disabled={deploying || !name || !allocation}
            className="gap-2"
          >
            <Bot className="w-4 h-4" />
            {deploying ? 'Deploying...' : 'Deploy Agent'}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  )
}

/* ─── Agent Card ────────────────────────────────────────────────── */

function AgentCard({ agent }: { agent: AgentData }) {
  const strategyLabel = STRATEGIES.find(s => s.value === agent.strategy)?.label || agent.strategy

  return (
    <Card hover className="relative overflow-hidden">
      {/* Status glow line */}
      <div className={`absolute top-0 left-0 right-0 h-0.5 ${agent.status === 'active' ? 'bg-accent-green' : agent.status === 'error' ? 'bg-accent-red' : 'bg-dashboard-border'}`} />

      <CardContent className="p-5">
        <div className="flex items-start justify-between mb-4">
          <div className="flex items-center gap-3">
            <div className={`w-10 h-10 rounded-xl flex items-center justify-center text-sm font-bold ${agent.status === 'active' ? 'bg-accent-purple/15 text-accent-purple' : 'bg-dashboard-card text-text-muted'}`}>
              <Bot className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-sm font-semibold text-text-primary">{agent.name}</h3>
              <Badge variant="purple" className="mt-1">{strategyLabel}</Badge>
            </div>
          </div>

          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <button className="p-1.5 rounded-md text-text-muted hover:text-text-primary hover:bg-dashboard-hover transition-colors">
                <MoreVertical className="w-4 h-4" />
              </button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              <DropdownMenuItem><Eye className="w-4 h-4" /> View Trades</DropdownMenuItem>
              <DropdownMenuItem><Pencil className="w-4 h-4" /> Edit Config</DropdownMenuItem>
              <DropdownMenuSeparator />
              <DropdownMenuItem className="text-accent-red"><Trash2 className="w-4 h-4" /> Delete Agent</DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>

        {/* Metrics */}
        <div className="grid grid-cols-2 gap-3 mb-4">
          <div>
            <p className="text-[10px] text-text-muted uppercase tracking-wider">Allocated</p>
            <p className="text-sm font-mono font-medium text-text-primary">{formatUSD(agent.allocatedBalance)}</p>
          </div>
          <div>
            <p className="text-[10px] text-text-muted uppercase tracking-wider">PnL</p>
            <p className={`text-sm font-mono font-medium ${pnlColor(agent.pnl)}`}>{formatPnL(agent.pnl)}</p>
          </div>
          <div>
            <p className="text-[10px] text-text-muted uppercase tracking-wider">Trades</p>
            <p className="text-sm font-mono font-medium text-text-primary">{agent.tradeCount}</p>
          </div>
          <div>
            <p className="text-[10px] text-text-muted uppercase tracking-wider">Win Rate</p>
            <div className="flex items-center gap-2">
              <p className={`text-sm font-mono font-medium ${agent.winRate >= 50 ? 'text-accent-green' : 'text-accent-red'}`}>
                {agent.winRate.toFixed(0)}%
              </p>
              {/* Mini bar */}
              <div className="flex-1 h-1.5 rounded-full bg-dashboard-card overflow-hidden">
                <div
                  className={`h-full rounded-full transition-all ${agent.winRate >= 50 ? 'bg-accent-green' : 'bg-accent-red'}`}
                  style={{ width: `${Math.min(agent.winRate, 100)}%` }}
                />
              </div>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="flex items-center justify-between pt-3 border-t border-dashboard-border">
          <div className="flex items-center gap-2">
            <Badge variant={agent.status as 'active' | 'paused' | 'stopped' | 'error'}>{agent.status}</Badge>
            <span className="text-[10px] text-text-muted">{timeAgo(agent.createdAt)}</span>
          </div>
          <Switch
            checked={agent.status === 'active'}
            disabled
          />
        </div>
      </CardContent>
    </Card>
  )
}

/* ─── Page ──────────────────────────────────────────────────────── */

export default function AgentsPage() {
  const [agents, setAgents] = useState<AgentData[]>([])
  const [wallet, setWallet] = useState<WalletData | null>(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState('')

  const load = useCallback(async () => {
    setLoading(true)
    setError('')
    try {
      const [a, w] = await Promise.all([
        fetchAPI<AgentData[]>('/api/agents'),
        fetchAPI<WalletData>('/api/wallet/sync'),
      ])
      setAgents(a)
      setWallet(w)
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Failed to load')
    } finally {
      setLoading(false)
    }
  }, [])

  useEffect(() => { load() }, [load])

  const totalAllocated = agents.reduce((s, a) => s + a.allocatedBalance, 0)
  const unallocated = (wallet?.accountValue || 0) - totalAllocated

  if (error) {
    return (
      <div className="flex flex-col items-center justify-center py-20 gap-4">
        <div className="w-12 h-12 rounded-full bg-accent-red/10 flex items-center justify-center">
          <svg className="w-6 h-6 text-accent-red" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/></svg>
        </div>
        <p className="text-text-secondary text-sm">{error}</p>
        <Button onClick={load} variant="outline" size="sm">Retry</Button>
      </div>
    )
  }

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Wallet Banner */}
      <Card glow>
        <CardContent className="py-5">
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
            <div className="grid grid-cols-3 gap-6">
              <div>
                <p className="text-xs text-text-muted uppercase tracking-wider mb-1">Account Value</p>
                {loading ? <Skeleton className="h-7 w-28" /> : (
                  <p className="text-xl font-bold font-mono text-text-primary">{formatUSD(wallet?.accountValue || 0)}</p>
                )}
              </div>
              <div>
                <p className="text-xs text-text-muted uppercase tracking-wider mb-1">Allocated</p>
                {loading ? <Skeleton className="h-7 w-24" /> : (
                  <p className="text-xl font-bold font-mono text-accent-purple">{formatUSD(totalAllocated)}</p>
                )}
              </div>
              <div>
                <p className="text-xs text-text-muted uppercase tracking-wider mb-1">Unallocated</p>
                {loading ? <Skeleton className="h-7 w-24" /> : (
                  <p className="text-xl font-bold font-mono text-accent-green">{formatUSD(unallocated)}</p>
                )}
              </div>
            </div>
            <CreateAgentDialog onCreated={load} />
          </div>
        </CardContent>
      </Card>

      {/* Agents Grid */}
      {loading ? (
        <div className="grid md:grid-cols-2 xl:grid-cols-3 gap-4">
          {Array.from({ length: 6 }).map((_, i) => (
            <Card key={i} className="p-5">
              <div className="flex items-center gap-3 mb-4">
                <Skeleton className="w-10 h-10 rounded-xl" />
                <div><Skeleton className="h-4 w-32 mb-1" /><Skeleton className="h-3 w-20" /></div>
              </div>
              <div className="grid grid-cols-2 gap-3 mb-4">
                {Array.from({ length: 4 }).map((_, j) => (
                  <div key={j}><Skeleton className="h-3 w-16 mb-1" /><Skeleton className="h-5 w-20" /></div>
                ))}
              </div>
              <Skeleton className="h-8 w-full" />
            </Card>
          ))}
        </div>
      ) : agents.length === 0 ? (
        <Card className="flex flex-col items-center justify-center py-16">
          <div className="w-16 h-16 rounded-2xl bg-accent-purple/10 flex items-center justify-center mb-4">
            <Bot className="w-8 h-8 text-accent-purple" />
          </div>
          <h3 className="text-lg font-semibold text-text-primary mb-2">No Agents Deployed</h3>
          <p className="text-sm text-text-muted mb-6 max-w-xs text-center">
            Create your first autonomous trading agent to start generating alpha.
          </p>
          <CreateAgentDialog onCreated={load} />
        </Card>
      ) : (
        <div className="grid md:grid-cols-2 xl:grid-cols-3 gap-4">
          {agents.map(agent => (
            <AgentCard key={agent.id} agent={agent} />
          ))}
        </div>
      )}
    </div>
  )
}
