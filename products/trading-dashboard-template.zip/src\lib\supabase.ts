/**
 * Supabase Client Factory
 *
 * Creates typed Supabase clients for browser and server contexts.
 * Uses environment variables for connection — no secrets in code.
 */

import { createClient, type SupabaseClient } from "@supabase/supabase-js";

// ─── Database Types ──────────────────────────────────────────────────────────

export interface Agent {
  id: string;
  name: string;
  strategy: string;
  config: Record<string, unknown>;
  allocated_balance: number;
  status: "active" | "paused" | "stopped" | "error";
  performance_json: Record<string, unknown> | null;
  created_at: string;
}

export interface AgentTrade {
  id: string;
  agent_id: string;
  symbol: string;
  side: "long" | "short";
  size: number;
  entry_price: number;
  exit_price: number | null;
  pnl: number | null;
  status: "open" | "closed" | "cancelled";
  stop_loss: number | null;
  take_profit: number | null;
  created_at: string;
  closed_at: string | null;
}

export interface AgentDecision {
  id: string;
  agent_id: string;
  decision: "buy" | "sell" | "hold";
  reasoning: string;
  market_data: Record<string, unknown>;
  created_at: string;
}

// ─── Client Factories ────────────────────────────────────────────────────────

let browserClient: SupabaseClient | null = null;

/**
 * Returns a Supabase client for browser/client-side use (anon key).
 * Singleton — safe to call multiple times.
 */
export function getSupabaseBrowser(): SupabaseClient {
  if (browserClient) return browserClient;

  const url = process.env.NEXT_PUBLIC_SUPABASE_URL;
  const anonKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY;

  if (!url || !anonKey) {
    throw new Error(
      "Missing NEXT_PUBLIC_SUPABASE_URL or NEXT_PUBLIC_SUPABASE_ANON_KEY. " +
      "Run `npm run setup` or check .env.local.",
    );
  }

  browserClient = createClient(url, anonKey);
  return browserClient;
}

/**
 * Returns a Supabase client with service role privileges (server-side only).
 * Creates a new instance each call — do NOT use in client components.
 */
export function getSupabaseAdmin(): SupabaseClient {
  const url = process.env.NEXT_PUBLIC_SUPABASE_URL;
  const serviceKey = process.env.SUPABASE_SERVICE_ROLE_KEY;

  if (!url || !serviceKey) {
    throw new Error(
      "Missing NEXT_PUBLIC_SUPABASE_URL or SUPABASE_SERVICE_ROLE_KEY. " +
      "Run `npm run setup` or check .env.local.",
    );
  }

  return createClient(url, serviceKey, {
    auth: { autoRefreshToken: false, persistSession: false },
  });
}
