-- ============================================================================
-- Trading Dashboard Pro — Supabase Schema
-- Run this once in your Supabase SQL Editor.
-- ============================================================================

-- ─── Agents ─────────────────────────────────────────────────────────────────
-- Stores agent configurations, status, and cached performance metrics.

CREATE TABLE IF NOT EXISTS agents (
  id          TEXT PRIMARY KEY,
  name        TEXT NOT NULL,
  strategy    TEXT NOT NULL CHECK (strategy IN ('vwap_reversion', 'ema_momentum', 'bb_breakout', 'custom')),
  config      JSONB NOT NULL DEFAULT '{}',
  allocated_balance NUMERIC(14, 2) NOT NULL DEFAULT 0,
  status      TEXT NOT NULL DEFAULT 'paused' CHECK (status IN ('active', 'paused', 'stopped', 'error')),
  performance_json JSONB DEFAULT NULL,
  created_at  TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at  TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX idx_agents_status ON agents (status);

-- ─── Agent Trades ───────────────────────────────────────────────────────────
-- Every trade: open and closed. entry/exit/pnl/sl/tp tracked per row.

CREATE TABLE IF NOT EXISTS agent_trades (
  id           TEXT PRIMARY KEY,
  agent_id     TEXT NOT NULL REFERENCES agents(id) ON DELETE CASCADE,
  symbol       TEXT NOT NULL,
  side         TEXT NOT NULL CHECK (side IN ('long', 'short')),
  size         NUMERIC(18, 8) NOT NULL,
  entry_price  NUMERIC(18, 8) NOT NULL,
  exit_price   NUMERIC(18, 8),
  pnl          NUMERIC(18, 8),
  fees         NUMERIC(18, 8) DEFAULT 0,
  stop_loss    NUMERIC(18, 8),
  take_profit  NUMERIC(18, 8),
  status       TEXT NOT NULL DEFAULT 'open' CHECK (status IN ('open', 'closed', 'cancelled')),
  close_reason TEXT,
  created_at   TIMESTAMPTZ NOT NULL DEFAULT now(),
  closed_at    TIMESTAMPTZ
);

CREATE INDEX idx_trades_agent ON agent_trades (agent_id);
CREATE INDEX idx_trades_status ON agent_trades (status);
CREATE INDEX idx_trades_symbol ON agent_trades (symbol);
CREATE INDEX idx_trades_created ON agent_trades (created_at DESC);
CREATE INDEX idx_trades_agent_status ON agent_trades (agent_id, status);

-- ─── Agent Decisions ────────────────────────────────────────────────────────
-- Reasoning log for every analysis cycle. Used for debugging and audit.

CREATE TABLE IF NOT EXISTS agent_decisions (
  id                  TEXT PRIMARY KEY,
  agent_id            TEXT NOT NULL REFERENCES agents(id) ON DELETE CASCADE,
  symbol              TEXT NOT NULL,
  decision            TEXT NOT NULL CHECK (decision IN ('buy', 'sell', 'hold')),
  strategy_signal     TEXT NOT NULL,
  strategy_confidence NUMERIC(5, 4),
  ai_override         JSONB,
  risk_check          JSONB NOT NULL DEFAULT '{}',
  reasoning           TEXT,
  executed            BOOLEAN NOT NULL DEFAULT false,
  market_data         JSONB DEFAULT '{}',
  created_at          TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX idx_decisions_agent ON agent_decisions (agent_id);
CREATE INDEX idx_decisions_created ON agent_decisions (created_at DESC);
CREATE INDEX idx_decisions_executed ON agent_decisions (agent_id, executed);

-- ─── Coordination Scratchpad ────────────────────────────────────────────────
-- Agents broadcast state here so others can avoid conflicts and
-- coordinate positions (e.g., prevent two agents from opening the same trade).

CREATE TABLE IF NOT EXISTS coordination_scratchpad (
  id           BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  agent_id     TEXT NOT NULL REFERENCES agents(id) ON DELETE CASCADE,
  agent_name   TEXT NOT NULL,
  message_type TEXT NOT NULL,
  payload      JSONB NOT NULL DEFAULT '{}',
  created_at   TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX idx_scratchpad_agent ON coordination_scratchpad (agent_id);
CREATE INDEX idx_scratchpad_created ON coordination_scratchpad (created_at DESC);

-- ─── Settings ───────────────────────────────────────────────────────────────
-- Key-value store for user preferences and app configuration.

CREATE TABLE IF NOT EXISTS settings (
  key        TEXT PRIMARY KEY,
  value      JSONB NOT NULL,
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Insert sensible defaults
INSERT INTO settings (key, value) VALUES
  ('theme', '"dark"'),
  ('default_leverage', '5'),
  ('notifications_enabled', 'true'),
  ('max_portfolio_drawdown', '15'),
  ('auto_rebalance', 'false')
ON CONFLICT (key) DO NOTHING;

-- ─── Helper Functions ───────────────────────────────────────────────────────

-- Auto-update updated_at on agents table
CREATE OR REPLACE FUNCTION update_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER agents_updated_at
  BEFORE UPDATE ON agents
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at();

-- Get agent P&L summary (useful for dashboard queries)
CREATE OR REPLACE FUNCTION get_agent_summary(p_agent_id TEXT)
RETURNS TABLE (
  total_trades  BIGINT,
  open_trades   BIGINT,
  total_pnl     NUMERIC,
  total_fees    NUMERIC,
  win_count     BIGINT,
  loss_count    BIGINT,
  best_trade    NUMERIC,
  worst_trade   NUMERIC
) AS $$
BEGIN
  RETURN QUERY
  SELECT
    COUNT(*)                                       AS total_trades,
    COUNT(*) FILTER (WHERE t.status = 'open')      AS open_trades,
    COALESCE(SUM(t.pnl), 0)                       AS total_pnl,
    COALESCE(SUM(t.fees), 0)                       AS total_fees,
    COUNT(*) FILTER (WHERE t.pnl > 0)              AS win_count,
    COUNT(*) FILTER (WHERE t.pnl <= 0 AND t.pnl IS NOT NULL) AS loss_count,
    COALESCE(MAX(t.pnl), 0)                        AS best_trade,
    COALESCE(MIN(t.pnl), 0)                        AS worst_trade
  FROM agent_trades t
  WHERE t.agent_id = p_agent_id;
END;
$$ LANGUAGE plpgsql;

-- Purge old scratchpad entries (call periodically or via cron)
CREATE OR REPLACE FUNCTION purge_old_scratchpad(days_to_keep INT DEFAULT 7)
RETURNS INT AS $$
DECLARE
  deleted_count INT;
BEGIN
  DELETE FROM coordination_scratchpad
  WHERE created_at < now() - (days_to_keep || ' days')::INTERVAL;
  GET DIAGNOSTICS deleted_count = ROW_COUNT;
  RETURN deleted_count;
END;
$$ LANGUAGE plpgsql;

-- ─── Row Level Security ─────────────────────────────────────────────────────
-- Enable RLS on all tables. The anon key gets read access; writes require
-- the service role key (used server-side by the agent engine).

ALTER TABLE agents ENABLE ROW LEVEL SECURITY;
ALTER TABLE agent_trades ENABLE ROW LEVEL SECURITY;
ALTER TABLE agent_decisions ENABLE ROW LEVEL SECURITY;
ALTER TABLE coordination_scratchpad ENABLE ROW LEVEL SECURITY;
ALTER TABLE settings ENABLE ROW LEVEL SECURITY;

-- Anon: read-only access (for the dashboard frontend)
CREATE POLICY agents_read ON agents FOR SELECT TO anon USING (true);
CREATE POLICY trades_read ON agent_trades FOR SELECT TO anon USING (true);
CREATE POLICY decisions_read ON agent_decisions FOR SELECT TO anon USING (true);
CREATE POLICY scratchpad_read ON coordination_scratchpad FOR SELECT TO anon USING (true);
CREATE POLICY settings_read ON settings FOR SELECT TO anon USING (true);

-- Service role: full access (for the agent engine server-side)
CREATE POLICY agents_all ON agents FOR ALL TO service_role USING (true) WITH CHECK (true);
CREATE POLICY trades_all ON agent_trades FOR ALL TO service_role USING (true) WITH CHECK (true);
CREATE POLICY decisions_all ON agent_decisions FOR ALL TO service_role USING (true) WITH CHECK (true);
CREATE POLICY scratchpad_all ON coordination_scratchpad FOR ALL TO service_role USING (true) WITH CHECK (true);
CREATE POLICY settings_all ON settings FOR ALL TO service_role USING (true) WITH CHECK (true);

-- ============================================================================
-- Done. Your database is ready.
-- ============================================================================
