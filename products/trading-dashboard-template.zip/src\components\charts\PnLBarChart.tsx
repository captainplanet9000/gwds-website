'use client'

import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid, Cell } from 'recharts'
import { formatUSD } from '@/lib/utils'

export interface PnLDay {
  date: string
  pnl: number
}

interface PnLBarChartProps {
  data: PnLDay[]
  height?: number
  className?: string
}

function CustomTooltip({ active, payload, label }: { active?: boolean; payload?: Array<{ value: number }>; label?: string }) {
  if (!active || !payload?.length) return null
  const value = payload[0].value
  return (
    <div className="bg-dashboard-surface border border-dashboard-border rounded-lg px-3 py-2 shadow-xl">
      <p className="text-xs text-text-muted mb-1">{label}</p>
      <p className={`text-sm font-mono font-semibold ${value >= 0 ? 'text-accent-green' : 'text-accent-red'}`}>
        {value >= 0 ? '+' : ''}{formatUSD(value)}
      </p>
    </div>
  )
}

export function PnLBarChart({ data, height = 280, className = '' }: PnLBarChartProps) {
  if (!data.length) return null

  return (
    <div className={className} style={{ height }}>
      <ResponsiveContainer width="100%" height="100%">
        <BarChart data={data} margin={{ top: 5, right: 5, left: 5, bottom: 0 }}>
          <CartesianGrid strokeDasharray="3 3" stroke="rgba(42, 42, 62, 0.5)" vertical={false} />
          <XAxis
            dataKey="date"
            tick={{ fill: '#64748b', fontSize: 10, fontFamily: "'JetBrains Mono', monospace" }}
            tickLine={false}
            axisLine={{ stroke: '#2a2a3e' }}
          />
          <YAxis
            tick={{ fill: '#64748b', fontSize: 10, fontFamily: "'JetBrains Mono', monospace" }}
            tickLine={false}
            axisLine={false}
            tickFormatter={(v: number) => formatUSD(v)}
            width={70}
          />
          <Tooltip content={<CustomTooltip />} cursor={{ fill: 'rgba(139, 92, 246, 0.05)' }} />
          <Bar dataKey="pnl" radius={[3, 3, 0, 0]} maxBarSize={32}>
            {data.map((entry, i) => (
              <Cell key={i} fill={entry.pnl >= 0 ? '#22c55e' : '#ef4444'} fillOpacity={0.8} />
            ))}
          </Bar>
        </BarChart>
      </ResponsiveContainer>
    </div>
  )
}
