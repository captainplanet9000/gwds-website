'use client'

import React from 'react'

interface CardProps extends React.HTMLAttributes<HTMLDivElement> {
  children: React.ReactNode
  hover?: boolean
  glow?: boolean
}

export function Card({ children, className = '', hover = false, glow = false, ...props }: CardProps) {
  return (
    <div
      className={`bg-dashboard-surface border border-dashboard-border rounded-xl ${hover ? 'hover:border-accent-purple/30 hover:bg-dashboard-hover transition-all duration-200' : ''} ${glow ? 'shadow-[0_0_20px_rgba(139,92,246,0.05)]' : ''} ${className}`}
      {...props}
    >
      {children}
    </div>
  )
}

export function CardHeader({ children, className = '' }: { children: React.ReactNode; className?: string }) {
  return (
    <div className={`px-5 py-4 border-b border-dashboard-border ${className}`}>
      {children}
    </div>
  )
}

export function CardContent({ children, className = '' }: { children: React.ReactNode; className?: string }) {
  return (
    <div className={`px-5 py-4 ${className}`}>
      {children}
    </div>
  )
}
