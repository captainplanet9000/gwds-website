# Changelog

All notable changes to Trading Dashboard Pro are documented here.

---

## 1.0.0 — March 2026

Initial release.

### Agent Engine
- `TradingAgent` class with full analysis cycle: fetch → strategy → risk → AI → execute
- `AgentOrchestrator` for managing multiple concurrent agents
- Multi-agent coordination via shared scratchpad
- Performance-based auto-rebalancing
- Automatic position monitoring with trailing stop support

### Strategies
- VWAP Mean Reversion — range-bound market strategy
- EMA Momentum Crossover (9/21) — trend-following strategy
- Bollinger Band Breakout — volatility breakout strategy
- Custom strategy support via `StrategyFunction` interface

### Risk Management
- Kelly Criterion position sizing (half-Kelly for safety)
- Fixed-fractional position sizing (1% risk per trade)
- Daily loss circuit breaker
- Max concurrent position limits
- Risk/reward ratio filter (min 1.0 R:R)
- Drawdown-adjusted sizing (auto-reduces in drawdowns)
- Correlation-based exposure monitoring

### AI Analysis
- DeepSeek V3 integration via OpenRouter
- Confirm/override/abstain decisions with reasoning
- Rate-limited to 10 requests/minute
- Graceful fallback when API key not configured

### Dashboard
- Real-time TradingView Lightweight Charts
- Live position and P&L tracking
- Agent status and performance metrics
- Trade history with decision audit trail

### Infrastructure
- Interactive setup wizard (`node setup.mjs`)
- Complete Supabase schema with RLS policies
- Hyperliquid mainnet + testnet support
- EIP-712 signed order placement
