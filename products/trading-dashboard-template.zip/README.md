# 🚀 Trading Dashboard Pro

**Autonomous trading agents for Hyperliquid DEX — with AI-powered analysis, real-time charting, and a risk management suite that actually works.**

Built by [Gamma Waves Design Studio](https://gwds-website.vercel.app)

![Trading Dashboard Pro](public/screenshot-placeholder.png)

---

## What You Get

**Autonomous Trading Agents** — Deploy agents that analyze markets, manage risk, and execute trades on Hyperliquid. Each agent runs its own strategy, tracks its own P&L, and respects its own risk limits. You configure them, they do the work.

**3 Built-In Strategies** — VWAP Mean Reversion (range-bound markets), EMA Momentum Crossover (trending markets), and Bollinger Band Breakout (volatility plays). Each one is production-tested with proper ATR-based stop losses and take profits.

**Real-Time Dashboard** — TradingView Lightweight Charts with live price feeds, position tracking, P&L curves, and agent status monitoring. Everything updates in real time.

**Risk Management Suite** — Kelly Criterion and fixed-fractional position sizing. Drawdown tracking. Correlation-based exposure limits. Daily loss circuit breakers. This isn't a toy — it's the same risk framework institutional desks use, scaled down for individual traders.

**AI Analysis Layer** — Optional DeepSeek V3 integration via OpenRouter. When enabled, the AI reviews every strategy signal before execution — confirming, overriding, or abstaining. Costs pennies per analysis.

**Multi-Agent Orchestration** — Run multiple agents simultaneously. Each operates independently but they coordinate through a shared scratchpad to prevent conflicting positions. The orchestrator handles portfolio-level risk and can auto-rebalance allocations based on agent performance.

**Full Source Code** — No black boxes. Every line of TypeScript is yours to read, modify, and deploy. Add your own strategies, connect additional exchanges, change the UI.

---

## Tech Stack

| Layer | Technology |
|---|---|
| Framework | Next.js 15 (App Router) |
| UI | shadcn/ui + Tailwind CSS 4 |
| Charts | TradingView Lightweight Charts + Recharts |
| Exchange | Hyperliquid DEX (Mainnet) |
| Database | Supabase (PostgreSQL) |
| AI | OpenRouter (DeepSeek V3) |
| Language | TypeScript (strict mode) |

---

## Quick Start

### 1. Clone and install

```bash
git clone <your-repo-url> trading-dashboard-pro
cd trading-dashboard-pro
npm install
```

### 2. Run the setup wizard

```bash
node setup.mjs
```

The wizard walks you through connecting your Hyperliquid wallet, Supabase database, and (optionally) OpenRouter for AI analysis. It tests every connection before finishing.

### 3. Create the database tables

Copy the contents of `setup.sql` into your [Supabase SQL Editor](https://supabase.com/dashboard) and run it. This creates all tables, indexes, RLS policies, and helper functions.

### 4. Start the dashboard

```bash
npm run dev
```

### 5. Open the dashboard

Navigate to [http://localhost:3000/dashboard](http://localhost:3000/dashboard)

---

## Architecture

```
┌──────────────┐     ┌──────────────────┐     ┌─────────────────┐
│   Dashboard   │────▶│  Agent Engine     │────▶│  Hyperliquid    │
│   (Next.js)   │     │  (Orchestrator)   │     │  DEX (Mainnet)  │
└──────────────┘     └──────────────────┘     └─────────────────┘
       │                     │                         │
       │              ┌──────┴──────┐                  │
       │              │             │                  │
       ▼              ▼             ▼                  │
┌──────────────┐ ┌─────────┐ ┌──────────┐             │
│   Supabase    │ │  Risk    │ │  AI      │             │
│  (Postgres)   │ │ Manager  │ │ Analysis │             │
└──────────────┘ └─────────┘ └──────────┘             │
                                    │                  │
                                    ▼                  │
                              ┌──────────┐             │
                              │ OpenRouter│─────────────┘
                              │(DeepSeek) │
                              └──────────┘
```

**The flow for every trade:**

1. **Fetch** — Agent pulls 15m candles from Hyperliquid for each symbol
2. **Analyze** — Strategy function processes candles, returns signal + confidence + SL/TP
3. **Risk Check** — Risk manager validates: position sizing, daily loss, concurrent positions, R:R ratio
4. **AI Review** (optional) — LLM confirms or overrides the signal with reasoning
5. **Execute** — Market order placed on Hyperliquid with calculated size
6. **Monitor** — Position tracked in real time, SL/TP checked every cycle, trailing stops updated
7. **Log** — Every decision, trade, and state change recorded in Supabase

---

## Agent System

### Creating an Agent

Agents are defined by their config:

```typescript
import { AgentOrchestrator } from "@/lib/agents/engine";
import { getSupabaseAdmin } from "@/lib/supabase";

const orchestrator = new AgentOrchestrator(getSupabaseAdmin());

orchestrator.addAgent({
  id: "btc-mean-reversion",
  name: "BTC Mean Reverter",
  strategy: "vwap_reversion",
  symbols: ["BTC"],
  allocatedBalance: 500,
  riskLimits: {
    maxPositionPercent: 10,     // max 10% of allocation per trade
    stopLossPercent: 2,         // 2% trailing stop
    takeProfitPercent: 4,       // 4% take profit
    maxConcurrentPositions: 2,  // max 2 open positions
    maxDailyLoss: 25,           // stop if $25 lost today
  },
  aiAnalysis: true,
  enabled: true,
});

// Start all agents
await orchestrator.startAll();
```

### Built-In Strategies

| Strategy | Best For | How It Works |
|---|---|---|
| `vwap_reversion` | Range-bound markets | Buys below VWAP, sells above. Targets mean reversion. |
| `ema_momentum` | Trending markets | Trades EMA 9/21 crossovers. Rides momentum. |
| `bb_breakout` | Volatile markets | Enters on Bollinger Band breaks. Uses band width for confirmation. |

### Custom Strategies

Add your own strategy by implementing the `StrategyFunction` type:

```typescript
import type { StrategyFunction } from "@/lib/trading/strategies";

const myStrategy: StrategyFunction = (candles) => {
  const price = candles[candles.length - 1].close;

  // Your logic here...

  return {
    signal: "buy",
    confidence: 0.75,
    stopLoss: price * 0.98,
    takeProfit: price * 1.04,
    reason: "My custom signal triggered",
  };
};

// Use it:
orchestrator.addAgent({
  id: "custom-agent",
  name: "My Custom Agent",
  strategy: "custom",
  customStrategy: myStrategy,
  // ... rest of config
});
```

### Risk Management

Every trade passes through the risk manager before execution:

- **Position sizing** — Uses the more conservative of Kelly Criterion (half-Kelly) and fixed-fractional (1% risk per trade)
- **Daily loss circuit breaker** — Agent pauses trading when daily loss exceeds the configured limit
- **Max concurrent positions** — Prevents over-exposure
- **Risk/reward filter** — Rejects trades with R:R below 1.0
- **Drawdown reduction** — Automatically reduces position sizes during drawdowns
- **Correlation monitoring** — Warns when multiple agents hold correlated positions

### Multi-Agent Coordination

Agents communicate through the `coordination_scratchpad` table:

- When an agent opens a position, it broadcasts to the scratchpad
- Other agents can check the scratchpad before trading to avoid conflicts
- The orchestrator monitors portfolio-level risk across all agents
- Auto-rebalance shifts allocation toward higher-performing agents

---

## Customization

### Adding a New Exchange

The exchange layer is in `src/lib/hyperliquid/client.ts`. To add another exchange:

1. Create `src/lib/exchanges/your-exchange.ts` with the same interface (`getBalance`, `getPositions`, `placeMarketOrder`, etc.)
2. Update the agent engine imports to use your exchange client
3. The strategies and risk manager work with any exchange — they only need candle data and order execution

### Changing the UI

The dashboard is standard Next.js + shadcn/ui. Pages live in `src/app/dashboard/`. Charts use TradingView Lightweight Charts (vanilla JS, no React wrapper needed) and Recharts for metrics.

### Environment Variables

See `.env.example` for all available configuration options.

---

## Deployment

### Vercel (Recommended)

```bash
npm run build
vercel deploy --prod
```

Set your environment variables in the Vercel dashboard. The agent engine runs server-side via API routes and Server Actions.

### Self-Hosted

```bash
npm run build
npm start
```

For 24/7 agent operation, run on a VPS with a process manager like PM2:

```bash
pm2 start npm --name "trading-dashboard" -- start
```

---

## Project Structure

```
├── src/
│   ├── app/                    # Next.js pages and API routes
│   │   └── dashboard/          # Dashboard pages
│   ├── components/             # React components
│   └── lib/
│       ├── agents/
│       │   ├── engine.ts       # TradingAgent + AgentOrchestrator
│       │   ├── risk-manager.ts # Position sizing, drawdown, circuit breakers
│       │   └── trade-logger.ts # Supabase logging
│       ├── hyperliquid/
│       │   ├── client.ts       # Hyperliquid REST + signed orders
│       │   └── network-config.ts
│       ├── llm/
│       │   └── openrouter.ts   # DeepSeek V3 via OpenRouter
│       ├── trading/
│       │   └── strategies.ts   # VWAP, EMA, Bollinger strategies
│       ├── supabase.ts         # Supabase client factory
│       └── utils.ts            # Formatting helpers
├── setup.sql                   # Supabase schema (run once)
├── setup.mjs                   # Interactive setup wizard
├── .env.example                # All environment variables
├── LICENSE.md                  # Commercial license
└── CHANGELOG.md
```

---

## FAQ

**Is this paper trading or real money?**
Real money. The agent engine places actual orders on Hyperliquid mainnet. Start with small allocations ($50-100) while you learn how the system behaves.

**Do I need the AI analysis?**
No. The AI layer is optional. Strategies work standalone. The AI adds a confirmation step that can improve win rate, but it's not required. Skip the OpenRouter key in setup to disable it.

**Can I run this 24/7?**
Yes. Deploy to a VPS or use Vercel's serverless functions with cron triggers. The agent engine is designed for continuous operation with automatic daily P&L resets and circuit breakers.

**What if something goes wrong?**
Every agent has multiple safety nets: stop losses on every position, daily loss limits that pause trading, max position limits, and the ability to stop all agents instantly. Every decision is logged with full reasoning for audit.

---

## License

Commercial single-developer license. See [LICENSE.md](LICENSE.md).

## Support

Email: gammawavesdesign@gmail.com

---

Built with conviction by [GWDS](https://gwds-website.vercel.app).
