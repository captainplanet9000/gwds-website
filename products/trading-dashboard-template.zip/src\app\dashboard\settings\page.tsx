'use client'

import { useState, useEffect, useCallback } from 'react'
import { Card, CardHeader, CardContent } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Switch } from '@/components/ui/switch'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Tabs, TabsList, TabsTrigger, TabsContent } from '@/components/ui/tabs'
import { Separator } from '@/components/ui/separator'
import { Badge } from '@/components/ui/badge'
import { fetchAPI } from '@/lib/utils'
import { Settings, Wifi, BarChart3, Bot, Wrench, Check, X, RefreshCw, Download, Trash2 } from 'lucide-react'

/* ─── Types ─────────────────────────────────────────────────────── */

interface SettingsData {
  connection: {
    hyperliquidConnected: boolean
    supabaseConnected: boolean
    openrouterConnected: boolean
    network: string
  }
  trading: {
    defaultLeverage: number
    maxPositionPct: number
    riskPerTradePct: number
    defaultSlippageBps: number
  }
  agents: {
    defaultStrategy: string
    autoTrade: boolean
    maxConcurrentPositions: number
    aiAnalysis: boolean
  }
  advanced: {
    network: string
    dataRetentionDays: number
  }
}

/* ─── Skeleton ──────────────────────────────────────────────────── */

function Skeleton({ className = '' }: { className?: string }) {
  return <div className={`skeleton ${className}`} />
}

/* ─── Connection Status ─────────────────────────────────────────── */

function ConnectionStatus({ label, connected, onTest }: { label: string; connected: boolean; onTest?: () => void }) {
  const [testing, setTesting] = useState(false)

  async function handleTest() {
    if (!onTest) return
    setTesting(true)
    await new Promise(r => setTimeout(r, 1500))
    onTest()
    setTesting(false)
  }

  return (
    <div className="flex items-center justify-between p-4 rounded-lg bg-dashboard-card border border-dashboard-border">
      <div className="flex items-center gap-3">
        <div className={`w-3 h-3 rounded-full ${connected ? 'bg-accent-green animate-pulse' : 'bg-text-muted'}`} />
        <div>
          <p className="text-sm font-medium text-text-primary">{label}</p>
          <p className="text-[10px] text-text-muted">{connected ? 'Connected' : 'Not configured'}</p>
        </div>
      </div>
      <Button variant="ghost" size="sm" onClick={handleTest} disabled={testing} className="gap-1.5">
        {testing ? <RefreshCw className="w-3.5 h-3.5 animate-spin" /> : connected ? <Check className="w-3.5 h-3.5 text-accent-green" /> : <X className="w-3.5 h-3.5 text-accent-red" />}
        {testing ? 'Testing...' : 'Test'}
      </Button>
    </div>
  )
}

/* ─── Slider-like Range Input ───────────────────────────────────── */

function RangeInput({ label, value, onChange, min = 0, max = 100, step = 1, suffix = '%' }: {
  label: string; value: number; onChange: (v: number) => void; min?: number; max?: number; step?: number; suffix?: string
}) {
  return (
    <div>
      <div className="flex items-center justify-between mb-2">
        <Label className="text-xs">{label}</Label>
        <span className="text-xs font-mono text-accent-purple font-medium">{value}{suffix}</span>
      </div>
      <input
        type="range"
        min={min}
        max={max}
        step={step}
        value={value}
        onChange={e => onChange(parseFloat(e.target.value))}
        className="w-full h-1.5 rounded-full bg-dashboard-border appearance-none cursor-pointer [&::-webkit-slider-thumb]:appearance-none [&::-webkit-slider-thumb]:w-4 [&::-webkit-slider-thumb]:h-4 [&::-webkit-slider-thumb]:rounded-full [&::-webkit-slider-thumb]:bg-accent-purple [&::-webkit-slider-thumb]:shadow-lg [&::-webkit-slider-thumb]:shadow-accent-purple/30 [&::-webkit-slider-thumb]:cursor-pointer"
      />
    </div>
  )
}

/* ─── Page ──────────────────────────────────────────────────────── */

export default function SettingsPage() {
  const [settings, setSettings] = useState<SettingsData | null>(null)
  const [loading, setLoading] = useState(true)
  const [saving, setSaving] = useState(false)
  const [saved, setSaved] = useState(false)

  const load = useCallback(async () => {
    setLoading(true)
    try {
      const data = await fetchAPI<SettingsData>('/api/settings')
      setSettings(data)
    } catch { /* silent */ } finally {
      setLoading(false)
    }
  }, [])

  useEffect(() => { load() }, [load])

  async function handleSave() {
    if (!settings) return
    setSaving(true)
    setSaved(false)
    try {
      await fetchAPI('/api/settings', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(settings),
      })
      setSaved(true)
      setTimeout(() => setSaved(false), 3000)
    } catch { /* silent */ } finally {
      setSaving(false)
    }
  }

  function updateTrading(key: keyof SettingsData['trading'], value: number) {
    if (!settings) return
    setSettings({ ...settings, trading: { ...settings.trading, [key]: value } })
  }

  function updateAgents(key: keyof SettingsData['agents'], value: unknown) {
    if (!settings) return
    setSettings({ ...settings, agents: { ...settings.agents, [key]: value } })
  }

  if (loading) {
    return (
      <div className="space-y-6 animate-fade-in">
        <Skeleton className="h-10 w-64" />
        <div className="space-y-4">
          {Array.from({ length: 4 }).map((_, i) => <Skeleton key={i} className="h-20 w-full" />)}
        </div>
      </div>
    )
  }

  return (
    <div className="space-y-6 animate-fade-in max-w-4xl">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-accent-purple/15 flex items-center justify-center">
            <Settings className="w-5 h-5 text-accent-purple" />
          </div>
          <div>
            <h1 className="text-lg font-semibold text-text-primary">Settings</h1>
            <p className="text-xs text-text-muted">Configure your trading dashboard</p>
          </div>
        </div>
        <Button onClick={handleSave} disabled={saving} className="gap-2">
          {saving ? <RefreshCw className="w-4 h-4 animate-spin" /> : saved ? <Check className="w-4 h-4" /> : null}
          {saving ? 'Saving...' : saved ? 'Saved!' : 'Save Changes'}
        </Button>
      </div>

      <Tabs defaultValue="connection">
        <TabsList>
          <TabsTrigger value="connection" className="gap-1.5"><Wifi className="w-3.5 h-3.5" /> Connection</TabsTrigger>
          <TabsTrigger value="trading" className="gap-1.5"><BarChart3 className="w-3.5 h-3.5" /> Trading</TabsTrigger>
          <TabsTrigger value="agents" className="gap-1.5"><Bot className="w-3.5 h-3.5" /> Agents</TabsTrigger>
          <TabsTrigger value="advanced" className="gap-1.5"><Wrench className="w-3.5 h-3.5" /> Advanced</TabsTrigger>
        </TabsList>

        {/* Connection Tab */}
        <TabsContent value="connection">
          <Card>
            <CardHeader>
              <h2 className="text-sm font-semibold text-text-primary">API Connections</h2>
              <p className="text-xs text-text-muted">Status of your external service connections</p>
            </CardHeader>
            <CardContent className="space-y-3">
              <ConnectionStatus label="Hyperliquid DEX" connected={settings?.connection.hyperliquidConnected || false} />
              <ConnectionStatus label="Supabase Database" connected={settings?.connection.supabaseConnected || false} />
              <ConnectionStatus label="OpenRouter (AI)" connected={settings?.connection.openrouterConnected || false} />

              <Separator className="my-4" />

              <div>
                <Label className="text-xs mb-1.5 block">Active Network</Label>
                <div className="flex items-center gap-2">
                  <Badge variant={settings?.connection.network === 'mainnet' ? 'active' : 'info'}>
                    {settings?.connection.network || 'mainnet'}
                  </Badge>
                  <span className="text-[10px] text-text-muted">Set via NEXT_PUBLIC_HYPERLIQUID_NETWORK in .env.local</span>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Trading Tab */}
        <TabsContent value="trading">
          <Card>
            <CardHeader>
              <h2 className="text-sm font-semibold text-text-primary">Trading Parameters</h2>
              <p className="text-xs text-text-muted">Default risk and position sizing</p>
            </CardHeader>
            <CardContent className="space-y-6">
              <div>
                <Label className="text-xs mb-1.5 block">Default Leverage</Label>
                <Select
                  value={String(settings?.trading.defaultLeverage || 5)}
                  onValueChange={v => updateTrading('defaultLeverage', parseInt(v))}
                >
                  <SelectTrigger className="w-[180px]">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {[1, 2, 3, 5, 10, 20, 50].map(l => (
                      <SelectItem key={l} value={String(l)}>{l}× Leverage</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <RangeInput
                label="Max Position Size"
                value={settings?.trading.maxPositionPct || 25}
                onChange={v => updateTrading('maxPositionPct', v)}
                max={100}
              />

              <RangeInput
                label="Risk Per Trade"
                value={settings?.trading.riskPerTradePct || 2}
                onChange={v => updateTrading('riskPerTradePct', v)}
                max={10}
                step={0.5}
              />

              <div>
                <Label className="text-xs mb-1.5 block">Default Slippage (bps)</Label>
                <Input
                  type="number"
                  value={settings?.trading.defaultSlippageBps || 50}
                  onChange={e => updateTrading('defaultSlippageBps', parseInt(e.target.value))}
                  className="w-[180px]"
                />
                <p className="text-[10px] text-text-muted mt-1">50 bps = 0.5% slippage tolerance</p>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Agents Tab */}
        <TabsContent value="agents">
          <Card>
            <CardHeader>
              <h2 className="text-sm font-semibold text-text-primary">Agent Defaults</h2>
              <p className="text-xs text-text-muted">Default configuration for new agents</p>
            </CardHeader>
            <CardContent className="space-y-6">
              <div>
                <Label className="text-xs mb-1.5 block">Default Strategy</Label>
                <Select
                  value={settings?.agents.defaultStrategy || 'vwap-mean-reversion'}
                  onValueChange={v => updateAgents('defaultStrategy', v)}
                >
                  <SelectTrigger className="w-[240px]">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="vwap-mean-reversion">VWAP Mean Reversion</SelectItem>
                    <SelectItem value="momentum-ema">EMA Momentum</SelectItem>
                    <SelectItem value="bollinger-breakout">BB Breakout</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="flex items-center justify-between p-4 rounded-lg bg-dashboard-card border border-dashboard-border">
                <div>
                  <p className="text-sm font-medium text-text-primary">Auto-Trade</p>
                  <p className="text-[10px] text-text-muted">Agents execute trades automatically</p>
                </div>
                <Switch
                  checked={settings?.agents.autoTrade || false}
                  onCheckedChange={v => updateAgents('autoTrade', v)}
                />
              </div>

              <div className="flex items-center justify-between p-4 rounded-lg bg-dashboard-card border border-dashboard-border">
                <div>
                  <p className="text-sm font-medium text-text-primary">AI Analysis</p>
                  <p className="text-[10px] text-text-muted">LLM-powered trade reasoning (requires OpenRouter)</p>
                </div>
                <Switch
                  checked={settings?.agents.aiAnalysis || false}
                  onCheckedChange={v => updateAgents('aiAnalysis', v)}
                />
              </div>

              <div>
                <Label className="text-xs mb-1.5 block">Max Concurrent Positions</Label>
                <Input
                  type="number"
                  value={settings?.agents.maxConcurrentPositions || 5}
                  onChange={e => updateAgents('maxConcurrentPositions', parseInt(e.target.value))}
                  className="w-[180px]"
                />
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Advanced Tab */}
        <TabsContent value="advanced">
          <Card>
            <CardHeader>
              <h2 className="text-sm font-semibold text-text-primary">Advanced Settings</h2>
              <p className="text-xs text-text-muted">System configuration and data management</p>
            </CardHeader>
            <CardContent className="space-y-6">
              <div>
                <Label className="text-xs mb-1.5 block">Network</Label>
                <Select
                  value={settings?.advanced.network || 'mainnet'}
                  onValueChange={v => setSettings(s => s ? { ...s, advanced: { ...s.advanced, network: v } } : s)}
                >
                  <SelectTrigger className="w-[180px]">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="mainnet">Mainnet</SelectItem>
                    <SelectItem value="testnet">Testnet</SelectItem>
                  </SelectContent>
                </Select>
                <p className="text-[10px] text-text-muted mt-1">Requires restart after change</p>
              </div>

              <Separator />

              <div className="space-y-3">
                <h3 className="text-sm font-medium text-text-primary">Data Management</h3>
                <div className="flex gap-3">
                  <Button variant="outline" size="sm" className="gap-1.5">
                    <Download className="w-3.5 h-3.5" />
                    Export Trades CSV
                  </Button>
                  <Button variant="outline" size="sm" className="gap-1.5">
                    <Download className="w-3.5 h-3.5" />
                    Export Agent Config
                  </Button>
                </div>
              </div>

              <Separator />

              <div className="space-y-3">
                <h3 className="text-sm font-medium text-accent-red">Danger Zone</h3>
                <div className="p-4 rounded-lg border border-accent-red/20 bg-accent-red/5">
                  <p className="text-xs text-text-secondary mb-3">
                    Reset all agent configurations and trade history. This cannot be undone.
                  </p>
                  <Button variant="destructive" size="sm" className="gap-1.5">
                    <Trash2 className="w-3.5 h-3.5" />
                    Reset All Data
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
