#!/usr/bin/env node

/**
 * Trading Dashboard Pro — Setup Wizard
 *
 * Interactive setup that:
 * 1. Collects Hyperliquid wallet config
 * 2. Collects Supabase credentials
 * 3. Optionally collects OpenRouter API key
 * 4. Tests all connections
 * 5. Writes .env.local
 *
 * Zero dependencies — uses Node built-ins only.
 */

import { createInterface } from "readline";
import { writeFileSync, existsSync } from "fs";
import { join } from "path";

const rl = createInterface({ input: process.stdin, output: process.stdout });

function ask(question) {
  return new Promise((resolve) => rl.question(question, resolve));
}

function print(msg = "") {
  console.log(msg);
}

function printHeader() {
  print();
  print("  🚀 Trading Dashboard Pro — Setup Wizard");
  print("  ═══════════════════════════════════════");
  print();
}

function printStep(n, total, title) {
  print(`  Step ${n}/${total}: ${title}`);
}

async function testHyperliquid(walletAddress) {
  try {
    const res = await fetch("https://api.hyperliquid.xyz/info", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ type: "clearinghouseState", user: walletAddress }),
    });

    if (!res.ok) return { ok: false, error: `HTTP ${res.status}` };

    const data = await res.json();
    const accountValue =
      data?.marginSummary?.accountValue ??
      data?.crossMarginSummary?.accountValue ??
      "0";

    return {
      ok: true,
      balance: parseFloat(accountValue).toFixed(2),
    };
  } catch (err) {
    return { ok: false, error: err.message };
  }
}

async function testSupabase(url, anonKey) {
  try {
    // Test basic connectivity by hitting the REST endpoint
    const res = await fetch(`${url}/rest/v1/`, {
      headers: {
        apikey: anonKey,
        Authorization: `Bearer ${anonKey}`,
      },
    });

    if (!res.ok && res.status !== 404) {
      return { ok: false, error: `HTTP ${res.status}` };
    }

    return { ok: true };
  } catch (err) {
    return { ok: false, error: err.message };
  }
}

async function testOpenRouter(apiKey) {
  try {
    const res = await fetch("https://openrouter.ai/api/v1/models", {
      headers: { Authorization: `Bearer ${apiKey}` },
    });

    if (!res.ok) return { ok: false, error: `HTTP ${res.status}` };

    return { ok: true };
  } catch (err) {
    return { ok: false, error: err.message };
  }
}

async function main() {
  printHeader();

  // Check if .env.local already exists
  const envPath = join(process.cwd(), ".env.local");
  if (existsSync(envPath)) {
    const overwrite = await ask(
      "  ⚠️  .env.local already exists. Overwrite? (y/N): ",
    );
    if (overwrite.toLowerCase() !== "y") {
      print("  Aborted. Existing .env.local preserved.");
      rl.close();
      return;
    }
    print();
  }

  // Step 1: Hyperliquid Wallet
  printStep(1, 5, "Hyperliquid Wallet");
  const walletAddress = await ask("  Enter your wallet address (0x...): ");

  if (!walletAddress.startsWith("0x") || walletAddress.length < 42) {
    print("  ⚠️  That doesn't look like a valid Ethereum address. Continuing anyway.");
  }
  print();

  // Step 2: API Wallet
  printStep(2, 5, "API Wallet (for trading)");
  print("  ⚠️  This key is stored locally in .env.local only.");
  print("  ⚠️  Use a dedicated API wallet, not your main wallet key.");
  const apiKey = await ask("  Enter your API wallet private key: ");
  print();

  // Step 3: Supabase
  printStep(3, 5, "Supabase Database");
  const supabaseUrl = await ask("  Enter Supabase URL: ");
  const supabaseAnonKey = await ask("  Enter Supabase Anon Key: ");
  const supabaseServiceKey = await ask("  Enter Supabase Service Role Key: ");
  print();

  // Step 4: OpenRouter (optional)
  printStep(4, 5, "AI Analysis (Optional)");
  print("  AI analysis uses DeepSeek V3 via OpenRouter to confirm trade signals.");
  const openRouterKey = await ask(
    "  Enter OpenRouter API Key (or press Enter to skip): ",
  );
  print();

  // Step 5: Test connections
  printStep(5, 5, "Testing Connections...");
  print();

  // Test Hyperliquid
  process.stdout.write("  ⏳ Hyperliquid: Testing...");
  const hlResult = await testHyperliquid(walletAddress);
  if (hlResult.ok) {
    process.stdout.write(
      `\r  ✅ Hyperliquid: Connected (mainnet, balance: $${hlResult.balance})     \n`,
    );
  } else {
    process.stdout.write(
      `\r  ❌ Hyperliquid: Failed (${hlResult.error})                            \n`,
    );
    print("     Double-check your wallet address. Continuing anyway.");
  }

  // Test Supabase
  process.stdout.write("  ⏳ Supabase: Testing...");
  const sbResult = await testSupabase(supabaseUrl, supabaseAnonKey);
  if (sbResult.ok) {
    process.stdout.write(
      "\r  ✅ Supabase: Connected                                               \n",
    );
  } else {
    process.stdout.write(
      `\r  ❌ Supabase: Failed (${sbResult.error})                              \n`,
    );
    print("     Check your URL and keys. Continuing anyway.");
  }

  // Test OpenRouter
  if (openRouterKey) {
    process.stdout.write("  ⏳ OpenRouter: Testing...");
    const orResult = await testOpenRouter(openRouterKey);
    if (orResult.ok) {
      process.stdout.write(
        "\r  ✅ OpenRouter: Connected (DeepSeek V3 available)                     \n",
      );
    } else {
      process.stdout.write(
        `\r  ❌ OpenRouter: Failed (${orResult.error})                            \n`,
      );
    }
  } else {
    print("  ⏭️  OpenRouter: Skipped (AI analysis disabled)");
  }

  print();

  // Write .env.local
  const envContent = `# Trading Dashboard Pro — Environment Variables
# Generated by setup wizard on ${new Date().toISOString().slice(0, 10)}

# ─── Hyperliquid ─────────────────────────────────────────────
NEXT_PUBLIC_MAIN_WALLET_ADDRESS=${walletAddress}
API_WALLET_PRIVATE_KEY=${apiKey}
NEXT_PUBLIC_HYPERLIQUID_NETWORK=mainnet

# ─── Supabase ────────────────────────────────────────────────
NEXT_PUBLIC_SUPABASE_URL=${supabaseUrl}
NEXT_PUBLIC_SUPABASE_ANON_KEY=${supabaseAnonKey}
SUPABASE_SERVICE_ROLE_KEY=${supabaseServiceKey}

# ─── OpenRouter (AI Analysis) ────────────────────────────────
OPENROUTER_API_KEY=${openRouterKey || ""}

# ─── App ─────────────────────────────────────────────────────
NEXT_PUBLIC_SITE_URL=http://localhost:3000
`;

  writeFileSync(envPath, envContent);
  print("  📝 Created .env.local");
  print();
  print("  ─── Next Steps ───────────────────────────────────────");
  print();
  print("  1. Run the SQL schema:");
  print("     Copy setup.sql into your Supabase SQL Editor and run it.");
  print();
  print("  2. Install dependencies:");
  print("     npm install");
  print();
  print("  3. Start the dashboard:");
  print("     npm run dev");
  print();
  print("  4. Open http://localhost:3000/dashboard");
  print();
  print("  Happy trading! 🎯");
  print();

  rl.close();
}

main().catch((err) => {
  console.error("Setup failed:", err.message);
  rl.close();
  process.exit(1);
});
