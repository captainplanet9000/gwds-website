/**
 * Trading Agent Engine
 *
 * The core autonomous trading system. Each TradingAgent runs independent
 * analysis cycles: fetch market data → run strategy → check risk → execute.
 *
 * The AgentOrchestrator coordinates multiple agents, prevents conflicts,
 * and manages portfolio-level risk.
 */

import type { SupabaseClient } from "@supabase/supabase-js";
import {
  getBalance,
  getPositions,
  getAllPrices,
  placeMarketOrder,
  placeLimitOrder,
  cancelOrder,
  type Position as HLPosition,
  type AssetPrice,
  type OrderResult,
} from "@/lib/hyperliquid/client";
import {
  vwapMeanReversion,
  momentumEMA,
  bollingerBreakout,
  type Candle,
  type StrategySignal,
  type StrategyFunction,
} from "@/lib/trading/strategies";
import { callLLMJson, isLLMConfigured } from "@/lib/llm/openrouter";
import { RiskManager, type RiskCheck } from "./risk-manager";
import { TradeLogger } from "./trade-logger";

// ─── Types ───────────────────────────────────────────────────────────────────

export interface AgentConfig {
  id: string;
  name: string;
  strategy: "vwap_reversion" | "ema_momentum" | "bb_breakout" | "custom";
  symbols: string[];
  allocatedBalance: number;
  riskLimits: {
    maxPositionPercent: number;
    stopLossPercent: number;
    takeProfitPercent: number;
    maxConcurrentPositions: number;
    maxDailyLoss: number;
  };
  aiAnalysis: boolean;
  enabled: boolean;
  customStrategy?: StrategyFunction;
  cycleIntervalMs?: number;
}

export interface AgentPosition {
  id: string;
  agentId: string;
  symbol: string;
  side: "long" | "short";
  size: number;
  entryPrice: number;
  currentPrice: number;
  unrealizedPnl: number;
  stopLoss: number;
  takeProfit: number;
  trailingStop?: number;
  openedAt: string;
}

export interface AgentTrade {
  id: string;
  agentId: string;
  symbol: string;
  side: "long" | "short";
  size: number;
  entryPrice: number;
  exitPrice: number;
  pnl: number;
  fees: number;
  openedAt: string;
  closedAt: string;
  reason: string;
}

export interface Decision {
  id: string;
  agentId: string;
  timestamp: string;
  symbol: string;
  strategySignal: StrategySignal;
  aiOverride: AIDecision | null;
  riskCheck: RiskCheck;
  finalAction: "buy" | "sell" | "hold";
  reasoning: string;
  executed: boolean;
}

export interface AIDecision {
  action: "confirm" | "override" | "abstain";
  confidence: number;
  reasoning: string;
  suggestedAction?: "buy" | "sell" | "hold";
}

export interface CycleResult {
  agentId: string;
  timestamp: string;
  symbolResults: SymbolCycleResult[];
  errors: string[];
  durationMs: number;
}

interface SymbolCycleResult {
  symbol: string;
  signal: StrategySignal;
  decision: Decision;
  tradeExecuted: boolean;
  orderResult?: OrderResult;
}

export interface AgentPerformance {
  totalPnl: number;
  winRate: number;
  tradeCount: number;
  winCount: number;
  lossCount: number;
  avgWin: number;
  avgLoss: number;
  profitFactor: number;
  maxDrawdown: number;
  sharpeRatio: number;
  dailyPnl: number;
  bestTrade: number;
  worstTrade: number;
}

export interface AgentState {
  config: AgentConfig;
  positions: AgentPosition[];
  performance: AgentPerformance;
  lastCycleAt: string | null;
  status: "running" | "paused" | "stopped" | "error";
  errorMessage?: string;
}

export interface PortfolioRisk {
  totalExposure: number;
  totalUnrealizedPnl: number;
  marginUsage: number;
  activeAgents: number;
  totalPositions: number;
  correlationWarnings: string[];
  dailyPnlAll: number;
}

// ─── Strategy Registry ──────────────────────────────────────────────────────

const STRATEGY_MAP: Record<string, StrategyFunction> = {
  vwap_reversion: vwapMeanReversion,
  ema_momentum: momentumEMA,
  bb_breakout: bollingerBreakout,
};

// ─── Candle Fetching ─────────────────────────────────────────────────────────

/**
 * Fetch candle data from Hyperliquid's info endpoint.
 * Returns the last `count` candles at the given interval.
 */
async function fetchCandles(
  symbol: string,
  interval: string = "15m",
  count: number = 100,
): Promise<Candle[]> {
  const now = Date.now();
  const intervalMs: Record<string, number> = {
    "1m": 60_000,
    "5m": 300_000,
    "15m": 900_000,
    "1h": 3_600_000,
    "4h": 14_400_000,
    "1d": 86_400_000,
  };
  const ms = intervalMs[interval] ?? 900_000;
  const startTime = now - ms * count;

  const res = await fetch("https://api.hyperliquid.xyz/info", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      type: "candleSnapshot",
      req: { coin: symbol, interval, startTime, endTime: now },
    }),
  });

  if (!res.ok) {
    throw new Error(`Candle fetch failed for ${symbol}: HTTP ${res.status}`);
  }

  const data = (await res.json()) as Array<{
    t: number;
    o: string;
    h: string;
    l: string;
    c: string;
    v: string;
  }>;

  return data.slice(-count).map((c) => ({
    timestamp: c.t,
    open: parseFloat(c.o),
    high: parseFloat(c.h),
    low: parseFloat(c.l),
    close: parseFloat(c.c),
    volume: parseFloat(c.v),
  }));
}

// ─── Trading Agent ───────────────────────────────────────────────────────────

export class TradingAgent {
  readonly config: AgentConfig;
  private supabase: SupabaseClient;
  private riskManager: RiskManager;
  private logger: TradeLogger;
  private strategy: StrategyFunction;
  private positions: Map<string, AgentPosition> = new Map();
  private trades: AgentTrade[] = [];
  private decisions: Decision[] = [];
  private dailyPnl = 0;
  private dailyPnlResetDate: string = "";
  private peakEquity: number;
  private currentDrawdown = 0;
  private status: "running" | "paused" | "stopped" | "error" = "stopped";
  private errorMessage?: string;
  private lastCycleAt: string | null = null;
  private cycleTimer: ReturnType<typeof setInterval> | null = null;

  constructor(config: AgentConfig, supabase: SupabaseClient) {
    this.config = config;
    this.supabase = supabase;
    this.peakEquity = config.allocatedBalance;

    this.riskManager = new RiskManager({
      maxPositionPercent: config.riskLimits.maxPositionPercent,
      stopLossPercent: config.riskLimits.stopLossPercent,
      takeProfitPercent: config.riskLimits.takeProfitPercent,
      maxConcurrentPositions: config.riskLimits.maxConcurrentPositions,
      maxDailyLoss: config.riskLimits.maxDailyLoss,
      allocatedBalance: config.allocatedBalance,
    });

    this.logger = new TradeLogger(supabase, config.id);

    // Resolve strategy
    if (config.strategy === "custom" && config.customStrategy) {
      this.strategy = config.customStrategy;
    } else {
      this.strategy = STRATEGY_MAP[config.strategy] ?? vwapMeanReversion;
    }
  }

  /**
   * Run a single analysis cycle across all configured symbols.
   * Fetches market data, runs strategy, checks risk, executes if signal.
   */
  async runCycle(): Promise<CycleResult> {
    const startTime = Date.now();
    const result: CycleResult = {
      agentId: this.config.id,
      timestamp: new Date().toISOString(),
      symbolResults: [],
      errors: [],
      durationMs: 0,
    };

    // Reset daily P&L at midnight
    const today = new Date().toISOString().slice(0, 10);
    if (this.dailyPnlResetDate !== today) {
      this.dailyPnl = 0;
      this.dailyPnlResetDate = today;
    }

    // Check daily loss circuit breaker
    if (this.dailyPnl <= -this.config.riskLimits.maxDailyLoss) {
      result.errors.push(
        `Daily loss limit hit ($${Math.abs(this.dailyPnl).toFixed(2)}). Pausing until tomorrow.`,
      );
      this.status = "paused";
      return result;
    }

    // Fetch current prices for position monitoring
    let currentPrices: AssetPrice[] = [];
    try {
      currentPrices = await getAllPrices();
    } catch (err) {
      result.errors.push(`Failed to fetch prices: ${(err as Error).message}`);
      return result;
    }

    // Monitor existing positions first (check SL/TP)
    try {
      await this.monitorPositions(currentPrices);
    } catch (err) {
      result.errors.push(`Position monitor error: ${(err as Error).message}`);
    }

    // Run strategy for each symbol
    for (const symbol of this.config.symbols) {
      try {
        const symbolResult = await this.runSymbolCycle(symbol, currentPrices);
        result.symbolResults.push(symbolResult);
      } catch (err) {
        const msg = `${symbol} cycle error: ${(err as Error).message}`;
        result.errors.push(msg);
        console.error(`[Agent ${this.config.name}] ${msg}`);
      }
    }

    this.lastCycleAt = result.timestamp;
    result.durationMs = Date.now() - startTime;

    // Update agent state in Supabase
    try {
      const perf = await this.getPerformance();
      await this.logger.updateAgentState(this.config, perf, this.status);
    } catch (err) {
      result.errors.push(`State update error: ${(err as Error).message}`);
    }

    return result;
  }

  /**
   * Run strategy analysis and execution for a single symbol.
   */
  private async runSymbolCycle(
    symbol: string,
    currentPrices: AssetPrice[],
  ): Promise<SymbolCycleResult> {
    // 1. Fetch candle data
    const candles = await fetchCandles(symbol, "15m", 100);
    if (candles.length < 20) {
      const holdSignal: StrategySignal = {
        signal: "hold",
        confidence: 0,
        stopLoss: 0,
        takeProfit: 0,
        reason: "Insufficient candle data",
      };
      const decision = this.buildDecision(symbol, holdSignal, null, {
        allowed: false,
        reason: "Insufficient data",
        positionSize: 0,
        riskRewardRatio: 0,
      });
      return { symbol, signal: holdSignal, decision, tradeExecuted: false };
    }

    // 2. Run strategy
    const signal = this.strategy(candles);

    // 3. Check risk limits
    const currentPrice =
      parseFloat(
        currentPrices.find((p) => p.coin.toUpperCase() === symbol.toUpperCase())
          ?.markPx ?? "0",
      ) || candles[candles.length - 1].close;

    const existingPosition = this.positions.get(symbol);
    const riskCheck = this.riskManager.evaluate(
      signal,
      currentPrice,
      Array.from(this.positions.values()),
      this.dailyPnl,
    );

    // 4. Optional AI analysis
    let aiDecision: AIDecision | null = null;
    if (
      this.config.aiAnalysis &&
      isLLMConfigured() &&
      signal.signal !== "hold" &&
      signal.confidence >= 0.4
    ) {
      try {
        aiDecision = await this.analyzeWithAI(symbol, candles, signal, currentPrice);
      } catch (err) {
        console.warn(
          `[Agent ${this.config.name}] AI analysis failed for ${symbol}: ${(err as Error).message}`,
        );
      }
    }

    // 5. Make final decision
    const decision = this.buildDecision(symbol, signal, aiDecision, riskCheck);

    // 6. Execute if warranted
    let tradeExecuted = false;
    let orderResult: OrderResult | undefined;

    if (decision.finalAction !== "hold" && riskCheck.allowed) {
      // Check if AI overrode to hold
      if (aiDecision?.action === "override" && aiDecision.suggestedAction === "hold") {
        decision.finalAction = "hold";
        decision.reasoning += " | AI override: hold";
      } else {
        try {
          const execResult = await this.executeSignal(
            symbol,
            decision.finalAction,
            riskCheck.positionSize,
            signal.stopLoss,
            signal.takeProfit,
            currentPrice,
          );
          tradeExecuted = execResult.executed;
          orderResult = execResult.orderResult;
          decision.executed = tradeExecuted;
        } catch (err) {
          console.error(
            `[Agent ${this.config.name}] Execution failed for ${symbol}: ${(err as Error).message}`,
          );
        }
      }
    }

    // Log decision
    try {
      await this.logger.logDecision(decision);
    } catch (err) {
      console.error(`[Agent ${this.config.name}] Decision logging failed: ${(err as Error).message}`);
    }

    this.decisions.push(decision);

    return { symbol, signal, decision, tradeExecuted, orderResult };
  }

  /**
   * Monitor open positions: check SL/TP levels, handle trailing stops.
   */
  async monitorPositions(currentPrices?: AssetPrice[]): Promise<void> {
    if (this.positions.size === 0) return;

    const prices = currentPrices ?? (await getAllPrices());

    for (const [symbol, position] of this.positions) {
      const priceData = prices.find(
        (p) => p.coin.toUpperCase() === symbol.toUpperCase(),
      );
      if (!priceData) continue;

      const currentPrice = parseFloat(priceData.markPx);
      position.currentPrice = currentPrice;

      const isLong = position.side === "long";
      position.unrealizedPnl = isLong
        ? (currentPrice - position.entryPrice) * position.size
        : (position.entryPrice - currentPrice) * position.size;

      // Check stop loss
      const hitStopLoss = isLong
        ? currentPrice <= position.stopLoss
        : currentPrice >= position.stopLoss;

      // Check take profit
      const hitTakeProfit = isLong
        ? currentPrice >= position.takeProfit
        : currentPrice <= position.takeProfit;

      // Trailing stop update
      if (position.trailingStop !== undefined) {
        if (isLong && currentPrice > position.entryPrice) {
          const newStop = currentPrice * (1 - position.trailingStop / 100);
          if (newStop > position.stopLoss) {
            position.stopLoss = newStop;
          }
        } else if (!isLong && currentPrice < position.entryPrice) {
          const newStop = currentPrice * (1 + position.trailingStop / 100);
          if (newStop < position.stopLoss) {
            position.stopLoss = newStop;
          }
        }
      }

      if (hitStopLoss || hitTakeProfit) {
        const reason = hitStopLoss ? "Stop loss triggered" : "Take profit hit";
        await this.closePosition(symbol, currentPrice, reason);
      }
    }
  }

  /**
   * Close a position and log the trade.
   */
  private async closePosition(
    symbol: string,
    exitPrice: number,
    reason: string,
  ): Promise<void> {
    const position = this.positions.get(symbol);
    if (!position) return;

    // Place closing order on Hyperliquid
    const isBuy = position.side === "short"; // close short = buy, close long = sell
    try {
      const result = await placeMarketOrder(symbol, isBuy, position.size);
      if (result.status === "error") {
        console.error(
          `[Agent ${this.config.name}] Close order failed for ${symbol}: ${result.error}`,
        );
        return;
      }
    } catch (err) {
      console.error(
        `[Agent ${this.config.name}] Close order exception for ${symbol}: ${(err as Error).message}`,
      );
      return;
    }

    const pnl =
      position.side === "long"
        ? (exitPrice - position.entryPrice) * position.size
        : (position.entryPrice - exitPrice) * position.size;

    const trade: AgentTrade = {
      id: `${this.config.id}-${Date.now()}`,
      agentId: this.config.id,
      symbol,
      side: position.side,
      size: position.size,
      entryPrice: position.entryPrice,
      exitPrice,
      pnl,
      fees: position.size * exitPrice * 0.0003, // ~3bps taker fee
      openedAt: position.openedAt,
      closedAt: new Date().toISOString(),
      reason,
    };

    this.trades.push(trade);
    this.dailyPnl += pnl;
    this.positions.delete(symbol);

    // Update drawdown tracking
    const equity = this.config.allocatedBalance + this.dailyPnl;
    if (equity > this.peakEquity) {
      this.peakEquity = equity;
    }
    this.currentDrawdown = (this.peakEquity - equity) / this.peakEquity;

    // Log trade to Supabase
    try {
      await this.logger.logTradeClose(trade);
      await this.logger.broadcastToScratchpad(this.config.id, this.config.name, {
        action: "closed",
        symbol,
        side: position.side,
        pnl,
        reason,
      });
    } catch (err) {
      console.error(`[Agent ${this.config.name}] Trade log failed: ${(err as Error).message}`);
    }
  }

  /**
   * Calculate performance metrics from completed trades.
   */
  async getPerformance(): Promise<AgentPerformance> {
    const wins = this.trades.filter((t) => t.pnl > 0);
    const losses = this.trades.filter((t) => t.pnl <= 0);

    const totalPnl = this.trades.reduce((sum, t) => sum + t.pnl, 0);
    const totalFees = this.trades.reduce((sum, t) => sum + t.fees, 0);
    const netPnl = totalPnl - totalFees;

    const avgWin = wins.length > 0 ? wins.reduce((s, t) => s + t.pnl, 0) / wins.length : 0;
    const avgLoss = losses.length > 0 ? Math.abs(losses.reduce((s, t) => s + t.pnl, 0) / losses.length) : 0;

    const grossWins = wins.reduce((s, t) => s + t.pnl, 0);
    const grossLosses = Math.abs(losses.reduce((s, t) => s + t.pnl, 0));
    const profitFactor = grossLosses > 0 ? grossWins / grossLosses : grossWins > 0 ? Infinity : 0;

    // Sharpe ratio approximation (daily returns basis)
    const dailyReturns = this.computeDailyReturns();
    const meanReturn = dailyReturns.length > 0
      ? dailyReturns.reduce((s, r) => s + r, 0) / dailyReturns.length
      : 0;
    const stdReturn = dailyReturns.length > 1
      ? Math.sqrt(
          dailyReturns.reduce((s, r) => s + (r - meanReturn) ** 2, 0) /
            (dailyReturns.length - 1),
        )
      : 0;
    const sharpeRatio = stdReturn > 0 ? (meanReturn / stdReturn) * Math.sqrt(252) : 0;

    return {
      totalPnl: netPnl,
      winRate: this.trades.length > 0 ? (wins.length / this.trades.length) * 100 : 0,
      tradeCount: this.trades.length,
      winCount: wins.length,
      lossCount: losses.length,
      avgWin,
      avgLoss,
      profitFactor,
      maxDrawdown: this.currentDrawdown * 100,
      sharpeRatio,
      dailyPnl: this.dailyPnl,
      bestTrade: this.trades.length > 0 ? Math.max(...this.trades.map((t) => t.pnl)) : 0,
      worstTrade: this.trades.length > 0 ? Math.min(...this.trades.map((t) => t.pnl)) : 0,
    };
  }

  /**
   * Get current agent state (for dashboard display).
   */
  getState(): AgentState {
    const perf = this.getPerformanceSync();
    return {
      config: this.config,
      positions: Array.from(this.positions.values()),
      performance: perf,
      lastCycleAt: this.lastCycleAt,
      status: this.status,
      errorMessage: this.errorMessage,
    };
  }

  /**
   * Start running cycles on an interval.
   */
  start(): void {
    if (this.status === "running") return;
    this.status = "running";
    this.errorMessage = undefined;
    const interval = this.config.cycleIntervalMs ?? 60_000; // default 1 minute

    // Run immediately, then on interval
    this.runCycle().catch((err) => {
      this.status = "error";
      this.errorMessage = (err as Error).message;
    });

    this.cycleTimer = setInterval(async () => {
      if (this.status !== "running") return;
      try {
        await this.runCycle();
      } catch (err) {
        this.status = "error";
        this.errorMessage = (err as Error).message;
        console.error(`[Agent ${this.config.name}] Cycle error: ${this.errorMessage}`);
      }
    }, interval);
  }

  /**
   * Stop the agent from running cycles.
   */
  stop(): void {
    if (this.cycleTimer) {
      clearInterval(this.cycleTimer);
      this.cycleTimer = null;
    }
    this.status = "stopped";
  }

  /**
   * Pause the agent (keeps positions monitored but no new trades).
   */
  pause(): void {
    this.status = "paused";
  }

  // ─── Private Methods ────────────────────────────────────────────────────

  /**
   * Ask the LLM to confirm or override the strategy signal.
   */
  private async analyzeWithAI(
    symbol: string,
    candles: Candle[],
    signal: StrategySignal,
    currentPrice: number,
  ): Promise<AIDecision> {
    const recentCandles = candles.slice(-10);
    const priceChange24h =
      candles.length >= 96
        ? ((currentPrice - candles[candles.length - 96].close) /
            candles[candles.length - 96].close) *
          100
        : 0;

    const prompt = `You are a trading analyst. Analyze this trade signal and decide whether to confirm, override, or abstain.

Symbol: ${symbol}
Current Price: $${currentPrice.toFixed(2)}
24h Change: ${priceChange24h.toFixed(2)}%

Strategy Signal: ${signal.signal.toUpperCase()}
Confidence: ${(signal.confidence * 100).toFixed(0)}%
Reason: ${signal.reason}
Stop Loss: $${signal.stopLoss.toFixed(2)}
Take Profit: $${signal.takeProfit.toFixed(2)}

Recent prices (last 10 candles, 15m):
${recentCandles.map((c) => `  ${new Date(c.timestamp).toISOString().slice(11, 16)} O:${c.open.toFixed(2)} H:${c.high.toFixed(2)} L:${c.low.toFixed(2)} C:${c.close.toFixed(2)} V:${c.volume.toFixed(0)}`).join("\n")}

Respond as JSON: { "action": "confirm"|"override"|"abstain", "confidence": 0-1, "reasoning": "...", "suggestedAction": "buy"|"sell"|"hold" }`;

    const result = await callLLMJson<AIDecision>(prompt, "You are a cautious quantitative trading analyst. Prioritize capital preservation.");

    if (!result) {
      return { action: "abstain", confidence: 0, reasoning: "LLM unavailable" };
    }

    return {
      action: result.action ?? "abstain",
      confidence: Math.min(Math.max(result.confidence ?? 0, 0), 1),
      reasoning: result.reasoning ?? "No reasoning provided",
      suggestedAction: result.suggestedAction,
    };
  }

  /**
   * Build a Decision record from all inputs.
   */
  private buildDecision(
    symbol: string,
    signal: StrategySignal,
    aiDecision: AIDecision | null,
    riskCheck: RiskCheck,
  ): Decision {
    let finalAction: "buy" | "sell" | "hold" = signal.signal;

    // If risk check says no, hold
    if (!riskCheck.allowed && signal.signal !== "hold") {
      finalAction = "hold";
    }

    // If AI overrides
    if (aiDecision?.action === "override" && aiDecision.suggestedAction) {
      finalAction = aiDecision.suggestedAction;
    }

    const parts: string[] = [
      `Strategy: ${signal.reason}`,
      `Risk: ${riskCheck.reason}`,
    ];
    if (aiDecision) {
      parts.push(`AI: ${aiDecision.action} (${aiDecision.reasoning})`);
    }

    return {
      id: `dec-${this.config.id}-${Date.now()}`,
      agentId: this.config.id,
      timestamp: new Date().toISOString(),
      symbol,
      strategySignal: signal,
      aiOverride: aiDecision,
      riskCheck,
      finalAction,
      reasoning: parts.join(" | "),
      executed: false,
    };
  }

  /**
   * Execute a trade signal: place order, create position, log.
   */
  private async executeSignal(
    symbol: string,
    action: "buy" | "sell",
    positionSize: number,
    stopLoss: number,
    takeProfit: number,
    currentPrice: number,
  ): Promise<{ executed: boolean; orderResult?: OrderResult }> {
    // Check for existing position in same symbol
    const existing = this.positions.get(symbol);
    if (existing) {
      // If signal is opposite to current position, close it first
      if (
        (existing.side === "long" && action === "sell") ||
        (existing.side === "short" && action === "buy")
      ) {
        await this.closePosition(symbol, currentPrice, "Signal reversal");
      } else {
        // Same direction — skip, already positioned
        return { executed: false };
      }
    }

    const isBuy = action === "buy";
    const result = await placeMarketOrder(symbol, isBuy, positionSize);

    if (result.status === "error") {
      console.error(
        `[Agent ${this.config.name}] Order error for ${symbol}: ${result.error}`,
      );
      return { executed: false, orderResult: result };
    }

    // Create tracked position
    const position: AgentPosition = {
      id: `pos-${this.config.id}-${Date.now()}`,
      agentId: this.config.id,
      symbol,
      side: isBuy ? "long" : "short",
      size: positionSize,
      entryPrice: currentPrice,
      currentPrice,
      unrealizedPnl: 0,
      stopLoss,
      takeProfit,
      trailingStop: this.config.riskLimits.stopLossPercent,
      openedAt: new Date().toISOString(),
    };

    this.positions.set(symbol, position);

    // Log trade open
    try {
      await this.logger.logTradeOpen(position);
      await this.logger.broadcastToScratchpad(this.config.id, this.config.name, {
        action: "opened",
        symbol,
        side: position.side,
        size: positionSize,
        entryPrice: currentPrice,
        stopLoss,
        takeProfit,
      });
    } catch (err) {
      console.error(`[Agent ${this.config.name}] Log failed: ${(err as Error).message}`);
    }

    return { executed: true, orderResult: result };
  }

  /**
   * Synchronous performance calculation (for getState without await).
   */
  private getPerformanceSync(): AgentPerformance {
    const wins = this.trades.filter((t) => t.pnl > 0);
    const losses = this.trades.filter((t) => t.pnl <= 0);
    const totalPnl = this.trades.reduce((s, t) => s + t.pnl - t.fees, 0);
    const avgWin = wins.length > 0 ? wins.reduce((s, t) => s + t.pnl, 0) / wins.length : 0;
    const avgLoss = losses.length > 0 ? Math.abs(losses.reduce((s, t) => s + t.pnl, 0) / losses.length) : 0;
    const grossWins = wins.reduce((s, t) => s + t.pnl, 0);
    const grossLosses = Math.abs(losses.reduce((s, t) => s + t.pnl, 0));

    return {
      totalPnl,
      winRate: this.trades.length > 0 ? (wins.length / this.trades.length) * 100 : 0,
      tradeCount: this.trades.length,
      winCount: wins.length,
      lossCount: losses.length,
      avgWin,
      avgLoss,
      profitFactor: grossLosses > 0 ? grossWins / grossLosses : grossWins > 0 ? Infinity : 0,
      maxDrawdown: this.currentDrawdown * 100,
      sharpeRatio: 0, // Async calculation needed for full Sharpe
      dailyPnl: this.dailyPnl,
      bestTrade: this.trades.length > 0 ? Math.max(...this.trades.map((t) => t.pnl)) : 0,
      worstTrade: this.trades.length > 0 ? Math.min(...this.trades.map((t) => t.pnl)) : 0,
    };
  }

  /**
   * Compute daily returns from trade history for Sharpe ratio.
   */
  private computeDailyReturns(): number[] {
    if (this.trades.length === 0) return [];

    const dailyMap = new Map<string, number>();
    for (const trade of this.trades) {
      const day = trade.closedAt.slice(0, 10);
      dailyMap.set(day, (dailyMap.get(day) ?? 0) + trade.pnl - trade.fees);
    }

    return Array.from(dailyMap.values()).map(
      (pnl) => pnl / this.config.allocatedBalance,
    );
  }
}

// ─── Agent Orchestrator ──────────────────────────────────────────────────────

export class AgentOrchestrator {
  agents: Map<string, TradingAgent> = new Map();
  private supabase: SupabaseClient;

  constructor(supabase: SupabaseClient) {
    this.supabase = supabase;
  }

  /**
   * Register a new agent with the orchestrator.
   */
  addAgent(config: AgentConfig): TradingAgent {
    if (this.agents.has(config.id)) {
      throw new Error(`Agent ${config.id} already exists`);
    }
    const agent = new TradingAgent(config, this.supabase);
    this.agents.set(config.id, agent);
    return agent;
  }

  /**
   * Remove an agent. Stops it first if running.
   */
  removeAgent(id: string): boolean {
    const agent = this.agents.get(id);
    if (!agent) return false;
    agent.stop();
    this.agents.delete(id);
    return true;
  }

  /**
   * Start all enabled agents.
   */
  async startAll(): Promise<void> {
    for (const [id, agent] of this.agents) {
      if (agent.config.enabled) {
        agent.start();
        console.log(`[Orchestrator] Started agent: ${agent.config.name}`);
      }
    }
  }

  /**
   * Stop all agents.
   */
  async stopAll(): Promise<void> {
    for (const [id, agent] of this.agents) {
      agent.stop();
    }
    console.log("[Orchestrator] All agents stopped");
  }

  /**
   * Run a single cycle on all agents (manual trigger).
   */
  async runAllCycles(): Promise<Map<string, CycleResult>> {
    const results = new Map<string, CycleResult>();

    for (const [id, agent] of this.agents) {
      if (!agent.config.enabled) continue;
      try {
        const result = await agent.runCycle();
        results.set(id, result);
      } catch (err) {
        results.set(id, {
          agentId: id,
          timestamp: new Date().toISOString(),
          symbolResults: [],
          errors: [(err as Error).message],
          durationMs: 0,
        });
      }
    }

    return results;
  }

  /**
   * Get portfolio-level risk metrics across all agents.
   */
  async getPortfolioRisk(): Promise<PortfolioRisk> {
    let totalExposure = 0;
    let totalUnrealizedPnl = 0;
    let totalPositions = 0;
    let dailyPnlAll = 0;
    const symbolExposure = new Map<string, number>();
    const warnings: string[] = [];

    for (const [id, agent] of this.agents) {
      const state = agent.getState();
      for (const pos of state.positions) {
        const exposure = pos.size * pos.currentPrice;
        totalExposure += exposure;
        totalUnrealizedPnl += pos.unrealizedPnl;
        totalPositions++;

        const current = symbolExposure.get(pos.symbol) ?? 0;
        symbolExposure.set(pos.symbol, current + exposure);
      }
      dailyPnlAll += state.performance.dailyPnl;
    }

    // Check for concentration risk
    for (const [symbol, exposure] of symbolExposure) {
      if (exposure > totalExposure * 0.5 && totalExposure > 0) {
        warnings.push(`High concentration in ${symbol}: ${((exposure / totalExposure) * 100).toFixed(0)}% of total exposure`);
      }
    }

    // Check for correlated positions (multiple agents same direction on same symbol)
    const directionMap = new Map<string, Set<string>>();
    for (const [id, agent] of this.agents) {
      for (const pos of agent.getState().positions) {
        const key = `${pos.symbol}-${pos.side}`;
        if (!directionMap.has(key)) directionMap.set(key, new Set());
        directionMap.get(key)!.add(id);
      }
    }
    for (const [key, agentIds] of directionMap) {
      if (agentIds.size > 1) {
        warnings.push(`${agentIds.size} agents have same ${key} position`);
      }
    }

    // Get margin usage from Hyperliquid
    let marginUsage = 0;
    try {
      const balance = await getBalance();
      const accountValue = parseFloat(balance.accountValue);
      const marginUsed = parseFloat(balance.totalMarginUsed);
      marginUsage = accountValue > 0 ? (marginUsed / accountValue) * 100 : 0;
    } catch {
      // Margin check failed, continue with 0
    }

    return {
      totalExposure,
      totalUnrealizedPnl,
      marginUsage,
      activeAgents: Array.from(this.agents.values()).filter(
        (a) => a.getState().status === "running",
      ).length,
      totalPositions,
      correlationWarnings: warnings,
      dailyPnlAll,
    };
  }

  /**
   * Rebalance allocations across agents based on performance.
   * Agents with higher Sharpe ratios get more allocation.
   */
  async rebalance(): Promise<void> {
    const states: Array<{ id: string; perf: AgentPerformance; config: AgentConfig }> = [];

    for (const [id, agent] of this.agents) {
      const perf = await agent.getPerformance();
      states.push({ id, perf, config: agent.config });
    }

    // Only rebalance agents with enough trade history
    const eligible = states.filter((s) => s.perf.tradeCount >= 10);
    if (eligible.length < 2) return;

    const totalAllocation = eligible.reduce((s, e) => s + e.config.allocatedBalance, 0);

    // Weight by Sharpe ratio (min 0.1 to prevent zeroing out)
    const weights = eligible.map((e) => Math.max(e.perf.sharpeRatio, 0.1));
    const totalWeight = weights.reduce((s, w) => s + w, 0);

    for (let i = 0; i < eligible.length; i++) {
      const newAllocation = (weights[i] / totalWeight) * totalAllocation;
      // Update config — the agent will use this on next cycle
      eligible[i].config.allocatedBalance = Math.round(newAllocation * 100) / 100;
    }

    console.log("[Orchestrator] Rebalance complete");
  }

  /**
   * Get all agent states for dashboard display.
   */
  getAllStates(): Map<string, AgentState> {
    const states = new Map<string, AgentState>();
    for (const [id, agent] of this.agents) {
      states.set(id, agent.getState());
    }
    return states;
  }

  /**
   * Load agent configs from Supabase and create agents.
   */
  async loadFromDatabase(): Promise<void> {
    const { data, error } = await this.supabase
      .from("agents")
      .select("*")
      .order("created_at", { ascending: true });

    if (error) {
      throw new Error(`Failed to load agents: ${error.message}`);
    }

    for (const row of data ?? []) {
      const config: AgentConfig = {
        id: row.id,
        name: row.name,
        strategy: row.strategy as AgentConfig["strategy"],
        symbols: row.config?.symbols ?? ["BTC", "ETH"],
        allocatedBalance: row.allocated_balance,
        riskLimits: row.config?.riskLimits ?? {
          maxPositionPercent: 10,
          stopLossPercent: 2,
          takeProfitPercent: 4,
          maxConcurrentPositions: 3,
          maxDailyLoss: 50,
        },
        aiAnalysis: row.config?.aiAnalysis ?? false,
        enabled: row.status === "active",
      };

      this.addAgent(config);
    }
  }
}
