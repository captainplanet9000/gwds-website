/**
 * OpenRouter LLM Client
 *
 * Provides text and JSON completions via OpenRouter's API.
 * Falls back gracefully when no API key is configured.
 *
 * Default model: DeepSeek V3 (fast, cheap, good at reasoning).
 * Change MODEL below to use a different model.
 */

const OPENROUTER_URL = "https://openrouter.ai/api/v1/chat/completions";
const MODEL = "deepseek/deepseek-chat-v3-0324";
const MAX_REQUESTS_PER_MINUTE = 10;

// Simple sliding-window rate limiter
const requestTimestamps: number[] = [];

function checkRateLimit(): boolean {
  const now = Date.now();
  const windowStart = now - 60_000;
  // Remove timestamps outside the window
  while (requestTimestamps.length > 0 && requestTimestamps[0] < windowStart) {
    requestTimestamps.shift();
  }
  if (requestTimestamps.length >= MAX_REQUESTS_PER_MINUTE) {
    return false;
  }
  requestTimestamps.push(now);
  return true;
}

/**
 * Check if the OpenRouter API key is configured.
 */
export function isLLMConfigured(): boolean {
  const key = process.env.OPENROUTER_API_KEY;
  return !!key && key !== "your_openrouter_key_here";
}

/**
 * Call the LLM and return a plain text response.
 *
 * @param prompt - The user message
 * @param systemPrompt - Optional system message for context
 * @param model - Override the default model
 * @returns The assistant's response text, or null if LLM is unavailable
 */
export async function callLLM(
  prompt: string,
  systemPrompt?: string,
  model?: string,
): Promise<string | null> {
  if (!isLLMConfigured()) {
    console.warn("OpenRouter API key not set. Skipping LLM call.");
    return null;
  }

  if (!checkRateLimit()) {
    console.warn("LLM rate limit reached (10/min). Skipping call.");
    return null;
  }

  const messages: Array<{ role: string; content: string }> = [];
  if (systemPrompt) {
    messages.push({ role: "system", content: systemPrompt });
  }
  messages.push({ role: "user", content: prompt });

  const res = await fetch(OPENROUTER_URL, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${process.env.OPENROUTER_API_KEY}`,
      "HTTP-Referer": process.env.NEXT_PUBLIC_SITE_URL ?? "http://localhost:3000",
      "X-Title": "Trading Dashboard Pro",
    },
    body: JSON.stringify({
      model: model ?? MODEL,
      messages,
      temperature: 0.3,
      max_tokens: 2048,
    }),
  });

  if (!res.ok) {
    const text = await res.text();
    console.error(`OpenRouter error ${res.status}: ${text}`);
    return null;
  }

  const data = await res.json();
  return data.choices?.[0]?.message?.content ?? null;
}

/**
 * Call the LLM and parse the response as JSON.
 *
 * Instructs the model to respond with valid JSON only.
 * Returns null if the LLM is unavailable or the response isn't valid JSON.
 *
 * @param prompt - The user message (should request JSON output)
 * @param systemPrompt - Optional system message
 * @returns Parsed JSON object, or null on failure
 */
export async function callLLMJson<T = Record<string, unknown>>(
  prompt: string,
  systemPrompt?: string,
): Promise<T | null> {
  const jsonSystemPrompt = [
    systemPrompt ?? "",
    "Respond with valid JSON only. No markdown, no code fences, no explanation.",
  ]
    .filter(Boolean)
    .join("\n\n");

  const text = await callLLM(prompt, jsonSystemPrompt);
  if (!text) return null;

  try {
    // Strip any accidental markdown fences
    const cleaned = text
      .replace(/^```(?:json)?\s*/i, "")
      .replace(/\s*```$/i, "")
      .trim();
    return JSON.parse(cleaned) as T;
  } catch (err) {
    console.error("Failed to parse LLM JSON response:", err);
    console.error("Raw response:", text);
    return null;
  }
}
