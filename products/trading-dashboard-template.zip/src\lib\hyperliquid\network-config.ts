/**
 * Hyperliquid network configuration.
 * Reads NEXT_PUBLIC_HYPERLIQUID_NETWORK from env to select mainnet or testnet.
 */

export type Network = "mainnet" | "testnet";

export interface NetworkConfig {
  network: Network;
  infoUrl: string;
  exchangeUrl: string;
  wsUrl: string;
  explorerUrl: string;
}

const CONFIGS: Record<Network, NetworkConfig> = {
  mainnet: {
    network: "mainnet",
    infoUrl: "https://api.hyperliquid.xyz/info",
    exchangeUrl: "https://api.hyperliquid.xyz/exchange",
    wsUrl: "wss://api.hyperliquid.xyz/ws",
    explorerUrl: "https://app.hyperliquid.xyz",
  },
  testnet: {
    network: "testnet",
    infoUrl: "https://api.hyperliquid-testnet.xyz/info",
    exchangeUrl: "https://api.hyperliquid-testnet.xyz/exchange",
    wsUrl: "wss://api.hyperliquid-testnet.xyz/ws",
    explorerUrl: "https://app.hyperliquid-testnet.xyz",
  },
};

/**
 * Returns the active network config based on the NEXT_PUBLIC_HYPERLIQUID_NETWORK env var.
 * Defaults to mainnet if not set.
 */
export function getNetworkConfig(): NetworkConfig {
  const network =
    (process.env.NEXT_PUBLIC_HYPERLIQUID_NETWORK as Network) || "mainnet";
  return CONFIGS[network] ?? CONFIGS.mainnet;
}
