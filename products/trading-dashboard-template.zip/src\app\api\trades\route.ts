import { NextRequest, NextResponse } from 'next/server'
import { getSupabaseAdmin, type AgentTrade } from '@/lib/supabase'

export async function GET(request: NextRequest) {
  try {
    const searchParams = request.nextUrl.searchParams
    const limit = parseInt(searchParams.get('limit') || '50')
    const agentId = searchParams.get('agent_id')
    const status = searchParams.get('status')

    const supabase = getSupabaseAdmin()
    let query = supabase
      .from('agent_trades')
      .select('*')
      .order('created_at', { ascending: false })
      .limit(limit)

    if (agentId) query = query.eq('agent_id', agentId)
    if (status) query = query.eq('status', status)

    const { data, error } = await query

    if (error) throw error

    const trades = (data as AgentTrade[]).map(t => ({
      id: t.id,
      agentId: t.agent_id,
      coin: t.symbol,
      side: t.side === 'long' ? 'buy' : 'sell',
      size: t.size,
      price: t.entry_price,
      exitPrice: t.exit_price,
      pnl: t.pnl || 0,
      status: t.status,
      stopLoss: t.stop_loss,
      takeProfit: t.take_profit,
      created_at: t.created_at,
      closed_at: t.closed_at,
    }))

    return NextResponse.json(trades)
  } catch (error) {
    console.error('Trades GET error:', error)
    return NextResponse.json({ error: 'Failed to fetch trades' }, { status: 500 })
  }
}
