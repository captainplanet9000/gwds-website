import { NextResponse } from 'next/server'
import { getBalance, getPositions } from '@/lib/hyperliquid/client'

export async function GET() {
  try {
    const [balance, positions] = await Promise.all([
      getBalance(),
      getPositions(),
    ])

    const accountValue = parseFloat(balance.accountValue)
    const marginUsed = parseFloat(balance.totalMarginUsed)

    const activePositions = positions
      .filter(p => parseFloat(p.szi) !== 0)
      .map(p => {
        const size = parseFloat(p.szi)
        const entryPx = parseFloat(p.entryPx)
        const posValue = parseFloat(p.positionValue)
        const pnl = parseFloat(p.unrealizedPnl)
        const liqPx = p.liquidationPx ? parseFloat(p.liquidationPx) : null
        const markPx = posValue / Math.abs(size) || entryPx

        const distToLiq = liqPx
          ? Math.abs((markPx - liqPx) / markPx) * 100
          : 100

        let riskLevel: 'low' | 'medium' | 'high' | 'critical' = 'low'
        if (distToLiq < 5) riskLevel = 'critical'
        else if (distToLiq < 15) riskLevel = 'high'
        else if (distToLiq < 30) riskLevel = 'medium'

        return {
          coin: p.coin,
          side: size > 0 ? 'long' : 'short',
          size: Math.abs(size),
          leverage: p.leverage.value,
          entryPrice: entryPx,
          markPrice: markPx,
          liquidationPrice: liqPx,
          distanceToLiq: distToLiq,
          pnl,
          exposure: posValue,
          riskLevel,
        }
      })

    const totalExposure = activePositions.reduce((s, p) => s + p.exposure, 0)
    const totalPnl = activePositions.reduce((s, p) => s + p.pnl, 0)
    const marginRatio = accountValue > 0 ? (marginUsed / accountValue) * 100 : 0

    // Risk score: 0-100 (lower = safer)
    let riskScore = 0
    riskScore += Math.min(marginRatio, 50) // margin usage up to 50 points
    riskScore += activePositions.filter(p => p.riskLevel === 'critical').length * 20
    riskScore += activePositions.filter(p => p.riskLevel === 'high').length * 10
    riskScore = Math.min(riskScore, 100)

    // Volatility regime (simplified)
    let volatilityRegime: 'low' | 'normal' | 'high' | 'extreme' = 'normal'
    if (marginRatio > 70) volatilityRegime = 'extreme'
    else if (marginRatio > 50) volatilityRegime = 'high'
    else if (marginRatio < 10) volatilityRegime = 'low'

    return NextResponse.json({
      riskScore: Math.round(riskScore),
      totalExposure,
      marginRatio: Math.round(marginRatio * 100) / 100,
      maxDrawdown: totalPnl < 0 ? Math.abs(totalPnl) : 0,
      sharpeRatio: 0, // Would need historical data
      positions: activePositions,
      accountValue,
      marginUsed,
      volatilityRegime,
    })
  } catch (error) {
    console.error('Risk calc error:', error)
    return NextResponse.json({ error: 'Failed to calculate risk' }, { status: 500 })
  }
}
