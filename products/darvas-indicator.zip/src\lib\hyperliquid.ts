/**
 * Hyperliquid API client for fetching market data
 */

import type { OHLCV } from './darvas'

const MAINNET_API = 'https://api.hyperliquid.xyz'
const TESTNET_API = 'https://api.hyperliquid-testnet.xyz'

function getApiUrl(): string {
  const network = process.env.NEXT_PUBLIC_HYPERLIQUID_NETWORK || 'mainnet'
  return network === 'testnet' ? TESTNET_API : MAINNET_API
}

/**
 * Fetch OHLCV candles for a symbol
 */
export async function fetchCandles(
  symbol: string,
  interval: string = '1h',
  lookbackHours: number = 168 // 7 days default
): Promise<OHLCV[]> {
  const api = getApiUrl()
  const endMs = Date.now()
  const startMs = endMs - lookbackHours * 3600 * 1000

  const res = await fetch(`${api}/info`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      type: 'candleSnapshot',
      req: { coin: symbol, interval, startTime: startMs, endTime: endMs },
    }),
    next: { revalidate: 60 },
  })

  if (!res.ok) throw new Error(`Hyperliquid API error: ${res.status}`)

  const raw = await res.json()
  if (!Array.isArray(raw)) return []

  return raw.map((c: any) => ({
    timestamp: c.t,
    open: parseFloat(c.o),
    high: parseFloat(c.h),
    low: parseFloat(c.l),
    close: parseFloat(c.c),
    volume: parseFloat(c.v || '0'),
  }))
}

/**
 * Fetch all tradeable assets on Hyperliquid
 */
export async function fetchAssets(): Promise<string[]> {
  const api = getApiUrl()

  const res = await fetch(`${api}/info`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ type: 'meta' }),
    next: { revalidate: 300 },
  })

  if (!res.ok) throw new Error(`Hyperliquid API error: ${res.status}`)

  const data = await res.json()
  return (data.universe || []).map((a: any) => a.name)
}

/**
 * Fetch current mid prices for all assets
 */
export async function fetchAllMids(): Promise<Record<string, number>> {
  const api = getApiUrl()

  const res = await fetch(`${api}/info`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ type: 'allMids' }),
    next: { revalidate: 10 },
  })

  if (!res.ok) throw new Error(`Hyperliquid API error: ${res.status}`)

  const data = await res.json()
  const mids: Record<string, number> = {}
  for (const [symbol, price] of Object.entries(data)) {
    mids[symbol] = parseFloat(price as string)
  }
  return mids
}
