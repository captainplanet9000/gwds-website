'use client'

import { useState, useEffect, useCallback } from 'react'
import DarvasChart from '@/components/DarvasChart'
import type { OHLCV, DarvasBox, DarvasSignal } from '@/lib/darvas'
import { TIMEFRAMES, type Timeframe } from '@/lib/darvas'

interface ScanResult {
  symbol: string
  boxes: DarvasBox[]
  signals: DarvasSignal[]
  currentPrice: number
}

export default function DashboardPage() {
  const [symbol, setSymbol] = useState('BTC')
  const [timeframe, setTimeframe] = useState<Timeframe>('1h')
  const [candles, setCandles] = useState<OHLCV[]>([])
  const [boxes, setBoxes] = useState<DarvasBox[]>([])
  const [signals, setSignals] = useState<DarvasSignal[]>([])
  const [scanResults, setScanResults] = useState<ScanResult[]>([])
  const [loading, setLoading] = useState(false)
  const [scanning, setScanning] = useState(false)
  const [error, setError] = useState<string | null>(null)

  const loadSymbol = useCallback(async (sym: string, tf: Timeframe) => {
    setLoading(true)
    setError(null)
    try {
      const res = await fetch(`/api/scan?symbol=${sym}&timeframe=${tf}`)
      const data = await res.json()
      if (data.error) throw new Error(data.error)

      setCandles(data.candles || [])
      setBoxes(data.boxes || [])
      setSignals(data.signals || [])
      setSymbol(sym)
    } catch (err: any) {
      setError(err.message)
    } finally {
      setLoading(false)
    }
  }, [])

  const runScan = useCallback(async () => {
    setScanning(true)
    try {
      const res = await fetch('/api/scan', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ timeframe }),
      })
      const data = await res.json()
      setScanResults(data.results || [])
    } catch (err: any) {
      setError(err.message)
    } finally {
      setScanning(false)
    }
  }, [timeframe])

  useEffect(() => {
    loadSymbol(symbol, timeframe)
  }, [])

  const handleSymbolSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    const form = e.target as HTMLFormElement
    const input = form.elements.namedItem('symbolInput') as HTMLInputElement
    if (input.value.trim()) {
      loadSymbol(input.value.trim().toUpperCase(), timeframe)
    }
  }

  return (
    <div style={{ minHeight: '100vh', background: '#09090b', padding: '24px' }}>
      {/* Header */}
      <div
        style={{
          display: 'flex',
          justifyContent: 'space-between',
          alignItems: 'center',
          marginBottom: 24,
        }}
      >
        <div>
          <h1 style={{ color: '#fafafa', fontSize: 24, fontWeight: 700, margin: 0 }}>
            Darvas Box Scanner
          </h1>
          <p style={{ color: '#71717a', fontSize: 13, margin: '4px 0 0' }}>
            Detect breakout patterns on Hyperliquid perpetuals
          </p>
        </div>
        <a
          href="/"
          style={{ color: '#3b82f6', textDecoration: 'none', fontSize: 14 }}
        >
          ← Back
        </a>
      </div>

      {/* Controls */}
      <div
        style={{
          display: 'flex',
          gap: 12,
          marginBottom: 24,
          flexWrap: 'wrap',
          alignItems: 'center',
        }}
      >
        <form onSubmit={handleSymbolSubmit} style={{ display: 'flex', gap: 8 }}>
          <input
            name="symbolInput"
            defaultValue={symbol}
            placeholder="Symbol (e.g. BTC)"
            style={{
              background: '#18181b',
              border: '1px solid #3f3f46',
              borderRadius: 6,
              padding: '8px 12px',
              color: '#fafafa',
              fontSize: 14,
              width: 140,
              outline: 'none',
            }}
          />
          <button
            type="submit"
            disabled={loading}
            style={{
              background: '#3b82f6',
              color: '#fff',
              border: 'none',
              borderRadius: 6,
              padding: '8px 16px',
              fontSize: 14,
              fontWeight: 600,
              cursor: 'pointer',
              opacity: loading ? 0.5 : 1,
            }}
          >
            {loading ? 'Loading...' : 'Load'}
          </button>
        </form>

        <div style={{ display: 'flex', gap: 4 }}>
          {TIMEFRAMES.map(tf => (
            <button
              key={tf.value}
              onClick={() => {
                setTimeframe(tf.value)
                loadSymbol(symbol, tf.value)
              }}
              style={{
                background: timeframe === tf.value ? '#3b82f6' : '#27272a',
                color: timeframe === tf.value ? '#fff' : '#a1a1aa',
                border: 'none',
                borderRadius: 4,
                padding: '6px 12px',
                fontSize: 13,
                cursor: 'pointer',
              }}
            >
              {tf.label}
            </button>
          ))}
        </div>

        <button
          onClick={runScan}
          disabled={scanning}
          style={{
            background: '#18181b',
            color: '#10b981',
            border: '1px solid #10b981',
            borderRadius: 6,
            padding: '8px 16px',
            fontSize: 14,
            fontWeight: 600,
            cursor: 'pointer',
            opacity: scanning ? 0.5 : 1,
            marginLeft: 'auto',
          }}
        >
          {scanning ? 'Scanning...' : 'Scan All Assets'}
        </button>
      </div>

      {error && (
        <div
          style={{
            background: '#1c1917',
            border: '1px solid #ef4444',
            borderRadius: 8,
            padding: 12,
            color: '#ef4444',
            fontSize: 14,
            marginBottom: 16,
          }}
        >
          {error}
        </div>
      )}

      {/* Chart */}
      <div
        style={{
          background: '#18181b',
          border: '1px solid #27272a',
          borderRadius: 12,
          overflow: 'hidden',
          marginBottom: 24,
        }}
      >
        {candles.length > 0 ? (
          <DarvasChart
            candles={candles}
            boxes={boxes}
            signals={signals}
            symbol={symbol}
            height={480}
          />
        ) : (
          <div
            style={{
              height: 480,
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              color: '#71717a',
            }}
          >
            {loading ? 'Loading chart data...' : 'No data available'}
          </div>
        )}
      </div>

      {/* Detected Boxes */}
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 24 }}>
        <div>
          <h2
            style={{
              color: '#fafafa',
              fontSize: 16,
              fontWeight: 600,
              margin: '0 0 12px',
            }}
          >
            Detected Boxes ({boxes.length})
          </h2>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
            {boxes.length === 0 && (
              <div
                style={{
                  background: '#18181b',
                  border: '1px solid #27272a',
                  borderRadius: 8,
                  padding: 16,
                  color: '#71717a',
                  fontSize: 14,
                }}
              >
                No Darvas Boxes detected in current data.
              </div>
            )}
            {boxes.map((box, i) => (
              <div
                key={box.id}
                style={{
                  background: '#18181b',
                  border: `1px solid ${
                    box.breakout === 'up'
                      ? '#10b981'
                      : box.breakout === 'down'
                      ? '#ef4444'
                      : '#3b82f6'
                  }40`,
                  borderRadius: 8,
                  padding: 14,
                }}
              >
                <div
                  style={{
                    display: 'flex',
                    justifyContent: 'space-between',
                    alignItems: 'center',
                    marginBottom: 8,
                  }}
                >
                  <span style={{ color: '#fafafa', fontWeight: 600, fontSize: 14 }}>
                    Box #{i + 1}
                  </span>
                  <span
                    style={{
                      fontSize: 12,
                      padding: '2px 8px',
                      borderRadius: 4,
                      background:
                        box.breakout === 'up'
                          ? '#10b98120'
                          : box.breakout === 'down'
                          ? '#ef444420'
                          : '#3b82f620',
                      color:
                        box.breakout === 'up'
                          ? '#10b981'
                          : box.breakout === 'down'
                          ? '#ef4444'
                          : '#3b82f6',
                    }}
                  >
                    {box.breakout === 'up'
                      ? '▲ Breakout'
                      : box.breakout === 'down'
                      ? '▼ Breakdown'
                      : '◼ Active'}
                  </span>
                </div>
                <div
                  style={{
                    display: 'grid',
                    gridTemplateColumns: '1fr 1fr',
                    gap: '4px 16px',
                    fontSize: 13,
                    color: '#a1a1aa',
                  }}
                >
                  <div>Top: <span style={{ color: '#fafafa' }}>${box.top.toFixed(2)}</span></div>
                  <div>Bottom: <span style={{ color: '#fafafa' }}>${box.bottom.toFixed(2)}</span></div>
                  <div>Height: <span style={{ color: '#fafafa' }}>{((box.height / box.top) * 100).toFixed(1)}%</span></div>
                  <div>Target: <span style={{ color: '#10b981' }}>${box.target.toFixed(2)}</span></div>
                  <div>Stop: <span style={{ color: '#ef4444' }}>${box.stopLoss.toFixed(2)}</span></div>
                  <div>
                    R:R{' '}
                    <span style={{ color: '#fafafa' }}>
                      1:{((box.target - box.top) / (box.top - box.stopLoss)).toFixed(1)}
                    </span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Signals */}
        <div>
          <h2
            style={{
              color: '#fafafa',
              fontSize: 16,
              fontWeight: 600,
              margin: '0 0 12px',
            }}
          >
            Signals ({signals.length})
          </h2>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
            {signals.length === 0 && (
              <div
                style={{
                  background: '#18181b',
                  border: '1px solid #27272a',
                  borderRadius: 8,
                  padding: 16,
                  color: '#71717a',
                  fontSize: 14,
                }}
              >
                No signals generated.
              </div>
            )}
            {signals.map((signal, i) => (
              <div
                key={i}
                style={{
                  background: '#18181b',
                  border: `1px solid ${
                    signal.type === 'breakout'
                      ? '#10b98140'
                      : signal.type === 'breakdown'
                      ? '#ef444440'
                      : '#3b82f640'
                  }`,
                  borderRadius: 8,
                  padding: 14,
                }}
              >
                <div
                  style={{
                    display: 'flex',
                    justifyContent: 'space-between',
                    marginBottom: 6,
                  }}
                >
                  <span
                    style={{
                      fontWeight: 600,
                      fontSize: 14,
                      color:
                        signal.type === 'breakout'
                          ? '#10b981'
                          : signal.type === 'breakdown'
                          ? '#ef4444'
                          : '#3b82f6',
                    }}
                  >
                    {signal.type === 'breakout'
                      ? '▲ BUY'
                      : signal.type === 'breakdown'
                      ? '▼ SELL'
                      : '◼ WATCH'}
                  </span>
                  <span style={{ color: '#71717a', fontSize: 12 }}>
                    {new Date(signal.timestamp).toLocaleString()}
                  </span>
                </div>
                <div style={{ fontSize: 13, color: '#a1a1aa' }}>
                  <div>
                    Price: <span style={{ color: '#fafafa' }}>${signal.price.toFixed(2)}</span>
                    {' · '}Conf: <span style={{ color: '#fafafa' }}>{(signal.confidence * 100).toFixed(0)}%</span>
                  </div>
                  <div>
                    Target: <span style={{ color: '#10b981' }}>${signal.target.toFixed(2)}</span>
                    {' · '}Stop: <span style={{ color: '#ef4444' }}>${signal.stopLoss.toFixed(2)}</span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Scanner Results */}
      {scanResults.length > 0 && (
        <div style={{ marginTop: 32 }}>
          <h2
            style={{
              color: '#fafafa',
              fontSize: 16,
              fontWeight: 600,
              margin: '0 0 12px',
            }}
          >
            Scan Results ({scanResults.length} setups found)
          </h2>
          <div
            style={{
              background: '#18181b',
              border: '1px solid #27272a',
              borderRadius: 12,
              overflow: 'hidden',
            }}
          >
            <table
              style={{
                width: '100%',
                borderCollapse: 'collapse',
                fontSize: 14,
              }}
            >
              <thead>
                <tr style={{ borderBottom: '1px solid #27272a' }}>
                  {['Symbol', 'Price', 'Boxes', 'Last Signal', 'Type', 'Target', 'Stop', ''].map(
                    (h, i) => (
                      <th
                        key={i}
                        style={{
                          textAlign: 'left',
                          padding: '10px 12px',
                          color: '#71717a',
                          fontWeight: 500,
                          fontSize: 12,
                          textTransform: 'uppercase',
                        }}
                      >
                        {h}
                      </th>
                    )
                  )}
                </tr>
              </thead>
              <tbody>
                {scanResults.map(result => {
                  const lastSignal = result.signals[result.signals.length - 1]
                  return (
                    <tr
                      key={result.symbol}
                      style={{ borderBottom: '1px solid #27272a' }}
                    >
                      <td style={{ padding: '10px 12px', color: '#fafafa', fontWeight: 600 }}>
                        {result.symbol}
                      </td>
                      <td style={{ padding: '10px 12px', color: '#a1a1aa' }}>
                        ${result.currentPrice.toFixed(2)}
                      </td>
                      <td style={{ padding: '10px 12px', color: '#a1a1aa' }}>
                        {result.boxes.length}
                      </td>
                      <td style={{ padding: '10px 12px', color: '#71717a', fontSize: 12 }}>
                        {lastSignal
                          ? new Date(lastSignal.timestamp).toLocaleString()
                          : '—'}
                      </td>
                      <td style={{ padding: '10px 12px' }}>
                        {lastSignal && (
                          <span
                            style={{
                              color:
                                lastSignal.type === 'breakout'
                                  ? '#10b981'
                                  : lastSignal.type === 'breakdown'
                                  ? '#ef4444'
                                  : '#3b82f6',
                              fontWeight: 600,
                            }}
                          >
                            {lastSignal.type === 'breakout'
                              ? '▲ BUY'
                              : lastSignal.type === 'breakdown'
                              ? '▼ SELL'
                              : '◼ WATCH'}
                          </span>
                        )}
                      </td>
                      <td style={{ padding: '10px 12px', color: '#10b981' }}>
                        {lastSignal ? `$${lastSignal.target.toFixed(2)}` : '—'}
                      </td>
                      <td style={{ padding: '10px 12px', color: '#ef4444' }}>
                        {lastSignal ? `$${lastSignal.stopLoss.toFixed(2)}` : '—'}
                      </td>
                      <td style={{ padding: '10px 12px' }}>
                        <button
                          onClick={() => loadSymbol(result.symbol, timeframe)}
                          style={{
                            background: '#27272a',
                            color: '#fafafa',
                            border: 'none',
                            borderRadius: 4,
                            padding: '4px 10px',
                            fontSize: 12,
                            cursor: 'pointer',
                          }}
                        >
                          View
                        </button>
                      </td>
                    </tr>
                  )
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  )
}
