import { NextResponse } from 'next/server'
import { detectDarvasBoxes, generateDarvasSignals, type DarvasConfig } from '@/lib/darvas'
import { fetchCandles, fetchAssets } from '@/lib/hyperliquid'

export const dynamic = 'force-dynamic'

/**
 * POST /api/scan
 * Scan Hyperliquid assets for Darvas Box setups
 *
 * Body: {
 *   symbols?: string[]    — specific symbols to scan (default: top 30 by volume)
 *   timeframe?: string    — candle interval (default: "1h")
 *   lookbackHours?: number — hours of history (default: 168 = 7 days)
 *   config?: Partial<DarvasConfig>
 * }
 */
export async function POST(request: Request) {
  try {
    const body = await request.json().catch(() => ({}))
    const timeframe = body.timeframe || '1h'
    const lookbackHours = body.lookbackHours || 168
    const config: Partial<DarvasConfig> = body.config || {}

    let symbols: string[] = body.symbols || []

    // If no symbols provided, fetch all and take top 30
    if (symbols.length === 0) {
      const allAssets = await fetchAssets()
      symbols = allAssets.slice(0, 30)
    }

    const results: {
      symbol: string
      boxes: ReturnType<typeof detectDarvasBoxes>
      signals: ReturnType<typeof generateDarvasSignals>
      currentPrice: number
    }[] = []

    // Scan each symbol
    for (const symbol of symbols) {
      try {
        const candles = await fetchCandles(symbol, timeframe, lookbackHours)
        if (candles.length < 30) continue

        const boxes = detectDarvasBoxes(candles, config)
        const signals = generateDarvasSignals(symbol, candles, boxes, config)
        const currentPrice = candles[candles.length - 1].close

        if (boxes.length > 0) {
          results.push({ symbol, boxes, signals, currentPrice })
        }
      } catch (err) {
        console.error(`Error scanning ${symbol}:`, err)
      }
    }

    // Sort: symbols with active (unbroken) boxes first, then by signal recency
    results.sort((a, b) => {
      const aActive = a.boxes.some(box => !box.breakout)
      const bActive = b.boxes.some(box => !box.breakout)
      if (aActive && !bActive) return -1
      if (!aActive && bActive) return 1

      const aLatest = a.signals[a.signals.length - 1]?.timestamp ?? 0
      const bLatest = b.signals[b.signals.length - 1]?.timestamp ?? 0
      return bLatest - aLatest
    })

    return NextResponse.json({
      scannedAt: new Date().toISOString(),
      symbolsScanned: symbols.length,
      setupsFound: results.length,
      results,
    })
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 })
  }
}

/**
 * GET /api/scan?symbol=BTC&timeframe=1h
 * Quick scan for a single symbol
 */
export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url)
    const symbol = searchParams.get('symbol') || 'BTC'
    const timeframe = searchParams.get('timeframe') || '1h'
    const lookbackHours = parseInt(searchParams.get('lookback') || '168')

    const candles = await fetchCandles(symbol, timeframe, lookbackHours)
    const boxes = detectDarvasBoxes(candles)
    const signals = generateDarvasSignals(symbol, candles, boxes)

    return NextResponse.json({
      symbol,
      timeframe,
      candleCount: candles.length,
      boxes,
      signals,
      candles,
    })
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 })
  }
}
