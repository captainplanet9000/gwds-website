/**
 * Supporting Technical Indicators
 * ATR, Volume Analysis, EMA, SMA for Darvas Box context
 */

export interface OHLCV {
  timestamp: number
  open: number
  high: number
  low: number
  close: number
  volume: number
}

/**
 * Average True Range — measures volatility
 */
export function calculateATR(candles: OHLCV[], period: number = 14): number[] {
  if (candles.length < 2) return []

  const trueRanges: number[] = []
  trueRanges.push(candles[0].high - candles[0].low)

  for (let i = 1; i < candles.length; i++) {
    const tr = Math.max(
      candles[i].high - candles[i].low,
      Math.abs(candles[i].high - candles[i - 1].close),
      Math.abs(candles[i].low - candles[i - 1].close)
    )
    trueRanges.push(tr)
  }

  const atr: number[] = []
  let sum = 0
  for (let i = 0; i < trueRanges.length; i++) {
    sum += trueRanges[i]
    if (i >= period) sum -= trueRanges[i - period]
    atr.push(i >= period - 1 ? sum / period : sum / (i + 1))
  }

  return atr
}

/**
 * Simple Moving Average
 */
export function calculateSMA(data: number[], period: number): number[] {
  const result: number[] = []
  for (let i = period - 1; i < data.length; i++) {
    const sum = data.slice(i - period + 1, i + 1).reduce((a, b) => a + b, 0)
    result.push(sum / period)
  }
  return result
}

/**
 * Exponential Moving Average
 */
export function calculateEMA(data: number[], period: number): number[] {
  if (data.length === 0) return []
  const k = 2 / (period + 1)
  const ema: number[] = [data[0]]
  for (let i = 1; i < data.length; i++) {
    ema.push(data[i] * k + ema[i - 1] * (1 - k))
  }
  return ema
}

/**
 * Relative Strength Index
 */
export function calculateRSI(closes: number[], period: number = 14): number[] {
  if (closes.length < period + 1) return []

  const gains: number[] = []
  const losses: number[] = []

  for (let i = 1; i < closes.length; i++) {
    const change = closes[i] - closes[i - 1]
    gains.push(change > 0 ? change : 0)
    losses.push(change < 0 ? Math.abs(change) : 0)
  }

  const rsi: number[] = []
  for (let i = period - 1; i < gains.length; i++) {
    const avgGain = gains.slice(i - period + 1, i + 1).reduce((a, b) => a + b, 0) / period
    const avgLoss = losses.slice(i - period + 1, i + 1).reduce((a, b) => a + b, 0) / period
    if (avgLoss === 0) { rsi.push(100); continue }
    const rs = avgGain / avgLoss
    rsi.push(100 - (100 / (1 + rs)))
  }

  return rsi
}

/**
 * Volume analysis — identify volume spikes relative to average
 */
export function analyzeVolume(candles: OHLCV[], period: number = 20): {
  avgVolume: number
  currentVolume: number
  volumeRatio: number
  isSpike: boolean
  trend: 'increasing' | 'decreasing' | 'flat'
} {
  if (candles.length === 0) {
    return { avgVolume: 0, currentVolume: 0, volumeRatio: 0, isSpike: false, trend: 'flat' }
  }

  const volumes = candles.map(c => c.volume)
  const recent = volumes.slice(-period)
  const avgVolume = recent.reduce((a, b) => a + b, 0) / recent.length
  const currentVolume = volumes[volumes.length - 1]
  const volumeRatio = avgVolume > 0 ? currentVolume / avgVolume : 0

  // Check trend in volume
  const firstHalf = recent.slice(0, Math.floor(recent.length / 2))
  const secondHalf = recent.slice(Math.floor(recent.length / 2))
  const avgFirst = firstHalf.reduce((a, b) => a + b, 0) / firstHalf.length
  const avgSecond = secondHalf.reduce((a, b) => a + b, 0) / secondHalf.length

  let trend: 'increasing' | 'decreasing' | 'flat' = 'flat'
  if (avgSecond > avgFirst * 1.15) trend = 'increasing'
  else if (avgSecond < avgFirst * 0.85) trend = 'decreasing'

  return {
    avgVolume,
    currentVolume,
    volumeRatio,
    isSpike: volumeRatio >= 1.5,
    trend,
  }
}

/**
 * Bollinger Bands
 */
export function calculateBollingerBands(
  closes: number[],
  period: number = 20,
  stdDevMultiplier: number = 2
): { upper: number[]; middle: number[]; lower: number[] } {
  const upper: number[] = []
  const middle: number[] = []
  const lower: number[] = []

  for (let i = period - 1; i < closes.length; i++) {
    const slice = closes.slice(i - period + 1, i + 1)
    const mean = slice.reduce((a, b) => a + b, 0) / period
    const variance = slice.reduce((a, b) => a + Math.pow(b - mean, 2), 0) / period
    const stdDev = Math.sqrt(variance)

    middle.push(mean)
    upper.push(mean + stdDev * stdDevMultiplier)
    lower.push(mean - stdDev * stdDevMultiplier)
  }

  return { upper, middle, lower }
}
