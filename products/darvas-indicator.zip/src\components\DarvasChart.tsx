'use client'

import { useEffect, useRef, useState } from 'react'
import {
  createChart,
  type IChartApi,
  type ISeriesApi,
  type CandlestickData,
  type Time,
  ColorType,
} from 'lightweight-charts'
import type { OHLCV, DarvasBox, DarvasSignal } from '@/lib/darvas'

interface DarvasChartProps {
  candles: OHLCV[]
  boxes: DarvasBox[]
  signals: DarvasSignal[]
  symbol: string
  height?: number
}

export default function DarvasChart({
  candles,
  boxes,
  signals,
  symbol,
  height = 500,
}: DarvasChartProps) {
  const containerRef = useRef<HTMLDivElement>(null)
  const chartRef = useRef<IChartApi | null>(null)
  const [hoveredBox, setHoveredBox] = useState<DarvasBox | null>(null)

  useEffect(() => {
    if (!containerRef.current || candles.length === 0) return

    // Clean up previous chart
    if (chartRef.current) {
      chartRef.current.remove()
      chartRef.current = null
    }

    const chart = createChart(containerRef.current, {
      width: containerRef.current.clientWidth,
      height,
      layout: {
        background: { type: ColorType.Solid, color: '#09090b' },
        textColor: '#a1a1aa',
      },
      grid: {
        vertLines: { color: '#27272a' },
        horzLines: { color: '#27272a' },
      },
      crosshair: {
        vertLine: { color: '#71717a', width: 1, style: 2 },
        horzLine: { color: '#71717a', width: 1, style: 2 },
      },
      timeScale: {
        borderColor: '#3f3f46',
        timeVisible: true,
      },
      rightPriceScale: {
        borderColor: '#3f3f46',
      },
    })

    chartRef.current = chart

    // Candlestick series
    const candleSeries = chart.addCandlestickSeries({
      upColor: '#10b981',
      downColor: '#ef4444',
      borderUpColor: '#10b981',
      borderDownColor: '#ef4444',
      wickUpColor: '#10b981',
      wickDownColor: '#ef4444',
    })

    const chartData: CandlestickData[] = candles.map(c => ({
      time: (c.timestamp / 1000) as Time,
      open: c.open,
      high: c.high,
      low: c.low,
      close: c.close,
    }))

    candleSeries.setData(chartData)

    // Volume series
    const volumeSeries = chart.addHistogramSeries({
      color: '#3b82f680',
      priceFormat: { type: 'volume' },
      priceScaleId: 'volume',
    })

    chart.priceScale('volume').applyOptions({
      scaleMargins: { top: 0.8, bottom: 0 },
    })

    volumeSeries.setData(
      candles.map(c => ({
        time: (c.timestamp / 1000) as Time,
        value: c.volume,
        color: c.close >= c.open ? '#10b98140' : '#ef444440',
      }))
    )

    // Draw Darvas Boxes as line series pairs (top and bottom)
    for (const box of boxes) {
      const boxStartTime = (box.startTime / 1000) as Time
      const boxEndTime = box.breakoutTime
        ? (box.breakoutTime / 1000) as Time
        : (box.endTime / 1000) as Time

      // Box top line
      const topLine = chart.addLineSeries({
        color: box.breakout === 'up' ? '#10b981' : box.breakout === 'down' ? '#ef4444' : '#3b82f6',
        lineWidth: 2,
        lineStyle: 0,
        priceLineVisible: false,
        lastValueVisible: false,
        crosshairMarkerVisible: false,
      })

      topLine.setData([
        { time: boxStartTime, value: box.top },
        { time: boxEndTime, value: box.top },
      ])

      // Box bottom line
      const bottomLine = chart.addLineSeries({
        color: box.breakout === 'up' ? '#10b981' : box.breakout === 'down' ? '#ef4444' : '#3b82f6',
        lineWidth: 2,
        lineStyle: 0,
        priceLineVisible: false,
        lastValueVisible: false,
        crosshairMarkerVisible: false,
      })

      bottomLine.setData([
        { time: boxStartTime, value: box.bottom },
        { time: boxEndTime, value: box.bottom },
      ])

      // Target line (dashed)
      if (box.breakout === 'up') {
        const targetLine = chart.addLineSeries({
          color: '#10b98180',
          lineWidth: 1,
          lineStyle: 2,
          priceLineVisible: false,
          lastValueVisible: false,
          crosshairMarkerVisible: false,
        })
        targetLine.setData([
          { time: boxEndTime, value: box.target },
          { time: (candles[candles.length - 1].timestamp / 1000) as Time, value: box.target },
        ])
      }
    }

    // Breakout markers
    const markers = signals
      .filter(s => s.type === 'breakout' || s.type === 'breakdown')
      .map(s => ({
        time: (s.timestamp / 1000) as Time,
        position: s.type === 'breakout' ? 'belowBar' as const : 'aboveBar' as const,
        color: s.type === 'breakout' ? '#10b981' : '#ef4444',
        shape: s.type === 'breakout' ? 'arrowUp' as const : 'arrowDown' as const,
        text: s.type === 'breakout'
          ? `BUY $${s.price.toFixed(2)}`
          : `SELL $${s.price.toFixed(2)}`,
      }))

    if (markers.length > 0) {
      candleSeries.setMarkers(markers)
    }

    // Resize handler
    const handleResize = () => {
      if (containerRef.current && chartRef.current) {
        chartRef.current.applyOptions({ width: containerRef.current.clientWidth })
      }
    }
    window.addEventListener('resize', handleResize)

    chart.timeScale().fitContent()

    return () => {
      window.removeEventListener('resize', handleResize)
      chart.remove()
      chartRef.current = null
    }
  }, [candles, boxes, signals, height])

  return (
    <div style={{ position: 'relative' }}>
      <div
        style={{
          position: 'absolute',
          top: 12,
          left: 12,
          zIndex: 10,
          display: 'flex',
          gap: 8,
          alignItems: 'center',
        }}
      >
        <span style={{ color: '#fafafa', fontWeight: 600, fontSize: 16 }}>{symbol}</span>
        <span style={{ color: '#a1a1aa', fontSize: 13 }}>
          {boxes.length} box{boxes.length !== 1 ? 'es' : ''} detected
        </span>
      </div>
      <div ref={containerRef} />
      {hoveredBox && (
        <div
          style={{
            position: 'absolute',
            bottom: 60,
            right: 12,
            background: '#18181b',
            border: '1px solid #3f3f46',
            borderRadius: 8,
            padding: 12,
            fontSize: 13,
            zIndex: 20,
          }}
        >
          <div style={{ color: '#fafafa', fontWeight: 600 }}>Box #{hoveredBox.id}</div>
          <div style={{ color: '#a1a1aa' }}>
            Top: ${hoveredBox.top.toFixed(2)} | Bottom: ${hoveredBox.bottom.toFixed(2)}
          </div>
          <div style={{ color: '#a1a1aa' }}>
            Height: {((hoveredBox.height / hoveredBox.top) * 100).toFixed(1)}%
          </div>
          {hoveredBox.breakout && (
            <div style={{ color: hoveredBox.breakout === 'up' ? '#10b981' : '#ef4444' }}>
              {hoveredBox.breakout === 'up' ? '▲ Breakout' : '▼ Breakdown'} @ $
              {hoveredBox.breakoutPrice?.toFixed(2)}
            </div>
          )}
        </div>
      )}
    </div>
  )
}
