import type { Metadata } from 'next'
import './globals.css'

export const metadata: Metadata = {
  title: 'Darvas Box Indicator',
  description: 'Detect Darvas Box breakout patterns on Hyperliquid',
}

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body className="antialiased">{children}</body>
    </html>
  )
}
