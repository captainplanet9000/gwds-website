/**
 * Darvas Box Detection Algorithm
 *
 * The Darvas Box method, created by Nicolas Darvas, identifies stocks making new highs
 * then consolidating into a "box" before breaking out. The algorithm:
 *
 * 1. Detect a new high (highest price in N periods)
 * 2. Wait for consolidation — price stays below the high for M periods
 * 3. Once a low is established (price stops making lower lows for M periods), the box is formed
 * 4. Box top = the new high, Box bottom = the consolidation low
 * 5. Breakout above box top = BUY signal
 * 6. Breakdown below box bottom = SELL signal
 * 7. Stop loss = box bottom (for longs), Target = box height projected upward
 */

export interface OHLCV {
  timestamp: number
  open: number
  high: number
  low: number
  close: number
  volume: number
}

export interface DarvasBox {
  id: string
  startIndex: number
  endIndex: number
  top: number
  bottom: number
  startTime: number
  endTime: number
  confirmed: boolean
  breakout: 'up' | 'down' | null
  breakoutIndex: number | null
  breakoutTime: number | null
  breakoutPrice: number | null
  height: number
  target: number         // box top + box height
  stopLoss: number       // box bottom
  volumeAtBreakout: number | null
  avgVolumeInBox: number
}

export interface DarvasSignal {
  type: 'breakout' | 'breakdown' | 'box_forming' | 'box_confirmed'
  symbol: string
  price: number
  boxTop: number
  boxBottom: number
  target: number
  stopLoss: number
  confidence: number    // 0-1
  timestamp: number
  box: DarvasBox
}

export interface DarvasConfig {
  /** Periods to confirm a new high (lookback window) */
  highLookback: number
  /** Periods to confirm the box top is holding */
  topConfirmPeriods: number
  /** Periods to confirm the box bottom is holding */
  bottomConfirmPeriods: number
  /** Minimum box height as % of price (filter tiny boxes) */
  minBoxHeightPct: number
  /** Maximum box height as % of price (filter absurdly large boxes) */
  maxBoxHeightPct: number
  /** Volume surge multiplier for breakout confirmation */
  volumeSurgeMultiplier: number
  /** Maximum number of candles a box can span */
  maxBoxDuration: number
}

const DEFAULT_CONFIG: DarvasConfig = {
  highLookback: 20,
  topConfirmPeriods: 3,
  bottomConfirmPeriods: 3,
  minBoxHeightPct: 0.5,
  maxBoxHeightPct: 15,
  volumeSurgeMultiplier: 1.5,
  maxBoxDuration: 50,
}

/**
 * Detect all Darvas Boxes in OHLCV data
 */
export function detectDarvasBoxes(
  candles: OHLCV[],
  config: Partial<DarvasConfig> = {}
): DarvasBox[] {
  const cfg = { ...DEFAULT_CONFIG, ...config }
  const boxes: DarvasBox[] = []

  if (candles.length < cfg.highLookback + cfg.topConfirmPeriods + cfg.bottomConfirmPeriods) {
    return boxes
  }

  let i = cfg.highLookback
  let boxCount = 0

  while (i < candles.length) {
    // Step 1: Find a new high — highest high in the lookback window
    const lookbackHighs = candles.slice(i - cfg.highLookback, i).map(c => c.high)
    const previousHigh = Math.max(...lookbackHighs)
    const currentHigh = candles[i].high

    if (currentHigh <= previousHigh) {
      i++
      continue
    }

    // We have a new high at index i
    const boxTop = currentHigh
    const boxStartIndex = i
    const boxStartTime = candles[i].timestamp

    // Step 2: Confirm the top — price must NOT exceed this high for topConfirmPeriods
    let topConfirmed = true
    let topCheckEnd = i + 1

    for (let j = i + 1; j < Math.min(i + 1 + cfg.topConfirmPeriods, candles.length); j++) {
      if (candles[j].high > boxTop) {
        topConfirmed = false
        i = j // Move to the new high and restart
        break
      }
      topCheckEnd = j + 1
    }

    if (!topConfirmed || topCheckEnd >= candles.length) {
      i++
      continue
    }

    // Step 3: Find the box bottom — lowest low during consolidation
    let boxBottom = Infinity
    let bottomIndex = topCheckEnd
    let bottomConfirmCount = 0
    let boxEndIndex = topCheckEnd

    for (let j = topCheckEnd; j < Math.min(i + cfg.maxBoxDuration, candles.length); j++) {
      // If price breaks above the top before bottom is confirmed, box is invalid
      if (candles[j].high > boxTop * 1.001) {
        break
      }

      if (candles[j].low < boxBottom) {
        boxBottom = candles[j].low
        bottomIndex = j
        bottomConfirmCount = 0
      } else {
        bottomConfirmCount++
      }

      boxEndIndex = j

      if (bottomConfirmCount >= cfg.bottomConfirmPeriods) {
        break
      }
    }

    if (bottomConfirmCount < cfg.bottomConfirmPeriods) {
      i = boxEndIndex + 1
      continue
    }

    // Validate box dimensions
    const boxHeight = boxTop - boxBottom
    const boxHeightPct = (boxHeight / boxTop) * 100

    if (boxHeightPct < cfg.minBoxHeightPct || boxHeightPct > cfg.maxBoxHeightPct) {
      i = boxEndIndex + 1
      continue
    }

    // Calculate average volume within the box
    const boxCandles = candles.slice(boxStartIndex, boxEndIndex + 1)
    const avgVolumeInBox = boxCandles.reduce((sum, c) => sum + c.volume, 0) / boxCandles.length

    // Step 4: Look for breakout/breakdown after box confirmation
    let breakout: 'up' | 'down' | null = null
    let breakoutIndex: number | null = null
    let breakoutTime: number | null = null
    let breakoutPrice: number | null = null
    let volumeAtBreakout: number | null = null

    for (let j = boxEndIndex + 1; j < candles.length; j++) {
      // Breakout above top
      if (candles[j].close > boxTop) {
        breakout = 'up'
        breakoutIndex = j
        breakoutTime = candles[j].timestamp
        breakoutPrice = candles[j].close
        volumeAtBreakout = candles[j].volume
        break
      }

      // Breakdown below bottom
      if (candles[j].close < boxBottom) {
        breakout = 'down'
        breakoutIndex = j
        breakoutTime = candles[j].timestamp
        breakoutPrice = candles[j].close
        volumeAtBreakout = candles[j].volume
        break
      }
    }

    boxCount++
    boxes.push({
      id: `darvas-${boxCount}`,
      startIndex: boxStartIndex,
      endIndex: boxEndIndex,
      top: boxTop,
      bottom: boxBottom,
      startTime: boxStartTime,
      endTime: candles[boxEndIndex].timestamp,
      confirmed: true,
      breakout,
      breakoutIndex,
      breakoutTime,
      breakoutPrice,
      height: boxHeight,
      target: boxTop + boxHeight,
      stopLoss: boxBottom,
      volumeAtBreakout,
      avgVolumeInBox,
    })

    // Move past this box
    i = (breakoutIndex ?? boxEndIndex) + 1
  }

  return boxes
}

/**
 * Generate trading signals from detected boxes
 */
export function generateDarvasSignals(
  symbol: string,
  candles: OHLCV[],
  boxes: DarvasBox[],
  config: Partial<DarvasConfig> = {}
): DarvasSignal[] {
  const cfg = { ...DEFAULT_CONFIG, ...config }
  const signals: DarvasSignal[] = []

  for (const box of boxes) {
    const currentCandle = candles[candles.length - 1]

    // Active box with breakout
    if (box.breakout === 'up' && box.breakoutPrice && box.breakoutTime) {
      const volumeSurge = box.volumeAtBreakout
        ? box.volumeAtBreakout / box.avgVolumeInBox
        : 1

      let confidence = 0.5
      if (volumeSurge >= cfg.volumeSurgeMultiplier) confidence += 0.2
      if (box.height / box.top > 0.02) confidence += 0.1
      if (box.breakoutPrice > box.top * 1.005) confidence += 0.1
      confidence = Math.min(confidence, 1)

      signals.push({
        type: 'breakout',
        symbol,
        price: box.breakoutPrice,
        boxTop: box.top,
        boxBottom: box.bottom,
        target: box.target,
        stopLoss: box.stopLoss,
        confidence,
        timestamp: box.breakoutTime,
        box,
      })
    }

    if (box.breakout === 'down' && box.breakoutPrice && box.breakoutTime) {
      signals.push({
        type: 'breakdown',
        symbol,
        price: box.breakoutPrice,
        boxTop: box.top,
        boxBottom: box.bottom,
        target: box.bottom - box.height,
        stopLoss: box.top,
        confidence: 0.6,
        timestamp: box.breakoutTime,
        box,
      })
    }

    // Currently forming box (no breakout yet, most recent box)
    if (!box.breakout && box === boxes[boxes.length - 1]) {
      signals.push({
        type: 'box_confirmed',
        symbol,
        price: currentCandle.close,
        boxTop: box.top,
        boxBottom: box.bottom,
        target: box.target,
        stopLoss: box.stopLoss,
        confidence: 0.4,
        timestamp: currentCandle.timestamp,
        box,
      })
    }
  }

  return signals
}

/**
 * Scan multiple symbols for Darvas setups
 */
export async function scanForDarvasSetups(
  symbols: string[],
  fetchCandles: (symbol: string) => Promise<OHLCV[]>,
  config: Partial<DarvasConfig> = {}
): Promise<{ symbol: string; boxes: DarvasBox[]; signals: DarvasSignal[] }[]> {
  const results: { symbol: string; boxes: DarvasBox[]; signals: DarvasSignal[] }[] = []

  for (const symbol of symbols) {
    try {
      const candles = await fetchCandles(symbol)
      if (candles.length < 30) continue

      const boxes = detectDarvasBoxes(candles, config)
      const signals = generateDarvasSignals(symbol, candles, boxes, config)

      if (boxes.length > 0) {
        results.push({ symbol, boxes, signals })
      }
    } catch (err) {
      console.error(`Error scanning ${symbol}:`, err)
    }
  }

  // Sort by most recent signal
  results.sort((a, b) => {
    const aTime = a.signals[a.signals.length - 1]?.timestamp ?? 0
    const bTime = b.signals[b.signals.length - 1]?.timestamp ?? 0
    return bTime - aTime
  })

  return results
}

/**
 * Timeframe label mapping
 */
export const TIMEFRAMES = [
  { value: '5m', label: '5 min', ms: 5 * 60 * 1000 },
  { value: '15m', label: '15 min', ms: 15 * 60 * 1000 },
  { value: '1h', label: '1 hour', ms: 60 * 60 * 1000 },
  { value: '4h', label: '4 hour', ms: 4 * 60 * 60 * 1000 },
  { value: '1d', label: '1 day', ms: 24 * 60 * 60 * 1000 },
] as const

export type Timeframe = typeof TIMEFRAMES[number]['value']
