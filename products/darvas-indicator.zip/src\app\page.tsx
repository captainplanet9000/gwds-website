import Link from 'next/link'

export default function Home() {
  return (
    <div
      style={{
        minHeight: '100vh',
        background: '#09090b',
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
        justifyContent: 'center',
        padding: '40px 20px',
      }}
    >
      <div style={{ maxWidth: 720, textAlign: 'center' }}>
        <div
          style={{
            fontSize: 14,
            fontWeight: 600,
            color: '#3b82f6',
            textTransform: 'uppercase',
            letterSpacing: 2,
            marginBottom: 16,
          }}
        >
          Darvas Box Indicator
        </div>

        <h1
          style={{
            fontSize: 48,
            fontWeight: 700,
            color: '#fafafa',
            lineHeight: 1.1,
            margin: '0 0 24px',
          }}
        >
          Detect breakout patterns
          <br />
          <span style={{ color: '#3b82f6' }}>before they move</span>
        </h1>

        <p
          style={{
            fontSize: 18,
            color: '#a1a1aa',
            lineHeight: 1.6,
            margin: '0 0 40px',
            maxWidth: 560,
            marginLeft: 'auto',
            marginRight: 'auto',
          }}
        >
          The Darvas Box method identifies stocks consolidating near highs. When price breaks out
          of the box with volume, you have a high-probability trade with a built-in stop loss.
        </p>

        <Link
          href="/dashboard"
          style={{
            display: 'inline-block',
            padding: '14px 32px',
            background: '#3b82f6',
            color: '#fff',
            borderRadius: 8,
            fontWeight: 600,
            fontSize: 16,
            textDecoration: 'none',
            transition: 'background 0.2s',
          }}
        >
          Open Scanner →
        </Link>

        <div
          style={{
            marginTop: 80,
            display: 'grid',
            gridTemplateColumns: 'repeat(3, 1fr)',
            gap: 24,
            textAlign: 'left',
          }}
        >
          {[
            {
              title: 'Box Detection',
              desc: 'Automatically identifies consolidation ranges after new highs. Validates box height, duration, and volume profile.',
            },
            {
              title: 'Breakout Signals',
              desc: 'Real-time alerts when price breaks above (buy) or below (sell) the box. Volume surge confirmation included.',
            },
            {
              title: 'Risk Management',
              desc: 'Every signal comes with a stop loss (box bottom) and price target (box height projection). Built-in risk/reward.',
            },
          ].map((feature, i) => (
            <div
              key={i}
              style={{
                background: '#18181b',
                border: '1px solid #27272a',
                borderRadius: 12,
                padding: 24,
              }}
            >
              <h3 style={{ color: '#fafafa', fontSize: 16, fontWeight: 600, margin: '0 0 8px' }}>
                {feature.title}
              </h3>
              <p style={{ color: '#71717a', fontSize: 14, lineHeight: 1.5, margin: 0 }}>
                {feature.desc}
              </p>
            </div>
          ))}
        </div>

        <div
          style={{
            marginTop: 80,
            background: '#18181b',
            border: '1px solid #27272a',
            borderRadius: 12,
            padding: 32,
            textAlign: 'left',
          }}
        >
          <h2 style={{ color: '#fafafa', fontSize: 20, fontWeight: 600, margin: '0 0 16px' }}>
            How the Darvas Box Works
          </h2>
          <ol
            style={{
              color: '#a1a1aa',
              fontSize: 14,
              lineHeight: 1.8,
              paddingLeft: 20,
              margin: 0,
            }}
          >
            <li>Price makes a <strong style={{ color: '#fafafa' }}>new high</strong> (highest in N periods)</li>
            <li>Price <strong style={{ color: '#fafafa' }}>consolidates</strong> — fails to exceed the high for several candles</li>
            <li>A <strong style={{ color: '#fafafa' }}>floor</strong> is established as the lowest point of consolidation</li>
            <li>The <strong style={{ color: '#3b82f6' }}>box</strong> is drawn: top = new high, bottom = floor</li>
            <li><strong style={{ color: '#10b981' }}>Breakout above</strong> the box top = buy signal with target = top + box height</li>
            <li><strong style={{ color: '#ef4444' }}>Breakdown below</strong> the box bottom = sell signal / stop loss</li>
          </ol>
        </div>
      </div>
    </div>
  )
}
