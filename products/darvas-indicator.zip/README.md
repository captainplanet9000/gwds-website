# Darvas Box Indicator

Detect Darvas Box breakout patterns on Hyperliquid perpetual futures.

## What is the Darvas Box?

The Darvas Box method was developed by Nicolas Darvas in the 1950s. He turned $10,000 into $2 million using this approach. The concept:

1. **New High** — Price reaches a new high (highest in N periods)
2. **Consolidation** — Price fails to exceed that high for several candles, establishing the box top
3. **Floor** — The lowest point during consolidation becomes the box bottom
4. **Breakout** — When price closes above the box top, that's a buy signal
5. **Breakdown** — When price closes below the box bottom, exit or short

Every trade has built-in risk management: stop loss at the box bottom, target at box top + box height.

## Quick Start

```bash
npm install
cp .env.example .env.local
npm run dev
```

Open [http://localhost:3100](http://localhost:3100)

## Features

- **Box Detection** — Automatic identification of Darvas Box formations
- **Multi-Timeframe** — 5m, 15m, 1h, 4h, 1d charts
- **Asset Scanner** — Scan all Hyperliquid assets for active Darvas setups
- **Interactive Chart** — TradingView Lightweight Charts with box overlays, breakout arrows, and target lines
- **Signal Generation** — Breakout/breakdown signals with confidence scores
- **Volume Confirmation** — Volume surge detection at breakout points

## Configuration

The detection algorithm is configurable:

| Parameter | Default | Description |
|-----------|---------|-------------|
| `highLookback` | 20 | Periods to confirm a new high |
| `topConfirmPeriods` | 3 | Candles to confirm box top is holding |
| `bottomConfirmPeriods` | 3 | Candles to confirm box bottom is holding |
| `minBoxHeightPct` | 0.5% | Minimum box height (filters noise) |
| `maxBoxHeightPct` | 15% | Maximum box height (filters outliers) |
| `volumeSurgeMultiplier` | 1.5x | Volume above average for breakout confirmation |

## API

### GET /api/scan?symbol=BTC&timeframe=1h

Returns candles, detected boxes, and signals for a single symbol.

### POST /api/scan

Scan multiple symbols:

```json
{
  "symbols": ["BTC", "ETH", "SOL"],
  "timeframe": "1h",
  "lookbackHours": 168
}
```

## Project Structure

```
src/
├── lib/
│   ├── darvas.ts          — Core Darvas Box detection algorithm
│   ├── indicators.ts      — Supporting indicators (ATR, RSI, volume)
│   └── hyperliquid.ts     — Hyperliquid API client
├── components/
│   └── DarvasChart.tsx    — Interactive chart with box overlays
└── app/
    ├── page.tsx           — Landing page
    ├── dashboard/page.tsx — Scanner dashboard
    └── api/scan/route.ts  — Scan API endpoint
```

## License

Commercial single-developer license. See LICENSE.md.
