# Commercial License — Single Developer

Copyright © 2024 Gamma Waves Design Studio

## Grant

You are granted a non-exclusive, non-transferable license to:

1. **Use** — Install and run this software for personal or commercial trading
2. **Modify** — Alter the source code for your own use
3. **Deploy** — Run the software on servers you control

## Restrictions

1. **No Redistribution** — You may not sell, sublicense, share, or redistribute the source code
2. **Single Developer** — This license covers one (1) individual developer
3. **No White-Label** — You may not rebrand and resell this as your own product
4. **No Warranty** — Software is provided "as is" — trading involves risk of financial loss

## Liability

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND. IN NO EVENT SHALL THE AUTHORS BE LIABLE FOR ANY TRADING LOSSES, DAMAGES, OR OTHER LIABILITY ARISING FROM THE USE OF THIS SOFTWARE.

**Trading cryptocurrencies carries significant risk. Past performance does not guarantee future results. Use at your own risk.**
